﻿using CatalogueLibrary;
using CatalogueLibrary.Data.DataLoad;
using CatalogueLibrary.DataFlowPipeline;
using DataLoadEngine.DataProvider;
using DataLoadEngine.Job;
using ReusableLibraryCode.Checks;
using ReusableLibraryCode.Progress;

namespace HelloWorldCaller1
{
    public class HelloWorld1Caller : IPluginDataProvider
    {
        public void LoadCompletedSoDispose(ExitCodeType exitCode, IDataLoadEventListener postLoadEventsListener)
        {

        }

        public bool DisposeImmediately { get; set; }
        public void Check(ICheckNotifier notifier)
        {
            notifier.OnCheckPerformed(new CheckEventArgs(new HelloWorld.HelloWorld().SayHello(), CheckResult.Success));
        }

        public ProcessExitCode Fetch(IDataLoadJob job, GracefulCancellationToken cancellationToken)
        {
            job.OnNotify(this, new NotifyEventArgs(ProgressEventType.Information, new HelloWorld.HelloWorld().SayHello()));
            return ProcessExitCode.Success;
        }

        public string GetDescription()
        {
            return "Calls HelloWorld v1";
        }

        public IDataProvider Clone()
        {
            return null;
        }

        public bool Validate(IHICProjectDirectory destination)
        {
            return true;
        }
    }
}

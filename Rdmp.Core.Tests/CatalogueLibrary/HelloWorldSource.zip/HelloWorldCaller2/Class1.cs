﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CatalogueLibrary;
using CatalogueLibrary.Data.DataLoad;
using CatalogueLibrary.DataFlowPipeline;
using DataLoadEngine.DataProvider;
using DataLoadEngine.Job;
using ReusableLibraryCode.Checks;
using ReusableLibraryCode.Progress;

namespace HelloWorldCaller2
{
    public class HelloWorld2Caller : IPluginDataProvider
    {
        public void LoadCompletedSoDispose(ExitCodeType exitCode, IDataLoadEventListener postLoadEventsListener)
        {
            
        }

        public bool DisposeImmediately { get; set; }
        public void Check(ICheckNotifier notifier)
        {
            notifier.OnCheckPerformed(new CheckEventArgs(new HelloWorld.HelloWorld().SayHello("Dave"),CheckResult.Success));
        }

        public ProcessExitCode Fetch(IDataLoadJob job, GracefulCancellationToken cancellationToken)
        {
            job.OnNotify(this, new NotifyEventArgs(ProgressEventType.Information,new HelloWorld.HelloWorld().SayHello("Dave")));
            return ProcessExitCode.Success;
        }

        public string GetDescription()
        {
            return "Calls HelloWorld v2";
        }

        public IDataProvider Clone()
        {
            return null;
        }

        public bool Validate(IHICProjectDirectory destination)
        {
            return true;
        }
    }
}

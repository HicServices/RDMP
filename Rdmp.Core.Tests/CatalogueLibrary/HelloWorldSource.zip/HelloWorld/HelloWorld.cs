﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld
{
    public class HelloWorld
    {
        //Version 1.0.0.0
        /*
        public string SayHello()
        {
            return "Assembly " + typeof (HelloWorld).Assembly.GetName().Version + " says 'Hello World'";
        }
        */

        //Version 2.0.0.0
        public string SayHello(string name)
        {
            return "Assembly " + typeof (HelloWorld).Assembly.GetName().Version + " says 'Hello there "+name+"'";
        }
    }
}

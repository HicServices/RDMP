// Copyright (c) The University of Dundee 2018-2019
// This file is part of the Research Data Management Platform (RDMP).
// RDMP is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
// RDMP is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
// You should have received a copy of the GNU General Public License along with RDMP. If not, see <https://www.gnu.org/licenses/>.

using System;
using CatalogueLibrary.Properties;
using ReusableLibraryCode.Comments;

namespace CatalogueLibrary.Repositories.Managers
{
    /// <summary>
    /// Subclass of <see cref="CommentStore"/> which also loads <see cref="Resources.KeywordHelp"/>
    /// </summary>
    public class CommentStoreWithKeywords : CommentStore
    {
        public override void ReadComments(params string[] directoriesToLookInForComments)
        {
            base.ReadComments(directoriesToLookInForComments);

            AddToHelp(Resources.KeywordHelp);
        }

        private void AddToHelp(string keywordHelpFileContents)
        {
            var lines = keywordHelpFileContents.Split(new[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries);

            foreach (var line in lines)
            {
                if (string.IsNullOrWhiteSpace(line))
                    continue;

                var split = line.Split(':');

                if (split.Length != 2)
                    throw new Exception("Malformed line in Resources.KeywordHelp, line is:" + Environment.NewLine + line + Environment.NewLine + "We expected it to have exactly one colon in it");

                if (!ContainsKey(split[0]))
                    Add(split[0], split[1]);
            }
        }
    }
}
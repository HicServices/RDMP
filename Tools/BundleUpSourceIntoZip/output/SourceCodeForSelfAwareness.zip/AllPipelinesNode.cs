﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CatalogueLibrary.Nodes.PipelineNodes
{
    public class AllPipelinesNode:SingletonNode
    {
        public AllPipelinesNode() : base("Pipelines")
        {

        }
    }
}

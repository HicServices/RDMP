﻿namespace CatalogueLibrary.Nodes.SharingNodes
{
    public class AllObjectSharingNode:SingletonNode
    {
        public AllObjectSharingNode() : base("Object Sharing")
        {
        }
    }
}

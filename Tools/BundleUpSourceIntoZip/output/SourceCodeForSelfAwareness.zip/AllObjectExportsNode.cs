﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CatalogueLibrary.Nodes.SharingNodes
{
    public class AllObjectExportsNode:SingletonNode
    {
        public AllObjectExportsNode() : base("All Exports")
        {
        }
    }
}

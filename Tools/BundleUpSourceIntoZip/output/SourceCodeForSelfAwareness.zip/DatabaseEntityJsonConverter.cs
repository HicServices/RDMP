using System;
using CatalogueLibrary.Data.ImportExport;
using CatalogueLibrary.Repositories;
using Newtonsoft.Json;

namespace CatalogueLibrary.Data.Serialization
{
    /// <summary>
    /// Handles Serialization of Database Entity classes.  Writing is done by by storing the ID, Type and RepositoryType where the object is stored.  Reading is done by
    /// using the IRDMPPlatformRepositoryServiceLocator to fetch the instance out of the database.  
    /// 
    /// <para>Also stores the ObjectExport SharingUID if available which will allow deserializing shared objects that might only exist in a local import form i.e. with a different ID
    /// (<see cref="ShareManager"/>)</para>
    /// </summary>
    public class DatabaseEntityJsonConverter:JsonConverter
    {
        private readonly ShareManager _shareManager;

        /// <summary>
        /// Creates a new serializer for objects stored in RDMP platform databases (only supports <see cref="DatabaseEntity"/>)
        /// 
        /// </summary>
        /// <param name="repositoryLocator"></param>
        public DatabaseEntityJsonConverter(IRDMPPlatformRepositoryServiceLocator repositoryLocator)
        {
            _shareManager = new ShareManager(repositoryLocator);
        }

        /// <summary>
        /// Serializes a <see cref="DatabaseEntity"/> by sharing it with <see cref="ShareManager.GetObjectFromPersistenceString"/>.  This
        /// creates a pointer only e.g. "Catalogue 123" and if an <see cref="ObjectExport"/> exists then also the <see cref="ObjectExport.SharingUID"/> 
        /// so that the JSON can be used in other instances (that have imported the <see cref="ShareDefinition"/> of the serialized object)
        /// </summary>
        /// <param name="writer"></param>
        /// <param name="value"></param>
        /// <param name="serializer"></param>
        public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
        {
            if (value == null)
            {
                writer.WriteNull();
                return;
            }

            writer.WriteStartObject();
            writer.WritePropertyName("PersistenceString");
            writer.WriteRawValue('"' + _shareManager.GetPersistenceString((DatabaseEntity)value) + '"');
            writer.WriteEndObject();
        }
        
        /// <summary>
        /// Deserializes a persisted <see cref="DatabaseEntity"/> by resolving it as a reference and fetching the original 
        /// object using <see cref="ShareManager.GetObjectFromPersistenceString"/>.
        /// </summary>
        /// <param name="reader"></param>
        /// <param name="objectType"></param>
        /// <param name="existingValue"></param>
        /// <param name="serializer"></param>
        /// <returns></returns>
        public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
        {
            if (reader.TokenType == JsonToken.Null) return null;
            
            if (reader.TokenType != JsonToken.StartObject) 
                throw new JsonReaderException("Malformed json");
            
            //instance to populate
            reader.Read();

            if(!reader.Value.Equals("PersistenceString"))
                throw new JsonReaderException("Malformed json, expected single property PersistenceString");

            //read the value
            reader.Read();
            var o = _shareManager.GetObjectFromPersistenceString((string) reader.Value);

            reader.Read();

            //read the end object
            if(reader.TokenType != JsonToken.EndObject)
                throw new JsonReaderException("Did not find EndObject");


            return o;
        }

        /// <summary>
        /// True if <paramref name="objectType"/> is a <see cref="DatabaseEntity"/> (the only thing this class can serialize)
        /// </summary>
        /// <param name="objectType"></param>
        /// <returns></returns>
        public override bool CanConvert(Type objectType)
        {
            return typeof(DatabaseEntity).IsAssignableFrom(objectType);
        }
    }
}

﻿namespace RDMPAutomationService.Options
{
    public enum CommandLineActivity
    {
        none,
        run,
        check
    }
}
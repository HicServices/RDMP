using System;
using System.Data.SqlClient;
using System.Linq;

namespace MapsDirectlyToDatabaseTable
{
}
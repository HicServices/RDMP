﻿namespace CatalogueLibrary.Nodes
{
    public class AllConnectionStringKeywordsNode:SingletonNode
    {
        public AllConnectionStringKeywordsNode() : base("Connection String Keywords")
        {
        }
    }
}

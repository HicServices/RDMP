using RDMPAutomationService.Options;
using RDMPAutomationService.Options.Abstracts;

namespace CatalogueManager.SimpleControls
{
    public delegate RDMPCommandLineOptions CommandGetterHandler(CommandLineActivity activityRequested);
}
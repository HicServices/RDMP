using System.Linq;
using BrightIdeasSoftware;
using CatalogueLibrary.Data;
using CatalogueLibrary.Providers;

namespace CatalogueManager.Collections.Providers.Filtering
{
    public class CatalogueCollectionFilter : IModelFilter
    {
        private readonly ICoreChildProvider _childProvider;
        private readonly bool _isInternal;
        private readonly bool _isDeprecated;
        private readonly bool _isColdStorage;
        private readonly bool _isProjectSpecific;
        private readonly bool _isNonExtractable;

        public CatalogueCollectionFilter(ICoreChildProvider childProvider, bool isInternal, bool isDeprecated, bool isColdStorage, bool isProjectSpecific, bool isNonExtractable)
        {
            _childProvider = childProvider;
            _isInternal = isInternal;
            _isDeprecated = isDeprecated;
            _isColdStorage = isColdStorage;
            _isProjectSpecific = isProjectSpecific;
            _isNonExtractable = isNonExtractable;
        }

        public bool Filter(object modelObject)
        {
            var cata = modelObject as Catalogue;
            
            //doesn't relate to us... but maybe we are descended from a Catalogue?
            if (cata == null)
            {
                var descendancy = _childProvider.GetDescendancyListIfAnyFor(modelObject);
                if (descendancy != null)
                    cata = descendancy.Parents.OfType<Catalogue>().SingleOrDefault();

                if(cata == null)
                    return true;
            }

            bool isProjectSpecific = cata.IsProjectSpecific(null); 
            bool isExtractable = cata.GetExtractabilityStatus(null) != null && cata.GetExtractabilityStatus(null).IsExtractable;
            
            return ( isExtractable && !cata.IsColdStorageDataset && !cata.IsDeprecated && !cata.IsInternalDataset && !isProjectSpecific) ||
                    ((_isColdStorage && cata.IsColdStorageDataset) ||
                    (_isDeprecated && cata.IsDeprecated) ||
                    (_isInternal && cata.IsInternalDataset) ||
                    (_isProjectSpecific && isProjectSpecific) ||
                    (_isNonExtractable && !isExtractable));
        }
    }
}
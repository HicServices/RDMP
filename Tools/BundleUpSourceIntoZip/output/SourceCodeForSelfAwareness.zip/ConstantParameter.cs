﻿using System;
using System.Text.RegularExpressions;
using CatalogueLibrary.Checks.SyntaxChecking;
using CatalogueLibrary.Data;
using CatalogueLibrary.DataHelper;
using MapsDirectlyToDatabaseTable;
using MapsDirectlyToDatabaseTable.Attributes;
using ReusableLibraryCode.Checks;
using ReusableLibraryCode.DatabaseHelpers.Discovery;
using ReusableLibraryCode.DatabaseHelpers.Discovery.QuerySyntax;

namespace CatalogueLibrary.QueryBuilding
{
    /// <summary>
    ///  Use this class to create standard parameters which you will always manually add in code to a QueryBuilder.  These are not editable
    ///  by users and are not stored in a database.  They should be used for things such as cohortDefinitionID, projectID etc.
    /// </summary>
    public class ConstantParameter : ISqlParameter
    {
        private readonly IQuerySyntaxHelper _syntaxHelper;

        /// <summary>
        /// Creates a new unchangeable always available parameter in a query being built.
        /// </summary>
        /// <param name="parameterSQL">The declaration sql e.g. DECLARE @bob as int</param>
        /// <param name="value">The value to set the paramater e.g. 1</param>
        /// <param name="comment">Some text to appear above the parameter, explaining its purpose</param>
        public ConstantParameter(string parameterSQL,string value,string comment, IQuerySyntaxHelper syntaxHelper)
        {
            _syntaxHelper = syntaxHelper;
            Value = value;
            Comment = comment;
            ParameterSQL = parameterSQL;
        }

        /// <summary>
        /// Not supported for constant parameters
        /// </summary>
        public void SaveToDatabase()
        {
            throw new NotSupportedException();
        }

        /// <inheritdoc cref="ParameterName"/>
        public override string ToString()
        {
            return ParameterName;
        }

        /// <summary>
        /// Checks the syntax of the parameter (See <see cref="ParameterSyntaxChecker"/>)
        /// </summary>
        /// <param name="notifier"></param>
        public void Check(ICheckNotifier notifier)
        {
            new ParameterSyntaxChecker(this).Check(notifier);
        }

        /// <inheritdoc/>
        public IQuerySyntaxHelper GetQuerySyntaxHelper()
        {
            return _syntaxHelper;
        }

        /// <inheritdoc/>
        public string ParameterName { get { return QuerySyntaxHelper.GetParameterNameFromDeclarationSQL(ParameterSQL); } }

        /// <inheritdoc/>
        [Sql]
        public string ParameterSQL { get; set; }

        /// <inheritdoc/>
        [Sql]
        public string Value { get; set; }

        /// <inheritdoc/>
        public string Comment { get; set; }

        /// <summary>
        /// Returns null, <see cref="ConstantParameter"/> are never owned by any objects
        /// </summary>
        /// <returns></returns>
        public IMapsDirectlyToDatabaseTable GetOwnerIfAny()
        {
            return null;
        }

        /// <summary>
        /// Attempts to parse the provided <paramref name="sql"/> text into a <see cref="ConstantParameter"/>
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="syntaxHelper"></param>
        /// <returns></returns>
        public static ConstantParameter Parse(string sql, IQuerySyntaxHelper syntaxHelper)
        {
            string[] lines = sql.Split(new[] { '\n' }, StringSplitOptions.RemoveEmptyEntries);

            string comment = null;

            Regex commentRegex = new Regex(@"/\*(.*)\*/");
            var matchComment = commentRegex.Match(lines[0]);
            if (lines.Length >= 3 && matchComment.Success)
                comment = matchComment.Groups[1].Value;

            string declaration = comment == null ? lines[0] : lines[1];
            declaration = declaration.TrimEnd(new[] { '\r' });

            string valueLine = comment == null ? lines[1] : lines[2];

            if (!valueLine.StartsWith("SET"))
                throw new Exception("Value line did not start with SET:" + sql);

            var valueLineSplit = valueLine.Split(new[] { '=' });
            var value = valueLineSplit[1].TrimEnd(new[] { ';', '\r' });
            
            return new ConstantParameter(declaration.Trim(), value.Trim(), comment, syntaxHelper);
        }
    }
}

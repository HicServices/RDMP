﻿namespace ReusableLibraryCode
{
    public enum DatabaseType
    {
        MicrosoftSQLServer,
        MYSQLServer,
        Oracle
    }
}
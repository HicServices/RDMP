// Copyright (c) The University of Dundee 2018-2019
// This file is part of the Research Data Management Platform (RDMP).
// RDMP is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
// RDMP is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
// You should have received a copy of the GNU General Public License along with RDMP. If not, see <https://www.gnu.org/licenses/>.

using System;
using System.Data;
using System.Data.SqlClient;
using CatalogueLibrary.Data;
using CohortManagerLibrary.QueryBuilding;
using FAnsi.Discovery;
using MapsDirectlyToDatabaseTable.Versioning;
using NUnit.Framework;
using QueryCaching.Aggregation;
using QueryCaching.Aggregation.Arguments;
using QueryCaching.Database;
using ReusableLibraryCode.Checks;
using Tests.Common;

namespace CohortManagerTests.QueryTests
{
    public class CohortQueryBuilderWithCacheTests : CohortIdentificationTests
    {
        private DiscoveredDatabase queryCacheDatabase;
        private ExternalDatabaseServer externalDatabaseServer;
        private DatabaseColumnRequest _chiColumnSpecification = new DatabaseColumnRequest("chi","varchar(10)");
        
        [OneTimeSetUp]
        public void SetUpCache()
        {
            queryCacheDatabase = DiscoveredServerICanCreateRandomDatabasesAndTablesOn.ExpectDatabase(TestDatabaseNames.Prefix + "QueryCache");

            MasterDatabaseScriptExecutor executor = new MasterDatabaseScriptExecutor(queryCacheDatabase);

            Console.WriteLine("QueryCachingDatabaseIs" + typeof (Class1).Assembly.FullName);

            executor.CreateAndPatchDatabase(typeof(CachedAggregateConfigurationResultsManager).Assembly,new ThrowImmediatelyCheckNotifier());
            
            externalDatabaseServer = new ExternalDatabaseServer(CatalogueRepository, "QueryCacheForUnitTests");
            externalDatabaseServer.SetProperties(queryCacheDatabase);
        }

        [OneTimeTearDown]
        public void DropDatabases()
        {
            queryCacheDatabase.Drop();
            externalDatabaseServer.DeleteInDatabase();
        }

        [Test]
        public void TestGettingAggregateJustFromConfig_DistinctCHISelect()
        {

            CachedAggregateConfigurationResultsManager manager = new CachedAggregateConfigurationResultsManager( externalDatabaseServer);
            
            cohortIdentificationConfiguration.QueryCachingServer_ID = externalDatabaseServer.ID;
            cohortIdentificationConfiguration.SaveToDatabase();
            

            CohortQueryBuilder builder = new CohortQueryBuilder(cohortIdentificationConfiguration);
            cohortIdentificationConfiguration.CreateRootContainerIfNotExists();
            cohortIdentificationConfiguration.RootCohortAggregateContainer.AddChild(aggregate1,0);
            try
            {
                Assert.AreEqual(
CollapseWhitespace(
string.Format(
@"
(
	/*cic_{0}_UnitTestAggregate1*/
	SELECT
	distinct
	[" + TestDatabaseNames.Prefix+@"ScratchArea]..[BulkData].[chi]
	FROM 
	["+TestDatabaseNames.Prefix+@"ScratchArea]..[BulkData]
)
",cohortIdentificationConfiguration.ID)), 
 CollapseWhitespace(builder.SQL));

                var server = queryCacheDatabase.Server;
                using(var con = server.GetConnection())
                {
                    con.Open();

                    var da = server.GetDataAdapter(builder.SQL, con);
                    var dt = new DataTable();
                    da.Fill(dt);

                    manager.CommitResults(new CacheCommitIdentifierList(aggregate1,
                        string.Format(@"/*cic_{0}_UnitTestAggregate1*/
SELECT
distinct
[" +TestDatabaseNames.Prefix+@"ScratchArea]..[BulkData].[chi]
FROM 
[" + TestDatabaseNames.Prefix + @"ScratchArea]..[BulkData]", cohortIdentificationConfiguration.ID), dt, _chiColumnSpecification, 30));
                }


                CohortQueryBuilder builderCached = new CohortQueryBuilder(cohortIdentificationConfiguration);

                Assert.AreEqual(
                    CollapseWhitespace(
                    string.Format(
@"
(
	/*Cached:cic_{0}_UnitTestAggregate1*/
	select * from [" + queryCacheDatabase.GetRuntimeName() + "]..[IndexedExtractionIdentifierList_AggregateConfiguration" + aggregate1.ID + @"]

)
",cohortIdentificationConfiguration.ID)),
 CollapseWhitespace(builderCached.SQL));

            }
            finally
            {
                cohortIdentificationConfiguration.RootCohortAggregateContainer.RemoveChild(aggregate1);
                
            }

        }
    }
}
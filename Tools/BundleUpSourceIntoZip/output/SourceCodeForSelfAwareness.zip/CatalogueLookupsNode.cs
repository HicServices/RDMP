// Copyright (c) The University of Dundee 2018-2019
// This file is part of the Research Data Management Platform (RDMP).
// RDMP is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
// RDMP is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
// You should have received a copy of the GNU General Public License along with RDMP. If not, see <https://www.gnu.org/licenses/>.

using CatalogueLibrary.Data;

namespace CatalogueLibrary.Nodes
{
    public class CatalogueLookupsNode
    {
        public Catalogue Catalogue { get; set; }
        public Lookup[] Lookups { get; set; }

        public CatalogueLookupsNode(Catalogue catalogue, Lookup[] lookups)
        {
            Catalogue = catalogue;
            Lookups = lookups;
        }

        public override string ToString()
        {
            return "Lookups";
        }

        protected bool Equals(CatalogueLookupsNode other)
        {
            return Equals(Catalogue, other.Catalogue);
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;
            if (obj.GetType() != typeof(CatalogueLookupsNode)) return false;
            return Equals((CatalogueLookupsNode)obj);
        }

        public override int GetHashCode()
        {
            return (Catalogue != null ? Catalogue.GetHashCode() : 0);
        }
    }
}
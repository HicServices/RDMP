﻿namespace CatalogueLibrary.Nodes
{
    public class AllStandardRegexesNode:SingletonNode
    {
        public AllStandardRegexesNode() : base("Standard Regexes")
        {
        }
    }
}

// Copyright (c) The University of Dundee 2018-2019
// This file is part of the Research Data Management Platform (RDMP).
// RDMP is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
// RDMP is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
// You should have received a copy of the GNU General Public License along with RDMP. If not, see <https://www.gnu.org/licenses/>.

using System;
using System.Collections.Generic;
using System.Windows.Forms;
using BrightIdeasSoftware;
using CatalogueLibrary.CommandExecution.AtomicCommands;
using CatalogueManager.Collections;
using CatalogueManager.ItemActivation;
using CatalogueManager.Menus;
using CatalogueManager.Menus.MenuItems;
using ReusableLibraryCode.CommandExecution.AtomicCommands;
using ReusableLibraryCode.Icons.IconProvision;

namespace CatalogueManager.CommandExecution.AtomicCommands.UIFactory
{
    public class AtomicCommandUIFactory
    {
        private readonly IActivateItems _activator;
        private readonly IIconProvider _iconProvider;

        public AtomicCommandUIFactory(IActivateItems activator)
        {
            _activator = activator;
            _iconProvider = activator.CoreIconProvider;
        }

        public ToolStripMenuItem CreateMenuItem(IAtomicCommand command)
        {
            return new AtomicCommandMenuItem(command, _activator);
        }

        public AtomicCommandLinkLabel CreateLinkLabel(IAtomicCommand command)
        {
            return new AtomicCommandLinkLabel(_iconProvider,command);
        }

        public AtomicCommandWithTargetUI<T> CreateLinkLabelWithSelection<T>(IAtomicCommandWithTarget command, IEnumerable<T> selection, Func<T, string> propertySelector)
        {
            return new AtomicCommandWithTargetUI<T>(_iconProvider, command, selection, propertySelector);
        }

        public RDMPContextMenuStrip CreateMenu(IActivateItems activator,TreeListView tree, RDMPCollection collection, params IAtomicCommand[] commands)
        {
            var toReturn = new RDMPContextMenuStrip(new RDMPContextMenuStripArgs(activator,tree,collection),collection);
            
            foreach (IAtomicCommand command in commands)
                toReturn.Items.Add(CreateMenuItem(command));

            return toReturn;
        }

        public ToolStripItem CreateToolStripItem(IAtomicCommand command)
        {
            return new AtomicCommandToolStripItem(command, _activator);
        }
    }

}

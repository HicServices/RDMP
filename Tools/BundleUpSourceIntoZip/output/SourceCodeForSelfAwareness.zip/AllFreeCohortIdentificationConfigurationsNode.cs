﻿namespace CatalogueLibrary.Nodes.CohortNodes
{
    public class AllFreeCohortIdentificationConfigurationsNode : SingletonNode
    {
        public AllFreeCohortIdentificationConfigurationsNode()
            : base("Free Configurations")
        {

        }
    }
}
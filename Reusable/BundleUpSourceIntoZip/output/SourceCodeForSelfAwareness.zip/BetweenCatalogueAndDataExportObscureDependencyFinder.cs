using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Linq;
using CatalogueLibrary.Data;
using DataExportManager2Library.Data.DataTables;
using DataExportManager2Library.Repositories;
using MapsDirectlyToDatabaseTable;

namespace DataExportManager2Library
{
    public class BetweenCatalogueAndDataExportObscureDependencyFinder : IObscureDependencyFinder
    {
        private readonly IDataExportRepositoryServiceLocator _serviceLocator;

        public BetweenCatalogueAndDataExportObscureDependencyFinder(IDataExportRepositoryServiceLocator serviceLocator)
        {
            _serviceLocator = serviceLocator;
        }

        public void ThrowIfDeleteDisallowed(IMapsDirectlyToDatabaseTable oTableWrapperObject)
        {
            var cata = oTableWrapperObject as Catalogue;

            //if there isn't a data export database then we don't care, delete away
            if (_serviceLocator.DataExportRepository == null)
                return;

            //they are trying to delete something that isn't a Catalogue thats fine too
            if (cata == null) return;
            
            //they are deleting a catalogue! see if it has an ExtractableDataSet associated with it
            var dependencies = _serviceLocator.DataExportRepository.GetAllObjects<ExtractableDataSet>("WHERE Catalogue_ID = " + cata.ID).ToArray();
            if(dependencies.Any())
                throw new Exception("Cannot delete Catalogue " + cata + " because there are ExtractableDataSets which depend on them (IDs=" +string.Join(",",dependencies.Select(ds=>ds.ID.ToString())) +")");
        }

        public void HandleCascadeDeletesForDeletedObject(IMapsDirectlyToDatabaseTable oTableWrapperObject)
        {
            
        }
    }
}

using ReusableUIComponents; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved

namespace CatalogueManager.DataLoadUIs.ANOUIs
{
    partial class ConfigureANOForTableInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbColumnInfos = new BetterListBox();
            this.btnAddANOTableToDiagram = new System.Windows.Forms.Button();
            this.btnCreateNewANOTable = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.checksUI1 = new ReusableUIComponents.ChecksUI.ChecksUI();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.btnCheckANOConfigurations = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbColumnInfos
            // 
            this.lbColumnInfos.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.lbColumnInfos.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.lbColumnInfos.FormattingEnabled = true;
            this.lbColumnInfos.Location = new System.Drawing.Point(19, 4);
            this.lbColumnInfos.Name = "lbColumnInfos";
            this.lbColumnInfos.Size = new System.Drawing.Size(401, 511);
            this.lbColumnInfos.TabIndex = 0;
            this.lbColumnInfos.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.lbColumnInfos_DrawItem);
            this.lbColumnInfos.MouseDown += new System.Windows.Forms.MouseEventHandler(this.lbColumnInfos_MouseDown);
            this.lbColumnInfos.MouseUp += new System.Windows.Forms.MouseEventHandler(this.lbColumnInfos_MouseUp);
            // 
            // btnAddANOTableToDiagram
            // 
            this.btnAddANOTableToDiagram.Location = new System.Drawing.Point(426, 4);
            this.btnAddANOTableToDiagram.Name = "btnAddANOTableToDiagram";
            this.btnAddANOTableToDiagram.Size = new System.Drawing.Size(122, 43);
            this.btnAddANOTableToDiagram.TabIndex = 1;
            this.btnAddANOTableToDiagram.Text = "Add ANOTable to Work Area";
            this.btnAddANOTableToDiagram.UseVisualStyleBackColor = true;
            this.btnAddANOTableToDiagram.Click += new System.EventHandler(this.btnAddANOTableToDiagram_Click);
            // 
            // btnCreateNewANOTable
            // 
            this.btnCreateNewANOTable.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCreateNewANOTable.Location = new System.Drawing.Point(1118, 511);
            this.btnCreateNewANOTable.Name = "btnCreateNewANOTable";
            this.btnCreateNewANOTable.Size = new System.Drawing.Size(135, 23);
            this.btnCreateNewANOTable.TabIndex = 1;
            this.btnCreateNewANOTable.Text = "Manage ANOTables";
            this.btnCreateNewANOTable.UseVisualStyleBackColor = true;
            this.btnCreateNewANOTable.Click += new System.EventHandler(this.btnManageANOTables_Click);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 521);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(264, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Instructions: Right Click column to add new ANOTable";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(426, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Work Area:";
            // 
            // checksUI1
            // 
            this.checksUI1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checksUI1.Location = new System.Drawing.Point(0, 0);
            this.checksUI1.Name = "checksUI1";
            this.checksUI1.Size = new System.Drawing.Size(1256, 248);
            this.checksUI1.TabIndex = 3;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.lbColumnInfos);
            this.splitContainer1.Panel1.Controls.Add(this.btnCreateNewANOTable);
            this.splitContainer1.Panel1.Controls.Add(this.label2);
            this.splitContainer1.Panel1.Controls.Add(this.label1);
            this.splitContainer1.Panel1.Controls.Add(this.btnAddANOTableToDiagram);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.btnCheckANOConfigurations);
            this.splitContainer1.Panel2.Controls.Add(this.checksUI1);
            this.splitContainer1.Size = new System.Drawing.Size(1256, 794);
            this.splitContainer1.SplitterDistance = 542;
            this.splitContainer1.TabIndex = 4;
            // 
            // btnCheckANOConfigurations
            // 
            this.btnCheckANOConfigurations.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCheckANOConfigurations.Location = new System.Drawing.Point(1103, 222);
            this.btnCheckANOConfigurations.Name = "btnCheckANOConfigurations";
            this.btnCheckANOConfigurations.Size = new System.Drawing.Size(150, 23);
            this.btnCheckANOConfigurations.TabIndex = 4;
            this.btnCheckANOConfigurations.Text = "Check ANOConfigurations";
            this.btnCheckANOConfigurations.UseVisualStyleBackColor = true;
            this.btnCheckANOConfigurations.Click += new System.EventHandler(this.btnCheckANOConfigurations_Click);
            // 
            // ConfigureANOForTableInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1256, 794);
            this.Controls.Add(this.splitContainer1);
            this.KeyPreview = true;
            this.Name = "ConfigureANOForTableInfo";
            this.Text = "ConfigureANOForTableInfo";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.ConfigureANOForTableInfo_KeyUp);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private BetterListBox lbColumnInfos;
        private System.Windows.Forms.Button btnAddANOTableToDiagram;
        private System.Windows.Forms.Button btnCreateNewANOTable;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private ReusableUIComponents.ChecksUI.ChecksUI checksUI1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Button btnCheckANOConfigurations;
    }
}

using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using CatalogueLibrary;
using CatalogueLibrary.Cloning;
using CatalogueLibrary.Data;
using CatalogueLibrary.Data.DataLoad;
using CatalogueLibrary.Repositories;
using DataLoadEngineTests.Properties;
using MapsDirectlyToDatabaseTable;
using NUnit.Framework;
using ReusableLibraryCode;
using Tests.Common;

namespace DataLoadEngineTests.Integration
{
    public class BiochemistryEndToEndTest : DatabaseTests
    {
        private const string _liveServer = "CONSUS";
        private readonly string _testDatabaseServer = Settings.Default.TestCatalogueConnectionString;
        
        private Dictionary<DateTime,int>GetTestDatesWithExpectedRecordCount()
        {
            var dictionary = new Dictionary<DateTime, int>();

            dictionary.Add(new DateTime(1990,2,1),5126 ); 
            dictionary.Add(new DateTime(1994,11,8),121 );
            dictionary.Add(new DateTime(2001,3,2),3954 );
            dictionary.Add(new DateTime(2002,3,9),1046 );
            dictionary.Add(new DateTime(2003,12,31),1186 );
            dictionary.Add(new DateTime(2007,1,1),381 );
            dictionary.Add(new DateTime(2009,11,22),817 );
            dictionary.Add(new DateTime(2012,7,12),4278 );
            dictionary.Add(new DateTime(2014,4,21),558 );

            return dictionary;
        }

        private string AdjustWhereString(string where, DateTime target)
        {
            return where.Replace("YY", target.Year.ToString())
                .Replace("MM", target.Month.ToString())
                .Replace("DD", target.Day.ToString());
        }

        [Test]
        [Ignore("This drops Biochemistry on the test server, be careful about running it")]
        public void EndToEndTest9DaysBetween1990And2014()
        {
            /* 
             * Copy the following from CONUS
             * Year	Month	Day	BC Cases
1990	2	1	5126
1994	11	8	121
2001	3	2	3954
2002	3	9	1046
2003	12	31	1186
2007	1	1	381
2009	11	22	817
2012	7	12	4278
2014	4	21	558
*/
            //set Catalogue to readonly mode
            
            Catalogue bc = CatalogueRepository.GetAllCatalogues().Single(c => c.Name.ToLower().Equals("biochemistry"));
            
            //confirm biochemistry has load metadata
            Assert.IsNotNull(bc.LoadMetadata);

            TableInfo[] tableInfoList = bc.GetTableInfoList(false);
            string database = bc.GetDatabaseName();
            string server = bc.GetServerFromExtractionInformation(ExtractionCategory.Core);

            Assert.AreNotEqual(server, _testDatabaseServer);
            Assert.AreEqual(server, _liveServer);

            //confirm we are talking about bc_header and bc_result
            Assert.True(tableInfoList.Any(t=>t.GetRuntimeName().ToLower().Equals("bc_header")));
            Assert.True(tableInfoList.Any(t => t.GetRuntimeName().ToLower().Equals("bc_results")));
            
            //target
            SqlConnectionStringBuilder destination = new SqlConnectionStringBuilder();
            destination.DataSource = _testDatabaseServer;
            destination.InitialCatalog = "TestDataCatalogue";
            destination.IntegratedSecurity = true;
            var destinationRepository = new CatalogueRepository(destination);

            //cloner clone catalogue
            CatalogueCloner cloner = new CatalogueCloner(CatalogueRepository, destinationRepository);
            cloner.CloneIntoNewDatabase(bc, CatalogueCloner.CloneDepth.FullTree, null, true);

            bool createdTestData = false;
            try
            {
                //point to target test data catalogue
                var clonedCatalogue = destinationRepository.GetAllObjects<Catalogue>().Single();

                //confirm clone biochemistry has load metadata
                Assert.IsNotNull(clonedCatalogue.LoadMetadata);

                createdTestData = true;
                
                CopyDataOutOfLive(server, database, _testDatabaseServer, database, bc);
             
                RunDataLoad(bc);
                CheckDataOutOfLiveIsSame();
            }
            finally
            {
                //MAKE SURE WE ARENT CHANGING LIVE!
                Assert.IsTrue(destinationRepository.ConnectionString.Contains("Test"));

                var clonedCatalogue = destinationRepository.GetAllObjects<Catalogue>().Single();
                var lmd = clonedCatalogue.LoadMetadata;

                cloner.FullTreeDelete(clonedCatalogue);//delete the catalogue
                lmd.DeleteInDatabase(); //delete the load metadata (has to come after deleting catalogue for referential integrity)


                try
                {
                    if (createdTestData)
                        CleanupDataCopiedFromLive(_testDatabaseServer, database);
                }
                catch (Exception ex)
                {
                    
                    Console.WriteLine("Could not cleanup data copied from live by droping database:" + ex.Message);
                }
            }

            //create

        }

   
        private void CopyDataOutOfLive(string sourceServer, string sourceDatabase, string destinationServer, string destinationDatabase, Catalogue c)
        {
            /*
            SqlConnectionStringBuilder destination = new SqlConnectionStringBuilder() { DataSource = destinationServer, InitialCatalog = destinationDatabase, IntegratedSecurity = true, Pooling = false };
            SqlConnectionStringBuilder source = new SqlConnectionStringBuilder(){DataSource = sourceServer,InitialCatalog = sourceDatabase,IntegratedSecurity = true};
            
            SqlConnection conSource = new SqlConnection(source.ConnectionString);
            conSource.Open();

            //create required tables
            //clone options
            var options = new ScriptingOptions
            {
                ScriptData = false,
                IncludeDatabaseContext = false,
                Triggers = true
            };


            DatabaseOperations.CloneDatabaseSchema(new DiscoveredDatabase(sourceServer, sourceDatabase), new DiscoveredDatabase(destinationServer, destinationDatabase), null, false, false,options);

            foreach (KeyValuePair<DateTime, int> keyValuePair in GetTestDatesWithExpectedRecordCount())
            {
                string baseQuery = " BC_header WHERE " +
                                   AdjustWhereString(_where, keyValuePair.Key);

                MigrateQuery("BC_header","Select top 10000 * from" + baseQuery, keyValuePair.Value,conSource,destination);

                MigrateQuery("BC_results",
                    "Select top 50000 * from BC_results WHERE Lab_number in (SELECT Lab_number from " + baseQuery + ")",
                    -1, conSource, destination);


            }
            conSource.Close();*/
        }

        private void MigrateQuery(string tableName,string sql, int expectedRowsRead,SqlConnection conSource, SqlConnectionStringBuilder destination)
        {
            SqlCommand cmd = new SqlCommand(sql, conSource);
            cmd.CommandTimeout = 500;

            DataTable theData = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(theData);

            if (expectedRowsRead != -1)
            Assert.AreEqual(theData.Rows.Count, expectedRowsRead);

            //copy to destination
            SqlBulkCopy cpy = new SqlBulkCopy(destination.ConnectionString);
            cpy.DestinationTableName = tableName;
            cpy.BulkCopyTimeout = 500;

            // This looks daft, but SqlBulkCopy uses ordinal positions, not names, for mapping
            foreach (DataColumn column in theData.Columns)
                cpy.ColumnMappings.Add(new SqlBulkCopyColumnMapping(column.ColumnName, column.ColumnName));


            cpy.WriteToServer(theData);
            cpy.Close();
        }

        private void CleanupDataCopiedFromLive(string destinationServer, string destinationDatabase)
        {
            SqlConnectionStringBuilder destination = new SqlConnectionStringBuilder() { DataSource = destinationServer, IntegratedSecurity = true, Pooling = false };

            Assert.IsFalse(destinationServer.ToUpper().Contains(_liveServer),"About to drop live server!");

            SqlConnection conDestination = new SqlConnection(destination.ConnectionString);
            conDestination.Open();
            SqlCommand cmdCreateDatabase = new SqlCommand(@"
ALTER DATABASE "+destinationDatabase+@" 
SET multi_user WITH ROLLBACK IMMEDIATE;

DROP Database " + destinationDatabase, conDestination);
            cmdCreateDatabase.ExecuteNonQuery();
            conDestination.Close();
        }


        private void RunDataLoad(Catalogue bc)
        {
            throw new NotImplementedException();
        }

        private void CheckDataOutOfLiveIsSame()
        {
            throw new NotImplementedException();
        }
    }
}

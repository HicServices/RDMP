using CatalogueLibrary.Repositories; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved

namespace CatalogueLibrary.Data.Cache
{
    public class CacheRebuilderFactory
    {
        private readonly CatalogueRepository _repository;

        public CacheRebuilderFactory(CatalogueRepository repository)
        {
            _repository = repository;
        }

        public ICacheRebuilder Create(string typeName)
        {
            return _repository.MEF.FactoryCreateA<ICacheRebuilder>(typeName);
        }

    }
}

using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Data.SqlClient;
using System.Diagnostics;
using System.Diagnostics.Contracts;
using System.IO;
using System.Text.RegularExpressions;
using CatalogueLibrary.Data;
using CatalogueLibrary.Repositories;
using DataExportManager2.Interfaces.Repositories;
using DataExportManager2Library.Repositories;
using DataQualityEngine.Data;
using HIC.Logging;
using MySql.Data.MySqlClient;
using NUnit.Framework;
using Oracle.ManagedDataAccess.Client;
using RDMPStartup;
using RDMPStartup.Events;
using ReusableLibraryCode;
using ReusableLibraryCode.Checks;
using ReusableLibraryCode.DatabaseHelpers.Discovery;
using Rhino.Mocks;

namespace Tests.Common
{
    public static class TestDatabaseNames
    {
        private const string Prefix = "RDMP_Tests_";

        public static string GetConsistentName(string databaseName)
        {
            return Prefix + databaseName;
        }
    }

    public enum CarePolice
    {
        IDontCareAboutAnythingOrAnyone,
        IWantMyTier1DatabasesToExist,
        IWantMyTier1DatabasesToBeHealthyToo,
        IWantAllDatabasesToBeHealthy,
        IWantAllMyPluginsToBeHealthyToo
    }

    
     
    [Category("Database")]
    public class DatabaseTests
    {
        protected readonly IRDMPPlatformRepositoryServiceLocator RepositoryLocator;

        public CatalogueRepository CatalogueRepository
        {
            get { return RepositoryLocator.CatalogueRepository; }
        }
        
        public DataExportRepository DataExportRepository 
        {
            get { return RepositoryLocator.DataExportRepository; }
        }
        
        protected SqlConnectionStringBuilder UnitTestLoggingConnectionString;
        protected string DataQualityEngineConnectionString;

        private const string _registryRoot = @"HKEY_CURRENT_USER\Software\HICDataManagementPlatform";
 
        private static string contentsOfAppConfig = null;

        protected SqlConnectionStringBuilder ServerICanCreateRandomDatabasesAndTablesOn;
        protected SqlConnectionStringBuilder DatabaseICanCreateRandomTablesIn;

        protected DiscoveredDatabase DiscoveredDatabaseICanCreateRandomTablesIn;
        protected DiscoveredServer DiscoveredServerICanCreateRandomDatabasesAndTablesOn;

        protected OracleConnectionStringBuilder OracleServer;
        protected MySqlConnectionStringBuilder MySQlServer;

        private Exception _fixtureSetupException;

        protected static int DatabaseCreationCount = 0;
        protected static Stopwatch DbExecutionTime = new Stopwatch();
        

        static private Startup _startup;

        protected CarePolice HowMuchDoICare = CarePolice.IWantMyTier1DatabasesToExist;
        private CarePolice HowMuchDidICareLastTime = CarePolice.IWantMyTier1DatabasesToExist;

        public DatabaseTests()
        {
            RepositoryLocator = new ConfigFileRepositoryFinder(".\\Tests.Common.dll.config");

            Console.WriteLine(typeof (DataQualityEngine.Class1).Name);
            Console.WriteLine(typeof(HIC.Logging.Class1).Name);
        }

        [ContractInvariantMethod]
        private void ObjectInvariant()
        {
            Contract.Invariant(RepositoryLocator != null);
        }

        [TestFixtureSetUp]
        protected virtual void SetUp()
        {
            //if it is the first time or client has changed how much he cares about stuff
            if (_startup == null || HowMuchDidICareLastTime != HowMuchDoICare)
            {
                _startup = new Startup(RepositoryLocator);

                _startup.DatabaseFound += StartupOnDatabaseFound;
                _startup.MEFFileDownloaded += StartupOnMEFFileDownloaded;
                _startup.PluginPatcherFound += StartupOnPluginPatcherFound;
                _startup.DoStartup(new IgnoreAllErrorsCheckNotifier());
            }

            RepositoryLocator.CatalogueRepository.MEF.Setup(_startup.MEFSafeDirectoryCatalog);
            
            try
            {
                //clear the registry for the user because we dont want the unit tests being repointed at a live system if the user is runing both simultaneously (unit tests and production software)
                new RegistryRepositoryFinder().ClearSettings();
                
                SetUpConnectionConfiguration();
                CreateScratchArea();
            }
            catch (Exception e)
            {
                _fixtureSetupException = e;
            }
        }



        private void StartupOnDatabaseFound(object sender, PlatformDatabaseFoundEventArgs args)
        { 
            //its a healthy message, jolly good
            if (args.Status == RDMPPlatformDatabaseStatus.Healthy)
                return;

            if(HowMuchDoICare == CarePolice.IDontCareAboutAnythingOrAnyone)
                return;

            //user only cares about tier 1 databases
            if (HowMuchDoICare <= CarePolice.IWantMyTier1DatabasesToBeHealthyToo)
            {
                //and this isn't a tier 1 message
                if (args.Tier != 1)
                    return;
            }

            //its a tier appropriate fatal error message
            if (args.Status == RDMPPlatformDatabaseStatus.Broken || args.Status == RDMPPlatformDatabaseStatus.Unreachable)
                Assert.Fail(args.SummariseAsString());

            //its slightly dodgy about it's version numbers
            if (args.Status == RDMPPlatformDatabaseStatus.RequiresPatching && HowMuchDoICare >= CarePolice.IWantMyTier1DatabasesToBeHealthyToo)
                Assert.Fail(args.SummariseAsString());

        }
        private void StartupOnPluginPatcherFound(object sender, PluginPatcherFoundEventArgs args)
        {
            if (HowMuchDoICare == CarePolice.IWantAllMyPluginsToBeHealthyToo)
                Assert.IsTrue(args.Status == PluginPatcherStatus.Healthy, "PluginPatcherStatus is " + args.Status + " for plugin " + args.Type.Name + Environment.NewLine + (args.Exception == null ? "No exception" : ExceptionHelper.ExceptionToListOfInnerMessages(args.Exception)));
        }

        private void StartupOnMEFFileDownloaded(object sender, MEFFileDownloadProgressEventArgs args)
        {
            if (HowMuchDoICare == CarePolice.IWantAllMyPluginsToBeHealthyToo)
                Assert.IsFalse(args.Status == MEFFileDownloadEventStatus.OtherError, "MEFFileDownloadEventStatus is " + args.Status + " for plugin " + args.FileBeingProcessed + Environment.NewLine + (args.Exception == null ? "No exception" : ExceptionHelper.ExceptionToListOfInnerMessages(args.Exception)));
        }

        [SetUp]
        protected void CheckForTestFixtureSetupFailure()
        {
            if (_fixtureSetupException == null)
                return;

            var msg = ExceptionHelper.ExceptionToListOfInnerMessages(_fixtureSetupException, true);
            Assert.Fail(msg);
        }

        [TestFixtureTearDown]
        protected virtual void FixtureTearDown()
        {
            DbExecutionTime.Start();

            // todo: don't need to do this unwiring/rewiring on each test fixture any more since we're not dropping/creating the DQE database?
            ClearDefaultDQE();
            DeleteExternalDatabaseRemnants(new SqlConnectionStringBuilder(DataQualityEngineConnectionString).InitialCatalog);
            //var dropOperation = new DropDatabaseOperation(ServerICanCreateRandomDatabasesAndTablesOn.ConnectionString, DQEDatabaseName);
            //dropOperation.Execute();
            DbExecutionTime.Stop();
            Console.WriteLine("Total number db creations so far: " + DatabaseCreationCount);
            Console.WriteLine("Total time spent creating/dropping databases: " + DbExecutionTime.Elapsed.ToString("g"));
        }

        protected void SetupDQEReportingDatabase()
        {
            DbExecutionTime.Start();

            var defaults = ClearDefaultDQE();

            //delete any remnants (the pointer to the database)
            var builder = new SqlConnectionStringBuilder(DataQualityEngineConnectionString);

            if (string.IsNullOrWhiteSpace(builder.InitialCatalog))
                throw new InvalidOperationException("The DataQualityEngine connection string does not contain a database name: " + DataQualityEngineConnectionString);

            DeleteExternalDatabaseRemnants(builder.InitialCatalog);

            //create a new pointer
            var dqeExternalDatabaseServer = new ExternalDatabaseServer(CatalogueRepository, "DQE")
            {
                Server = builder.DataSource,
                Database = builder.InitialCatalog,
                Password = builder.Password,
                Username = builder.UserID
            };

            dqeExternalDatabaseServer.SaveToDatabase();

            //now make it the default DQE
            defaults.SetDefault(ServerDefaults.PermissableDefaults.DQE, dqeExternalDatabaseServer);
            DbExecutionTime.Stop();
        }

        private void DeleteExternalDatabaseRemnants(string databaseName)
        {
            foreach (var remnant in CatalogueRepository.GetAllObjects<ExternalDatabaseServer>("WHERE Name = '" + databaseName + "'"))
                remnant.DeleteInDatabase();
        }

        private ServerDefaults ClearDefaultDQE()
        {
            //clear the default DQE
            ServerDefaults defaults = new ServerDefaults(CatalogueRepository);
            defaults.ClearDefault(ServerDefaults.PermissableDefaults.DQE);
            return defaults;
        }

        private void CreateScratchArea()
        {
            DatabaseCreationCount++;
            DbExecutionTime.Start();
            
            var scratchDatabaseName = TestDatabaseNames.GetConsistentName("ScratchArea");
            DatabaseICanCreateRandomTablesIn = new SqlConnectionStringBuilder(ServerICanCreateRandomDatabasesAndTablesOn.ConnectionString)
            {
                InitialCatalog = scratchDatabaseName
            };


            using(SqlConnection con = new SqlConnection(ServerICanCreateRandomDatabasesAndTablesOn.ConnectionString))
            {
                con.Open();

                SqlCommand cmd = new SqlCommand(@"IF EXISTS(select * from sys.databases where name='" + scratchDatabaseName + @"')
begin
ALTER DATABASE " + scratchDatabaseName + @" SET SINGLE_USER WITH ROLLBACK IMMEDIATE
DROP DATABASE " + scratchDatabaseName + @" 
end

CREATE DATABASE " + scratchDatabaseName, con);

                cmd.ExecuteNonQuery();
                con.Close();
            }

            DbExecutionTime.Stop();

            DiscoveredDatabaseICanCreateRandomTablesIn = new DiscoveredServer(DatabaseICanCreateRandomTablesIn).ExpectDatabase(DatabaseICanCreateRandomTablesIn.InitialCatalog);
        }

        public void SetUpConnectionConfiguration()
        {
            //Oracle
            string oracleServer = null;
            try
            {
                oracleServer = GetValueFromAppConfigSuperAwesome("OracleServer");
            }
            catch (Exception e)
            {
                Console.WriteLine("=I= Oracle connection string not found so not bothering to set it");
                //Console.WriteLine(e);
            }

            if(!string.IsNullOrWhiteSpace(oracleServer))
                OracleServer = new OracleConnectionStringBuilder(oracleServer);

            //MySQL
            string mysqlServer = null;
            try
            {
                mysqlServer = GetValueFromAppConfigSuperAwesome("MySQLServer");
            }
            catch (Exception)
            {
                Console.WriteLine("=I= MySQL connection string not found so not bothering to set it");
                //Console.WriteLine(e);
            }

            if(!string.IsNullOrWhiteSpace(mysqlServer))
                MySQlServer = new MySqlConnectionStringBuilder(mysqlServer);
            
            //Other databases
            var configValue = GetValueFromAppConfigSuperAwesome("ServerICanCreateRandomDatabasesAndTablesOnConnectionString");
            try
            {
                ServerICanCreateRandomDatabasesAndTablesOn = new SqlConnectionStringBuilder(configValue);
                DiscoveredServerICanCreateRandomDatabasesAndTablesOn = new DiscoveredServer(ServerICanCreateRandomDatabasesAndTablesOn);
            }
            catch (Exception e)
            {
                throw new Exception("Couldn't create the SqlConnectionStringBuilder for 'ServerICanCreateRandomDatabasesAndTablesOn'. Possible dodgy config value: " + configValue, e);
            }

            if (ShouldSetUpConnections)
                SetUpConnections();
        }

        protected bool ShouldSetUpConnections = true;

        private void SetUpConnections()
        {
            //DatabaseSettings are not valid for these, DatabaseSettings tells you where to find the master databases i.e. DataCatalogue tells you where to find everything else via it's ExternalDatabaseServer table
            UnitTestLoggingConnectionString =
                new SqlConnectionStringBuilder(GetValueFromAppConfigSuperAwesome("UnitTestLoggingConnectionString"));
            // todo: get rid of this hardcoded policy stuff (into external configuration)
            if (UnitTestLoggingConnectionString.DataSource == "EOS")
                throw new Exception("Don't point tests at EOS");

            // Add DQE database details into catalogue as an ExternalDatabaseServer
            DataQualityEngineConnectionString = GetValueFromAppConfigSuperAwesome("DataQualityEngineConnectionString");
            SetupDQEReportingDatabase();

            //run logging checks
            LoggingDatabaseChecker loggingChecker =
                new LoggingDatabaseChecker(new DiscoveredServer(UnitTestLoggingConnectionString));
            loggingChecker.Check(new AcceptAllCheckNotifier());
        }

        protected string GetValueFromAppConfigSuperAwesome(string key)
        {
            if (contentsOfAppConfig == null)
                contentsOfAppConfig = File.ReadAllText(".\\Tests.Common.dll.config");

            MatchCollection matchCollection = Regex.Matches(contentsOfAppConfig, "<" + key + ">(.*)</" + key + ">");

            if (matchCollection.Count != 1)
                throw new Exception("Problem with regex reading from config, unexpected number of matches:" + matchCollection.Count + " for key:"+ key);

            return matchCollection[0].Groups[1].Value;
        }
        
        protected DiscoveredDatabase ToDiscoveredDatabase(SqlConnectionStringBuilder builder)
        {
            if(string.IsNullOrWhiteSpace(builder.InitialCatalog) )
                throw new NotSupportedException("Your builder must have an InitialCatalogue to be turned into a discovered database (and her-in lies the problem)");

            return new DiscoveredServer(builder).ExpectDatabase(builder.InitialCatalog);
        }
    }
}

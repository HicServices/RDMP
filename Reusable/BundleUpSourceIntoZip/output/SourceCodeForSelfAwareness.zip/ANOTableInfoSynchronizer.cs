using System.Collections.Generic; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Linq;
using CatalogueLibrary;
using CatalogueLibrary.Data;
using CatalogueLibrary.Data.DataLoad;
using ReusableLibraryCode.Checks;

namespace DataLoadEngine.DataFlowPipeline.Components.Anonymisation
{
    public class ANOTableInfoSynchronizer
    {
        private readonly TableInfo _tableToSync;

        public ANOTableInfoSynchronizer(TableInfo tableToSync)
        {
            _tableToSync = tableToSync;
            
        }

        public void Synchronize(ICheckNotifier notifier)
        {
            var preLoadDiscardedColumns = PreLoadDiscardedColumn.GetAllPreLoadDiscardedColumnsFor(_tableToSync).ToArray();
            
            IdentifierDumper dumper = new IdentifierDumper(_tableToSync,preLoadDiscardedColumns);
            dumper.Check(notifier);


            var columnInfosWithANOTransforms = _tableToSync.ColumnInfos.Where(c => c.ANOTable_ID != null).ToArray();

            if (!columnInfosWithANOTransforms.Any())
                notifier.OnCheckPerformed(
                    new CheckEventArgs(
                        "There are no ANOTables configured for this table so skipping ANOTable checking",
                        CheckResult.Success));
            
            foreach (ColumnInfo columnInfoWithANOTransform in columnInfosWithANOTransforms)
            {
                ANOTable anoTable = columnInfoWithANOTransform.ANOTable;
                anoTable.Check(new ThrowImmediatelyCheckNotifier());
                
                if(!anoTable.GetRuntimeDataType(LoadStage.PostLoad).Equals(columnInfoWithANOTransform.Data_type))
                    throw new ANOConfigurationException("Mismatch between anoTable.GetRuntimeDataType(LoadStage.PostLoad) = " + anoTable.GetRuntimeDataType(LoadStage.PostLoad) + " and column " + columnInfoWithANOTransform + " datatype = " +columnInfoWithANOTransform.Data_type);
                
                notifier.OnCheckPerformed(
                    new CheckEventArgs(
                        "ANOTable " + anoTable + " has shared compatible datatype " + columnInfoWithANOTransform.Data_type + " with ColumnInfo " +
                        columnInfoWithANOTransform, CheckResult.Success));
            }
        }
    }
}

using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using CatalogueLibrary.Data;
using CatalogueLibrary.QueryBuilding;
using CatalogueManager.ExtractionUIs.FilterUIs;
using CatalogueManager.TestsAndSetup.ServicePropogation;
using DataExportManager2Library;
using DataExportManager2Library.Data;
using DataExportManager2Library.Data.DataTables;
using DataExportManager2Library.DataRelease;
using DataExportManager2Library.ExtractionTime;
using DataExportManager2Library.ExtractionTime.ExtractionPipeline;
using DataExportManager2Library.ExtractionTime.UserPicks;
using DataExportManager2Library.Repositories;
using MapsDirectlyToDatabaseTable;
using ScintillaNET;
using IContainer = CatalogueLibrary.Data.IContainer;

namespace DataExportManager2.ProjectUI.FilterConfiguration
{
    /// <summary>
    /// Allows you configure filters specific to a gieven project extraction of a dataset.  Datasets are automatically filtered to only include records for the patients in the research
    /// cohort (via the cohort join) but you can further restrict the extract here.  For example a researcher may only have governance approval for records in the dataset 'Prescribing'
    /// where the drug is 'Propranolol' and not any other scripts.
    /// 
    /// For more information on using this control see FilterTreeUI.
    /// 
    /// NOTE: if there are any filters in the Catalogue Database marked with IsMandatory then they will automatically appear in a your extraction configuration as soon as you add the 
    /// dataset (although you can delete them if you want).
    /// 
    /// IMPORTANT: these filters are seperate from the master set held in the Catalogue Database so you can change the implementation (and populate the values of parameters) without
    /// affecting the original master.
    /// </summary>
    public partial class DeployedExtractionFilterUI : RDMPForm, IContainerTreeChangeOrchestrator
    {
        private readonly ExtractionConfiguration _configuration;
        private readonly ExtractableCohort _cohort;
        private readonly ExtractableDataSet _dataSet;

        List<ISqlParameter> _globals;
        
        private Scintilla QueryPreview;

        private HICProjectSalt _salt;
        private List<IColumn> availableColumnsForUserToMessAroundWith;


        public DeployedExtractionFilterUI(ExtractionConfiguration configuration, ExtractableDataSet dataSet, HICProjectSalt salt)
        {
            _configuration = configuration;
            _dataSet = dataSet;
            _salt = salt;

            InitializeComponent();

            if(_configuration == null)
                return;

            _globals = new List<ISqlParameter>(configuration.GlobalExtractionFilterParameters);
            _globals.AddRange(QueryBuilderHost.PreviewConstantParameters(configuration));

            
            filterTreeUI.ChangeOrchestrator = this;
            filterTreeUI.RootContentChanged += filterTreeUI_RootContentChanged;

        }

        protected override void OnLoad(EventArgs e)
        {

            #region Query Editor setup

            if (VisualStudioDesignMode)
                return;

            QueryPreview = new Scintilla();
            QueryPreview.Dock = DockStyle.Fill;
            QueryPreview.Scrolling.ScrollBars = ScrollBars.Both;
            QueryPreview.ConfigurationManager.Language = "mssql";
            QueryPreview.Margins[0].Width = 40; //allows display of line numbers
            QueryPreview.IsReadOnly = true;

            RegenerateQueryText();

            pQueryPreview.Controls.Add(QueryPreview);
            //SetupFiltersBasedOnCurrentState();

            #endregion

            filterTreeUI.GlobalFilterParameters = _configuration.GlobalExtractionFilterParameters.Union(QueryBuilderHost.PreviewConstantParameters(_configuration)).ToArray();
            filterTreeUI.SetRootContainerTo(_configuration.GetFilterContainerFor(_dataSet));

            //tells the component how/where to create new containers during saving (IFilters that are added will already exist in the database so can just be saved
            filterTreeUI.ContainerConstructor = () => new FilterContainer(RepositoryLocator.DataExportRepository);


            availableColumnsForUserToMessAroundWith = new List<IColumn>(_configuration.GetAllExtractableColumnsFor(_dataSet).ToList());

            if (_configuration.Cohort_ID != null)
            {
                var cohort = RepositoryLocator.DataExportRepository.GetObjectByID<ExtractableCohort>((int)_configuration.Cohort_ID);
                availableColumnsForUserToMessAroundWith.AddRange(cohort.CustomCohortColumns);

            }

            filterTreeUI.SetInsertColumnCollection(availableColumnsForUserToMessAroundWith.ToArray());



            //tell it about the Catalogue unless this is an orphan
            if (_dataSet.Catalogue_ID != null)
                filterTreeUI.extractionFilterUI1.Catalogue = RepositoryLocator.CatalogueRepository.GetObjectByID<Catalogue>((int)_dataSet.Catalogue_ID);


            base.OnLoad(e);

        }

        void filterTreeUI_RootContentChanged()
        {
            RegenerateQueryText();
        }


        private void RegenerateQueryText()
        {
            try
            {
                QueryPreview.IsReadOnly = false;
                
                ReleasePotential p = new ReleasePotential(_configuration,_dataSet);
                QueryPreview.Text = p.SqlCurrentConfiguration;
            }
            catch (Exception e)
            {
                QueryPreview.Text = e.ToString();
            }
            QueryPreview.IsReadOnly = true;
        }
        
        public void DeleteRootNodeFromDatabaseIfExists()
        {
            //delete the current root node
            var fOldRoot = _configuration.GetFilterContainerFor(_dataSet);

            if (fOldRoot != null)
                fOldRoot.DeleteInDatabase();
        }

        public IContainer CreateNewContainerInDatabase()
        {
            return new FilterContainer(RepositoryLocator.DataExportRepository);
        }

        public IContainer AssertNoCurrentRootThenCreateNewRootContainer()
        {
            if(_configuration.GetFilterContainerFor(_dataSet) !=null)
                throw new Exception("Configuration " + _configuration + " dataset " + _dataSet + " already has a root filter container");

            var container = CreateNewContainerInDatabase();
            ((FilterContainer)container).SetAsRootContainerFor(_configuration, _dataSet);

            return container;
        }

        public IFilter CreateNewEmptyFilter()
        {
            return new DeployedExtractionFilter(RepositoryLocator.DataExportRepository, "Custom " + Guid.NewGuid(), null);
        }

        public IEnumerable<IFilter> ImportFiltersFromCatalogue()
        {
            Debug.Assert(_dataSet.Catalogue_ID != null, "_dataSet.Catalogue_ID != null");

            FilterImporter fi = new FilterImporter(_dataSet.Catalogue, 
                name=> new DeployedExtractionFilter(_dataSet.Repository, name, null),
                (sql,parent)=>new DeployedExtractionFilterParameter(_dataSet.Repository,sql,parent));

            fi.GlobalFilterParameters = _globals.Cast<ISqlParameter>().ToList();
            fi.ShowDialog(this);

            List<IFilter> toReturn = new List<IFilter>();

            if (fi.DialogResult == DialogResult.OK)
                foreach (var extractionFilter in fi.Imported)
                {
                    //get a list of currently existing filters and parameters
                    var existingFilters = filterTreeUI.GetAllFiltersRecursively();
                    var existingParameters = new List<ISqlParameter>();

                    foreach (IFilter existingFilter in existingFilters)
                        existingParameters.AddRange(existingFilter.GetAllParameters());


                    //make sure no name conflicts
                    while (existingFilters.Any(f => f.Name.Equals(extractionFilter.Name)))
                    {
                        //rename
                        extractionFilter.Name = "Copy of " + extractionFilter.Name;
                        extractionFilter.SaveToDatabase();
                    }

                    //make sure no parameter name conflicts
                    ISqlParameter[] newParameters = extractionFilter.GetAllParameters();

                    foreach (ISqlParameter parameter in newParameters)
                    {
                        string name = Regex.Escape(parameter.ParameterName);

                        //find other parameters that start with name then optionally numbers so myParam matches "myParam" and "myParam54" but not "HeyTheremyParam"
                        var parametersWithSameName = existingParameters.Where(existing => Regex.IsMatch(existing.ParameterName, "^" + name + @"\d*")).ToArray();

                        //if no collisions
                        if (!parametersWithSameName.Any())
                            break;

                        //it is a duplicate
                        var highestParameterNumbersAsString = parametersWithSameName.Select(p => Regex.Match(p.ParameterName, @"\d*$").Value);

                        var highestParameterNumbers = highestParameterNumbersAsString.Select(p => string.IsNullOrWhiteSpace(p) ? 1 : int.Parse(p)).ToArray();
                        int highestExistingParameterWithSameName = highestParameterNumbers.Max();

                        //add 1 to the parameter name
                        string newParameterName = parameter.ParameterName + (highestExistingParameterWithSameName + 1);

                        //replace the parameter name in the filter
                        extractionFilter.WhereSQL = extractionFilter.WhereSQL.Replace(parameter.ParameterName, newParameterName);
                        extractionFilter.SaveToDatabase();

                        parameter.ParameterSQL = parameter.ParameterSQL.Replace(parameter.ParameterName, newParameterName);
                        parameter.SaveToDatabase();

                    }


                    toReturn.Add(extractionFilter);
                }

            return toReturn;
        }
    }
}

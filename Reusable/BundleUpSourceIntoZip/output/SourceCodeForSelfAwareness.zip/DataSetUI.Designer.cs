namespace DataExportManager2.DataSetUI // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
{
    partial class DataSetUI
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbID = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.cbxCatalogueID = new System.Windows.Forms.ComboBox();
            this.cbDisableExtraction = new System.Windows.Forms.CheckBox();
            this.lblSaved = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tbID
            // 
            this.tbID.Location = new System.Drawing.Point(116, 6);
            this.tbID.Name = "tbID";
            this.tbID.ReadOnly = true;
            this.tbID.Size = new System.Drawing.Size(100, 20);
            this.tbID.TabIndex = 22;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(11, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(21, 13);
            this.label5.TabIndex = 21;
            this.label5.Text = "ID:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(11, 36);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(58, 13);
            this.label6.TabIndex = 27;
            this.label6.Text = "Catalogue:";
            // 
            // cbxCatalogueID
            // 
            this.cbxCatalogueID.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cbxCatalogueID.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append;
            this.cbxCatalogueID.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cbxCatalogueID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxCatalogueID.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.cbxCatalogueID.FormattingEnabled = true;
            this.cbxCatalogueID.Location = new System.Drawing.Point(116, 32);
            this.cbxCatalogueID.Name = "cbxCatalogueID";
            this.cbxCatalogueID.Size = new System.Drawing.Size(476, 21);
            this.cbxCatalogueID.Sorted = true;
            this.cbxCatalogueID.TabIndex = 28;
            this.cbxCatalogueID.SelectedIndexChanged += new System.EventHandler(this.cbxCatalogueID_SelectedIndexChanged);
            this.cbxCatalogueID.TextChanged += new System.EventHandler(this.cbxCatalogueID_TextChanged);
            // 
            // cbDisableExtraction
            // 
            this.cbDisableExtraction.AutoSize = true;
            this.cbDisableExtraction.Location = new System.Drawing.Point(116, 59);
            this.cbDisableExtraction.Name = "cbDisableExtraction";
            this.cbDisableExtraction.Size = new System.Drawing.Size(111, 17);
            this.cbDisableExtraction.TabIndex = 29;
            this.cbDisableExtraction.Text = "Disable Extraction";
            this.cbDisableExtraction.UseVisualStyleBackColor = true;
            this.cbDisableExtraction.CheckedChanged += new System.EventHandler(this.cbDisableExtraction_CheckedChanged);
            // 
            // lblSaved
            // 
            this.lblSaved.AutoSize = true;
            this.lblSaved.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaved.Location = new System.Drawing.Point(113, 115);
            this.lblSaved.Name = "lblSaved";
            this.lblSaved.Size = new System.Drawing.Size(47, 13);
            this.lblSaved.TabIndex = 15;
            this.lblSaved.Text = "Saved...";
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(116, 83);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(100, 23);
            this.btnSave.TabIndex = 30;
            this.btnSave.Text = "Save (Ctrl + S)";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // DataSetUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.cbDisableExtraction);
            this.Controls.Add(this.cbxCatalogueID);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.tbID);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblSaved);
            this.Name = "DataSetUI";
            this.Size = new System.Drawing.Size(595, 144);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbID;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cbxCatalogueID;
        private System.Windows.Forms.CheckBox cbDisableExtraction;
        private System.Windows.Forms.Label lblSaved;
        private System.Windows.Forms.Button btnSave;
    }
}

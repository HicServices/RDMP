using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using CatalogueLibrary.Checks;
using CatalogueLibrary.Data;
using CatalogueLibrary.DataHelper;
using MapsDirectlyToDatabaseTable;
using ReusableLibraryCode.Checks;

namespace DataExportManager2Library.Data.DataTables
{
    public class DeployedExtractionFilter : VersionedDatabaseEntity, IFilter, ICheckable
    {
        public int? FilterContainer_ID { get; set; }

        #region Relationships
        [NoMappingToDatabase]
        public DeployedExtractionFilterParameter[] ExtractionFilterParameters
        {
            get
            {
                return
                Repository.GetAllObjects<DeployedExtractionFilterParameter>(
                    "WHERE ExtractionFilter_ID=" + ID)
                    .ToArray();
            }
        }
        #endregion

        public string WhereSQL { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public int? ClonedFromExtractionFilter_ID { get; set; }

        public ColumnInfo GetColumnInfoIfExists()
        {
            return null;
        }
        
        public ISqlParameter[] GetAllParameters()
        {
            return ExtractionFilterParameters.Cast<ISqlParameter>().ToArray();

        }

        public static int Name_MaxLength = -1;
        public static int Description_MaxLength = -1;
        
        //mandatory filters only applies to the catalogue
        public bool IsMandatory { get; set; }

        public DeployedExtractionFilter(IRepository repository, string name, FilterContainer container)
        {
            Repository = repository;
            Repository.InsertAndHydrate(this, new Dictionary<string, object>
            {
                {"Name", name != null ? (object) name : DBNull.Value},
                {"FilterContainer_ID", container != null ? (object) container.ID : DBNull.Value}
            });
        }

        public DeployedExtractionFilter(IRepository repository, DbDataReader r) : base(repository, r)
        {
            WhereSQL = r["WhereSQL"] as string;
            Description = r["Description"] as string;
            Name = r["Name"] as string;
            IsMandatory = (bool)r["IsMandatory"];

            if (r["FilterContainer_ID"] != null && !string.IsNullOrWhiteSpace(r["FilterContainer_ID"].ToString()))
                FilterContainer_ID = int.Parse(r["FilterContainer_ID"].ToString());
            else
                FilterContainer_ID = null;

            ClonedFromExtractionFilter_ID = ObjectToNullableInt(r["ClonedFromExtractionFilter_ID"]);
        }

        public override string ToString()
        {
            return Name;
        }

        public void CreateOrDeleteParametersBasedOnSQL(IEnumerable<ISqlParameter> globals)
        {
            //get what parameter exists
            ISqlParameter[] sqlParameters = this.GetAllParameters();

            //all parameters in the Select SQL
            HashSet<string> parametersRequiredByWhereSQL = QuerySyntaxHelper.GetRequiredParamaterNamesForQuery(this.WhereSQL, globals);


            //find which current parameters are redundant and delete them
            foreach (DeployedExtractionFilterParameter parameter in sqlParameters)
                if (!parametersRequiredByWhereSQL.Contains(parameter.ParameterName))
                    parameter.DeleteInDatabase();
           
            //find new parameters that we don't hvae
            foreach (string requiredParameter in parametersRequiredByWhereSQL)
            {
                if (!sqlParameters.Any(p => p.ParameterName.Equals(requiredParameter)))
                {
                    //no parameters have this parameters name
                    new DeployedExtractionFilterParameter(Repository, "DECLARE " + requiredParameter + " AS VARCHAR(50)", this);
                }
            }
        }

        public void CopyValuesOutOfCatalogueVersion(ExtractionFilter catalogueVersion)
        {
            Description = catalogueVersion.Description;
            IsMandatory = catalogueVersion.IsMandatory;
            WhereSQL = catalogueVersion.WhereSQL;
            ClonedFromExtractionFilter_ID = catalogueVersion.ID;
            SaveToDatabase();
        }
        
        public void Check(ICheckNotifier notifier)
        {
            var checker = new ClonedFilterChecker(this, this.ClonedFromExtractionFilter_ID, (TableRepository)Repository);
            checker.Check(notifier);
        }

        public IFilter CreateNewExtractionFilterInDatabase(string name)
        {
            // todo: why is parent null here?
            return new ExtractionFilter(Repository, name, null);
        }
    }
}

using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Linq;
using System.Windows.Forms;
using CatalogueLibrary.DataFlowPipeline;
using CatalogueLibrary.DataFlowPipeline.Requirements;
using DataExportManager2Library.CohortCreationPipeline;
using DataExportManager2Library.Data.DataTables;
using ReusableLibraryCode.DatabaseHelpers.Discovery;

namespace RDMPObjectVisualisation.DataObjects
{
    public class DataObjectVisualisationFactory
    {
        public Control Create(object value)
        {
            var type = value.GetType();
            if(type == typeof(FlatFileToLoad))
                return new FlatFileToLoadVisualisation((FlatFileToLoad)value);

            if (type == typeof(ExtractableCohort))
                return new ExtractableCohortVisualisation((ExtractableCohort)value);

            if (IsGenericType(value.GetType(), typeof (IDataFlowSource<>)))
                return new DataFlowComponentVisualisation(DataFlowComponentVisualisation.Role.Source, value,null);

            if (IsGenericType(value.GetType(), typeof(IDataFlowDestination<>)))
                return new DataFlowComponentVisualisation(DataFlowComponentVisualisation.Role.Destination, value, null);

            if (IsGenericType(value.GetType(), typeof(IDataFlowComponent<>)))
                return new DataFlowComponentVisualisation(DataFlowComponentVisualisation.Role.Middle, value, null);
            
            if (type == typeof(DiscoveredDatabase))
                return new DiscoveredDatabaseVisualisation((DiscoveredDatabase)value);

            if (type == typeof (CohortCreationRequest))
                return new CohortCreationRequestVisualisation((CohortCreationRequest)value);
            
            throw new NotSupportedException("Did not know how to visualise object of type " + type);
        }

        private bool IsGenericType(Type toCheck, Type genericType)
        {
            return toCheck.GetInterfaces().Any(x => x.IsGenericType && x.GetGenericTypeDefinition() == genericType);
        }
    }
}

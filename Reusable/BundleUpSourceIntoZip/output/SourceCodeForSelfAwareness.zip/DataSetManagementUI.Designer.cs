using CatalogueManager.MainFormUITabs.SubComponents; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved

namespace DataExportManager2.DataSetUI
{
    partial class DataSetManagementUI
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbDataSets = new System.Windows.Forms.ListBox();
            this.btnCohortDatabaseTableAdd = new System.Windows.Forms.Button();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.tbFilter = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.btnImportAsExtractableDataset = new System.Windows.Forms.Button();
            this.catalogueCollectionHost1 = new CatalogueManager.MainFormUITabs.SubComponents.CatalogueCollectionHost();
            this.dataSetUI1 = new DataExportManager2.DataSetUI.DataSetUI();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbDataSets
            // 
            this.lbDataSets.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbDataSets.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.lbDataSets.FormattingEnabled = true;
            this.lbDataSets.Location = new System.Drawing.Point(3, 25);
            this.lbDataSets.Name = "lbDataSets";
            this.lbDataSets.Size = new System.Drawing.Size(356, 537);
            this.lbDataSets.Sorted = true;
            this.lbDataSets.TabIndex = 1;
            this.lbDataSets.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.lbDataSets_DrawItem);
            this.lbDataSets.SelectedIndexChanged += new System.EventHandler(this.lbCohortDatabaseTable_SelectedIndexChanged);
            this.lbDataSets.KeyUp += new System.Windows.Forms.KeyEventHandler(this.lbCohortDatabaseTable_KeyUp);
            // 
            // btnCohortDatabaseTableAdd
            // 
            this.btnCohortDatabaseTableAdd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCohortDatabaseTableAdd.Location = new System.Drawing.Point(284, 592);
            this.btnCohortDatabaseTableAdd.Name = "btnCohortDatabaseTableAdd";
            this.btnCohortDatabaseTableAdd.Size = new System.Drawing.Size(75, 23);
            this.btnCohortDatabaseTableAdd.TabIndex = 2;
            this.btnCohortDatabaseTableAdd.Text = "Add New";
            this.btnCohortDatabaseTableAdd.UseVisualStyleBackColor = true;
            this.btnCohortDatabaseTableAdd.Click += new System.EventHandler(this.btnCohortDatabaseTableAdd_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.label3);
            this.splitContainer1.Panel1.Controls.Add(this.tbFilter);
            this.splitContainer1.Panel1.Controls.Add(this.label1);
            this.splitContainer1.Panel1.Controls.Add(this.lbDataSets);
            this.splitContainer1.Panel1.Controls.Add(this.btnCohortDatabaseTableAdd);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.dataSetUI1);
            this.splitContainer1.Size = new System.Drawing.Size(752, 618);
            this.splitContainer1.SplitterDistance = 376;
            this.splitContainer1.TabIndex = 4;
            // 
            // tbFilter
            // 
            this.tbFilter.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbFilter.Location = new System.Drawing.Point(70, 566);
            this.tbFilter.Name = "tbFilter";
            this.tbFilter.Size = new System.Drawing.Size(289, 20);
            this.tbFilter.TabIndex = 4;
            this.tbFilter.TextChanged += new System.EventHandler(this.tbFilter_TextChanged);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(29, 569);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(32, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Filter:";
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.label2);
            this.splitContainer2.Panel1.Controls.Add(this.btnImportAsExtractableDataset);
            this.splitContainer2.Panel1.Controls.Add(this.catalogueCollectionHost1);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.splitContainer1);
            this.splitContainer2.Size = new System.Drawing.Size(1227, 618);
            this.splitContainer2.SplitterDistance = 471;
            this.splitContainer2.TabIndex = 5;
            // 
            // btnImportAsExtractableDataset
            // 
            this.btnImportAsExtractableDataset.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnImportAsExtractableDataset.Location = new System.Drawing.Point(344, 101);
            this.btnImportAsExtractableDataset.Name = "btnImportAsExtractableDataset";
            this.btnImportAsExtractableDataset.Size = new System.Drawing.Size(124, 44);
            this.btnImportAsExtractableDataset.TabIndex = 1;
            this.btnImportAsExtractableDataset.Text = "Import As ExtractableDataset";
            this.btnImportAsExtractableDataset.UseVisualStyleBackColor = true;
            this.btnImportAsExtractableDataset.Click += new System.EventHandler(this.btnImportAsExtractableDataset_Click);
            // 
            // catalogueCollectionHost1
            // 
            this.catalogueCollectionHost1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.catalogueCollectionHost1.Collection = null;
            this.catalogueCollectionHost1.Location = new System.Drawing.Point(3, 16);
            this.catalogueCollectionHost1.Name = "catalogueCollectionHost1";
            this.catalogueCollectionHost1.Size = new System.Drawing.Size(335, 599);
            this.catalogueCollectionHost1.TabIndex = 0;
            // 
            // dataSetUI1
            // 
            this.dataSetUI1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataSetUI1.ExtractableDataSet = null;
            this.dataSetUI1.Location = new System.Drawing.Point(0, 0);
            this.dataSetUI1.Name = "dataSetUI1";
            this.dataSetUI1.Size = new System.Drawing.Size(372, 618);
            this.dataSetUI1.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(233, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Catalogues with at least 1 ExtractionInformation:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(353, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "ExtractableDatasets (Catalogues that have been chosen for extractability)";
            // 
            // DataSetManagementUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.splitContainer2);
            this.Name = "DataSetManagementUI";
            this.Size = new System.Drawing.Size(1227, 618);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel1.PerformLayout();
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lbDataSets;
        private System.Windows.Forms.Button btnCohortDatabaseTableAdd;
        private DataSetUI dataSetUI1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TextBox tbFilter;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private CatalogueCollectionHost catalogueCollectionHost1;
        private System.Windows.Forms.Button btnImportAsExtractableDataset;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}

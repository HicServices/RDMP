namespace CatalogueLibrary.Data
{
    public enum AggregateTopXOrderByDirection
    {
        Ascending,
        Descending
    }
}

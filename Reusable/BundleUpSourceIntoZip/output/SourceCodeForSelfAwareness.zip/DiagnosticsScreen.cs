using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Security.AccessControl;
using System.Windows.Forms;
using CatalogueLibrary;
using CatalogueLibrary.Checks;
using CatalogueLibrary.Data;
using CatalogueLibrary.Repositories;
using CatalogueManager.LocationsMenu;
using CatalogueManager.Properties;
using CatalogueManager.SimpleDialogs;
using CatalogueManager.TestsAndSetup.ServicePropogation;
using DataExportManager2Library.Data.DataTables;
using DataLoadEngine.DataFlowPipeline.Components.Anonymisation;
using Diagnostics;
using HIC.Logging;
using MapsDirectlyToDatabaseTable.Versioning;
using RDMPObjectVisualisation;
using RDMPStartup;
using ReusableLibraryCode;
using ReusableLibraryCode.Checks;
using ReusableLibraryCode.DatabaseHelpers.Discovery;
using ReusableUIComponents;
using ReusableUIComponents.ChecksUI;
using MapsDirectlyToDatabaseTableUI;

namespace CatalogueManager.TestsAndSetup
{
    internal enum ConnectionTypes
    {
        Logging,
        ANO,
        IdentifierDump
    }

    /// <summary>
    /// This super technical  screen appears when things go irrecoverably wrong or when the user launches it from the CatalogueManager main menu.  It includes a veriety of tests that 
    /// can be run on the current platform databases to check the contents/configurations.  It also includes 'Create Test Dataset' which can be used as a user acceptance test to make
    /// sure that thier installation is succesfully working (See UserManual.docx)
    /// 
    /// The 'Evaluate MEF Exports' button is particularly useful if you are trying to debug a plugin you have written to find out why your class isn't appearing in the relevant part of
    /// the RDMP.
    /// </summary>
    public partial class DiagnosticsScreen : RDMPForm
    {
        private readonly Exception _originalException;

        public bool ShouldReloadCatalogues = false;
        private bool setupComplete = false;

        public DiagnosticsScreen(Exception exception)
        {
            _originalException = exception;

            InitializeComponent();
            
            if (_originalException != null)
                btnViewOriginalException.Enabled = true;

            string defaultConnectionString = new SqlConnectionStringBuilder(){DataSource = Environment.MachineName,IntegratedSecurity =true}.ConnectionString;

            tbLoggingConnectionString.Text = defaultConnectionString;
            tbANOConnectionString.Text = defaultConnectionString;
            tbDumpConnectionString.Text = defaultConnectionString;
            tbTestDatasetServer.Text = defaultConnectionString;

            RecentHistoryOfControls.GetInstance().HostControl(tbANOConnectionString);
            RecentHistoryOfControls.GetInstance().HostControl(tbDumpConnectionString);
            RecentHistoryOfControls.GetInstance().HostControl(tbTestDatasetServer);
            RecentHistoryOfControls.GetInstance().HostControl(tbLoggingConnectionString);

            RecentHistoryOfControls.GetInstance().SetValueToMostRecentlySavedValue(tbANOConnectionString);
            RecentHistoryOfControls.GetInstance().SetValueToMostRecentlySavedValue(tbDumpConnectionString);
            RecentHistoryOfControls.GetInstance().SetValueToMostRecentlySavedValue(tbTestDatasetServer);
            RecentHistoryOfControls.GetInstance().SetValueToMostRecentlySavedValue(tbLoggingConnectionString);

            setupComplete = true;

            
            
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            if(VisualStudioDesignMode)
                return;

            BetterToolTip.SetToolTip(this, ToolTips.DiagnosticsScreen, Images.DiagnosticsScreen);
            BetterToolTip.SetToolTip(tabControl1, ToolTips.SetupTestDataset, Images.SetupTestDataset);
        }

        public static void OfferLaunchingDiagnosticsScreenOrEnvironmentExit(IRDMPPlatformRepositoryServiceLocator locator, IWin32Window owner, Exception e)
        {
            if (MessageBox.Show(ExceptionHelper.ExceptionToListOfInnerMessages(e) + Environment.NewLine + Environment.NewLine + " Would you like to launch the Diagnostics Screen? (If you choose No then the application will exit ᕦ(ò_óˇ)ᕤ )", "Launch Diagnostics?", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                DiagnosticsScreen screen = new DiagnosticsScreen(e);
                screen.RepositoryLocator = locator;
                screen.ShowDialog(owner);
            }
            else
                Environment.Exit(499);
        }

        private void btnCatalogueFields_Click(object sender, EventArgs e)
        {

            StartChecking(new MissingFieldsChecker(MissingFieldsChecker.ThingToCheck.Catalogue, RepositoryLocator.CatalogueRepository, RepositoryLocator.DataExportRepository));
        }
        private void btnDataExportManagerFields_Click(object sender, EventArgs e)
        {
            StartChecking(new MissingFieldsChecker(MissingFieldsChecker.ThingToCheck.DataExportManager, RepositoryLocator.CatalogueRepository, RepositoryLocator.DataExportRepository));
        }

        private void btnCheckANOConfigurations_Click(object sender, EventArgs e)
        {
            StartChecking(new ANOConfigurationChecker(RepositoryLocator.CatalogueRepository));
        }
        private void btnCohortDatabase_Click(object sender, EventArgs e)
        {
            StartChecking(new CohortConfigurationChecker(RepositoryLocator.DataExportRepository));
        }
        private void btnListBadAssemblies_Click(object sender, EventArgs e)
        {

            StartChecking(new BadAssembliesChecker(RepositoryLocator.CatalogueRepository.MEF));
        }

        private void btnCatalogueTableNames_Click(object sender, EventArgs e)
        {
            StartChecking(new DodgyNamedTableAndColumnsChecker(RepositoryLocator.CatalogueRepository));
        }

        private void StartChecking(ICheckable checkable)
        {
            tabControl1.SelectTab(tpProgress);
            checksUI1.Clear();
            checksUI1.StartChecking(checkable);
        }

        #region setup test environment
        private void btnCreateTestDataset_Click(object sender, EventArgs e)
        {
            
            var loggingBuilder = new SqlConnectionStringBuilder(tbLoggingConnectionString.Text);
            var testDataBuilder = new SqlConnectionStringBuilder(tbTestDatasetServer.Text);
            SqlConnectionStringBuilder dumpBuilder = null;
            SqlConnectionStringBuilder anoBuilder = null;

            if (cbIncludeAnonymisation.Checked)
            {
                dumpBuilder = new SqlConnectionStringBuilder(tbDumpConnectionString.Text);
                anoBuilder = new SqlConnectionStringBuilder(tbANOConnectionString.Text);
            }

            if (string.IsNullOrWhiteSpace(tbLoggingConnectionString.Text))
            {
                MessageBox.Show("Please enter a connection string for the Logging server", "Create Test Dataset error");
                return;
            }
            
            //switch to the progress tab
            tabControl1.SelectTab(tpProgress);

            checksUI1.StartChecking(new UserAcceptanceTestEnvironment(testDataBuilder, cbxDataSetFolder.Text, loggingBuilder, ddLoggingTask.Text, anoBuilder, dumpBuilder,RepositoryLocator));
            ShouldReloadCatalogues = true;

            btnAddExportFunctionality.Enabled = true;
        }

        private void PerformLoggingDatabaseChecks()
        {
            checksUI1.Clear();
            
            var builder = new SqlConnectionStringBuilder(tbLoggingConnectionString.Text);
            
            var loggingChecker = new LoggingDatabaseChecker(new DiscoveredServer(builder));

            loggingChecker.Check(new ThrowImmediatelyCheckNotifier());
        }

        private void PopulateLoggingTasks()
        {
            string before = ddLoggingTask.Text;

            var builder = new SqlConnectionStringBuilder(tbLoggingConnectionString.Text);

            LogManager lm = new LogManager(new DiscoveredServer(builder), ProgressLogging.GetInstance(), FatalErrorLogging.GetInstance(), RowErrorLogging.GetInstance());
            ddLoggingTask.Items.Clear();
            ddLoggingTask.Items.AddRange(lm.ListDataTasks());
            lblLoggingDatabaseState.Text = "Success";
            lblLoggingDatabaseState.ForeColor = Color.Black;

            if (ddLoggingTask.Items.Contains(before))
                ddLoggingTask.Text = before;
        }

        private void cbIncludeAnonymisation_CheckedChanged(object sender, EventArgs e)
        {
            gbAnonymisation.Enabled = cbIncludeAnonymisation.Checked;
        }

        private void cbxDataSetFolder_Leave(object sender, EventArgs e)
        {
            if (!setupComplete)
                return;
            try
            {
                DirectoryInfo d = new DirectoryInfo(cbxDataSetFolder.Text);

                if (!d.Exists)
                    lblDatasetFolder.Text = "Directory does not exist";
                else
                    lblDatasetFolder.Text = "Ok";

                try
                {
                    // Attempt to get a list of security permissions from the folder. 
                    // This will raise an exception if the path is read only or do not have access to view the permissions. 
                    DirectorySecurity ds = d.GetAccessControl();

                }
                catch (UnauthorizedAccessException exception)
                {
                    lblDatasetFolder.Text = "Access Rights Problem:" + exception.Message;
                }
            }
            catch (Exception exception)
            {
                lblDatasetFolder.Text = exception.Message;
            }

        }

        #endregion


        private void btnViewOriginalException_Click(object sender, EventArgs e)
        {
            ExceptionViewer.Show(_originalException);
        }


        private void btnAddExportFunctionality_Click(object sender, EventArgs e)
        {
            ShouldReloadCatalogues = true;
            checksUI1.Clear();
            var setup = new UserAcceptanceTestDataExportFunctionality(cbxProjectExtractionDirectory.Text, RepositoryLocator);
            
            //switch to the progress tab
            tabControl1.SelectTab(tpProgress);

            setup.Check(checksUI1);
        }
        
        private void btnImportHospitalAdmissions_Click(object sender, EventArgs e)
        {
            ShouldReloadCatalogues = true;
            checksUI1.Clear();
            
            //do not need to provide server because this test will pick up the server settings off of the DMPTestCatalogue and use the same target data server to load to
            var setup = new UserAcceptanceTestImportHospitalAdmissions(RepositoryLocator);

            //switch to the progress tab
            tabControl1.SelectTab(tpProgress);

            setup.Check(checksUI1);

        }
        
        private void btnCreateNewLoggingDatabase_Click(object sender, EventArgs e)
        {
            try
            {
                CreatePlatformDatabase dialog = new CreatePlatformDatabase( typeof(HIC.Logging.Database.Class1).Assembly);
                dialog.ShowDialog();

                if (dialog.DatabaseConnectionString!= null)
                {
                    tbLoggingConnectionString.Text = dialog.DatabaseConnectionString;
                    tbLoggingConnectionString.Focus();
                    AfterUpdateConnectionString(ConnectionTypes.Logging, tbLoggingConnectionString);//run logging checks
                }

                if (ddLoggingTask.SelectedItem == null)
                    ddLoggingTask.Text = "Internal";
            }
            catch (Exception exception)
            {
                ExceptionViewer.Show(exception);
            }
        }

        private void AfterUpdateConnectionString(ConnectionTypes connectionType, TextBox tbConnectionString)
        {
            DiscoveredServer server=null;

            try
            {
                server = new DiscoveredServer(new SqlConnectionStringBuilder(tbConnectionString.Text));
                server.TestConnection();
                
                switch (connectionType)
                {
                    case ConnectionTypes.Logging:
                        PerformLoggingDatabaseChecks();
                        PopulateLoggingTasks();
                        break;
                    case ConnectionTypes.ANO:

                        lblANODatabaseState.Text = "State:Broken";
                        lblANODatabaseState.ForeColor = Color.Red;
                        ANOTransformer.ConfirmDependencies(server.GetCurrentDatabase(), new ThrowImmediatelyCheckNotifier());
                        lblANODatabaseState.Text = "State:Ok";
                        lblANODatabaseState.ForeColor = Color.Green;

                        break;
                    case ConnectionTypes.IdentifierDump:
                        lblIdentifierDumpDatabaseState.Text = "State:Broken";
                        lblIdentifierDumpDatabaseState.ForeColor = Color.Red;
                        IdentifierDumper.ConfirmDependencies(server.GetCurrentDatabase(), new ThrowImmediatelyCheckNotifier());
                        lblIdentifierDumpDatabaseState.Text = "State:Ok";
                        lblIdentifierDumpDatabaseState.ForeColor = Color.Green;
                        break;
                    default:
                        throw new ArgumentOutOfRangeException("connectionType", connectionType, null);
                }
            }
            catch (Exception exception)
            {
                ExceptionViewer.Show("Failed to check " + connectionType + "(" + server+")",exception);
            }
        }

        private void btnLoggingConnection_Click(object sender, EventArgs e)
        {
            if (CreateConnectionStringDialog(tbLoggingConnectionString) == DialogResult.Cancel)
                return;

            AfterUpdateConnectionString(ConnectionTypes.Logging, tbLoggingConnectionString);
        }

        private void btnRawServerConnection_Click(object sender, EventArgs e)
        {
            if (CreateConnectionStringDialog(tbTestDatasetServer, false) == DialogResult.Cancel)
                return;
        }

        private DialogResult CreateConnectionStringDialog(TextBox textbox, bool includeDatabase = true)
        {
            if (!setupComplete)
                throw new Exception("Does this ever happen?");

            var control = new ConnectionStringControl(includeDatabase);
            var dialog = new GenericOkCancelDialog<ConnectionStringControl>(control, "Edit Connection String");

            var result = dialog.ShowDialog();

            if (result == DialogResult.OK)
            {
                textbox.Text = dialog.Child.ConnectionString;
                textbox.Focus();//give it input focus so that leave events are captured
            }

            return result;
        }


        private void tbLoggingConnectionString_Leave(object sender, EventArgs e)
        {
            AfterUpdateConnectionString(ConnectionTypes.Logging, tbLoggingConnectionString);
        }

        private void tbANOConnectionString_Leave(object sender, EventArgs e)
        {
            AfterUpdateConnectionString(ConnectionTypes.ANO, tbANOConnectionString);
        }

        private void tbDumpConnectionString_Leave(object sender, EventArgs e)
        {
            AfterUpdateConnectionString(ConnectionTypes.IdentifierDump, tbDumpConnectionString);
        }

        private void btnRefreshDataLoadTasks_Click(object sender, EventArgs e)
        {
            AfterUpdateConnectionString(ConnectionTypes.Logging, tbLoggingConnectionString);
        }

        private void btnChangePlatformDatabases_Click(object sender, EventArgs e)
        {
            ChoosePlatformDatabases chooser = new ChoosePlatformDatabases();
            chooser.RepositoryLocator = RepositoryLocator;
            chooser.ShowDialog();
        }

        private void btnCreateNewANOStore_Click(object sender, EventArgs e)
        {
            CreatePlatformDatabase dialog = new CreatePlatformDatabase(typeof(ANOStore.Database.Class1).Assembly);
            dialog.ShowDialog(this);

            if(!string.IsNullOrWhiteSpace(dialog.DatabaseConnectionString))
                tbANOConnectionString.Text = dialog.DatabaseConnectionString;
        }

        private void btnCreateNewIdentifierDump_Click(object sender, EventArgs e)
        {
            CreatePlatformDatabase dialog = new CreatePlatformDatabase(typeof(IdentifierDump.Database.Class1).Assembly);
            dialog.ShowDialog(this);

            if (!string.IsNullOrWhiteSpace(dialog.DatabaseConnectionString))
                tbDumpConnectionString.Text = dialog.DatabaseConnectionString;

        }

        private void btnCatalogueCheck_Click(object sender, EventArgs e)
        {
            checksUI1.Clear();
            try
            {
                foreach (Catalogue c in RepositoryLocator.CatalogueRepository.GetAllCatalogues(true))
                    c.Check(checksUI1);
            }
            catch (Exception exception)
            {
                checksUI1.OnCheckPerformed(new CheckEventArgs("Catalogue checking crashed completely", CheckResult.Fail,exception));
            }
        }

        private void btnCheckANOStore_Click(object sender, EventArgs e)
        {
            AfterUpdateConnectionString(ConnectionTypes.ANO, tbANOConnectionString);
        }
        
        private void btnCheckIdentifierDump_Click(object sender, EventArgs e)
        {
            AfterUpdateConnectionString(ConnectionTypes.IdentifierDump, tbDumpConnectionString);
        }
    }
}

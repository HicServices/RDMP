namespace CatalogueManager.AggregationUIs // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
{
    partial class AggregateManagement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.lbAggregates = new System.Windows.Forms.ListBox();
            this.aggregateConfigurationUI1 = new CatalogueManager.AggregationUIs.AggregateConfigurationUI();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.newAggregateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cbShowCohortSpecificAggregates = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer1.Location = new System.Drawing.Point(0, 28);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.cbShowCohortSpecificAggregates);
            this.splitContainer1.Panel1.Controls.Add(this.lbAggregates);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.aggregateConfigurationUI1);
            this.splitContainer1.Size = new System.Drawing.Size(1588, 806);
            this.splitContainer1.SplitterDistance = 297;
            this.splitContainer1.TabIndex = 0;
            // 
            // lbAggregates
            // 
            this.lbAggregates.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbAggregates.FormattingEnabled = true;
            this.lbAggregates.Location = new System.Drawing.Point(0, 0);
            this.lbAggregates.Name = "lbAggregates";
            this.lbAggregates.Size = new System.Drawing.Size(297, 806);
            this.lbAggregates.TabIndex = 0;
            this.lbAggregates.SelectedIndexChanged += new System.EventHandler(this.lbAggregates_SelectedIndexChanged);
            this.lbAggregates.KeyUp += new System.Windows.Forms.KeyEventHandler(this.lbAggregates_KeyUp);
            // 
            // aggregateConfigurationUI1
            // 
            this.aggregateConfigurationUI1.AggregateConfiguration = null;
            this.aggregateConfigurationUI1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.aggregateConfigurationUI1.Location = new System.Drawing.Point(0, 0);
            this.aggregateConfigurationUI1.Name = "aggregateConfigurationUI1";
            this.aggregateConfigurationUI1.Size = new System.Drawing.Size(1287, 806);
            this.aggregateConfigurationUI1.TabIndex = 0;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(93, 26);
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(92, 22);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1588, 24);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem1
            // 
            this.fileToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newAggregateToolStripMenuItem,
            this.saveToolStripMenuItem});
            this.fileToolStripMenuItem1.Name = "fileToolStripMenuItem1";
            this.fileToolStripMenuItem1.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem1.Text = "File";
            // 
            // newAggregateToolStripMenuItem
            // 
            this.newAggregateToolStripMenuItem.Name = "newAggregateToolStripMenuItem";
            this.newAggregateToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.newAggregateToolStripMenuItem.Size = new System.Drawing.Size(199, 22);
            this.newAggregateToolStripMenuItem.Text = "New Aggregate";
            this.newAggregateToolStripMenuItem.Click += new System.EventHandler(this.newAggregateToolStripMenuItem_Click);
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(199, 22);
            this.saveToolStripMenuItem.Text = "Save";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
            // 
            // cbShowCohortSpecificAggregates
            // 
            this.cbShowCohortSpecificAggregates.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cbShowCohortSpecificAggregates.AutoSize = true;
            this.cbShowCohortSpecificAggregates.Location = new System.Drawing.Point(3, 786);
            this.cbShowCohortSpecificAggregates.Name = "cbShowCohortSpecificAggregates";
            this.cbShowCohortSpecificAggregates.Size = new System.Drawing.Size(207, 17);
            this.cbShowCohortSpecificAggregates.TabIndex = 1;
            this.cbShowCohortSpecificAggregates.Text = "Show Cohort Identification Aggregates";
            this.cbShowCohortSpecificAggregates.UseVisualStyleBackColor = true;
            this.cbShowCohortSpecificAggregates.CheckedChanged += new System.EventHandler(this.cbShowCohortSpecificAggregates_CheckedChanged);
            // 
            // AggregateManagement
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1588, 834);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.splitContainer1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "AggregateManagement";
            this.Text = "AggregateManagement";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.contextMenuStrip1.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.ListBox lbAggregates;
        private AggregateConfigurationUI aggregateConfigurationUI1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem newAggregateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.CheckBox cbShowCohortSpecificAggregates;
    }
}

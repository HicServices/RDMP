namespace DataExportManager
{
    public delegate void ChangesSavedHandler();
}

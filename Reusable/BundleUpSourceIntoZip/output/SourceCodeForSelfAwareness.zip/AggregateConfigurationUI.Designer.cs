using System.Windows.Forms; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using CatalogueManager.ExtractionUIs.FilterUIs;

namespace CatalogueManager.AggregationUIs
{
    partial class AggregateConfigurationUI
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AggregateConfigurationUI));
            this.tbID = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tbCreated = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbName = new System.Windows.Forms.TextBox();
            this.tbDescription = new System.Windows.Forms.TextBox();
            this.tpDimensions = new System.Windows.Forms.TabPage();
            this.aggregateDimensionManagementTabUI1 = new CatalogueManager.AggregationUIs.AggregateDimensionManagementTabUI();
            this.tpDescriptive = new System.Windows.Forms.TabPage();
            this.pHavingSQL = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.btnConfigureDeclareParameters = new System.Windows.Forms.Button();
            this.cbIsExtractable = new System.Windows.Forms.CheckBox();
            this.btnClearPivotDimension = new System.Windows.Forms.Button();
            this.ddPivotDimension = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.pCountSql = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.btnSaveDescriptiveData = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tpFilters = new System.Windows.Forms.TabPage();
            this.aggregateFilterConfigurationTabUI1 = new CatalogueManager.AggregationUIs.AggregateFilterConfigurationTabUI();
            this.label12 = new System.Windows.Forms.Label();
            this.tpSqlPreview = new System.Windows.Forms.TabPage();
            this.tpGraph = new System.Windows.Forms.TabPage();
            this.btnSaveGraph = new System.Windows.Forms.Button();
            this.tbTimeoutOnGraphCreation = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.btnLoadGraph = new System.Windows.Forms.Button();
            this.aggregateGraph1 = new CatalogueManager.AggregationUIs.AggregateGraph();
            this.tpDimensions.SuspendLayout();
            this.tpDescriptive.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tpFilters.SuspendLayout();
            this.tpGraph.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbID
            // 
            this.tbID.Location = new System.Drawing.Point(82, 6);
            this.tbID.Name = "tbID";
            this.tbID.ReadOnly = true;
            this.tbID.Size = new System.Drawing.Size(100, 20);
            this.tbID.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 97);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Description:";
            // 
            // tbCreated
            // 
            this.tbCreated.Location = new System.Drawing.Point(82, 33);
            this.tbCreated.Name = "tbCreated";
            this.tbCreated.ReadOnly = true;
            this.tbCreated.Size = new System.Drawing.Size(100, 20);
            this.tbCreated.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(14, 36);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Created:";
            // 
            // tbName
            // 
            this.tbName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbName.Location = new System.Drawing.Point(82, 68);
            this.tbName.Name = "tbName";
            this.tbName.Size = new System.Drawing.Size(989, 20);
            this.tbName.TabIndex = 6;
            this.tbName.TextChanged += new System.EventHandler(this.tbName_TextChanged);
            // 
            // tbDescription
            // 
            this.tbDescription.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbDescription.Location = new System.Drawing.Point(82, 94);
            this.tbDescription.Multiline = true;
            this.tbDescription.Name = "tbDescription";
            this.tbDescription.Size = new System.Drawing.Size(989, 262);
            this.tbDescription.TabIndex = 7;
            this.tbDescription.TextChanged += new System.EventHandler(this.tbDescription_TextChanged);
            // 
            // tpDimensions
            // 
            this.tpDimensions.Controls.Add(this.aggregateDimensionManagementTabUI1);
            this.tpDimensions.Location = new System.Drawing.Point(4, 22);
            this.tpDimensions.Name = "tpDimensions";
            this.tpDimensions.Padding = new System.Windows.Forms.Padding(3);
            this.tpDimensions.Size = new System.Drawing.Size(1077, 705);
            this.tpDimensions.TabIndex = 1;
            this.tpDimensions.Text = "Dimensions / Force Joins";
            this.tpDimensions.UseVisualStyleBackColor = true;
            // 
            // aggregateDimensionManagementTabUI1
            // 
            this.aggregateDimensionManagementTabUI1.AggregateConfiguration = null;
            this.aggregateDimensionManagementTabUI1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.aggregateDimensionManagementTabUI1.Location = new System.Drawing.Point(3, 3);
            this.aggregateDimensionManagementTabUI1.Name = "aggregateDimensionManagementTabUI1";
            this.aggregateDimensionManagementTabUI1.Size = new System.Drawing.Size(1071, 699);
            this.aggregateDimensionManagementTabUI1.TabIndex = 1;
            // 
            // tpDescriptive
            // 
            this.tpDescriptive.Controls.Add(this.pHavingSQL);
            this.tpDescriptive.Controls.Add(this.label5);
            this.tpDescriptive.Controls.Add(this.btnConfigureDeclareParameters);
            this.tpDescriptive.Controls.Add(this.cbIsExtractable);
            this.tpDescriptive.Controls.Add(this.btnClearPivotDimension);
            this.tpDescriptive.Controls.Add(this.ddPivotDimension);
            this.tpDescriptive.Controls.Add(this.label8);
            this.tpDescriptive.Controls.Add(this.pCountSql);
            this.tpDescriptive.Controls.Add(this.label7);
            this.tpDescriptive.Controls.Add(this.btnSaveDescriptiveData);
            this.tpDescriptive.Controls.Add(this.tbID);
            this.tpDescriptive.Controls.Add(this.tbDescription);
            this.tpDescriptive.Controls.Add(this.label1);
            this.tpDescriptive.Controls.Add(this.tbName);
            this.tpDescriptive.Controls.Add(this.label2);
            this.tpDescriptive.Controls.Add(this.tbCreated);
            this.tpDescriptive.Controls.Add(this.label3);
            this.tpDescriptive.Controls.Add(this.label4);
            this.tpDescriptive.Location = new System.Drawing.Point(4, 22);
            this.tpDescriptive.Name = "tpDescriptive";
            this.tpDescriptive.Padding = new System.Windows.Forms.Padding(3);
            this.tpDescriptive.Size = new System.Drawing.Size(1077, 705);
            this.tpDescriptive.TabIndex = 0;
            this.tpDescriptive.Text = "Descriptive / Count / Pivot";
            this.tpDescriptive.UseVisualStyleBackColor = true;
            // 
            // pHavingSQL
            // 
            this.pHavingSQL.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pHavingSQL.Location = new System.Drawing.Point(82, 497);
            this.pHavingSQL.Name = "pHavingSQL";
            this.pHavingSQL.Size = new System.Drawing.Size(989, 128);
            this.pHavingSQL.TabIndex = 12;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 497);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "HAVING SQL:";
            // 
            // btnConfigureDeclareParameters
            // 
            this.btnConfigureDeclareParameters.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnConfigureDeclareParameters.Location = new System.Drawing.Point(82, 674);
            this.btnConfigureDeclareParameters.Name = "btnConfigureDeclareParameters";
            this.btnConfigureDeclareParameters.Size = new System.Drawing.Size(278, 23);
            this.btnConfigureDeclareParameters.TabIndex = 15;
            this.btnConfigureDeclareParameters.Text = "Configure additional SQL DECLARE @Parameters...";
            this.btnConfigureDeclareParameters.UseVisualStyleBackColor = true;
            this.btnConfigureDeclareParameters.Click += new System.EventHandler(this.btnConfigureDeclareParameters_Click);
            // 
            // cbIsExtractable
            // 
            this.cbIsExtractable.AutoSize = true;
            this.cbIsExtractable.Location = new System.Drawing.Point(189, 35);
            this.cbIsExtractable.Name = "cbIsExtractable";
            this.cbIsExtractable.Size = new System.Drawing.Size(90, 17);
            this.cbIsExtractable.TabIndex = 14;
            this.cbIsExtractable.Text = "Is Extractable";
            this.cbIsExtractable.UseVisualStyleBackColor = true;
            this.cbIsExtractable.CheckedChanged += new System.EventHandler(this.cbIsExtractable_CheckedChanged);
            // 
            // btnClearPivotDimension
            // 
            this.btnClearPivotDimension.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnClearPivotDimension.Location = new System.Drawing.Point(798, 645);
            this.btnClearPivotDimension.Name = "btnClearPivotDimension";
            this.btnClearPivotDimension.Size = new System.Drawing.Size(75, 23);
            this.btnClearPivotDimension.TabIndex = 13;
            this.btnClearPivotDimension.Text = "Clear";
            this.btnClearPivotDimension.UseVisualStyleBackColor = true;
            this.btnClearPivotDimension.Click += new System.EventHandler(this.btnClearPivotDimension_Click);
            // 
            // ddPivotDimension
            // 
            this.ddPivotDimension.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ddPivotDimension.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddPivotDimension.FormattingEnabled = true;
            this.ddPivotDimension.Location = new System.Drawing.Point(82, 647);
            this.ddPivotDimension.Name = "ddPivotDimension";
            this.ddPivotDimension.Size = new System.Drawing.Size(710, 21);
            this.ddPivotDimension.TabIndex = 12;
            this.ddPivotDimension.SelectedIndexChanged += new System.EventHandler(this.ddPivotDimension_SelectedIndexChanged);
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(-1, 650);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(86, 13);
            this.label8.TabIndex = 11;
            this.label8.Text = "Pivot Dimension:";
            // 
            // pCountSql
            // 
            this.pCountSql.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pCountSql.Location = new System.Drawing.Point(82, 363);
            this.pCountSql.Name = "pCountSql";
            this.pCountSql.Size = new System.Drawing.Size(989, 128);
            this.pCountSql.TabIndex = 10;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(23, 362);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 13);
            this.label7.TabIndex = 9;
            this.label7.Text = "Count SQL:";
            // 
            // btnSaveDescriptiveData
            // 
            this.btnSaveDescriptiveData.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSaveDescriptiveData.Enabled = false;
            this.btnSaveDescriptiveData.Location = new System.Drawing.Point(996, 650);
            this.btnSaveDescriptiveData.Name = "btnSaveDescriptiveData";
            this.btnSaveDescriptiveData.Size = new System.Drawing.Size(75, 23);
            this.btnSaveDescriptiveData.TabIndex = 8;
            this.btnSaveDescriptiveData.Text = "Save";
            this.btnSaveDescriptiveData.UseVisualStyleBackColor = true;
            this.btnSaveDescriptiveData.Click += new System.EventHandler(this.btnbtnSaveDescriptiveData_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(21, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID:";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tpDescriptive);
            this.tabControl1.Controls.Add(this.tpDimensions);
            this.tabControl1.Controls.Add(this.tpFilters);
            this.tabControl1.Controls.Add(this.tpSqlPreview);
            this.tabControl1.Controls.Add(this.tpGraph);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1085, 731);
            this.tabControl1.TabIndex = 8;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tpFilters
            // 
            this.tpFilters.Controls.Add(this.aggregateFilterConfigurationTabUI1);
            this.tpFilters.Controls.Add(this.label12);
            this.tpFilters.Location = new System.Drawing.Point(4, 22);
            this.tpFilters.Name = "tpFilters";
            this.tpFilters.Padding = new System.Windows.Forms.Padding(3);
            this.tpFilters.Size = new System.Drawing.Size(1077, 705);
            this.tpFilters.TabIndex = 2;
            this.tpFilters.Text = "Filters";
            this.tpFilters.UseVisualStyleBackColor = true;
            // 
            // aggregateFilterConfigurationTabUI1
            // 
            this.aggregateFilterConfigurationTabUI1.AggregateConfiguration = null;
            this.aggregateFilterConfigurationTabUI1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.aggregateFilterConfigurationTabUI1.Location = new System.Drawing.Point(3, 3);
            this.aggregateFilterConfigurationTabUI1.Name = "aggregateFilterConfigurationTabUI1";
            this.aggregateFilterConfigurationTabUI1.Size = new System.Drawing.Size(1071, 699);
            this.aggregateFilterConfigurationTabUI1.TabIndex = 9;
            // 
            // label12
            // 
            this.label12.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(253, -3133);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(0, 52);
            this.label12.TabIndex = 8;
            this.label12.Text = resources.GetString("label12.Text");
            // 
            // tpSqlPreview
            // 
            this.tpSqlPreview.Location = new System.Drawing.Point(4, 22);
            this.tpSqlPreview.Name = "tpSqlPreview";
            this.tpSqlPreview.Padding = new System.Windows.Forms.Padding(3);
            this.tpSqlPreview.Size = new System.Drawing.Size(1077, 705);
            this.tpSqlPreview.TabIndex = 3;
            this.tpSqlPreview.Text = "SQL Preview";
            this.tpSqlPreview.UseVisualStyleBackColor = true;
            // 
            // tpGraph
            // 
            this.tpGraph.Controls.Add(this.btnSaveGraph);
            this.tpGraph.Controls.Add(this.tbTimeoutOnGraphCreation);
            this.tpGraph.Controls.Add(this.label13);
            this.tpGraph.Controls.Add(this.label14);
            this.tpGraph.Controls.Add(this.btnLoadGraph);
            this.tpGraph.Controls.Add(this.aggregateGraph1);
            this.tpGraph.Location = new System.Drawing.Point(4, 22);
            this.tpGraph.Name = "tpGraph";
            this.tpGraph.Padding = new System.Windows.Forms.Padding(3);
            this.tpGraph.Size = new System.Drawing.Size(1077, 705);
            this.tpGraph.TabIndex = 4;
            this.tpGraph.Text = "Graph";
            this.tpGraph.UseVisualStyleBackColor = true;
            // 
            // btnSaveGraph
            // 
            this.btnSaveGraph.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnSaveGraph.Location = new System.Drawing.Point(6, -3110);
            this.btnSaveGraph.Name = "btnSaveGraph";
            this.btnSaveGraph.Size = new System.Drawing.Size(75, 23);
            this.btnSaveGraph.TabIndex = 4;
            this.btnSaveGraph.Text = "Save Graph";
            this.btnSaveGraph.UseVisualStyleBackColor = true;
            this.btnSaveGraph.Click += new System.EventHandler(this.btnSaveGraph_Click);
            // 
            // tbTimeoutOnGraphCreation
            // 
            this.tbTimeoutOnGraphCreation.Location = new System.Drawing.Point(175, 9);
            this.tbTimeoutOnGraphCreation.Name = "tbTimeoutOnGraphCreation";
            this.tbTimeoutOnGraphCreation.Size = new System.Drawing.Size(153, 20);
            this.tbTimeoutOnGraphCreation.TabIndex = 2;
            this.tbTimeoutOnGraphCreation.Text = "30";
            this.tbTimeoutOnGraphCreation.TextChanged += new System.EventHandler(this.tbTimeoutOnGraphCreation_TextChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(172, 32);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(606, 13);
            this.label13.TabIndex = 1;
            this.label13.Text = "(Depending on the complexity of your aggregate and the indexes/fragmentation of y" +
    "our database design this might take a while)";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(121, 12);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(48, 13);
            this.label14.TabIndex = 1;
            this.label14.Text = "Timeout:";
            // 
            // btnLoadGraph
            // 
            this.btnLoadGraph.Location = new System.Drawing.Point(3, 6);
            this.btnLoadGraph.Name = "btnLoadGraph";
            this.btnLoadGraph.Size = new System.Drawing.Size(113, 23);
            this.btnLoadGraph.TabIndex = 0;
            this.btnLoadGraph.Text = "Load Graph";
            this.btnLoadGraph.UseVisualStyleBackColor = true;
            this.btnLoadGraph.Click += new System.EventHandler(this.btnLoadGraph_Click);
            // 
            // aggregateGraph1
            // 
            this.aggregateGraph1.AggregateConfiguration = null;
            this.aggregateGraph1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.aggregateGraph1.BackColor = System.Drawing.Color.White;
            this.aggregateGraph1.Location = new System.Drawing.Point(6, 48);
            this.aggregateGraph1.Name = "aggregateGraph1";
            this.aggregateGraph1.RepositoryLocator = null;
            this.aggregateGraph1.Size = new System.Drawing.Size(1065, 654);
            this.aggregateGraph1.TabIndex = 3;
            // 
            // AggregateConfigurationUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tabControl1);
            this.Name = "AggregateConfigurationUI";
            this.Size = new System.Drawing.Size(1085, 731);
            this.Load += new System.EventHandler(this.AggregateConfigurationUI_Load);
            this.tpDimensions.ResumeLayout(false);
            this.tpDescriptive.ResumeLayout(false);
            this.tpDescriptive.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tpFilters.ResumeLayout(false);
            this.tpGraph.ResumeLayout(false);
            this.tpGraph.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox tbID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbCreated;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbName;
        private System.Windows.Forms.TextBox tbDescription;
        private System.Windows.Forms.TabPage tpDimensions;
        private System.Windows.Forms.TabPage tpDescriptive;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.Button btnSaveDescriptiveData;
        private System.Windows.Forms.TabPage tpFilters;
        private System.Windows.Forms.TabPage tpSqlPreview;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel pCountSql;
        private System.Windows.Forms.ComboBox ddPivotDimension;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnClearPivotDimension;
        private System.Windows.Forms.CheckBox cbIsExtractable;
        private System.Windows.Forms.TabPage tpGraph;
        private System.Windows.Forms.TextBox tbTimeoutOnGraphCreation;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btnLoadGraph;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnSaveGraph;
        private AggregateGraph aggregateGraph1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button btnConfigureDeclareParameters;
        private AggregateDimensionManagementTabUI aggregateDimensionManagementTabUI1;
        private AggregateFilterConfigurationTabUI aggregateFilterConfigurationTabUI1;
        private Panel pHavingSQL;
        private Label label5;
    }
}

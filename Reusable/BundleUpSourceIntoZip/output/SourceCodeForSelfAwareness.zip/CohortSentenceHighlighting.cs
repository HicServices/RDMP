using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CohortManagerLibrary.FreeText.Paragraphing;
using CohortManagerLibrary.FreeText.Sentencing;
using ReusableUIComponents;

namespace CohortManager.UserFriendly
{
    public class CohortSentenceHighlighting
    {
        public Dictionary<Enum, Color> HighlightValues = new Dictionary<Enum, Color>();

        public CohortSentenceHighlighting()
        {
            HighlightValues.Add(SentenceSectionType.Catalogue, Color.Blue);
            HighlightValues.Add(SentenceSectionType.Filter, Color.ForestGreen);
            HighlightValues.Add(SentenceSectionType.FilterContainerOperation, Color.Brown);
            HighlightValues.Add(SentenceSectionType.FilterParameter, Color.LightPink);
            HighlightValues.Add(SentenceSectionType.FilterParameterValue, Color.HotPink);

            HighlightValues.Add(SentenceSectionType.GlobalParameter, Color.LightPink);
            HighlightValues.Add(SentenceSectionType.GlobalParameterValue, Color.HotPink);

            HighlightValues.Add(ParagraphSectionType.SetOperation, Color.PowderBlue);
        }


        public Color GetColorFor(SentenceSectionType type)
        {
            return HighlightValues[type];
        }
        public Color GetColorFor(ParagraphSectionType type)
        {
            if(type == ParagraphSectionType.Sentence)
                throw new NotSupportedException("Do not pass ParagraphSectionType.Sentence, instead pass the bit of the sentence you have encountered and want to render");

            return HighlightValues[type];
        }

        public System.Windows.Media.Color GetWPFColorFor(SentenceSectionType e)
        {
            Color formsColor = HighlightValues[e];
            return System.Windows.Media.Color.FromRgb(formsColor.R, formsColor.G, formsColor.B);
        }

        public System.Windows.Media.Color GetWPFColorFor(ParagraphSectionType e)
        {
            Color formsColor = HighlightValues[e];
            return System.Windows.Media.Color.FromRgb(formsColor.R, formsColor.G, formsColor.B);
        }

    }
}

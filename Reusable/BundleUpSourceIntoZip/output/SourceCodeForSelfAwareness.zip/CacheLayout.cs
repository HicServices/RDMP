using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using CatalogueLibrary.Data.DataLoad;
using ICSharpCode.SharpZipLib.Tar;

namespace CatalogueLibrary.Data.Cache
{
    public class CacheLayout : ICacheLayout
    {
        public ILoadCachePathResolver Resolver { get; set; }
        public string DateFormat { get; set; }
        public CacheArchiveType ArchiveType { get; set; }
        public virtual DirectoryInfo RootDirectory { get; protected set; }

        public virtual DateTime? GetMostRecentDateToLoadAccordingToFilesystem()
        {
            throw new NotImplementedException();
        }

        public virtual void CreateIfNotExists()
        {
            var downloadDirectory = Resolver.GetLoadCacheDirectory(RootDirectory);
            if (!downloadDirectory.Exists)
                downloadDirectory.Create();
        }

        public virtual void Cleanup()
        {
            throw new NotImplementedException();
        }

        public virtual bool CheckExists(DateTime archiveDate)
        {
            return GetArchiveFileInfoForDate(archiveDate).Exists;
        }

        public virtual string GetArchiveFilepathForDate(DateTime archiveDate)
        {
            var loadCacheDirectory = GetLoadCacheDirectory();
            var filename = archiveDate.ToString(DateFormat) + "." + ArchiveType.ToString().ToLower();
            return Path.Combine(loadCacheDirectory.FullName, filename);
        }

        public virtual FileInfo GetArchiveFileInfoForDate(DateTime archiveDate)
        {
            return new FileInfo(GetArchiveFilepathForDate(archiveDate));
        }

        /// <summary>
        /// The cache sub-directory for a particular load schedule within a load metadata. Uses a resolver for dataset-specific cache layout knowledge
        /// </summary>
        /// <returns></returns>
        public virtual DirectoryInfo GetLoadCacheDirectory()
        {
            Contract.Requires<InvalidOperationException>(Resolver != null, "No Resolver (ILoadCachePathResolver) has been set.");
            var downloadDirectory = Resolver.GetLoadCacheDirectory(RootDirectory);
            return downloadDirectory.Exists ? downloadDirectory : Directory.CreateDirectory(downloadDirectory.FullName);
        }

        public virtual void CreateArchive(DateTime archiveDate)
        {
            throw new NotImplementedException();
        }

        public virtual void ValidateLayout()
        {
            throw new NotImplementedException();
        }

        private IEnumerable<FileInfo> GetArchiveFilesInLoadCacheDirectory()
        {
            var disciplineRoot = GetLoadCacheDirectory();
            return disciplineRoot.EnumerateFiles("*." + ArchiveType);
        }

        private IEnumerable<DateTime> GetDateListFromArchiveFilesInLoadCacheDirectory()
        {
            // remove the extension
            return GetArchiveFilesInLoadCacheDirectory()
                .Select(info => DateTime.ParseExact(Path.GetFileNameWithoutExtension(info.Name), DateFormat, CultureInfo.InvariantCulture));
        }

        public virtual Queue<DateTime> GetSortedDateQueue()
        {
            var dateList = GetDateListFromArchiveFilesInLoadCacheDirectory().ToList();
            dateList.Sort();

            return new Queue<DateTime>(dateList);
        }

        public bool CheckCacheFilesAvailability()
        {
            return GetArchiveFilesInLoadCacheDirectory().Any();
        }

        public DateTime? GetEarliestDateToLoadAccordingToFilesystem()
        {
            var dateList = GetDateListFromArchiveFilesInLoadCacheDirectory().ToList();

            if (!dateList.Any())
                return null;

            dateList.Sort();
            return dateList[0];
        }

        protected void ArchiveFiles(FileInfo[] files, DateTime archiveDate)
        {
            if (!files.Any()) return;

            var archiveFilepath = GetArchiveFilepathForDate(archiveDate);
            var archiveDirectory = new FileInfo(archiveFilepath).DirectoryName;
            if (archiveDirectory == null)
                throw new Exception("The directory for the archive within the cache is being reported as null, which should not be possible.");

            if (!Directory.Exists(archiveDirectory))
                Directory.CreateDirectory(archiveDirectory);

            // todo: should control whether using existing files is allowed or whether should throw if we the archive already exists
            var zipArchiveMode = File.Exists(archiveFilepath) ? ZipArchiveMode.Update : ZipArchiveMode.Create;
            if (ArchiveType == CacheArchiveType.Zip)
                using (var zipArchive = ZipFile.Open(archiveFilepath, zipArchiveMode))
                {
                    // Entries can't be inspected if the zip archive has been opened in create mode
                    if (zipArchiveMode == ZipArchiveMode.Update)
                    {
                        var entries = zipArchive.Entries;
                        // don't add an entry where one already exists for a particular dataFile
                        foreach (var dataFile in files.Where(dataFile => entries.All(e => e.Name != dataFile.Name)))
                        {
                            zipArchive.CreateEntryFromFile(dataFile.FullName, dataFile.Name, CompressionLevel.Optimal);
                        }
                    }
                    else
                    {
                        // We are creating a new file, so don't have to check for the existence of entries.
                        foreach (var dataFile in files)
                        {
                            zipArchive.CreateEntryFromFile(dataFile.FullName, dataFile.Name, CompressionLevel.Optimal);
                        }
                        
                    }
                }
            else
                using (var tarArchive = TarArchive.CreateOutputTarArchive(new FileStream(archiveFilepath, FileMode.CreateNew)))
                {
                    // RootPath is case-sensitive *and* requires forward slashes!
                    tarArchive.RootPath = archiveDirectory.Replace(@"\", @"/");
                    foreach (var item in files)
                    {
                        var entry = TarEntry.CreateEntryFromFile(item.FullName);
                        tarArchive.WriteEntry(entry, true);
                    }
                }
        }
    }
}

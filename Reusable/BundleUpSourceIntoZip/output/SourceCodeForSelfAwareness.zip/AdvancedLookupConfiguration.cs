using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

using CatalogueLibrary.Data;
using CatalogueLibrary.DataHelper;
using CatalogueLibrary.Repositories;
using CatalogueManager.Properties;
using MapsDirectlyToDatabaseTable;
using RDMPObjectVisualisation;
using ReusableLibraryCode;
using ReusableUIComponents;

namespace CatalogueManager.ExtractionUIs
{
    /// <summary>
    /// Allows you to rapidly import and configure lookup table relationships into the RDMP.  This has two benefits, firstly lookup tables will be automatically included in project extracts
    /// of the dataset you are editting.  Secondly lookup columns will be available for inclusion directly into the extraction on a per row basis (for researchers who can't deal with having
    /// to lookup the meaning of codes in seperate files).
    /// 
    /// Start by identifying a lookup table and click Import Lookup.  Then drag the primary key of the lookup into the PrimaryKey box.  Then drag the description column of the lookup onto the
    /// Foreign key field in the dataset you are modifying.  If you have multiple foreign keys (e.g. two columns SendingLocation and DischargeLocation both of which are location codes) then 
    /// join them both up (this will give you two lookup description fields SendingLocation_Desc and DischargeLocation_Desc).  
    /// 
    /// All Lookups and Lookup column description configurations are artifacts in the RDMP database and no actual changes will take place on your data repository. 
    /// </summary>
    public partial class AdvancedLookupConfiguration : BetterToolTipForm
    {
        private readonly Catalogue _catalogue;
        private readonly CatalogueRepository _catalogueRepository;

        object oCurrentlySelectedLookup_Lock = new object();

        List<Lookup> _currentlyConfiguredLookups = new List<Lookup>();

        

        //constructor
        public AdvancedLookupConfiguration(Catalogue catalogue)
        {
            _catalogue = catalogue;
            
            InitializeComponent();
            
            if (catalogue == null)
                return;

            _catalogueRepository = (CatalogueRepository)catalogue.Repository;
            serverDatabaseTableSelector1.AllowTableValuedFunctionSelection = false;

            //add the currently configured extraction informations in the order they appear in the dataset
            List<ExtractionInformation> allExtractionInformationFromCatalogue = new List<ExtractionInformation>(_catalogue.GetAllExtractionInformation(ExtractionCategory.Any));
            allExtractionInformationFromCatalogue.Sort();
            lbExtractionInformation.Items.AddRange(allExtractionInformationFromCatalogue.ToArray());
            
            RefreshUIFromDatabase();
            
            RecentHistoryOfControls.GetInstance().HostControl(serverDatabaseTableSelector1.cbxServer);
            RecentHistoryOfControls.GetInstance().AddHistoryAsItemsToComboBox(serverDatabaseTableSelector1.cbxServer);
        }

        private void RefreshUIFromDatabase()
        {
            List<TableInfo> seenBefore = new List<TableInfo>();
            lbLookupsAssociatedWithCatalogue.Items.Clear();
            
            

            foreach (ExtractionInformation extractionInformation in lbExtractionInformation.Items)
                foreach (Lookup lookup in extractionInformation.ColumnInfo.GetAllLookupForColumnInfoWhereItIsA(LookupType.ForeignKey))
                    if (!seenBefore.Any(l => l.ID == lookup.PrimaryKey.TableInfo_ID)) // dont double add
                    {
                        var toAdd = lookup.PrimaryKey.TableInfo;
                        seenBefore.Add(toAdd);
                        lbLookupsAssociatedWithCatalogue.Items.Add(toAdd);
                    }
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            BetterToolTip.SetToolTip(this, ToolTips.ConfigureLookups, Images.ConfigureLookups);
        }


        private void lbLookupsAssociatedWithCatalogue_SelectedIndexChanged(object sender, EventArgs e)
        {
            SetCurrentlySelectedLookupTable(lbLookupsAssociatedWithCatalogue.SelectedItem as TableInfo);
        }

        /// <summary>
        /// User has selected a new lookup table so show him the columns in that lookup table and setup the dictionary so that 
        /// we can draw existing relationships onto the UI.
        /// </summary>
        /// <param name="tableInfo"></param>
        private void SetCurrentlySelectedLookupTable(TableInfo tableInfo)
        {
            lock (oCurrentlySelectedLookup_Lock)
            {

                //clear old mappings
                clbCurrentlySelectedLookupTableColumns.Items.Clear();
                _currentlyConfiguredLookups.Clear();

                //primary key info for lookup
                SetLookupPrimaryKeyOnUI(null);

                
                //get new mappings
                if (tableInfo != null)
                {
                    //get all the lookup columns
                    ColumnInfo[] allColumnInfosInLookup = tableInfo.ColumnInfos.ToArray();

                    //add them to the checked list box representing the lookups
                    clbCurrentlySelectedLookupTableColumns.Items.AddRange(allColumnInfosInLookup);
                    
                    foreach (TableInfo catalogueTable in GetAllTableInfosInCatalogue())
                    {
                        //if we are not looking at a LookupDescription already!
                        if(catalogueTable.ID != tableInfo.ID)
                             _currentlyConfiguredLookups.AddRange(Lookup.GetAllLookupsBetweenTables(catalogueTable, tableInfo));
                    } 
                }

                //set the primary key to the first primary key defined in the lookup collection (there should all be the same!)
                if (_currentlyConfiguredLookups.Any())
                    SetLookupPrimaryKeyOnUI(_currentlyConfiguredLookups[0].PrimaryKey);

                //we changed highlighting so invalidate the UI
                lbExtractionInformation.Invalidate();
             
            }
        }

        private void SetLookupPrimaryKeyOnUI(ColumnInfo primaryKey)
        {
            tbPrimaryKey.Text = primaryKey == null ? "":primaryKey.ToString();
            tbPrimaryKey.Tag = primaryKey;
        }

        private IEnumerable<TableInfo> GetAllTableInfosInCatalogue()
        {
            HashSet<int> TableIDsSeen = new HashSet<int>();

            foreach (ExtractionInformation extractionInformation in lbExtractionInformation.Items)
                if (TableIDsSeen.Add(extractionInformation.ColumnInfo.TableInfo_ID))
                    yield return extractionInformation.ColumnInfo.TableInfo;
        }

        private void lbExtractionInformation_DrawItem(object sender, DrawItemEventArgs e)
        {
            lock (oCurrentlySelectedLookup_Lock)
            {
                if (e.Index != -1)
                {

                    e.DrawBackground();
                    Graphics g = e.Graphics;

                    // draw the background color you want
                    // mine is set to olive, change it to whatever you want
                    g.FillRectangle(new SolidBrush(e.BackColor), e.Bounds);
                     
                    if (e.Index != -1)
                    {
                        ExtractionInformation toDrawExtractionInformation =(ExtractionInformation)(sender as ListBox).Items[e.Index];

                        //if the current listbox item we are drawing is the primary key of the currently selected lookup draw it red
                        if (_currentlyConfiguredLookups.Any(l => l.ForeignKey.ID == toDrawExtractionInformation.ColumnInfo.ID))
                            g.DrawString(toDrawExtractionInformation.ToString(), e.Font, new SolidBrush(Color.Blue), new PointF(e.Bounds.X, e.Bounds.Y)); // is the foreign key for the currently selected lookup
                        else
                        if(_currentlyConfiguredLookups.Any(l => l.Description.ID == toDrawExtractionInformation.ColumnInfo.ID))
                            g.DrawString(toDrawExtractionInformation.ToString(), e.Font, new SolidBrush(Color.LightBlue), new PointF(e.Bounds.X, e.Bounds.Y)); //is a description in currently selected Lookup
                        else
                            g.DrawString(toDrawExtractionInformation.ToString(), e.Font, new SolidBrush(e.ForeColor), new PointF(e.Bounds.X, e.Bounds.Y)); //draw normal because not a description
                      
                    }


                    e.DrawFocusRectangle();
                }
            }
        }

        private void clbCurrentlySelectedLookupTableColumns_MouseDown(object sender, MouseEventArgs e)
        {
            if (this.clbCurrentlySelectedLookupTableColumns.SelectedItem == null) return;

            this.clbCurrentlySelectedLookupTableColumns.DoDragDrop(this.clbCurrentlySelectedLookupTableColumns.SelectedItem, DragDropEffects.Copy);
        }

        #region allow dropping on text box primary key and creating new Description Maps
        private void tbPrimaryKey_DragOver(object sender, DragEventArgs e)
        {
            if(e.Data.GetDataPresent(typeof(ColumnInfo)))
                e.Effect = DragDropEffects.Copy;
            else
                e.Effect = DragDropEffects.None;
        }

        private void tbPrimaryKey_DragDrop(object sender, DragEventArgs e)
        {
            SetLookupPrimaryKeyOnUI(e.Data.GetData(typeof(ColumnInfo)) as ColumnInfo);
        }

        private void lbExtractionInformation_DragEnter(object sender, DragEventArgs e)
        {
            if(e.Data.GetDataPresent(typeof(ColumnInfo)))
                e.Effect = DragDropEffects.Copy;
            else
                e.Effect = DragDropEffects.None;
        }

        private void lbExtractionInformation_DragDrop(object sender, DragEventArgs e)
        {
            ColumnInfo data = e.Data.GetData(typeof(ColumnInfo)) as ColumnInfo;

            if (data != null)
            {
                int idxDropTarget = lbExtractionInformation.IndexFromPoint(lbExtractionInformation.PointToClient(new Point(e.X, e.Y)));
                
                if(idxDropTarget <0)
                    return;

                ExtractionInformation dropTargetExtractionInformation = lbExtractionInformation.Items[idxDropTarget] as ExtractionInformation; 

                //create a new lookup where the dragged column is the description, the item it is dropped on is the foregin key and the primary key
                ColumnInfo lookupTablePrimaryKey = tbPrimaryKey.Tag as ColumnInfo;

                if (lookupTablePrimaryKey == null)
                {
                    MessageBox.Show("You must set the Lookup Primary Key");
                    return;
                }

               
                //tell them about the lookup we are about to create
                if(
                    cbStopPesteringMeWithDialogues.Checked
                    ||
                    MessageBox.Show("Create new Lookup description (and CatalogueItem,ExtractionInformation):" + Environment.NewLine +
                                   "Foreign Key:" + dropTargetExtractionInformation.ColumnInfo + Environment.NewLine +
                                   "Primary Key:" + lookupTablePrimaryKey + Environment.NewLine +
                                   "Description Field:" + data + Environment.NewLine ,"Create new Lookup?",MessageBoxButtons.YesNo) == DialogResult.Yes)
                {

                    CreateNewLookupAssocation(data, dropTargetExtractionInformation, lookupTablePrimaryKey,idxDropTarget+1);

                    SaveOrderOfExtractionInformations();

                    RefreshUIFromDatabase();
                    
                }
            }
        }

        private void CreateNewLookupAssocation(ColumnInfo lookupTableDescription, ExtractionInformation catalogueForeignKeyAsExtractionInformation, ColumnInfo lookupTablePrimaryKey,int positionToInsertAtInListbox)
        {
            //things we are going to try and create
            CatalogueItem newCatalogueItem = null;
            ExtractionInformation newExtractionInformation;

            try
            {
                new Lookup(_catalogueRepository,lookupTableDescription, catalogueForeignKeyAsExtractionInformation.ColumnInfo, lookupTablePrimaryKey, ExtractionJoinType.Left, tbCollation.Text);
            }
            catch (Exception exception)
            {
                MessageBox.Show("Problem creating Lookup:" + exception.Message);
                return;
            }

            try
            {
                //add a new CatalogueItem, ExtractionInformation to accompany it
                
                newCatalogueItem = new CatalogueItem(_catalogueRepository, _catalogue,catalogueForeignKeyAsExtractionInformation.CatalogueItem.Name + "_Desc");
            }
            catch (Exception exception)
            {
                MessageBox.Show("Succesfully created Lookup link but occured problem creating a new CatalogueItem for the Lookup Description field:" + exception.Message);
                return;
            }

            try
            {
                newExtractionInformation = new ExtractionInformation(_catalogueRepository, newCatalogueItem, lookupTableDescription, lookupTableDescription.ToString());
                newExtractionInformation.ExtractionCategory = ExtractionCategory.Supplemental;
                newExtractionInformation.Alias = newCatalogueItem.Name;
                
                newExtractionInformation.SaveToDatabase();
            }
            catch (Exception e)
            {
                MessageBox.Show(
                    "Succesfully created lookup and a new CatalogueItem for the lookup description but problem occurred associating the two and marking them as extractable:" +
                    e.Message);
                return;
            }

            lbExtractionInformation.Items.Insert(positionToInsertAtInListbox, newExtractionInformation);

          
        }

        private void SaveOrderOfExtractionInformations()
        {
            for (int i = 0; i < lbExtractionInformation.Items.Count; i++)
            {
                ExtractionInformation info = (ExtractionInformation)lbExtractionInformation.Items[i];
                info.Order = i;
                info.SaveToDatabase();
            }
        }

        #endregion

        private void btnImportLookup_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(serverDatabaseTableSelector1.Table))
            {
                MessageBox.Show("You must select a table first");
                return;
            }

            TableInfo alreadyExistingTable =
                _catalogue.Repository.GetAllObjects<TableInfo>()
                    .FirstOrDefault(
                        t =>
                            t.GetDatabaseRuntimeName().Equals(serverDatabaseTableSelector1.Database) &&
                            t.GetRuntimeName().Equals(serverDatabaseTableSelector1.Table));
                
            //user dragged a table onto the panel that has already been imported
            if (alreadyExistingTable != null)
            {
                //AND it is already associated with the table!
                if (lbLookupsAssociatedWithCatalogue.Items.Cast<TableInfo>().Any(t => t.ID == alreadyExistingTable.ID))
                {
                    MessageBox.Show("That table is already associated as a lookup");
                    return;
                }
                else
                {
                    //its not associated yet but it is already in the database so create a soft association with it (it appears on UI so they can create new Lookup) associations 
                    //but there isn't anything actually tying them together yet and if they close the UI and reopen it then it will be gone
                    lbLookupsAssociatedWithCatalogue.Items.Add(alreadyExistingTable);
                    return;
                }
            }

            try
            {
                //if we get here then we know they dragged and dropped a table with a unique name so lets import it and then make it available for creating new Lookups
                TableInfoImporter tableInfoImporter = new TableInfoImporter(_catalogueRepository, serverDatabaseTableSelector1.Server, serverDatabaseTableSelector1.Database, serverDatabaseTableSelector1.Table, serverDatabaseTableSelector1.DatabaseType, username: serverDatabaseTableSelector1.Username, password: serverDatabaseTableSelector1.Password);

                TableInfo toAddLookup;
                ColumnInfo[] ignored;

                tableInfoImporter.DoImport(out toAddLookup, out ignored);
                lbLookupsAssociatedWithCatalogue.Items.Add(toAddLookup);
            }
            catch (Exception exception)
            {
                MessageBox.Show("Could not import TableInfo:" + exception.Message);
            }
        }

    }
}

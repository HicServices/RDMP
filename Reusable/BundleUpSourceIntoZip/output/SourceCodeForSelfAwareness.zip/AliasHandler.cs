using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading;
using CatalogueLibrary.Data;
using CatalogueLibrary.DataFlowPipeline;
using LoadModules.Generic.DataFlowOperations.Aliases.Exceptions;
using ReusableLibraryCode;
using ReusableLibraryCode.Checks;
using ReusableLibraryCode.DataAccess;
using ReusableLibraryCode.Progress;

namespace LoadModules.Generic.DataFlowOperations.Aliases
{
    public class AliasHandler : IPluginDataFlowComponent<DataTable>
    {
        [DemandsInitialization("The server that will be connected to to fetch the alias resolution table", Mandatory = true)]
        public ExternalDatabaseServer ServerToExecuteQueryOn { get; set; }

        [DemandsInitialization("The context under which to connect to the server, if unsure just select DataAccessContext.DataLoad (this only matters if you have encrypted logon credentials configured on a per context level)", DemandType.Unspecified, DataAccessContext.DataLoad)]
        public DataAccessContext DataAccessContext { get; set; }

        [DemandsInitialization("A fully specified SQL Select query to execute on ServerToExecuteQueryOn, this should result in the alias table.  The alias table must have only 2 columns.  The first column must match a column name in the input DataTable.  The second column must contain a known aliases which is different from the first column value.", DemandType.SQL, Mandatory = true)]
        public string AliasTableSQL { get; set; }

        [DemandsInitialization("Maximum amount of time in seconds to let the AliasTableSQL execute for before giving up",DemandType.Unspecified,120)]
        public int TimeoutForAssemblingAliasTable { get; set; }

        [DemandsInitialization("Strategy for dealing with aliases in DataTables")]
        public AliasResolutionStrategy ResolutionStrategy { get; set; }

        [DemandsInitialization("The name of the input column name in pipeline data (which must exist!) which contains the aliasable values.  This is probably your patient identifier column.", Mandatory = true)]
        public string AliasColumnInInputDataTables { get; set; }

        public DataTable ProcessPipelineData(DataTable toProcess, IDataLoadEventListener listener,GracefulCancellationToken cancellationToken)
        {
            List<object[]> newRows = new List<object[]>();

            if(_aliasDictionary == null)
                _aliasDictionary = GenerateAliasTable(TimeoutForAssemblingAliasTable);

            var idx = toProcess.Columns.IndexOf(AliasColumnInInputDataTables);

            if(idx == -1)
                throw new KeyNotFoundException("You asked to resolve aliases on a column called '" + AliasColumnInInputDataTables + "' but no column by that name appeared in the DataTable being processed.  Columns in that table were:" + string.Join(",",toProcess.Columns.Cast<DataColumn>().Select(c=>c.ColumnName)));

            var elements = toProcess.Columns.Count;

            int matchesFound = 0;
            
            foreach (DataRow r in toProcess.Rows)
            {
                if(_aliasDictionary.ContainsKey(r[AliasColumnInInputDataTables]))
                {
                    matchesFound++;
                    switch (ResolutionStrategy)
                    {
                        case AliasResolutionStrategy.CrashIfAliasesFound:
                            throw new AliasException("Found Alias in input data and ResolutionStrategy is " + ResolutionStrategy + ", aliased value was " + r[AliasColumnInInputDataTables]);

                        case AliasResolutionStrategy.MultiplyInputDataRowsByAliases:
                            
                            //Get all aliases for the input value
                            foreach (object alias in _aliasDictionary[r[AliasColumnInInputDataTables]])
                            {
                                //Create a copy of the input row
                                object[] newRow = new object[elements];
                                r.ItemArray.CopyTo(newRow,0);

                                //Set the aliasable element to the alias
                                newRow[idx] = alias;

                                //Add it to our new rows collection
                                newRows.Add(newRow);
                            }
                            
                            break;
                        default:
                            throw new ArgumentOutOfRangeException();
                    }
                }
            }

            if (newRows.Any())
                listener.OnNotify(this, new NotifyEventArgs(ProgressEventType.Warning, "Found " + matchesFound + " aliased input values, resolved by adding " +  newRows.Count + " additional duplicate rows to the dataset"));
            else
                listener.OnNotify(this, new NotifyEventArgs(ProgressEventType.Information, "No Aliases found for identifiers in column " + AliasColumnInInputDataTables));
            
            foreach (object[] newRow in newRows)
                toProcess.Rows.Add(newRow);

            return toProcess;
        }

        public void Dispose(IDataLoadEventListener listener, Exception pipelineFailureExceptionIfAny)
        {
            if (_aliasDictionary != null)
                _aliasDictionary.Clear();//Free up memory
        }

        public void Abort(IDataLoadEventListener listener)
        {
            
        }

        public void Check(ICheckNotifier notifier)
        {
            int timeout = 5;
            try
            {
                var result = GenerateAliasTable(timeout);
                notifier.OnCheckPerformed(new CheckEventArgs("Found " + result.Count + " aliases",CheckResult.Success));
            }
            catch (Exception e)
            {
                var isTimeout = e.Message.ToLower().Contains("timeout");
                notifier.OnCheckPerformed(new CheckEventArgs("Failed to generate alias table after " + timeout + "s",isTimeout ? CheckResult.Warning : CheckResult.Fail, e));
            }
            
        }

        private Dictionary<object, List<object>> _aliasDictionary;

        private Dictionary<object, List<object>> GenerateAliasTable(int timeoutInSeconds)
        {
            const string expectation = "(expected the query to return 2 columns, the first one being the input column the second being known aliases)";
            
            var toReturn = new Dictionary<object, List<object>>();

            var server = DataAccessPortal.GetInstance().ExpectServer(ServerToExecuteQueryOn, DataAccessContext);

            using (var con = server.GetConnection())
            {
                con.Open();

                var cmd = server.GetCommand(AliasTableSQL, con);
                cmd.CommandTimeout = timeoutInSeconds;

                var r = cmd.ExecuteReader();

                bool haveCheckedColumns = false;

                while (r.Read())
                {
                    if (!haveCheckedColumns)
                    {
                        int idx;

                        try
                        {
                            idx = r.GetOrdinal(AliasColumnInInputDataTables);
                        }
                        catch (IndexOutOfRangeException)
                        {
                            throw new AliasTableFetchException("Alias table did not contain a column called '" + AliasColumnInInputDataTables + "' " + expectation);
                        }

                        if(idx == -1)
                        {
                            throw new AliasTableFetchException("Alias table did not contain a column called '" + AliasColumnInInputDataTables + "' " + expectation);
                        }

                        if(idx != 0)
                            throw new AliasTableFetchException("Alias table DID contain column '" + AliasColumnInInputDataTables + "' but it was not the first column in the result set " + expectation);

                        if(r.FieldCount != 2)
                            throw new AliasTableFetchException("Alias table SQL resulted in " + r.FieldCount + " fields being returned, we expect exactly 2 " + expectation);

                        haveCheckedColumns = true;
                    }

                    object input = r[0];
                    object alias = r[1];
                    
                    if(input == null || input == DBNull.Value || alias == null || alias == DBNull.Value)
                        throw new AliasTableFetchException("Alias table contained nulls");

                    if(input.Equals(alias))
                        throw new AliasTableFetchException("Alias table SQL should only return aliases not exact matches e.g. in the case of a simple alias X is Y, do not return 4 rows {X=X AND Y=Y AND Y=X AND X=Y}, only return 2 rows {X=Y and Y=X}");

                    if (!toReturn.ContainsKey(input))
                        toReturn.Add(input, new List<object>());

                    toReturn[input].Add(alias);
                }
            }

            return toReturn;

        }

    }
}

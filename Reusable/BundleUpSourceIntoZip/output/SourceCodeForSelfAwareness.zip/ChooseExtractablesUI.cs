using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using BrightIdeasSoftware;
using CatalogueLibrary.Data;
using CatalogueManager.ExtractionUIs;
using DataExportManager2.Interfaces.Data.DataTables;
using DataExportManager2.Interfaces.ExtractionTime.UserPicks;
using DataExportManager2Library.Data.DataTables;
using DataExportManager2Library.ExtractionTime.UserPicks;
using ReusableUIComponents;

namespace DataExportManager2.ProjectUI
{
    public delegate void BundleSelectedHandler(object sender,ExtractableDatasetBundle bundle);
    
    /// <summary>
    /// Part of ExecuteExtractionUI.  This control allows you to select which datasets, extractable attachments (See SupportingDocumentsViewer), custom data (See ImportCustomDataFileUI)
    /// and Lookups (See ConfigureLookups) you want to execute on this pass.  You can only select datasets etc which are part of the currently executing project configuration (See 
    /// ExecuteExtractionUI).
    /// 
    /// All artifacts are extracted in parallel into the data extraction directory of the project (in a subfolder for the configuration).  This execution will override any files it finds
    /// for previous executions of the same dataset but will not delete unticked datasets.  This allows you to run an extraction overnight of half the datasets and then do the other half
    /// the next night.
    /// </summary>
    public partial class ChooseExtractablesUI : UserControl
    {
        private const string Globals = "Globals";
        private const string Bundles = "Datasets";
        private const string CustomTables = "Custom Tables";//these are cohort custom tables - random stuff the user has uploaded for attached to a given cohort e.g. questionnaire data etc 

        public event BundleSelectedHandler BundleSelected;

        private GlobalsBundle _lastDispatchedGlobalsBundle = null;

        private Dictionary<string, List<object>> Categories = new Dictionary<string, List<object>>();
        
        public ChooseExtractablesUI()
        {
            InitializeComponent();

            // Set a watermark in the bottom right of the control
            tlvDatasets.SetNativeBackgroundWatermark(DataExportManagerUIImages.ExtractionBackdrop);

            tlvDatasets.RowFormatter+= RowFormatter;
        }

        private void RowFormatter(OLVListItem olvItem)
        {
            var eds = olvItem.RowObject as ExtractableDataSet;
            var bundle = olvItem.RowObject as ExtractableDatasetBundle;

            if (eds != null && eds.DisableExtraction)
                olvItem.ForeColor = Color.Red;

            if(bundle != null && bundle.DataSet.DisableExtraction)
                olvItem.ForeColor = Color.Red;

        }

        public ListView.ListViewItemCollection Items {get { return tlvDatasets.Items; }
        }

        public ExtractableDatasetBundle[] CheckedExtractableDatasets
        {
            get
            {
                var bundles = Categories[Bundles].OfType<ExtractableDatasetBundle>().ToList();


                var toReturn = new List<ExtractableDatasetBundle>();

                foreach (ExtractableDatasetBundle bundle in bundles)
                    if (tlvDatasets.IsChecked(bundle)) //entire bundle is checked
                        toReturn.Add(bundle);
                    else 
                        if (tlvDatasets.IsCheckedIndeterminate(bundle)) //half the dataset is checked
                        {
                            //remove unticked stuff
                            foreach (var content in bundle.Contents.ToArray()) //for each bit of content in the bundle
                                if (!tlvDatasets.IsChecked(content)) //if it is not checked
                                    bundle.DropContent(content); //remove it
                            
                            //then add the refined bundle
                            toReturn.Add(bundle);
                        }


                return toReturn.ToArray();
            }
        }

        public void Setup(IExtractableDataSet[] _toExtract, IExtractableCohort _extractableCohort)
        {
            olvColumn1.ImageGetter += ImageGetter;
            
            //todo could move this into a DatasetBundleFactory?
            Categories.Add(Globals, new List<object>());
            Categories.Add(Bundles, new List<object>());
            Categories.Add(CustomTables, new List<object>());

            //find all the things that are available for extraction
            //get all the custom tables
            Categories[CustomTables].AddRange(_extractableCohort.GetCustomTableNames().Select(name=>new ExtractableCohortCustomTablePair(_extractableCohort,name)));

            bool firstTime = true;

            foreach (ExtractableDataSet extractableDataSet in _toExtract)
            {
                Catalogue catalogue = extractableDataSet.Catalogue;

                //get all extractable locals AND extractable globals first time then just extractable locals
                var docs = catalogue.GetAllSupportingDocuments( firstTime ? FetchOptions.ExtractableGlobalsAndLocals : FetchOptions.ExtractableLocals);
                
                //add globals to the globals category
                Categories[Globals].AddRange(docs.Where(d=>d.IsGlobal));

                var sqls = catalogue.GetAllSupportingSQLTablesForCatalogue(firstTime ? FetchOptions.ExtractableGlobalsAndLocals : FetchOptions.ExtractableLocals);
                
                //add global SQLs to globals category
                Categories[Globals].AddRange(sqls.Where(sql=>sql.IsGlobal));

                //Now find all the lookups and include them into the bundle
                List<TableInfo> lookupsFound;
                List<TableInfo> normalTablesFound;
                catalogue.GetTableInfos(out normalTablesFound, out lookupsFound);

                //bundle consists of:
                var bundle = new ExtractableDatasetBundle(
                    extractableDataSet,//the dataset
                    docs.Where(d => d.IsGlobal == false).ToArray(),//all non global extractable docs (SupportingDocuments)
                    sqls.Where(sql => sql.IsGlobal == false).ToArray(),//all non global extractable sql (SupportingSQL)
                    lookupsFound.Select(t=>new BundledLookupTable(t)).ToArray());//all lookups associated with the Catalogue (the one behind the ExtractableDataset)

                //add the bundle
                Categories[Bundles].Add(bundle);
                firstTime = false;
            }


            tlvDatasets.SetObjects(Categories.Keys);
            

            tlvDatasets.CanExpandGetter = x => x is ExtractableDatasetBundle || (x is string && Categories.ContainsKey((string) x));
            tlvDatasets.ChildrenGetter += ChildrenGetter;

            tlvDatasets.CheckAll();
     
            tlvDatasets.ExpandAll();

            foreach (ExtractableDatasetBundle eds in Categories[Bundles])
                if (eds.DataSet.DisableExtraction)
                    tlvDatasets.UncheckObject(eds);
        }

        private IEnumerable ChildrenGetter(object model)
        {
            if(model is string)
                foreach (object o in Categories[(string) model])
                    yield return o;
            
            ExtractableDatasetBundle bundle = model as ExtractableDatasetBundle;
            if (bundle != null)
            {
                yield return bundle.DataSet;

                foreach (SupportingDocument o in bundle.Documents)
                    yield return o;

                foreach (SupportingSQLTable o in bundle.SupportingSQL)
                    yield return o;

                foreach (BundledLookupTable o in bundle.LookupTables)
                    yield return o;
            }
        }

        private object ImageGetter(object rowObject)
        {
            //if we have dispatched the globals
            if (_lastDispatchedGlobalsBundle != null)
                if (_lastDispatchedGlobalsBundle.States.ContainsKey(rowObject)) //and this object was in the global bundle dispatched
                    return GetStringForState(_lastDispatchedGlobalsBundle.States[rowObject]); //return an appropriate icon that reflects it's status
                        
            //it is not a global or globals haven't been dispatched yet

            //see if it is from a non global bundle
            var objectIsFromAKnownBundle = GetBundleIfAnyForObject(rowObject);
                
            //it IS from a non global bundle
            if (objectIsFromAKnownBundle != null)
            {
                //see if we have a state icon for this 
                string icon = GetStringForState(objectIsFromAKnownBundle.States[rowObject]);
                if (icon != null)
                    return icon;
            }
            
            //It was not a known state, probably means that it has not been started or is in NotLaunched state, so give a better icon

            if (rowObject is string)
                return "folder.bmp";
            
            if (rowObject.GetType() == typeof (SupportingDocument))
                return "supportingdocument.bmp";

            if(rowObject.GetType() == typeof(SupportingSQLTable) 
                ||
                rowObject.GetType() == typeof(BundledLookupTable))
                return "sql.bmp";

            if (rowObject.GetType() == typeof(ExtractableDatasetBundle))
                return "bundle.bmp";
            
            if (rowObject.GetType() == typeof(ExtractableDataSet))
                return "extractabledataset.bmp";
           
            return null;
        }

        private string GetStringForState(ExecuteDatasetExtractionState state)
        {
            //and we know the state
            //get an appropriate icon for the state it is in
            switch (state)
            {
                case ExecuteDatasetExtractionState.NotLaunched:return null;
                case ExecuteDatasetExtractionState.WaitingToExecute: return "sleeping.bmp";
                case ExecuteDatasetExtractionState.WaitingForSQLServer: return "talkingtoSQL.bmp";
                case ExecuteDatasetExtractionState.WritingToFile: return "writting.bmp";
                case ExecuteDatasetExtractionState.Crashed: return "failed.bmp";
                case ExecuteDatasetExtractionState.UserAborted: return "stopped.bmp";
                case ExecuteDatasetExtractionState.Completed: return "tick.bmp";
                case ExecuteDatasetExtractionState.Warning: return "warning.bmp";
                case ExecuteDatasetExtractionState.WritingMetadata: return "word.bmp";
                default:
                    throw new ArgumentOutOfRangeException("state");
            }
        }

        private void lvDatasets_MouseDoubleClick(object sender, MouseEventArgs e)
        {

            var item = (OLVListItem)tlvDatasets.HitTest(e.Location).Item;


            if (item == null)
                return;

            var doc = item.RowObject as SupportingDocument;
            if (doc != null)
                try
                {
                    Process.Start(doc.URL.ToString());
                }
                catch (Exception ex)
                {
                    ExceptionViewer.Show(ex);
                }

            var sql = item.RowObject as SupportingSQLTable;
            if (sql != null)
                try
                {

                    if (sql.ExternalDatabaseServer_ID == null)
                        throw new NotSupportedException("There is no known server for SupportingSql " + sql);

                    var server = sql.ExternalDatabaseServer;
                    DataTableViewer dtv = new DataTableViewer(server, sql.SQL, sql.Name);
                    dtv.Show();
                }
                catch (Exception ex)
                {
                    ExceptionViewer.Show(ex);
                }


            //User double clicks a lookup table
            var lookup = item.RowObject as BundledLookupTable;

            if (lookup != null)
            {
                ViewColumnInfoExtraction f = new ViewColumnInfoExtraction(
                lookup.TableInfo,
                null,
                 ViewColumnInfoExtraction.ViewType.TOP_100);

                f.Show();
            }
        }
        
        public GlobalsBundle GetGlobalsAndCustomTablesBundle()
        {
            //get the checked globals
            var docs = Categories[Globals].OfType<SupportingDocument>().Where(g => tlvDatasets.CheckedObjects.Contains(g)).ToArray();

            //and the checked global supporting sql
            var sqls = Categories[Globals].OfType<SupportingSQLTable>().Where(g => tlvDatasets.CheckedObjects.Contains(g)).ToArray();

            //and the custom table pairs
            var customTables = Categories[CustomTables].Cast<ExtractableCohortCustomTablePair>().Where(c => tlvDatasets.CheckedObjects.Contains(c)).ToArray();

            //record it so we can decide what icon to use
            _lastDispatchedGlobalsBundle = new GlobalsBundle(docs, sqls, customTables);
            return _lastDispatchedGlobalsBundle;
        }
        
        public void ChangeState(IExtractableDatasetBundle bundle)
        {
            //invalidate the UI because there is a legit state change
            if (this.InvokeRequired)
                Invoke(new MethodInvoker(() =>
                {
                    tlvDatasets.Invalidate();
                }));
        }

        private void tlvDatasets_ItemSelectionChanged(object sender, ListViewItemSelectionChangedEventArgs e)
        {
            if (e.IsSelected)
            {
                var item =(OLVListItem) e.Item;
                var bundle = item.RowObject as ExtractableDatasetBundle;

                if (bundle != null && BundleSelected != null)
                    BundleSelected(this, bundle);
            }
        }


        private void tlvDatasets_ItemChecked(object sender, ItemCheckedEventArgs e)
        {
            var obj = ((OLVListItem) e.Item).RowObject;

            //if it is a dataset
            var eds = obj as ExtractableDataSet;
            //if is it bundled object (get the parent bundle)
            var bundle = GetBundleIfAnyForObject(obj);

            if(eds != null && eds.DisableExtraction )
                tlvDatasets.UncheckObject(eds);

            if(bundle != null && bundle.DataSet.DisableExtraction)
                tlvDatasets.UncheckObject(bundle);
            
            //if user is trying to uncheck a dataset
            if (eds != null && !IsChecked(obj))
            {
                //also uncheck the bundle
                tlvDatasets.UncheckObject(
                    Categories[Bundles].Cast<ExtractableDatasetBundle>().Single(b => b.DataSet == obj));//todo put in helper method?

                return;
            }
            
            //if it is from a bundle then it could be lookup or attachment or somethign
            if (bundle != null && IsChecked(obj))
                tlvDatasets.CheckObject(bundle.DataSet); //so also tick the dataset
        }


        //Helper methods
        private ExtractableDatasetBundle GetBundleIfAnyForObject(object rowObject)
        {
            return Categories[Bundles].Cast<ExtractableDatasetBundle>().SingleOrDefault(b => b.States.ContainsKey(rowObject));
        }

        private bool IsChecked(object obj)
        {
            return tlvDatasets.CheckedObjects.Contains(obj);
        }
    }

}

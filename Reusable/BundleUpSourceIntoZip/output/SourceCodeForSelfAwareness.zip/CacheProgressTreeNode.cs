using System.Windows.Forms; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using CatalogueLibrary.Data;

namespace CachingDashboard
{
    public class CacheProgressTreeNode : TreeNode
    {
        public ICacheProgress CacheProgress { get; private set; }

        public CacheProgressTreeNode(ICacheProgress cacheProgress)
        {
            CacheProgress = cacheProgress;

            var loadProgress = CacheProgress.GetLoadProgress();
            Text = loadProgress.ResourceIdentifier;

            if (loadProgress.LockedBecauseRunning)
            {
                ImageIndex = 1;
                SelectedImageIndex = 1;
            }
        }
    }
}

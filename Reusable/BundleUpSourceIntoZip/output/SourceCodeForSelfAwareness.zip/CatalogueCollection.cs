using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Input;
using BrightIdeasSoftware;
using CatalogueLibrary;
using CatalogueLibrary.Cloning;
using CatalogueLibrary.Data;
using CatalogueLibrary.Data.Aggregation;
using CatalogueLibrary.Data.Cohort;
using CatalogueLibrary.Data.DataLoad;
using CatalogueManager.AggregationUIs;
using CatalogueManager.DataLoadUIs;
using CatalogueManager.ExtractionUIs;
using CatalogueManager.Issues;
using CatalogueManager.ObjectVisualisation;
using CatalogueManager.SimpleDialogs;
using CatalogueManager.SimpleDialogs.Revertable;
using CatalogueManager.SimpleDialogs.SimpleFileImporting;
using CatalogueManager.TestsAndSetup.ServicePropogation;
using CatalogueManager.Validation;
using MapsDirectlyToDatabaseTable;
using ReusableLibraryCode.Checks;
using ReusableUIComponents;
using ReusableUIComponents.ChecksUI;
using ReusableUIComponents.Dependencies;
using KeyEventArgs = System.Windows.Forms.KeyEventArgs;

namespace CatalogueManager.MainFormUITabs.SubComponents
{
    /// <summary>
    /// This control is used in several places in the application and lets you select a dataset (called a Catalogue) to work with.  In adittion you can right click datasets to access 
    /// Catalogue level functionality (configuring validation, deleting, logging etc).  You can also drag Catalogues between folders or delete them (by pressing Del).
    /// 
    /// The Right click menu for empty space includes:
    /// 
    ///     Create New Catalogue (creates an empty header record for a dataset - NOT ADVISED)
    /// 
    ///     Create New Catalogue by importing a flat file (Recommended method if you don't have a table already loaded in your database)
    /// 
    /// Right clicking a dataset lets you:
    /// 
    ///     View Extraction SQL - based on the CatalogueItems / ExtractionInformation configured the QueryBuilder will show you how it would execute SELECT queries against the dataset
    /// 
    ///     View Checks - Checks the integrity of the catalogue (does the extraction SQL actually work, is at least 1 row returned etc)
    /// 
    ///     Configure Lookups - Launches AdvancedLookupConfiguration
    /// 
    ///     ViewSupportingSQL - Launches SupportingSQLTableViewer
    /// 
    ///     View Supporting Documents - Launches SupportingDocumentsViewer
    /// 
    ///     View Issues - Launches ViewAllIssues
    /// 
    ///     View Issues All Catalogues - Same as above but for all issues in all datasets, not just the one right clicked
    /// 
    ///     Choose Time Cover Column - Lets you select a single extractable CatalogueItem (column/transform) as the time indicator for the dataset e.g. DatePrescriptionCollected
    /// 
    ///     Choose Pivot Category Column - Lets you select a single extractable CatalogueItem (column/transform) as a category indicator for the dataset e.g. Healthboard (make sure it doesn't
    ///  have too many values!)
    /// 
    ///     Configure Aggregates - Launches AggregateManagement
    /// 
    ///     Configure Validation - Launches ValidationSetupForm
    /// 
    ///     Import Validation - Launches ImportValidationFromUnderlyingColumnInfos
    /// 
    ///     Configure Load Metadata - Launches SelectLoadMetadataOrCreateNewUI
    /// 
    ///     Disassociate Catalogue From Load Metadata - Unregisteres the Catalogue from it's load logic (used if you no longer wish to load the underlying tables as part of that load)
    /// 
    ///     Configure Logging - Launches ChooseLoggingTaskDialog
    /// 
    ///     Clone Catalogue - Creates an exact copy of the (metadata only!) of a Catalogue... not sure why you would want to do this tbh
    /// 
    ///     Set Deprecated, Internal, Cold Storage status of the dataset
    /// 
    ///     Delete the Catalogue
    /// 
    ///     View Dependencies of the Catalogue - Launches DependencyGraph
    /// 
    /// Finally you can launch 'Checking' for every dataset, this will attempt to verify the extraction SQL you
    /// have configured for each dataset and to ensure that it runs and that at least 1 row of data is returned.  Checking all the datasets can take a while so runs asynchronously.
    /// </summary>
    public partial class CatalogueCollection : RDMPUserControl
    {
        private ObservableCollection<Catalogue> _collection;

        public event EventHandler CatalogueCollectionChanged;
        
        /// <summary>
        /// Occurs when user selects a different Catalogue
        /// </summary>
        public event EventHandler SelectionChanged;


        //hide this stuff from visual studio designer it freaks out 
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public ObservableCollection<Catalogue> Collection
        {
            get { return _collection; }
            set
            {
                if (_collection == value)
                    return;

                //new collection
                _collection = value;

                //subscribe to changes
                if (value != null)
                    _collection.CollectionChanged += (s,e)=>RefreshFromCollection();

                //refresh ui
                RefreshFromCollection();
            }
        }

        private IEnumerable<Catalogue> VisibleCatalogues
        {
            get { return Collection.Except(hiddenCatalogues);}
        }

        ContextMenuStrip RightClickMenu = new ContextMenuStrip();

        public Catalogue SelectedCatalogue
        {
            get
            {
                return otlvCatalogues.SelectedObject as Catalogue;
            }
            set
            {
                otlvCatalogues.SelectedObject = value;
            }
        }

        public object SelectedObject { get { return otlvCatalogues.SelectedObject; }}

        private string _filter;
        private bool _showInternal = false;
        private bool _showDeprecated = false;
        private bool _showColdStorage = false;
        
        //constructor
        public CatalogueCollection()
        {
            InitializeComponent();

            
            //prevent visual studio crashes
            if (VisualStudioDesignMode)
                return;
            
            olvColumn1.ImageGetter += ImageGetter;
            olvCheckResult.ImageGetter += CheckImageGetter;

            otlvCatalogues.CanExpandGetter+= CanExpandGetter;
            otlvCatalogues.ChildrenGetter+= ChildrenGetter;
            otlvCatalogues.AddObject(CatalogueFolder.Root);
            otlvCatalogues.ModelCanDrop += OtlvCataloguesModelCanDrop;
            otlvCatalogues.ModelDropped += otlvCatalogues_ModelDropped;
        }

        #region drag and drop
        void OtlvCataloguesModelCanDrop(object sender, ModelDropEventArgs e)
        {
            e.Handled = true;
            e.Effect = DragDropEffects.None;
            
            if (e.SourceModels.Count < 1)
            {
                e.InfoMessage = "You must drag at least one object";
                return;
            }

            foreach (var m in e.SourceModels)
                if (m.GetType() != typeof (Catalogue))
                {
                    e.InfoMessage = "You can only drag and drop Catalogues";
                    return;
                }


            var catalogueFolder = e.TargetModel as CatalogueFolder;

            if (e.SourceListView == otlvCatalogues)
                if (catalogueFolder != null)
                    e.Effect = DragDropEffects.Move;
                else
                    e.InfoMessage = "Catalogues can only be dropped onto CatalogueFolders";
            else
                e.InfoMessage = "Drop only supported when dragging within this control";
        }

        void otlvCatalogues_ModelDropped(object sender, ModelDropEventArgs e)
        {
            var catalogueFolder = (CatalogueFolder)e.TargetModel;

            foreach (Catalogue c in e.SourceModels)
            {
                c.Folder = catalogueFolder;
                c.SaveToDatabase();
            }

            RefreshFromCollection();
            CatalogueCollectionChanged(this,new EventArgs());

        }

        #endregion

        
        //gets reset whenever RefreshFromCollection() is called
        private Dictionary<object, object[]> _childDictionary = new Dictionary<object, object[]>();

        #region How to find children objects
        private bool CanExpandGetter(object model)
        {
            if (_childDictionary.ContainsKey(model))
                return _childDictionary[model].Any();

            var folder = model as CatalogueFolder;

            object[] children = new object[0];

            //it is a folder
            if (folder != null)
            {
                children = GetChildObjects(folder);

                //folder has no catalogues and no subfolders apparently
                if (children == null)
                    return false;
            }
            
            var cata = model as Catalogue;

            //it's a catalogue - are we showing aggregates?
            if (cata != null && ShowAggregates != AggregatesToShow.None)
            {
                //if so the children are the aggregates
                children = cata.AggregateConfigurations.Where( 
                    a=>!a.IsCohortIdentificationAggregate//if it is not a cohort identification specific one
                    || 
                    ShowAggregates == AggregatesToShow.All //or you want them all anyway
                    ).ToArray();


                //if there is a filter they might be filtering on the Catalogue/Folder or the Aggregates!
                if (!string.IsNullOrWhiteSpace(Filter))
                    children = children.Where(
                        //if the aggregate matches
                        c => c.ToString().ToLower().Contains(Filter.ToLower())
                        || 
                        cata.Name.ToLower().Contains(Filter.ToLower())//or it's the parent they were searching on after all
                        ||
                        cata.Folder.Path.Contains(Filter.ToLower())//or it's the parents folder they were searching on after all

                        ).ToArray();

            }

            _childDictionary.Add(model,children);

            return children.Any();
        }

        private IEnumerable ChildrenGetter(object model)
        {
            if (_childDictionary.ContainsKey(model))
                return _childDictionary[model];
            
            return null;
        }

        private object[] GetChildObjects(CatalogueFolder folder)
        {
            List<object> childObjects = new List<object>();

            if (Collection == null)
                return null;

            //add subfolders
            childObjects.AddRange(folder.GetImmediateSubFoldersUsing(VisibleCatalogues));

            //add catalogues in folder
            childObjects.AddRange(VisibleCatalogues.Where(c => c.Folder.Equals(folder)));


            return childObjects.ToArray();
        }
       
        private object ImageGetter(object rowObject)
        {

            if (rowObject is Catalogue)
                return "Catalogue.bmp";

            if (rowObject is CatalogueFolder)
                return "Folder.bmp";

           var ac = rowObject as AggregateConfiguration;
            if(ac != null)
                return ac.OverrideFiltersByUsingParentAggregateConfigurationInstead_ID != null ? "aggregatesShortcut.png" : "aggregates.png";

            return null;
        }
        #endregion


        
        //The color to highlight each Catalogue based on its extractability status
        private object ocheckResultsDictionaryLock = new object();
        Dictionary<ICheckable, CheckResult> checkResultsDictionary = new Dictionary<ICheckable, CheckResult>();
        private Thread checkingThread;

        public void CheckCatalogues()
        {
            if (checkingThread != null && checkingThread.IsAlive)
            {
                MessageBox.Show("Checking is already happening");
                return;
            }
            
            //reset the dictionary
            lock (ocheckResultsDictionaryLock)
            {
                checkResultsDictionary = new Dictionary<ICheckable, CheckResult>();
            }

            //reset the progress bar
            progressBar1.Maximum = Collection.Count;
            progressBar1.Value = 0;
            progressBar1.Visible = true;

            checkingThread = new Thread(() =>
            {
                //only check the items that are visible int he listview
                foreach (var catalogue in _childDictionary.Keys.OfType<Catalogue>().ToArray())//make copy to prevent synchronization issues
                {
                    var notifier = new ToMemoryCheckNotifier();
                    catalogue.Check(notifier);

                    lock (ocheckResultsDictionaryLock)
                        checkResultsDictionary.Add(catalogue, notifier.GetWorst());

                    //increase progress bar count by one
                    Invoke(new MethodInvoker(() => { progressBar1.Value++; }));
                }

                

                if (ShowAggregates != AggregatesToShow.None)
                    foreach (var configuration in RepositoryLocator.CatalogueRepository.GetAllObjects<AggregateConfiguration>().ToArray())
                    {
                        var notifier = new ToMemoryCheckNotifier();
                        configuration.Check(notifier);
                        
                        lock (ocheckResultsDictionaryLock)
                            checkResultsDictionary.Add(configuration, notifier.GetWorst());
                    }


                //now load images to UI
                Invoke(new MethodInvoker(() =>
                {
                    progressBar1.Visible = false;
                    RefreshFromCollection();
                }));

            });

            checkingThread.Start();
        }

        private object CheckImageGetter(object rowobject)
        {
            var checkable = rowobject as ICheckable;
            if (checkable == null)
                return null;
            
            lock (ocheckResultsDictionaryLock)
            {
                if(checkResultsDictionary.ContainsKey(checkable))
                    switch (checkResultsDictionary[checkable])
                    {
                        case CheckResult.Success:
                            return "tick.bmp";
                        case CheckResult.Warning:
                            return "warning.bmp";
                        case CheckResult.Fail:
                            return "failedWithException.bmp";
                        default:
                            throw new ArgumentOutOfRangeException();
                    }
            }
            //not been checked yet
            return null;
        }

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (checkingThread != null)
                checkingThread.Abort();

            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void tlvCatalogues_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
                RightClickMenu_Delete_Click(null, null);

            if (e.KeyCode == Keys.N && e.Control)
                RightClickMenu_btnNew_Click(null, null);

        }
        public string Filter
        {
            get { return _filter; }
            set
            {
                _filter = value;
                ApplyFilters();

            }
        }

        public bool ShowDeprecated
        {
            get { return _showDeprecated; }
            set
            {
                _showDeprecated = value;
                ApplyFilters();
            }
        }

        public bool ShowInternal
        {
            get { return _showInternal; }
            set
            {
                _showInternal = value;
                ApplyFilters();
            }
        }

        public bool ShowColdStorage
        {
            get { return _showColdStorage; }
            set
            {
                _showColdStorage = value;
                ApplyFilters();
            }
        }
        
        public AggregatesToShow ShowAggregates
        {
            get { return _showAggregates; }
            set
            {
                _showAggregates = value;
                RefreshFromCollection();
            }
        }

        public void RefreshFromCollection()
        {
            //reset the cached answers
            _childDictionary = new Dictionary<object, object[]>();

            otlvCatalogues.RefreshObject(CatalogueFolder.Root);
            otlvCatalogues.Invalidate();
            otlvCatalogues.ExpandAll();
        }

        #region RightClick Menu and Double Clicking


        private void tlvCatalogues_CellRightClick(object sender, CellRightClickEventArgs e)
        {

            if (e.Item == null || e.Item.RowObject is CatalogueFolder)
            {
                ShowEmptyContextMenu(e.Location);
                return;
            }
            
            var cata = (e.Item.RowObject) as Catalogue;

            if (cata != null)
                ShowContextMenu(cata, e.Location);

            var aggregate = (e.Item.RowObject) as AggregateConfiguration;

            if (aggregate != null)
                ShowContextMenu(aggregate, e.Location);

        }
        
        private void RightClickMenu_Delete_Click(object sender, EventArgs e)
        {
            try
            {
                IDeleteable deleteable = otlvCatalogues.SelectedObject as IDeleteable;


                if (deleteable != null)
                {
                    DialogResult result = MessageBox.Show("Are you sure you want to delete " + deleteable + " from the database?", "Delete Record",
                                MessageBoxButtons.YesNo);

                    if (result == DialogResult.Yes)
                    {
                        deleteable.DeleteInDatabase();

                        if (deleteable is Catalogue)
                        {
                            Collection.Remove((Catalogue) deleteable);
                            otlvCatalogues.RemoveObject(deleteable);//get rid of this since it's just been deleted!
                        }
                    }
                }

                Thread.Sleep(300);

                if (CatalogueCollectionChanged != null)
                    CatalogueCollectionChanged(this, new EventArgs());
            }
            catch (Exception ex)
            {

                ExceptionViewer.Show(ex);
            }

        }

        private void RightClickMenu_Deprecate_Click(object sender, EventArgs e)
        {
            try
            {
                Catalogue c = (Catalogue)SelectedCatalogue;

                if (c != null)
                {
                    DialogResult result = MessageBox.Show("Are you sure you want to DEPRECATE the catalogue " + c.Name + "?", "Deprecate Record",
                                MessageBoxButtons.YesNo);

                    if (result == DialogResult.Yes)
                    {
                        c.IsDeprecated = true;
                        c.SaveToDatabase();
                    }
                }

                Thread.Sleep(300);

                if (CatalogueCollectionChanged != null)
                    CatalogueCollectionChanged(this, new EventArgs());
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }


        private void RightClickMenu_UnDeprecate_Click(object sender, EventArgs e)
        {
            try
            {
                Catalogue c = (Catalogue)SelectedCatalogue;

                if (c != null)
                {
                    c.IsDeprecated = false;
                    c.SaveToDatabase();
                }

                if (CatalogueCollectionChanged != null)
                    CatalogueCollectionChanged(this, new EventArgs());


            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
        private void RightClickMenu_SetColdStorageTrue_Click(object sender, EventArgs e)
        {
            Catalogue c = SelectedCatalogue as Catalogue;
            try
            {
                if (c != null)
                {

                    c.IsColdStorageDataset = true;
                    c.SaveToDatabase();
                }
                if (CatalogueCollectionChanged != null)
                    CatalogueCollectionChanged(this, new EventArgs());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void RightClickMenu_SetColdStorageFalse_Click(object sender, EventArgs e)
        {
            Catalogue c = SelectedCatalogue as Catalogue;
            try
            {
                if (c != null)
                {

                    c.IsColdStorageDataset = false;
                    c.SaveToDatabase();
                }
                if (CatalogueCollectionChanged != null)
                    CatalogueCollectionChanged(this, new EventArgs());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void RightClickMenu_SetInternalFalse_Click(object sender, EventArgs e)
        {
            Catalogue c = SelectedCatalogue as Catalogue;
            try
            {
                if (c != null)
                {

                    c.IsInternalDataset = false;
                    c.SaveToDatabase();
                }
                if (CatalogueCollectionChanged != null)
                    CatalogueCollectionChanged(this, new EventArgs());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void RightClickMenu_SetInternalTrue_Click(object sender, EventArgs e)
        {
            Catalogue c = SelectedCatalogue as Catalogue;
            try
            {
                if (c != null)
                {

                    c.IsInternalDataset = true;
                    c.SaveToDatabase();

                }
                if (CatalogueCollectionChanged != null)
                    CatalogueCollectionChanged(this, new EventArgs());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void ShowContextMenu(AggregateConfiguration aggregate, Point location)
        {

            //create right click context menu
            RightClickMenu = new ContextMenuStrip();
            RightClickMenu.Items.Add("View Checks", imageList1.Images["warning.bmp"], (s,e)=> PopupChecks(aggregate));

            //show it
            RightClickMenu.Show(this, location);
        }


        private void ShowContextMenu(Catalogue catalogue, Point location)
        {
            //make sure we select the Catalogue that they right clicked
            SelectedCatalogue = catalogue;

            //Things that are only visible when a Catalogue is selected   

            //create right click context menu
            RightClickMenu = new ContextMenuStrip();

            RightClickMenu.Items.Add("Generate/View Extraction SQL", imageList_RightClickIcons.Images["DEM"], RightClickMenu_GenerateSQL_Click);

            RightClickMenu.Items.Add("View Checks", imageList1.Images["warning.bmp"], (s, e) => PopupChecks(SelectedCatalogue));


            RightClickMenu.Items.Add("Configure Lookups", imageList_RightClickIcons.Images["DEM"], RightClickMenu_ConfigureLookups_Click);
            RightClickMenu.Items.Add("View Supporting SQL", null, RightClickMenu_ViewSupportingSQL_Click);
            RightClickMenu.Items.Add("View Supporting Documents", null, RightClickMenu_ViewSupportingDocuments_Click);
            RightClickMenu.Items.Add("View Issues", null, RightClickMenu_ViewIssues_Click);
            RightClickMenu.Items.Add("View Issues (All Catalogues)", null, RightClickMenu_ViewIssuesAllCatalogues_Click);


            RightClickMenu.Items.Add("Choose Time Coverage Column", imageList_RightClickIcons.Images["DQE"], RightClickMenu_ChooseTimeCoverageExtractionInformation_Click);
            RightClickMenu.Items.Add("Choose Pivot Category Column", imageList_RightClickIcons.Images["DQE"], RightClickMenu_ChoosePivotCategoryExtractionInformation_Click);


            RightClickMenu.Items.Add(new ToolStripSeparator());

            RightClickMenu.Items.Add("Configure Aggregates", imageList_RightClickIcons.Images["aggregates.png"], RightClickMenu_ConfigureAggregates_Click);


            RightClickMenu.Items.Add(new ToolStripSeparator());

            RightClickMenu.Items.Add("Configure Validation", imageList_RightClickIcons.Images["DQE"], RightClickMenu_ConfigureValidation_Click);
            RightClickMenu.Items.Add("Import Validation", imageList_RightClickIcons.Images["DQE"], RightClickMenu_ImportValidation_Click);

            RightClickMenu.Items.Add(new ToolStripSeparator());


            string configureLoadMetadataTitle = "Configure Load Metadata";
            if (catalogue.LoadMetadata_ID != null)
                configureLoadMetadataTitle += "(" + catalogue.LoadMetadata.Name + ")";
            RightClickMenu.Items.Add(configureLoadMetadataTitle, imageList_RightClickIcons.Images["DLE"], RightClickMenu_LoadMetadata_Click);

            if (catalogue.LoadMetadata_ID != null)
                RightClickMenu.Items.Add("Disassociate Catalogue From Load Metadata", imageList_RightClickIcons.Images["DLE"], RightClickMenu_ClearLoadMetadata_Click);


            RightClickMenu.Items.Add("Configure Logging", imageList_RightClickIcons.Images["LOG"], RightClickMenu_ConfigureLogging_Click);


            RightClickMenu.Items.Add(new ToolStripSeparator());
            RightClickMenu.Items.Add("Clone Catalogue", null, RightClickMenu_CloneCatalogue_Click);


            RightClickMenu.Items.Add(new ToolStripSeparator());

            if (catalogue.IsDeprecated)
                RightClickMenu.Items.Add("Un Deprecate", null, RightClickMenu_UnDeprecate_Click);
            else
                RightClickMenu.Items.Add("Deprecate Catalogue", null, RightClickMenu_Deprecate_Click);

            if (catalogue.IsInternalDataset)
                RightClickMenu.Items.Add("UnSet Internal Use Only", null, RightClickMenu_SetInternalFalse_Click);
            else
                RightClickMenu.Items.Add("Set Internal Use Only", null, RightClickMenu_SetInternalTrue_Click);

            if (catalogue.IsColdStorageDataset)
                RightClickMenu.Items.Add("Remove from Cold Storage (make Warm)", null, RightClickMenu_SetColdStorageFalse_Click);
            else
                RightClickMenu.Items.Add("Set Cold Storage", null, RightClickMenu_SetColdStorageTrue_Click);

            RightClickMenu.Items.Add("Delete Catalogue", null, RightClickMenu_Delete_Click);


            RightClickMenu.Items.Add(new ToolStripSeparator());


            var initialTypesToShow = new List<Type> { typeof(Catalogue), typeof(CatalogueItem),typeof(LoadMetadata)};
            RightClickMenu.Items.Add(new ViewDependenciesToolStripMenuItem(catalogue, CatalogueObjectVisualisation.GetInstance(), initialTypesToShow));
            RightClickMenu.Items.Add(new ToolStripSeparator());


            //Things that are always visible regardless
            RightClickMenu.Items.Add("Create new Catalogue", null, RightClickMenu_btnNew_Click);

            RightClickMenu.Items.Add("Create new Catalogue(s) by importing flat files", null, RightClickMenu_CreateCatalogueByImportFlatFile_Click);

            //show it
            RightClickMenu.Show(this, location);

        }

    

        private void ShowEmptyContextMenu(Point location)
        {
            RightClickMenu = new ContextMenuStrip();//Things that are only visible when a Catalogue is not selected


            //Things that are always visible regardless
            RightClickMenu.Items.Add("Create new Catalogue", null, RightClickMenu_btnNew_Click);

            RightClickMenu.Items.Add("Create new Catalogue(s) by importing flat files", null, RightClickMenu_CreateCatalogueByImportFlatFile_Click);

            //show it
            RightClickMenu.Show(this, location);
        }


        private void RightClickMenu_CreateCatalogueByImportFlatFile_Click(object sender, EventArgs e)
        {

            OpenFileDialog ofd = new OpenFileDialog();
            DialogResult result = ofd.ShowDialog();

            if (result == DialogResult.OK)
            {
                SimpleImportDataFileUI dialog = new SimpleImportDataFileUI(new FileInfo(ofd.FileName),true);
                dialog.RepositoryLocator = RepositoryLocator;
                dialog.ShowDialog();

                if (CatalogueCollectionChanged != null)
                    CatalogueCollectionChanged(this, new EventArgs());
            }
        }


        private void RightClickMenu_ViewIssues_Click(object sender, EventArgs e)
        {

            Catalogue catalogue = SelectedCatalogue as Catalogue;

            if (catalogue != null)
            {
                var dialog = new ViewAllIssues(catalogue);
                dialog.RepositoryLocator = RepositoryLocator;
                dialog.Show();
            }

        }

        private void RightClickMenu_ViewIssuesAllCatalogues_Click(object sender, EventArgs e)
        {
            var dialog = new ViewAllIssues();
            dialog.RepositoryLocator = RepositoryLocator;
            dialog.Show();
        }


        private void RightClickMenu_ConfigureAggregates_Click(object sender, EventArgs e)
        {
            Catalogue catalogue = SelectedCatalogue as Catalogue;

            if (catalogue != null)
            {
                var dialog = new AggregateManagement(catalogue);
                dialog.RepositoryLocator = RepositoryLocator;

                if (ShowAggregates != AggregatesToShow.None)
                {
                    dialog.ShowDialog();
                    RefreshFromCollection();
                }
                else
                    dialog.Show();
            }

        }


        private void RightClickMenu_GenerateSQL_Click(object sender, EventArgs e)
        {
            Catalogue catalogue = SelectedCatalogue as Catalogue;

            if (catalogue != null)
            {
                var vs = new ViewExtractionSql(catalogue);
                vs.Show();
            }
        }
        private void PopupChecks(ICheckable checkable)
        {
            var popupChecksUI = new PopupChecksUI("Checking " + checkable, false);
            checkable.Check(popupChecksUI);
        }
        private void RightClickMenu_ConfigureLookups_Click(object sender, EventArgs e)
        {
            Catalogue cata = SelectedCatalogue as Catalogue;

            if (cata != null)
            {
                AdvancedLookupConfiguration dialog = new AdvancedLookupConfiguration(cata);
                dialog.ShowDialog();

                if (CatalogueCollectionChanged != null)
                    CatalogueCollectionChanged(this, new EventArgs());

            }
        }

        private void RightClickMenu_ViewSupportingSQL_Click(object sender, EventArgs e)
        {
            Catalogue catalogue = SelectedCatalogue as Catalogue;
            if (catalogue != null)
            {
                SupportingSQLTableViewer viewer = new SupportingSQLTableViewer(catalogue);
                viewer.RepositoryLocator = RepositoryLocator;
                viewer.ShowDialog(this);
            }
        }


        private void RightClickMenu_ViewSupportingDocuments_Click(object sender, EventArgs e)
        {
            var cata = SelectedCatalogue as Catalogue;

            if (cata != null)
            {
                SupportingDocumentsViewer viewer = new SupportingDocumentsViewer(cata);
                viewer.RepositoryLocator = RepositoryLocator;
                viewer.Show();
            }
        }
        private void RightClickMenu_ChooseTimeCoverageExtractionInformation_Click(object sender, EventArgs e)
        {
            try
            {
                var cata = SelectedCatalogue as Catalogue;

                if (cata != null)
                {
                    //fire up a chooser for the current value
                    DialogResult dr;

                    var extractionInformation = SelectAppropriateExtractionInformation(cata,cata.TimeCoverage_ExtractionInformation_ID,out dr);

                    //if the user chose a new value
                    if(dr == DialogResult.OK)
                    {
                        //set the Catalogues property to the new value
                        if (extractionInformation != null)
                            SelectedCatalogue.TimeCoverage_ExtractionInformation_ID = extractionInformation.ID;
                        else
                            SelectedCatalogue.TimeCoverage_ExtractionInformation_ID = null;

                        SelectedCatalogue.SaveToDatabase();

                        if (CatalogueCollectionChanged != null)
                            CatalogueCollectionChanged(this, new EventArgs());
                    }
                    else
                    {
                        SelectedCatalogue.TimeCoverage_ExtractionInformation_ID = null;
                    }
                }
            }
            catch (Exception exception)
            {
                ExceptionViewer.Show(exception);
            }
        }
        private void RightClickMenu_ChoosePivotCategoryExtractionInformation_Click(object sender, EventArgs e)
        {
            var cata = SelectedCatalogue as Catalogue;

            if (cata != null)
            {
                //fire up a chooser for the current value
                DialogResult dr;
                var extractionInformation = SelectAppropriateExtractionInformation(cata, cata.PivotCategory_ExtractionInformation_ID,out dr);

                //if the user chose a new value
                if (dr == DialogResult.OK)
                {
                    //set the Catalogues property to the new value
                    if (extractionInformation != null)
                        SelectedCatalogue.PivotCategory_ExtractionInformation_ID = extractionInformation.ID;
                    else
                        SelectedCatalogue.PivotCategory_ExtractionInformation_ID = null;

                    SelectedCatalogue.SaveToDatabase();

                    if (CatalogueCollectionChanged != null)
                        CatalogueCollectionChanged(this, new EventArgs());
                }
            }
        }

        private ExtractionInformation SelectAppropriateExtractionInformation(Catalogue cata, int? oldValue, out DialogResult dialogResult)
        {
            if (cata != null)
            {
                ExtractionInformationChooserUI chooser;

                //pass old value
                if (oldValue == null)
                    chooser = new ExtractionInformationChooserUI(cata, null);
                else
                {
                    ExtractionInformation info = RepositoryLocator.CatalogueRepository.GetObjectByID<ExtractionInformation>((int)oldValue);
                    chooser = new ExtractionInformationChooserUI(cata, info);
                }

                chooser.ShowDialog(this);
                dialogResult = chooser.DialogResult;
                return chooser.Result;
            }

            dialogResult = DialogResult.Ignore;
            return null;
        }


        private void RightClickMenu_ConfigureValidation_Click(object sender, EventArgs e)
        {
            Catalogue catalogue = SelectedCatalogue as Catalogue;

            if (catalogue != null)
            {
                List<string> columnNames = new List<string>();


                foreach (ExtractionInformation extractionInformation in catalogue.GetAllExtractionInformation(ExtractionCategory.Any))
                    columnNames.Add(extractionInformation.ToString());

                ValidationSetupForm dialog = new ValidationSetupForm(catalogue.ValidatorXML, columnNames.ToArray());
                dialog.RepositoryLocator = RepositoryLocator;

                if (dialog.ShowDialog(this) == DialogResult.OK)
                {

                    string newXML = null;

                    #region Save to XML into variable newXML (and alert users to errors)
                    try
                    {
                        newXML = dialog.Validator.SaveToXml();
                    }
                    catch (InvalidOperationException ex)
                    {
                        string msg = ex.Message + Environment.NewLine;
                        Exception ex2 = ex.InnerException;
                        while (ex2.InnerException != null)
                        {
                            ex2 = ex2.InnerException;
                            msg += ex2.Message + Environment.NewLine;
                        }

                        ExceptionViewer.Show(msg,ex);

                        return;
                    }
                    #endregion

                    if (newXML != catalogue.ValidatorXML)
                    {
                        catalogue.ValidatorXML = newXML;
                        catalogue.SaveToDatabase();
                    }
                }
            }
        }

        private void RightClickMenu_ConfigureLogging_Click(object sender, EventArgs e)
        {
            Catalogue catalogue = SelectedCatalogue as Catalogue;

            if (catalogue != null)
            {
                try
                {
                    ChooseLoggingTaskDialog dialog = new ChooseLoggingTaskDialog(catalogue);
                    dialog.ShowDialog(this);
                }
                catch (Exception exception)
                {
                    ExceptionViewer.Show(exception);
                }
            }
            else
                MessageBox.Show("Select a Catalogue first (on the left)");
        }

        private void RightClickMenu_ImportValidation_Click(object sender, EventArgs e)
        {
            Catalogue catalogue = SelectedCatalogue as Catalogue;

            if (catalogue != null)
            {
                ImportValidationFromUnderlyingColumnInfos importer =
                    new ImportValidationFromUnderlyingColumnInfos(catalogue);
                importer.ShowDialog(this);
            }
            else
                MessageBox.Show("Select a Catalogue first (on the left)");
        }


        private void RightClickMenu_CloneCatalogue_Click(object sender, EventArgs e)
        {

            Catalogue catalogue = SelectedCatalogue as Catalogue;

            if (catalogue != null)
            {
                if (DialogResult.Yes ==
                    MessageBox.Show("Confirm creating a duplicate of Catalogue \"" + catalogue.Name + "\"?",
                                    "Create Duplicate?", MessageBoxButtons.YesNo))
                {

                    try
                    {
                        CatalogueCloner cloner = new CatalogueCloner(RepositoryLocator.CatalogueRepository, RepositoryLocator.CatalogueRepository);
                        cloner.CreateDuplicateInSameDatabase(catalogue);

                        if (CatalogueCollectionChanged != null)
                            CatalogueCollectionChanged(this, new EventArgs());
                    }
                    catch (Exception exception)
                    {
                        if (exception.Message.Contains("runcated"))
                            //skip the t because unsure what capitalisation it will be
                            MessageBox.Show(
                                "The name of the Catalogue to clone was too long, when we tried to put _DUPLICATE on the end it resulted in error:" +
                                exception.Message);
                        else
                            MessageBox.Show(exception.Message);
                    }
                }
            }
            else
                MessageBox.Show("Select a Catalogue first (on the left)");

        }

        private void RightClickMenu_LoadMetadata_Click(object sender, EventArgs e)
        {
            var catalogue = SelectedCatalogue as Catalogue;

            if (catalogue != null)
            {
                RDMPForm dialog = null;

                //see if catalogue already has one configured
                if (catalogue.LoadMetadata_ID != null)
                {
                    dialog = new LoadMetadataUI(catalogue.LoadMetadata);
                    dialog.RepositoryLocator = RepositoryLocator;//I know this line is duplicated, it is because of unit test FindUninitializedForms() which evaluates the source code and expects to see this line after every use of an RDMPForm constructor
                }
                else
                {
                    dialog = new SelectLoadMetadataOrCreateNewUI(catalogue);
                    dialog.RepositoryLocator = RepositoryLocator;
                }


                // If the XML hasn't been deserialised, the dialog will be closed.
                if (!dialog.IsDisposed)
                    dialog.ShowDialog();

            }
        }
        private void RightClickMenu_ClearLoadMetadata_Click(object sender, EventArgs e)
        {
            var catalogue = SelectedCatalogue as Catalogue;


            if (catalogue != null)
            {
                if (MessageBox.Show("Disassociate Catalogue" + catalogue.Name + " from it's Load Metadata (load logic)?", "Confirm disassociation", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    try
                    {
                        catalogue.LoadMetadata_ID = null;
                        catalogue.SaveToDatabase();
                    }
                    catch (Exception exception)
                    {
                        ExceptionViewer.Show(exception);
                    }
                }
            }
        }


        private void RightClickMenu_btnNew_Click(object sender, EventArgs e)
        {
            try
            {
                var cata = new Catalogue(RepositoryLocator.CatalogueRepository,"New Catalogue " + Guid.NewGuid());

                Collection.Add(cata);

                if (CatalogueCollectionChanged != null)
                    CatalogueCollectionChanged(this, new EventArgs());

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void tlvCatalogues_ItemActivate(object sender, EventArgs e)
        {
       
            //if user double clicked aggregate configuration
            var config = otlvCatalogues.SelectedObject as AggregateConfiguration;
            if (config != null)
            {
                AggregateConfigurationUI.PopupOnNewForm(config);
                RefreshFromCollection();
            }
            else if (SelectedCatalogue != null) //if user double clicked a catalogue
            {
                var vs = new ViewExtractionSql(SelectedCatalogue);
                vs.Show();
                
            }

        }

        #endregion

        List<Catalogue>  hiddenCatalogues = new List<Catalogue>();
        private AggregatesToShow _showAggregates;

        public void ApplyFilters()
        {
            if (Collection == null)
                return;

            hiddenCatalogues.Clear();
            
            foreach (Catalogue catalogue in Collection)
                if (
                    !String.IsNullOrWhiteSpace(Filter) && //if there is a filter
                    !catalogue.ToString().ToLower().Contains(Filter.ToLower()) && //and it does not match the name
                    !catalogue.Folder.Path.Contains(Filter.ToLower()) && //and it does not match the path either
                    !HasChildMatchingFilter(catalogue,Filter)
                    )
                    hiddenCatalogues.Add(catalogue);//hide it
                else
                    if (catalogue.IsDeprecated != ShowDeprecated)
                        hiddenCatalogues.Add(catalogue);
                    else
                        if (catalogue.IsInternalDataset != ShowInternal)
                            hiddenCatalogues.Add(catalogue);
                        else
                            if (catalogue.IsColdStorageDataset != ShowColdStorage)
                                hiddenCatalogues.Add(catalogue);

            RefreshFromCollection();
        }

        private bool HasChildMatchingFilter(object o, string filter)
        {
            if (_childDictionary.ContainsKey(o))
                return _childDictionary[o].Any(child => child.ToString().ToLower().Contains(filter.ToLower()));

            return false;
        }


        public enum HighlightCatalogueType
        {
            None,
            Extractable,
            ExtractionBroken,
            TOP1Worked
        }

        private Catalogue _lastSelected = null;

        private void tlvCatalogues_ItemSelectionChanged(object sender, ListViewItemSelectionChangedEventArgs e)
        {
            //if we are going from zero selection to zero selection who cares
            if (_lastSelected == null && SelectedCatalogue == null)
                return;

            //if we are selecting something different (deals with null=>something and something=>null and something=>something equality)
            if (!RepositoryLocator.CatalogueRepository.AreEqual(_lastSelected ,SelectedCatalogue))
            {
                OfferChanceToSaveDialog.ShowIfRequired(_lastSelected);

                _lastSelected = SelectedCatalogue;

                if (SelectionChanged != null)
                    SelectionChanged(sender, e);
            }

            
        }

        private void btnCheckCatalogues_Click(object sender, EventArgs e)
        {
            CheckCatalogues();
        }

        public void AllowUserToSaveChanges()
        {
            OfferChanceToSaveDialog.ShowIfRequired(_lastSelected);
        }
    }

}

public enum AggregatesToShow
{
    None,
    CoreOnly,
    All
}

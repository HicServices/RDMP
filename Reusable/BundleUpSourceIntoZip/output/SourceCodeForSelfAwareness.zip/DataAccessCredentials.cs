using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Data.Common;
using System.Diagnostics.Contracts;
using System.Linq;
using CatalogueLibrary.Repositories;
using MapsDirectlyToDatabaseTable;
using ReusableLibraryCode.DataAccess;

namespace CatalogueLibrary.Data
{ 
    /// <summary>
    /// Stores a username and encrypted password the Password property of the entity will be a hex value formatted as string which can be decrypted at runtime via 
    /// the methods of base class EncryptedPasswordHost which currently uses SimpleStringValueEncryption which is a wrapper for RSACryptoServiceProvider.  The layout
    /// of this hierarchy however allows for future plugin utility e.g. using different encryption keys for different tables / user access rights etc. 
    /// </summary>
    public class DataAccessCredentials : DatabaseEntity, IDataAccessCredentials
    {
        public string Name { get; set; }
        public string Username { get; set; }

        private readonly EncryptedPasswordHost _encryptedPasswordHost;
        
        public DataAccessCredentials(IRepository repository, string name="")
        {
            // You know we said we'd accept IRepositories? Well, no. Sorry about that.
            Contract.Requires<ArgumentException>(repository.GetType().IsAssignableFrom(typeof(CatalogueRepository)));

            if (string.IsNullOrWhiteSpace(name))
                name = "DMP_Credentials_" + Guid.NewGuid();

            // todo: this is bad, we advertise IRepository in the API but we actually want a CatalogueRepository (surprise, callers!) - the IRepository ctor signature is required for ConstructEntity to work, so creation logic needs a bit of thought
            var catalogueRepository = new CatalogueRepository(((CatalogueRepository)repository).ConnectionStringBuilder);
            _encryptedPasswordHost = new EncryptedPasswordHost(catalogueRepository);

            repository.InsertAndHydrate(this, new Dictionary<string, object>
            {
                {"Name", name}
            });
        }

        public DataAccessCredentials(IRepository repository, DbDataReader r) : base(repository, r)
        {
            var catalogueRepository = new CatalogueRepository(((TableRepository)repository).ConnectionStringBuilder);
            _encryptedPasswordHost = new EncryptedPasswordHost(catalogueRepository);
            
            Name = (string)r["Name"];
            Username = r["Username"].ToString();
            Password = r["Password"].ToString();
        }

        public override void DeleteInDatabase()
        {
            try
            {
                base.DeleteInDatabase();
            }
            catch (Exception e)
            {
                if(e.Message.Contains("FK_DataAccessCredentials_TableInfo_DataAccessCredentials"))
                    throw new Exception("Cannot delete credentials " + Name + " because it is in use by one or more TableInfo objects(" + string.Join("",GetAllTableInfosThatUseThis().Values.Select(t=>string.Join(",",t)))+")");

                throw;
            }
        }
        
        #region equality
        public override int GetHashCode()
        {
            return ID;
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;
            if (obj.GetType() != this.GetType()) return false;
            return Equals((DataAccessCredentials)obj);
        }

        protected bool Equals(DataAccessCredentials other)
        {
            return ID == other.ID;
        }
        #endregion

        public Dictionary<DataAccessContext, List<TableInfo>> GetAllTableInfosThatUseThis()
        {
            return ((CatalogueRepository)Repository).TableInfoToCredentialsLinker.GetAllTablesUsingCredentials(this);
        }

        
        public override string ToString()
        {
            return Name + " (ID="+ID+")";
        }


        public string Password {
            get { return _encryptedPasswordHost.Password; }
            set { _encryptedPasswordHost.Password = value; } 
        }

        public string GetDecryptedPassword()
        {
            return _encryptedPasswordHost.GetDecryptedPassword();
        }
    }
}

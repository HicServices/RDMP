using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Data.Common;
using System.Diagnostics;
using System.Diagnostics.Contracts;
using System.IO;
using System.Linq;
using CatalogueLibrary.Data.Aggregation;
using CatalogueLibrary.Data.DataLoad;
using CatalogueLibrary.Data.EntityNaming;
using CatalogueLibrary.QueryBuilding;
using CatalogueLibrary.Repositories;
using CatalogueLibrary.Spontaneous;
using HIC.Logging;
using MapsDirectlyToDatabaseTable;
using ReusableLibraryCode;
using ReusableLibraryCode.Checks;
using ReusableLibraryCode.DataAccess;
using ReusableLibraryCode.DatabaseHelpers.Discovery;

namespace CatalogueLibrary.Data
{
    /// <summary>
    /// The central class for the RDMP, a Catalogue is a virtual dataset e.g. 'Hospital Admissions'.  A Catalogue can be a merging of multiple underlying tables and exists 
    /// independent of where the data is actually stored (look at other classes like TableInfo to see the actual locations of data).
    /// 
    /// As well as storing human readable names/descriptions of what is in the dataset it is the hanging off point for Attachments (SupportingDocument), validation logic, 
    /// extractable columns (CatalogueItem->ExtractionInformation->ColumnInfo) ways of filtering the data, aggregations to help understand the dataset etc.
    /// 
    /// Catalogues are always flat views although they can be built from multiple relational data tables underneath.
    /// 
    /// Whenever you see Catalogue, think Dataset (which is a reserved class in C#, hence the somewhat confusing name Catalogue)
    /// </summary>
    public class Catalogue : VersionedDatabaseEntity, IComparable, ICatalogue, IHasDependencies, ICheckable
    {
        #region Database Properties
        public string Acronym { get; set; }
        public string Name { get; set; }
        
        public CatalogueFolder Folder { get; set; }
        
        public string Description { get; set; }
        public Uri Detail_Page_URL { get; set; }
        public CatalogueType Type { get; set; }
        public CataloguePeriodicity Periodicity { get; set; }
        public CatalogueGranularity Granularity { get; set; }
        public string Geographical_coverage { get; set; }
        public string Background_summary { get; set; }
        public string Search_keywords { get; set; }
        public string Update_freq { get; set; }
        public string Update_sched { get; set; }
        public string Time_coverage { get; set; }
        public DateTime? Last_revision_date { get; set; }
        public string Contact_details { get; set; }
        public string Resource_owner { get; set; }
        public string Attribution_citation { get; set; }
        public string Access_options { get; set; }
        public string SubjectNumbers { get; set; }
        public Uri API_access_URL { get; set; }
        public Uri Browse_URL { get; set; }
        public Uri Bulk_Download_URL { get; set; }
        public Uri Query_tool_URL { get; set; }
        public Uri Source_URL { get; set; }

        //new fields requested by Wilfred
        public string Country_of_origin { get; set; }
        public string Data_standards { get; set; }
        public string Administrative_contact_name { get; set; }
        public string Administrative_contact_email { get; set; }
        public string Administrative_contact_telephone { get; set; }
        public string Administrative_contact_address { get; set; }
        public bool? Explicit_consent { get; set; }
        public string Ethics_approver { get; set; }
        public string Source_of_data_collection { get; set; }
        public string Ticket { get; set; }

        [DoNotExtractProperty]
        public string LoggingDataTask { get;  set; }
        [DoNotExtractProperty]
        public string ValidatorXML { get; set; }
        
        [DoNotExtractProperty]
        public int? TimeCoverage_ExtractionInformation_ID { get; set; }

        [DoNotExtractProperty]
        public int? PivotCategory_ExtractionInformation_ID { get; set; }


        [DoNotExtractProperty]
        public bool IsDeprecated { get; set; }
        [DoNotExtractProperty]
        public bool IsInternalDataset { get; set; }
        [DoNotExtractProperty]
        public bool IsColdStorageDataset { get; set; }

        [DoNotExtractProperty]
        public int? LiveLoggingServer_ID { get; set; }
        [DoNotExtractProperty]
        public int? TestLoggingServer_ID { get; set; }
        
        //just create these variables (one for every string or Uri field and reflection will populate them
        public static int Acronym_MaxLength = -1;
        public static int Name_MaxLength = -1;
        public static int Description_MaxLength = -1;
        public static int Geographical_coverage_MaxLength = -1;
        public static int Background_summary_MaxLength = -1;
        public static int Search_keywords_MaxLength = -1;
        public static int Update_freq_MaxLength = -1;
        public static int Update_sched_MaxLength = -1;
        public static int Time_coverage_MaxLength = -1;
        public static int Contact_details_MaxLength = -1;
        public static int Resource_owner_MaxLength = -1;
        public static int Attribution_citation_MaxLength = -1;
        public static int Access_options_MaxLength = -1;

        public static int Detail_Page_URL_MaxLength = -1;
        public static int API_access_URL_MaxLength = -1;
        public static int Browse_URL_MaxLength = -1;
        public static int Bulk_Download_URL_MaxLength = -1;
        public static int Query_tool_URL_MaxLength = -1;
        public static int Source_URL_MaxLength = -1;

        public static int Country_of_origin_MaxLength = -1;
        public static int Data_standards_MaxLength = -1;
        public static int Administrative_contact_name_MaxLength = -1;
        public static int Administrative_contact_email_MaxLength = -1;
        public static int Administrative_contact_telephone_MaxLength = -1;
        public static int Administrative_contact_address_MaxLength = -1;
        public static int Ethics_approver_MaxLength = -1;
        public static int Source_of_data_collection_MaxLength = -1;
        public static int SubjectNumbers_MaxLength = -1;
        public static int ValidatorXML_MaxLength = -1;

        public static int Ticket_MaxLength = -1;
        
        public DateTime? DatasetStartDate { get; set; }
        
        private int? _loadMetadataId;
        [DoNotExtractProperty]
        public int? LoadMetadata_ID
        {
            get { return _loadMetadataId; }
            set
            {
                //someone is changing LoadMetadataId, make sure there are no dependencies that are affected by this change
                PerformDisassociationCheck();

                _loadMetadataId = value;
            }
        }
        #endregion

        #region Relationships
        [NoMappingToDatabase]
        public CatalogueItem[] CatalogueItems
        {
            get
            {
                return Repository.GetAllObjectsWithParent<CatalogueItem>(this);
            }
        }

        [NoMappingToDatabase]
        public LoadMetadata LoadMetadata
        {
            get
            {
                if (LoadMetadata_ID == null)
                    return null;

                return Repository.GetObjectByID<LoadMetadata>((int) LoadMetadata_ID);
            }
        }
        
        [NoMappingToDatabase]
        public AggregateConfiguration[] AggregateConfigurations
        {
            get { return Repository.GetAllObjectsWithParent<AggregateConfiguration>(this); }
        }

        [NoMappingToDatabase]
        public ExternalDatabaseServer LiveLoggingServer
        {
            get
            {
                return LiveLoggingServer_ID == null
                    ? null
                    : Repository.GetObjectByID<ExternalDatabaseServer>((int)LiveLoggingServer_ID);
            }
        }

        [NoMappingToDatabase]
        public ExternalDatabaseServer TestLoggingServer
        {
            get
            {
                return TestLoggingServer_ID == null
                    ? null
                    : Repository.GetObjectByID<ExternalDatabaseServer>((int)TestLoggingServer_ID);
            }
        }

        [NoMappingToDatabase]
        public ExtractionInformation TimeCoverage_ExtractionInformation {
            get
            {
                return TimeCoverage_ExtractionInformation_ID == null
                    ? null
                    : Repository.GetObjectByID<ExtractionInformation>(TimeCoverage_ExtractionInformation_ID.Value);
            }
        }

        [NoMappingToDatabase]
        public ExtractionInformation PivotCategory_ExtractionInformation
        {
            get
            {
                return PivotCategory_ExtractionInformation_ID == null
                    ? null
                    : Repository.GetObjectByID<ExtractionInformation>(PivotCategory_ExtractionInformation_ID.Value);
            }
        }

        #endregion

        public enum CatalogueType
        {
            Unknown,
            ResearchStudy,
            Cohort,
            NationalRegistry, 
            HealthcareProviderRegistry,
            EHRExtract
        }

        public enum CataloguePeriodicity
        {
            Unknown,
            Daily,
            Weekly,
            Fortnightly,
            Monthly,
            BiMonthly,
            Quarterly,
            Yearly
        }

        public enum CatalogueGranularity
        {
            Unknown,
            National,
            Regional,
            HealthBoard,
            Hospital,
            Clinic
        }
        
        public Catalogue(IRepository repository, string name)
        {
            repository.InsertAndHydrate(this,new Dictionary<string, object>()
            {
                {"Name",name}
            });

            if (ID == 0 || string.IsNullOrWhiteSpace(Name) || Repository != repository)
                throw new ArgumentException("Repository failed to properly hydrate this class");
        }
        
        /// <summary>
        /// Creates a single runtime instance of the Catalogue based on the current state of the row read from the DbDataReader (does not advance the reader)
        /// </summary>
        /// <param name="r"></param>
        public Catalogue(IRepository repository, DbDataReader r): base(repository, r)
        {
            if(r["LoadMetadata_ID"] != DBNull.Value)
                LoadMetadata_ID = int.Parse(r["LoadMetadata_ID"].ToString()); 
          
            Acronym = r["Acronym"].ToString();
            Name = r["Name"].ToString();
            Description = r["Description"].ToString();

            //detailed info url with support for invalid urls
            Detail_Page_URL = ParseUrl(r, "Detail_Page_URL");

            LoggingDataTask = r["LoggingDataTask"] as string;

            if (r["LiveLoggingServer_ID"] == DBNull.Value)
                LiveLoggingServer_ID = null;
            else
                LiveLoggingServer_ID = (int) r["LiveLoggingServer_ID"];
            
            if (r["TestLoggingServer_ID"] == DBNull.Value)
                TestLoggingServer_ID = null;
            else
                TestLoggingServer_ID = (int)r["TestLoggingServer_ID"];
            
            ////Type - with handling for invalid enum values listed in database
            object type = r["Type"];
            if (type == null || type == DBNull.Value)
                Type = CatalogueType.Unknown;
            else
            {
                CatalogueType typeAsEnum;

                if (CatalogueType.TryParse(type.ToString(), true, out typeAsEnum))
                    Type = typeAsEnum;
                else
                    throw new Exception(" r[\"Type\"] had value " + type + " which is not contained in Enum CatalogueType");
                    
            }

            //Periodicity - with handling for invalid enum values listed in database
            object periodicity = r["Periodicity"];
            if (periodicity == null || periodicity == DBNull.Value)
                Periodicity = CataloguePeriodicity.Unknown;
            else
            {
                CataloguePeriodicity periodicityAsEnum;

                if (CataloguePeriodicity.TryParse(periodicity.ToString(), true, out periodicityAsEnum))
                    Periodicity = periodicityAsEnum;
                else
                {
                    throw new Exception(" r[\"Periodicity\"] had value " + periodicity + " which is not contained in Enum CataloguePeriodicity");
                }
            }

            object granularity = r["Granularity"];
            if (granularity == null || granularity == DBNull.Value)
                Granularity = CatalogueGranularity.Unknown;
            else
            {
                CatalogueGranularity granularityAsEnum;

                if (CatalogueGranularity.TryParse(granularity.ToString(), true, out granularityAsEnum))
                    Granularity = granularityAsEnum;
                else
                    throw new Exception(" r[\"granularity\"] had value " + granularity + " which is not contained in Enum CatalogueGranularity");
              
            }

            Geographical_coverage = r["Geographical_coverage"].ToString();
            Background_summary = r["Background_summary"].ToString();
            Search_keywords = r["Search_keywords"].ToString();
            Update_freq = r["Update_freq"].ToString();
            Update_sched = r["Update_sched"].ToString();
            Time_coverage = r["Time_coverage"].ToString();
            SubjectNumbers = r["SubjectNumbers"].ToString();

            object dt = r["Last_revision_date"];
            if (dt == null || dt == DBNull.Value)
                Last_revision_date = null;
            else
                Last_revision_date = (DateTime)dt;

            Contact_details = r["Contact_details"].ToString();
            Resource_owner = r["Resource_owner"].ToString();
            Attribution_citation = r["Attribution_citation"].ToString();
            Access_options = r["Access_options"].ToString();
            
            Country_of_origin = r["Country_of_origin"].ToString();
            Data_standards = r["Data_standards"].ToString();
            Administrative_contact_name = r["Administrative_contact_name"].ToString();
            Administrative_contact_email = r["Administrative_contact_email"].ToString();
            Administrative_contact_telephone = r["Administrative_contact_telephone"].ToString();
            Administrative_contact_address = r["Administrative_contact_address"].ToString();
            Ethics_approver = r["Ethics_approver"].ToString();
            Source_of_data_collection = r["Source_of_data_collection"].ToString();

            if (r["Explicit_consent"] != null && r["Explicit_consent"]!= DBNull.Value)
                Explicit_consent = (bool)r["Explicit_consent"];

            TimeCoverage_ExtractionInformation_ID = ObjectToNullableInt(r["TimeCoverage_ExtractionInformation_ID"]);
            PivotCategory_ExtractionInformation_ID = ObjectToNullableInt(r["PivotCategory_ExtractionInformation_ID"]);

            object oDatasetStartDate = r["DatasetStartDate"];
            if (oDatasetStartDate == null || oDatasetStartDate == DBNull.Value)
                DatasetStartDate = null;
            else
                DatasetStartDate = (DateTime) oDatasetStartDate;

            
            ValidatorXML = r["ValidatorXML"] as string;

            Ticket = r["Ticket"] as string;

            //detailed info url with support for invalid urls
            API_access_URL = ParseUrl(r, "API_access_URL");
            Browse_URL = ParseUrl(r, "Browse_URL" );
            Bulk_Download_URL = ParseUrl(r, "Bulk_Download_URL");
            Query_tool_URL = ParseUrl(r, "Query_tool_URL");
            Source_URL = ParseUrl(r, "Source_URL");
            IsDeprecated = (bool) r["IsDeprecated"];
            IsInternalDataset = (bool)r["IsInternalDataset"];
            IsColdStorageDataset = (bool) r["IsColdStorageDataset"];

            Folder = new CatalogueFolder(this,r["Folder"].ToString());
        }
        
        public override string ToString()
        {
            return Name;
        }

        public int CompareTo(object obj)
        {
            if (obj is Catalogue)
            {
                return -(obj.ToString().CompareTo(this.ToString())); //sort alphabetically (reverse)
            }

            throw new Exception("Cannot compare " + this.GetType().Name + " to " + obj.GetType().Name);
        }

      
        public string GetServerFromExtractionInformation(ExtractionCategory category)
        {
            string lastServerEncountered = null;
            
            foreach (var extractionInformation in GetAllExtractionInformation(category))
            {
                string currentServer = extractionInformation.ColumnInfo.TableInfo.Server;

                //if we haven't yet found any Server names then pick up the first one we see
                if (lastServerEncountered == null)
                    lastServerEncountered = currentServer;
                else
                    if (lastServerEncountered != currentServer) //if we have found a server name before now but this one is different!
                        throw new Exception("Found multiple servers listed under ExtractionInformations of category:" + category + " for catalogue:" + this.Name + ".  The servers were " + lastServerEncountered + " and " + currentServer);
                    
                if(string.IsNullOrWhiteSpace(currentServer))
                    throw new NullReferenceException("ExtractionInformation " + extractionInformation + " does not list a server where it's data can be fetched from");

                //if we get here then the server had the same name
                Debug.Assert(lastServerEncountered == currentServer);
            }

            return lastServerEncountered;
        }

        public void Check(ICheckNotifier notifier)
        {
            string reason;

            if (!IsAcceptableName(Name, out reason))
                notifier.OnCheckPerformed(
                    new CheckEventArgs(
                        "Catalogue name " + Name + " (ID=" + ID + ") does not follow naming conventions reason:" + reason,
                        CheckResult.Fail));
            else
                notifier.OnCheckPerformed(new CheckEventArgs("Catalogue name " + Name + " follows naming conventions ",CheckResult.Success));

            foreach (var catalogueItem in CatalogueItems)
                catalogueItem.Check(notifier);

            TableInfo[] tables = GetTableInfoList(true);
            foreach (TableInfo t in tables)
                t.Check(notifier);

            ExtractionInformation[] extractionInformations = this.GetAllExtractionInformation(ExtractionCategory.Core);
            
            if (extractionInformations.Any())
            {
                bool missingColumnInfos = false;

                foreach (ExtractionInformation missingColumnInfo in extractionInformations.Where(e=>e.ColumnInfo == null))
                {
                    notifier.OnCheckPerformed(
                        new CheckEventArgs(
                            "ColumnInfo behind ExtractionInformation/CatalogueItem " +
                            missingColumnInfo.GetRuntimeName() + " is MISSING, it must have been deleted",
                            CheckResult.Fail));
                    missingColumnInfos = true;
                }

                if (missingColumnInfos)
                    return;

                notifier.OnCheckPerformed(
                    new CheckEventArgs(
                        "Found " + extractionInformations.Length +
                        " ExtractionInformation(s), preparing to validate SQL with QueryBuilder", CheckResult.Success));

                var accessContext = DataAccessContext.InternalDataProcessing;

                try
                {
                    var server = DataAccessPortal.GetInstance().ExpectDistinctServer(tables, accessContext, false);
                
                    using (var con = server.GetConnection())
                    {
                        con.Open();
                        
                        string sql;
                        try
                        {
                            QueryBuilder qb = new QueryBuilder("TOP 1", null);
                            qb.AddColumnRange(extractionInformations);
                    
                            sql = qb.SQL;
                            notifier.OnCheckPerformed(new CheckEventArgs("Query Builder assembled the following SQL:" + Environment.NewLine + sql, CheckResult.Success));
                        }
                        catch (Exception e)
                        {
                            notifier.OnCheckPerformed(
                                new CheckEventArgs("Could not generate extraction SQL for Catalogue " + this,
                                    CheckResult.Fail, e));
                            return;
                        }
                
                        var cmd = DatabaseCommandHelper.GetCommand(sql, con);
                        cmd.CommandTimeout = 10;
                        DbDataReader r = cmd.ExecuteReader();

                        if (r.Read())
                            notifier.OnCheckPerformed(new CheckEventArgs("Succesfully read a row of data from the extraction SQL of Catalogue " + this,CheckResult.Success));
                        else
                            notifier.OnCheckPerformed(new CheckEventArgs("The query produced an empty result set for Catalogue" + this, CheckResult.Warning));
                    
                        con.Close();
                    }
                }
                catch (Exception e)
                {
                    notifier.OnCheckPerformed(
                        new CheckEventArgs(
                            "Extraction SQL Checking failed for Catalogue " + this +
                            " make sure that you can access the underlying server under DataAccessContext." +
                            accessContext +
                            " and that the SQL generated runs correctly (see internal exception for details)",
                            CheckResult.Fail, e));
                }
            }

            //supporting documents
            var f = new SupportingDocumentsFetcher(this);
            f.Check(notifier);
        }

        

        /// <summary>
        /// Retrieves all the TableInfo objects associated with a particular catalogue
        /// </summary>
        /// <returns></returns>
        public TableInfo[] GetTableInfoList(bool includeLookupTables)
        {
            List<TableInfo> normalTables, lookupTables;
            GetTableInfos(out normalTables, out lookupTables);

            if (includeLookupTables)
                return normalTables.Union(lookupTables).ToArray();

            return normalTables.ToArray();
        }

        /// <summary>
        /// Retrieves all the TableInfo objects associated with a particular catalogue
        /// </summary>
        /// <returns></returns>
        public TableInfo[] GetLookupTableInfoList()
        {
            List<TableInfo> normalTables, lookupTables;
            GetTableInfos(out normalTables, out lookupTables);

            return lookupTables.ToArray();
        }

        public ILoadMetadata GetLoadMetadata()
        {
            return LoadMetadata;
        }

        public void GetTableInfos(out List<TableInfo> normalTables, out List<TableInfo> lookupTables)
        {
            var normalTableIds = new HashSet<int>();
            var lookupTableIds = new HashSet<int>();

            foreach (var col in ((CatalogueRepository)Repository).Linker.GetColumnInfos(this))//get all the ColumnInfos that are associated with any of this Catalogue's CatalogueItems
            {
                if(col == ColumnInfo.Missing)
                    continue;

                if (col.GetAllLookupForColumnInfoWhereItIsA(LookupType.Description).Any())//if the column acts as a description for any dataset anywhere
                {
                    //it is a lookup table

                    //if we previously identified it as a regular table
                    if (normalTableIds.Contains(col.TableInfo_ID))
                        normalTableIds.Remove(col.TableInfo_ID); //it is not a regular table anymore

                    //it is a lookup table
                    if (!lookupTableIds.Contains(col.TableInfo_ID))
                        lookupTableIds.Add(col.TableInfo_ID);
                } 
                else
                {
                    //it is a normal table

                    //unless it is not (it could be that we have a regular column but there are also lookup columns in that table - bit freaky but could happen
                    if (lookupTableIds.Contains(col.TableInfo_ID))
                        continue;
                    
                    if (!normalTableIds.Contains(col.TableInfo_ID))
                        normalTableIds.Add(col.TableInfo_ID);
                }
            }
            
            //now use the IDs to get the unique tables
            normalTables = Repository.GetAllObjectsInIDList<TableInfo>(normalTableIds).ToList();
            lookupTables = Repository.GetAllObjectsInIDList<TableInfo>(lookupTableIds).ToList();
        }

        private string _getServerNameCachedAnswer = null;
        public string GetServerName(bool allowCaching = true)
        {
            if (!allowCaching)
                _getServerNameCachedAnswer = null;

            if(_getServerNameCachedAnswer == null)
            {

                var tableInfoList = GetTableInfoList(false);
                if (!tableInfoList.Any()) throw new Exception("'" + Name + "' catalogue (" + ID + ") has no TableInfo entries");
                if (tableInfoList.Select(info => info.GetDatabaseRuntimeName()).Distinct().Count() > 1)
                    throw new Exception("'" + Name + "' catalogue (" + ID + ") references multiple databases");
                _getServerNameCachedAnswer = tableInfoList.First().Server;
            }

            return _getServerNameCachedAnswer;
        }

        private string _getDatabaseNameCachedAnswer = null;
        

        public string GetDatabaseName(bool allowCaching = true)
        {
            if (!allowCaching)
                _getDatabaseNameCachedAnswer = null;

            if (_getDatabaseNameCachedAnswer == null)
            {

                var tableInfoList = GetTableInfoList(false);
                if (!tableInfoList.Any()) throw new Exception("'" + Name + "' catalogue (" + ID + ") has no TableInfo entries");
                if (tableInfoList.Select(info => info.GetDatabaseRuntimeName()).Distinct().Count() > 1)
                    throw new Exception("'" + Name + "' catalogue (" + ID + ") references multiple databases");
                _getDatabaseNameCachedAnswer = tableInfoList.First().GetDatabaseRuntimeName();
            }

            return _getDatabaseNameCachedAnswer;
        }

        public string GetRawDatabaseName()
        {
            return GetDatabaseName() + "_RAW";
        }

        private void PerformDisassociationCheck()
        {
            if(LoadMetadata_ID == null)
                return;
            //make sure there are no depencencies amongst the processes in the load
            foreach (ProcessTask p in LoadMetadata.GetAllProcessTasks(true))
                if (p.RelatesSolelyToCatalogue_ID == ID)
                    throw new Exception("Unable to change LoadMetadata for Catalogue " + Name + " because process " + p.Name + " relates solely to this Catalogue - remove the process from the load to fix this problem");
        }

        /// <summary>
        /// For a particular destination naming convention (e.g. RAW, STAGING), return a map of all table names in the catalogue and their correct
        /// mapping according to the convention and the table naming scheme
        /// </summary>
        /// <param name="destinationNamingConvention"></param>
        /// <param name="tableNamingScheme"></param>
        /// <returns></returns>
        public Dictionary<string, string> GetListOfTableNameMappings(LoadBubble destinationNamingConvention, INameDatabasesAndTablesDuringLoads namer)
        {
            var mappings = new Dictionary<string, string>();

            var normalTableInfoList = GetTableInfoList(false).ToList();
            
            normalTableInfoList.ForEach(info =>
                mappings.Add(info.GetRuntimeName(), info.GetRuntimeNameFor(namer, destinationNamingConvention)));

            return mappings;
        }

        public IDataAccessPoint GetLoggingServer(bool isTest)
        {
            return isTest ? TestLoggingServer : LiveLoggingServer;
        }

        public DiscoveredServer GetDistinctLiveDatabaseServer(DataAccessContext context, bool setInitialDatabase)
        {
            IDataAccessPoint whoCares;
            return GetDistinctLiveDatabaseServer(context, setInitialDatabase, out whoCares);
        }

        public DiscoveredServer GetDistinctLiveDatabaseServer(DataAccessContext context, bool setInitialDatabase, out IDataAccessPoint distinctAccessPoint)
        {
            return DataAccessPortal.GetInstance().ExpectDistinctServer(GetTableInfoList(false), context, setInitialDatabase, out distinctAccessPoint);
        }

        /// <summary>
        /// Use to set LoadMetadata to null without first performing Disassociation checks.  This should only be used for in-memory operations such as cloning
        /// This (if saved to the original database it was read from) could create orphans - load stages that relate to the disassociated catalogue.  But if 
        /// you are cloning a catalogue and dropping the LoadMetadata then you wont be saving the dropped state to the original database ( you will be saving it
        /// to the clone database so it won't be a problem).
        /// </summary>
        public void HardDisassociateLoadMetadata()
        {
            _loadMetadataId = null;
        }

        public LogManager GetLogManager(bool live)
        {
            ExternalDatabaseServer loggingServer;

            if (live)
                if(LiveLoggingServer_ID == null) 
                    throw new Exception("No live logging server set for Catalogue " + this.Name);
                else
                    loggingServer = LiveLoggingServer;
            else//not live
                if(TestLoggingServer_ID == null) 
                    throw new Exception("No test logging server set for Catalogue " + this.Name);
                else
                    loggingServer = TestLoggingServer;
            
            var server = DataAccessPortal.GetInstance().ExpectServer(loggingServer, DataAccessContext.Logging);

            return new LogManager(server, ProgressLogging.GetInstance(), FatalErrorLogging.GetInstance(), RowErrorLogging.GetInstance());

        }
        
        public IHasDependencies[] GetObjectsThisDependsOn()
        {
            List<IHasDependencies> iDependOn = new List<IHasDependencies>();

            iDependOn.AddRange(CatalogueItems);
            
            if(LoadMetadata != null)
                iDependOn.Add(LoadMetadata);

            return iDependOn.ToArray();
        }

        public IHasDependencies[] GetObjectsDependingOnThis()
        {
            return null;
        }

        public static bool IsAcceptableName(string name, out string reason)
        {
            if (name == null || string.IsNullOrWhiteSpace(name))
            {
                reason = "Name cannot be blank";
                return false;
            }

            var invalidCharacters = name.Where(c => Path.GetInvalidPathChars().Contains(c) || c == '\\' || c == '/' || c == '.' || c == '#' || c=='@' || c=='$').ToArray();
            if (invalidCharacters.Any())
            {
                reason = "The following invalid characters were found:" + string.Join(",", invalidCharacters.Select(c=>"'"+c+"'"));
                return false;
            }

            reason = null;
            return true;
        }

        public static bool IsAcceptableName(string name)
        {
            string whoCares;
            return IsAcceptableName(name, out whoCares);
        }


        public CatalogueItemIssue[] GetAllIssues()
        {
            return Repository.GetAllObjects<CatalogueItemIssue>("WHERE CatalogueItem_ID in (select ID from CatalogueItem WHERE Catalogue_ID =  " + ID + ")").ToArray();
        }

        public SupportingDocument[] GetAllSupportingDocuments(FetchOptions fetch)
        {
            string sql = GetFetchSQL(fetch);

            return Repository.GetAllObjects<SupportingDocument>(sql).ToArray();
        }

        public SupportingSQLTable[] GetAllSupportingSQLTablesForCatalogue(FetchOptions fetch)
        {
            string sql = GetFetchSQL(fetch);

            return Repository.GetAllObjects<SupportingSQLTable>(sql).ToArray();
        }

        private string GetFetchSQL(FetchOptions fetch)
        {
            switch (fetch)
            {
                case FetchOptions.AllGlobals:
                    return "WHERE IsGlobal=1";
                case FetchOptions.ExtractableGlobalsAndLocals:
                    return  "WHERE (Catalogue_ID=" + ID + " OR IsGlobal=1) AND Extractable=1";
                  case FetchOptions.ExtractableGlobals:
                    return  "WHERE IsGlobal=1 AND Extractable=1";
                    
                case FetchOptions.AllLocals:
                    return  "WHERE Catalogue_ID=" + ID + "  AND IsGlobal=0";//globals still retain their Catalogue_ID incase the configurer removes the global attribute in which case they revert to belonging to that Catalogue as a local
                    
                case FetchOptions.ExtractableLocals:
                    return  "WHERE Catalogue_ID=" + ID + " AND Extractable=1 AND IsGlobal=0";
                    
                case FetchOptions.AllGlobalsAndAllLocals:
                    return  "WHERE Catalogue_ID=" + ID + " OR IsGlobal=1";
                    
                default:
                    throw new ArgumentOutOfRangeException("fetch");
            }
        }

        public ExtractionInformation[] GetAllExtractionInformation(ExtractionCategory category)
        {
            return ((CatalogueRepository) Repository).Linker.GetAllExtractionInformationFrom(new []{this}, category);
        }
    }
}

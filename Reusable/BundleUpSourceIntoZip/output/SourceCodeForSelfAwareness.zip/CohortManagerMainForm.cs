using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Controls;
using System.Windows.Forms;
using System.Windows.Media;
using CatalogueLibrary.Data;
using CatalogueLibrary.Data.Cohort;
using CatalogueManager;
using CatalogueManager.SimpleDialogs;
using CatalogueManager.TestsAndSetup;
using CatalogueManager.TestsAndSetup.ServicePropogation;
using CohortManager.UserFriendly;
using ReusableUIComponents;

namespace CohortManager
{
    /// <summary>
    /// Main window of the Catalogue Manager application.  Cohort creation is the process of comming up with a list of patient identifiers that fulfil a researchers study requirements (e.g.
    /// 'I want all patients prescribed an opiate between 2001 and 2016 and are still alive today and resident in Tayside'.  Identifying the patient list is done through the creation of a
    /// CohortIdentificationConfiguration, this is a high level description of what you are trying to achieve.  Once you have a CohortIdentificationConfiguration you can start creating 
    /// Sets with filters and set operations (See 'Cohort Generation' in UserManual.docx).
    /// 
    /// The menu on the top lets you create new CohortIdentificationConfiguration
    /// 
    /// Everything else is handled by CohortIdentificationConfigurationUI
    /// </summary>
    public partial class CohortManagerMainForm : RDMPForm
    {
        CohortManagerUserFriendlyMode userFriendlyMode;

        public CohortManagerMainForm()
        {
            InitializeComponent();

            userFriendlyMode = new CohortManagerUserFriendlyMode();
            userFriendlyMode.Dock = DockStyle.Fill;

            //disables controls
            cohortIdentificationConfigurationUI1.Configuration = null;
        }

        private void openToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            var allCohortIdentificationConfigurations = RepositoryLocator.CatalogueRepository.GetAllObjects<CohortIdentificationConfiguration>();
            
            var selecter = new SelectIMapsDirectlyToDatabaseTableDialog(allCohortIdentificationConfigurations, false, true);
            var dr = selecter.ShowDialog();
            
            //user could have been sneaky and deleted the configuration!
            if(cohortIdentificationConfigurationUI1.Configuration != null)
                if (!cohortIdentificationConfigurationUI1.Configuration.StillExists())
                    cohortIdentificationConfigurationUI1.Configuration = null;

            if (dr == DialogResult.OK)
            {
                cohortIdentificationConfigurationUI1.Configuration = selecter.Selected as CohortIdentificationConfiguration;

                if(cbUserFriendly.Checked)
                    try
                    {
                        userFriendlyMode.CohortIdentificationConfiguration = selecter.Selected as CohortIdentificationConfiguration;
                    }
                    catch (Exception exception)
                    {
                        ExceptionViewer.Show(exception);
                    }
            }
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            cohortIdentificationConfigurationUI1.Configuration = new CohortIdentificationConfiguration(RepositoryLocator.CatalogueRepository,"Configuration " + Guid.NewGuid());
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            cohortIdentificationConfigurationUI1.Save();
        }

        private void refreshAllCataloguesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            cohortIdentificationConfigurationUI1.RefreshUIFromDatabase();
        }

        private void showPerformanceCounterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new CatalogueLibraryPerformanceCounterUI().Show();
        }

        private void launchDiagnosticsScreenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DiagnosticsScreen dialog = new DiagnosticsScreen(null);
            dialog.RepositoryLocator = RepositoryLocator;
            dialog.ShowDialog();
        }

        private void cbUserFriendly_CheckedChanged(object sender, EventArgs e)
        {
            if(cbUserFriendly.Checked)
                SwitchToUserFriendly();
            else
                SwitchToTechy();
        }
        private void SwitchToUserFriendly()
        {
            this.Controls.Remove(cohortIdentificationConfigurationUI1);

            //propagate the RepositoryLocator down to children of the control we are about to add
            new ServiceLocatorPropagatorToChildControls(this).PropagateRecursively(new[] { userFriendlyMode },false);

            this.Controls.Add(userFriendlyMode);
        }
        private void SwitchToTechy()
        {
            this.Controls.Remove(userFriendlyMode);

            //propagate the RepositoryLocator down to children of the control we are about to add
            new ServiceLocatorPropagatorToChildControls(this).PropagateRecursively(new[] { cohortIdentificationConfigurationUI1 },false);

            this.Controls.Add(cohortIdentificationConfigurationUI1);

        }
    }
}

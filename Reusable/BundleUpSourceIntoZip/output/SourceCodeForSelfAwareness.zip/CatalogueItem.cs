using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Reflection;
using CatalogueLibrary.Repositories;
using MapsDirectlyToDatabaseTable;
using MapsDirectlyToDatabaseTable.Revertable;
using ReusableLibraryCode;
using ReusableLibraryCode.Checks;


namespace CatalogueLibrary.Data
{
    /// <summary>
    /// A virtual column that is made available to researchers.  Each Catalogue has 1 or more CatalogueItems, these contain the descriptions of what is contained
    /// in the column as well as any outstanding/resolved issues with the column (see CatalogueItemIssue).
    /// 
    /// It is important to note that CatalogueItems are not tied to underlying database tables/columns except via an ExtractionInformation.  This means that you can
    /// for example have multiple different versions of the same underlying ColumnInfo 
    /// 
    /// e.g.
    /// CatalogueItem: PatientDateOfBirth (ExtractionInformation verbatim but 'Special Approval Required')
    /// CatalogueItem: PatientDateOfBirthApprox (ExtractionInformation rounds to nearest quarter but governance is 'Core')
    /// 
    /// Both the above would extract from the same ColumnInfo DateOfBirth
    /// </summary>
    public class CatalogueItem : VersionedDatabaseEntity, IDeleteable, IComparable, IHasDependencies,ICheckable,IRevertable
    {
        #region Database Properties
        public static int Name_MaxLength = -1;
        public static int Statistical_cons_MaxLength = -1;
        public static int Research_relevance_MaxLength = -1;
        public static int Description_MaxLength = -1;
        public static int Topic_MaxLength = -1;
        public static int Agg_method_MaxLength = -1;
        public static int Limitations_MaxLength = -1;
        public static int Comments_MaxLength = -1;

        [DoNotExtractProperty]
        public int Catalogue_ID { get; private set; }
        
        public string _Name;
        public string _Statistical_cons;
        public string _Research_relevance;
        public string _Description;
        public string _Topic;
        public string _Agg_method;
        public string _Limitations;
        public string _Comments;

        public string Name {
            get { return _Name;}
            set {
                if (value.Length > Name_MaxLength && Comments_MaxLength != -1) 
                    throw new Exception("Value is too long and would result in database truncation");
                _Name = value;
            } 
        }

        public string Statistical_cons {
            get { return _Statistical_cons; }
            set
            {
                if (value.Length > Statistical_cons_MaxLength && Comments_MaxLength != -1)
                    throw new Exception("Value is too long and would result in database truncation");
                else 
                    _Statistical_cons = value;
            } 
        }

        public string Research_relevance
        {
            get { return _Research_relevance; }
            set
            {
                if (value.Length > Research_relevance_MaxLength && Comments_MaxLength != -1)
                    throw new Exception("Value is too long and would result in database truncation");
                else
                    _Research_relevance = value;
            }
        }

        public string Description
        {
            get { return _Description; }
            set
            {
                if (value.Length > Description_MaxLength && Comments_MaxLength != -1)
                    throw new Exception("Value is too long and would result in database truncation");
                else
                    _Description = value;
            }
        }
        public string Topic
        {
            get { return _Topic; }
            set
            {
                if (value.Length > Topic_MaxLength && Comments_MaxLength != -1)
                    throw new Exception("Value is too long and would result in database truncation");
                else
                    _Topic = value;
            }
        }

        public string Agg_method
        {
            get { return _Agg_method; }
            set
            {
                if (value.Length > Agg_method_MaxLength && Comments_MaxLength != -1)
                    throw new Exception("Value is too long and would result in database truncation");
                else
                    _Agg_method = value;
            }
        }

        public string Limitations
        {
            get { return _Limitations; }
            set
            {
                if (value.Length > Limitations_MaxLength && Comments_MaxLength != -1)
                    throw new Exception("Value is too long and would result in database truncation");
                else
                    _Limitations = value;
            }
        }

        public string Comments
        {
            get { return _Comments; }
            set
            {

                if (value.Length > Comments_MaxLength && Comments_MaxLength !=-1)
                    throw new Exception("Value is too long and would result in database truncation");
                else
                    _Comments = value;
            }
        }

        public Catalogue.CataloguePeriodicity Periodicity { get; set; }
        #endregion


        #region Relationships
        [NoMappingToDatabase]
        public Catalogue Catalogue {
            get { return Repository.GetObjectByID<Catalogue>(Catalogue_ID); }
        }

        [NoMappingToDatabase]
        public IEnumerable<ExtractionInformation> ExtractionInformations
        {
            get
            {
                return ((CatalogueRepository) Repository).Linker.GetAllExtractionInformationFrom(this, ExtractionCategory.Any);
            }
        }

        [NoMappingToDatabase]
        public IEnumerable<ColumnInfo> ColumnInfos
        {
            get
            {
                return ((CatalogueRepository)Repository).Linker.GetColumnInfos(this);
            }
        }

        [NoMappingToDatabase]
        public IEnumerable<CatalogueItemIssue> CatalogueItemIssues
        {
            get { return Repository.GetAllObjectsWithParent<CatalogueItemIssue>(this); }
        }

        #endregion

        public CatalogueItem(IRepository repository, Catalogue parent, string name)
        {
            repository.InsertAndHydrate(this,new Dictionary<string, object>
            {
                {"Name", name},
                {"Catalogue_ID", parent.ID}
            });
        }

        public CatalogueItem(IRepository repository, DbDataReader r): base(repository, r)
        {
            Catalogue_ID = int.Parse(r["Catalogue_ID"].ToString()); //gets around decimals and other random crud number field types that sql returns
            Name = (string)r["Name"];
            Statistical_cons = r["Statistical_cons"].ToString();
            Research_relevance = r["Research_relevance"].ToString();
            Description = r["Description"].ToString();
            Topic = r["Topic"].ToString();
            Agg_method = r["Agg_method"].ToString();
            Limitations = r["Limitations"].ToString();
            Comments = r["Comments"].ToString();


            //Periodicity - with handling for invalid enum values listed in database
            object periodicity = r["Periodicity"];
            if (periodicity == null || periodicity == DBNull.Value)
                Periodicity = Catalogue.CataloguePeriodicity.Unknown;
            else
            {
                Catalogue.CataloguePeriodicity periodicityAsEnum;

                if(Catalogue.CataloguePeriodicity.TryParse(periodicity.ToString(), true, out periodicityAsEnum))
                    Periodicity = periodicityAsEnum;
                else
                     Periodicity = Catalogue.CataloguePeriodicity.Unknown;

            }
        }

        public override string ToString()
        {
            return Name;
        }

        public int CompareTo(object obj)
        {
            if (obj is CatalogueItem)
            {
                return -(obj.ToString().CompareTo(this.ToString())); //sort alphabetically (reverse)
            }

            throw new Exception("Cannot compare " + this.GetType().Name + " to " + obj.GetType().Name);
        }
        
        
        public CatalogueItem CloneCatalogueItemWithIDIntoCatalogue(Catalogue cataToImportTo)
        {
            if(this.Catalogue_ID == cataToImportTo.ID)
                throw new ArgumentException("Cannot clone a CatalogueItem into it's own parent, specify a different catalogue to clone into");

            var clone = new CatalogueItem(cataToImportTo.Repository, cataToImportTo, this.Name);
            
            //Get all the properties           
            PropertyInfo[] propertyInfo = this.GetType().GetProperties(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);

            //Assign all source property to taget object 's properties
            foreach (PropertyInfo property in propertyInfo)
            {
                //Check whether property can be written to
                if (property.CanWrite && !property.Name.Equals("ID") && !property.Name.Equals("Catalogue_ID"))
                    if (property.PropertyType.IsValueType || property.PropertyType.IsEnum || property.PropertyType.Equals(typeof(System.String)))
                        property.SetValue(clone, property.GetValue(this, null), null);
            }

            clone.SaveToDatabase();
            
            return clone;
        }


        public IEnumerable<ColumnInfo> GuessAssociatedColumn(ColumnInfo[] guessPool)
        {
            //exact matches exist so return those
            ColumnInfo[] Guess = guessPool.Where(col => col.GetRuntimeName().Equals(this.Name)).ToArray();
            if (Guess.Any())
                return Guess;

            //ignore caps match instead
            Guess = guessPool.Where(col => col.GetRuntimeName().ToLower().Equals(this.Name.ToLower())).ToArray();
            if (Guess.Any())
                return Guess;

            //ignore caps and remove spaces match instead
            Guess =
                guessPool.Where(col => col.GetRuntimeName().ToLower().Replace(" ", "").Equals(this.Name.ToLower().Replace(" ", ""))).ToArray();
            if (Guess.Any())
                return Guess;

            //contains match is final last resort
            return guessPool.Where(col =>
                col.GetRuntimeName().ToLower().Contains(this.Name.ToLower())
                ||
                Name.ToLower().Contains(col.GetRuntimeName().ToLower()));
            
        }

        public IHasDependencies[] GetObjectsThisDependsOn()
        {
            return null;
        }

        public IHasDependencies[] GetObjectsDependingOnThis()
        {
            List<IHasDependencies> dependantObjects = new List<IHasDependencies>();
            
            //all extraction informations are children
            var extractionInformations = ExtractionInformations.ToArray();
            
            //also any columninfo that does not have an extraction information is also dependant
            //add in column infos that don't have extraction informations
            dependantObjects.AddRange(
                //get all column infos
                ColumnInfos.Where(c=>!extractionInformations.Any(e=>e.ColumnInfo.Equals(c)) //where the columninfo is not already referenced via a Extraction information
                ));

            dependantObjects.Add(Catalogue);
            dependantObjects.AddRange(extractionInformations);
            return dependantObjects.ToArray();
        }

        public void Check(ICheckNotifier notifier)
        {
            var columnInfos = ColumnInfos.ToArray();

            if (columnInfos.Length > 1)
                notifier.OnCheckPerformed(
                    new CheckEventArgs(
                        "There are " + columnInfos.Length + " ColumnInfos associated with CatalogueItem " + Name +
                        " (ID=" + ID + "):" + string.Join(",", columnInfos.Select(c => c.ToString())),
                        CheckResult.Warning));

            var extractions = ExtractionInformations.ToArray();
            if(extractions.Length > 1)
                notifier.OnCheckPerformed(new CheckEventArgs("There are " + extractions.Length + " Extractable ColumnInfos associated with CatalogueItem " + Name +
                        " (ID=" + ID + ") - while it only dodgy having 2+ associated columns for the same CatalogueItem, it is utterly forbidden to have 2+ EXTRACTABLE ones!:" + string.Join(",", extractions.Select(c => c.ColumnInfo.Name)),
                        CheckResult.Fail));
        }
    }
}

using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.ComponentModel;
using System.Windows.Forms;
using CatalogueLibrary.Data.Cohort;
using CatalogueLibrary.QueryBuilding;
using CohortManagerLibrary;
using CohortManagerLibrary.QueryBuilding;
using ScintillaNET;

namespace CohortManager.Results
{
    /// <summary>
    /// Shows the SQL Query that CohortQueryBuilder has built for the current CohortIdentificationConfiguration (See ConfigureCohortContainersUI).  The 'Full SQL' tab is the SQL that will
    /// be run for the entire configuration.  The 'Selected Task Only SQL' tab will show only the SQL for the selected Set / Container in ConfigureCohortContainersUI.
    /// </summary>
    public partial class CohortQueryBuilderUI : UserControl
    {
        private Scintilla FullSQLQueryEditor;
        private Scintilla SelectedSQLQueryEditor;

        private CohortIdentificationConfiguration _configuration;

        private bool designMode;
        public CohortQueryBuilderUI()
        {
            InitializeComponent();

             designMode = (LicenseManager.UsageMode == LicenseUsageMode.Designtime);

            if (designMode) //dont add the QueryEditor if we are in design time (visual studio) because it breaks
                return;

            FullSQLQueryEditor = new Scintilla();
            FullSQLQueryEditor.Dock = DockStyle.Fill;
            FullSQLQueryEditor.Scrolling.ScrollBars = ScrollBars.Both;
            FullSQLQueryEditor.ConfigurationManager.Language = "mssql";
            FullSQLQueryEditor.Margins[0].Width = 40; //allows display of line numbers
            
            FullSQLQueryEditor.IsReadOnly = true;


            SelectedSQLQueryEditor = new Scintilla();
            SelectedSQLQueryEditor.Dock = DockStyle.Fill;
            SelectedSQLQueryEditor.Scrolling.ScrollBars = ScrollBars.Both;
            SelectedSQLQueryEditor.ConfigurationManager.Language = "mssql";
            SelectedSQLQueryEditor.Margins[0].Width = 40; //allows display of line numbers
                        SelectedSQLQueryEditor.IsReadOnly = true;

            tpSQL.Controls.Add(FullSQLQueryEditor);
            tabPage1.Controls.Add(SelectedSQLQueryEditor);
        }

        public CohortIdentificationConfiguration Configuration
        {
            get { return _configuration; }
            set
            {
                //if configuration is changed refresh from database
                _configuration = value;
                RefreshUIFromDatabase();
            }
        }

        public void RefreshUIFromDatabase()
        {
            if(designMode)
                return;

            FullSQLQueryEditor.IsReadOnly = false;

            if (Configuration == null)
                FullSQLQueryEditor.Text = "";
            else
            {
                //refresh it out of the database
                Configuration.RevertToDatabaseState();
                try
                {
                    CohortQueryBuilder queryBuilder = new CohortQueryBuilder(Configuration);
                    FullSQLQueryEditor.Text = queryBuilder.SQL;
                }
                catch (Exception ex)
                {
                    FullSQLQueryEditor.Text = ex.ToString();
                }
                
            }

            FullSQLQueryEditor.IsReadOnly = true;
        }

        public void SetSelectedSQL(string sql)
        {
            SelectedSQLQueryEditor.IsReadOnly = false;
            SelectedSQLQueryEditor.Text = sql;
            SelectedSQLQueryEditor.IsReadOnly = true;
        }

    }
}

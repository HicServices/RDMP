using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using CatalogueLibrary.Data;
using CatalogueLibrary.QueryBuilding;
using HIC.Logging;
using ReusableLibraryCode.Checks;
using ReusableUIComponents;

namespace CatalogueManager.MainFormUITabs.SubComponents
{
    /// <summary>
    /// This control wraps CatalogueCollection (See CatalogueCollection for full documentation of functionality).  It lets you rapidly switch between viewing live or depracated / internal
    /// datasets.  You can also filter by dataset (Catalogue) name or folder name.
    /// </summary>
    public partial class CatalogueCollectionHost : UserControl
    {

        public event EventHandler CollectionChanged;
        public event EventHandler SelectedCatalogueChanged;
        public Catalogue SelectedCatalogue { get { return CatalogueCollection.SelectedCatalogue as Catalogue; } }


        public ObservableCollection<Catalogue> Collection
        {
            get
            {
                return CatalogueCollection.Collection;
            }
            set
            {
                CatalogueCollection.Collection = value;
                CatalogueCollection.ApplyFilters();
            }
        }

        
        public CatalogueCollectionHost()
        {
            InitializeComponent();

            //prevent visual studio crashes
            if (LicenseManager.UsageMode == LicenseUsageMode.Designtime)
                return;

            CatalogueCollection.CatalogueCollectionChanged += (s,e) =>
            {
                CatalogueCollection.ApplyFilters();

                //bubble this event
                if (CollectionChanged != null)
                    CollectionChanged(s,e);
            };

            CatalogueCollection.SelectionChanged += FireSelectedCatalogueChanged;//bubble this up


            BetterToolTip toolTip = new BetterToolTip(this);
            toolTip.SetToolTip(groupBox1, ToolTips.InternalOnlyRadio, Images.InternalOnlyRadio);
            toolTip.SetToolTip(groupBox2, ToolTips.InternalOnlyRadio, Images.InternalOnlyRadio);
            toolTip.SetToolTip(gbColdStorage, ToolTips.HotVsColdStorage,Images.HotVsColdStorage);
        }



        private void FireSelectedCatalogueChanged(object sender, EventArgs e)
        {
            if(SelectedCatalogueChanged!= null)
                SelectedCatalogueChanged(sender,e);
        }

        private void tbFilter_TextChanged(object sender, EventArgs e)
        {
            CatalogueCollection.Filter = tbFilter.Text;
        }

        private void anyRadiobuttonThatRefreshesLists_CheckedChanged(object sender, EventArgs e)
        {
            CatalogueCollection.ShowColdStorage = rbColdStorage.Checked;
            CatalogueCollection.ShowDeprecated = rbDeprecated.Checked;
            CatalogueCollection.ShowInternal = rbInternal.Checked;
        }
        
        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}

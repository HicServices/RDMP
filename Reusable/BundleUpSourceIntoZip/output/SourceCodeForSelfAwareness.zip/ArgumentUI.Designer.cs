namespace RDMPObjectVisualisation.DemandsInitializationUIs // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
{
    partial class ArgumentUI<T>
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label4 = new System.Windows.Forms.Label();
            this.tbName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbID = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tbDescription = new System.Windows.Forms.TextBox();
            this.tbType = new System.Windows.Forms.TextBox();
            this.cbxValue = new System.Windows.Forms.ComboBox();
            this.lblError = new System.Windows.Forms.Label();
            this.cbValue = new System.Windows.Forms.CheckBox();
            this.btnSetSQL = new System.Windows.Forms.Button();
            this.btnLaunchCustomUI = new System.Windows.Forms.Button();
            this.cbxRelatedToLoadMetadata = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 58);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "Type:";
            // 
            // tbName
            // 
            this.tbName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbName.Location = new System.Drawing.Point(94, 29);
            this.tbName.Name = "tbName";
            this.tbName.ReadOnly = true;
            this.tbName.Size = new System.Drawing.Size(383, 20);
            this.tbName.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(31, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Name:";
            // 
            // tbID
            // 
            this.tbID.Location = new System.Drawing.Point(94, 3);
            this.tbID.Name = "tbID";
            this.tbID.ReadOnly = true;
            this.tbID.Size = new System.Drawing.Size(100, 20);
            this.tbID.TabIndex = 10;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(48, 6);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(21, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "ID:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(5, 84);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Value:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(29, 145);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 13);
            this.label5.TabIndex = 14;
            this.label5.Text = "Description:";
            // 
            // tbDescription
            // 
            this.tbDescription.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbDescription.Location = new System.Drawing.Point(99, 145);
            this.tbDescription.Multiline = true;
            this.tbDescription.Name = "tbDescription";
            this.tbDescription.ReadOnly = true;
            this.tbDescription.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tbDescription.Size = new System.Drawing.Size(388, 107);
            this.tbDescription.TabIndex = 15;
            // 
            // tbType
            // 
            this.tbType.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbType.Location = new System.Drawing.Point(37, 55);
            this.tbType.Name = "tbType";
            this.tbType.ReadOnly = true;
            this.tbType.Size = new System.Drawing.Size(453, 20);
            this.tbType.TabIndex = 16;
            // 
            // cbxValue
            // 
            this.cbxValue.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cbxValue.FormattingEnabled = true;
            this.cbxValue.Location = new System.Drawing.Point(37, 81);
            this.cbxValue.Name = "cbxValue";
            this.cbxValue.Size = new System.Drawing.Size(450, 21);
            this.cbxValue.TabIndex = 17;
            this.cbxValue.TextChanged += new System.EventHandler(this.cbxValue_TextChanged);
            // 
            // lblError
            // 
            this.lblError.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblError.ForeColor = System.Drawing.Color.Red;
            this.lblError.Location = new System.Drawing.Point(151, 106);
            this.lblError.Name = "lblError";
            this.lblError.Size = new System.Drawing.Size(336, 36);
            this.lblError.TabIndex = 18;
            // 
            // cbValue
            // 
            this.cbValue.AutoSize = true;
            this.cbValue.Location = new System.Drawing.Point(48, 83);
            this.cbValue.Name = "cbValue";
            this.cbValue.Size = new System.Drawing.Size(15, 14);
            this.cbValue.TabIndex = 19;
            this.cbValue.UseVisualStyleBackColor = true;
            this.cbValue.CheckedChanged += new System.EventHandler(this.cbValue_CheckedChanged);
            // 
            // btnSetSQL
            // 
            this.btnSetSQL.Location = new System.Drawing.Point(48, 81);
            this.btnSetSQL.Name = "btnSetSQL";
            this.btnSetSQL.Size = new System.Drawing.Size(75, 23);
            this.btnSetSQL.TabIndex = 20;
            this.btnSetSQL.Text = "SetSQL";
            this.btnSetSQL.UseVisualStyleBackColor = true;
            this.btnSetSQL.Visible = false;
            this.btnSetSQL.Click += new System.EventHandler(this.btnSetSQL_Click);
            // 
            // btnLaunchCustomUI
            // 
            this.btnLaunchCustomUI.Location = new System.Drawing.Point(51, 83);
            this.btnLaunchCustomUI.Name = "btnLaunchCustomUI";
            this.btnLaunchCustomUI.Size = new System.Drawing.Size(168, 23);
            this.btnLaunchCustomUI.TabIndex = 20;
            this.btnLaunchCustomUI.Text = "Launch Custom UI";
            this.btnLaunchCustomUI.UseVisualStyleBackColor = true;
            this.btnLaunchCustomUI.Visible = false;
            this.btnLaunchCustomUI.Click += new System.EventHandler(this.btnLaunchCustomUI_Click);
            // 
            // cbxRelatedToLoadMetadata
            // 
            this.cbxRelatedToLoadMetadata.AutoSize = true;
            this.cbxRelatedToLoadMetadata.Checked = true;
            this.cbxRelatedToLoadMetadata.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbxRelatedToLoadMetadata.Location = new System.Drawing.Point(37, 113);
            this.cbxRelatedToLoadMetadata.Name = "cbxRelatedToLoadMetadata";
            this.cbxRelatedToLoadMetadata.Size = new System.Drawing.Size(243, 17);
            this.cbxRelatedToLoadMetadata.TabIndex = 21;
            this.cbxRelatedToLoadMetadata.Text = "Only show items related to this Load Metadata";
            this.cbxRelatedToLoadMetadata.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.cbxRelatedToLoadMetadata.UseVisualStyleBackColor = true;
            this.cbxRelatedToLoadMetadata.CheckedChanged += new System.EventHandler(this.cbRelatedToLoadMetadata_CheckedChanged);
            // 
            // ArgumentUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.cbxRelatedToLoadMetadata);
            this.Controls.Add(this.btnLaunchCustomUI);
            this.Controls.Add(this.btnSetSQL);
            this.Controls.Add(this.cbValue);
            this.Controls.Add(this.lblError);
            this.Controls.Add(this.cbxValue);
            this.Controls.Add(this.tbType);
            this.Controls.Add(this.tbDescription);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbName);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbID);
            this.Controls.Add(this.label2);
            this.Name = "ArgumentUI";
            this.Size = new System.Drawing.Size(490, 255);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbDescription;
        private System.Windows.Forms.TextBox tbType;
        private System.Windows.Forms.ComboBox cbxValue;
        private System.Windows.Forms.Label lblError;
        private System.Windows.Forms.CheckBox cbValue;
        private System.Windows.Forms.Button btnSetSQL;
        private System.Windows.Forms.Button btnLaunchCustomUI;
        private System.Windows.Forms.CheckBox cbxRelatedToLoadMetadata;

    }
}

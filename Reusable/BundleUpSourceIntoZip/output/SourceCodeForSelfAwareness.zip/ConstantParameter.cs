using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using CatalogueLibrary.Data;
using CatalogueLibrary.DataHelper;

namespace CatalogueLibrary.QueryBuilding
{
    public class ConstantParameter : ISqlParameter
    {
        /// <summary>
        /// Use this class to create standard parameters which you will always manually add in code to a QueryBuilder.  These are not editable
        /// by users and are not stored in a database.  They should be used for things such as cohortDefinitionID, projectID etc.
        /// </summary>
        /// <param name="parameterSQL">The declaration sql e.g. DECLARE @bob as int</param>
        /// <param name="value">The value to set the paramater e.g. 1</param>
        /// <param name="comment">Some text to appear above the parameter, explaining its purpose</param>
        public ConstantParameter(string parameterSQL,string value,string comment)
        {
            Value = value;
            Comment = comment;
            ParameterSQL = parameterSQL;
        }

        public void SaveToDatabase()
        {
            throw new NotSupportedException();
        }

        public override string ToString()
        {
            return ParameterName;
        }

        public string ParameterName { get { return QuerySyntaxHelper.GetParameterNameFromDeclarationSQL(ParameterSQL); } }
        public string ParameterSQL { get; set; }
        public string Value { get; set; }
        public string Comment { get; set; }
    }
}

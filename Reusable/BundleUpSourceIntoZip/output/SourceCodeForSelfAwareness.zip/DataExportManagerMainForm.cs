using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Data.SqlClient;
using System.Windows.Forms;
using CatalogueManager.LocationsMenu;
using CatalogueManager.SimpleDialogs;
using CatalogueManager.TestsAndSetup;
using CatalogueManager.TestsAndSetup.ServicePropogation;
using DataExportManager2.SimpleDialogs;

namespace DataExportManager2
{
    /// <summary>
    /// The main window of the Data Export Manager application.  Contains tabs for Cohort (identifier lists), Dataset (which datasets are extractable) and Project management (ongoing and 
    /// historical projects involving anonymous cohort linked data extractions).
    /// 
    /// See ExtractableCohortManagementUI , DataSetManagementUI and ProjectManagementUI
    /// </summary>
    public partial class DataExportManagerMainForm : RDMPForm
    {
        public DataExportManagerMainForm()
        {
            InitializeComponent();

            //cohorts or datasets have changed so trigger a resonnance cascade down onto those children UIs
            cohortManagement1.ChangesSaved += new ChangesSavedHandler(cohortManagement1_ChangesSaved);
            dataSetManagementUI1.ChangesSaved += new ChangesSavedHandler(dataSetManagementUI1_ChangesSaved);
        }

        void dataSetManagementUI1_ChangesSaved()
        {
            projectManagementUI1.RefreshUIFromDatabase();
        }

        void cohortManagement1_ChangesSaved()
        {
            projectManagementUI1.RefreshUIFromDatabase();
        }

        private void changeCatalogueConnectionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ChooseCatalogueDatabaseConnection();
        }

        private void ChooseCatalogueDatabaseConnection()
        {
            var dialog = new ChoosePlatformDatabases();
            dialog.RepositoryLocator = RepositoryLocator;
            dialog.ShowDialog(this);

            projectManagementUI1.RefreshUIFromDatabase();
            dataSetManagementUI1.RefreshUIFromDatabase();
            cohortManagement1.RefreshUIFromDatabase();
            
        }


        private void launchDiagnosticsScreenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DiagnosticsScreen diagnostics = new DiagnosticsScreen(null);
            diagnostics.RepositoryLocator = RepositoryLocator;
            diagnostics.ShowDialog(this);

            if (diagnostics.ShouldReloadCatalogues)
            {
                projectManagementUI1.RefreshUIFromDatabase();
                cohortManagement1.RefreshUIFromDatabase();
                dataSetManagementUI1.RefreshUIFromDatabase();
            }
        }

        private void setHashingAlgorithmToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ConfigureHashingAlgorithm dialog = new ConfigureHashingAlgorithm();
            dialog.RepositoryLocator = RepositoryLocator;
            dialog.ShowDialog(this);
        }

        private void refreshAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            projectManagementUI1.RefreshUIFromDatabase();
            dataSetManagementUI1.RefreshUIFromDatabase();
            cohortManagement1.RefreshUIFromDatabase();

        }

        private void setReleaseDocumentDisclaimerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ConfigureDisclaimer dialog = new ConfigureDisclaimer();
            dialog.RepositoryLocator = RepositoryLocator;
            dialog.ShowDialog();
        }
    }
}

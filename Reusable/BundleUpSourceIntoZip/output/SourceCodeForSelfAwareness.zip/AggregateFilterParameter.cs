using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using MapsDirectlyToDatabaseTable;
using QuerySyntaxHelper = CatalogueLibrary.DataHelper.QuerySyntaxHelper;

namespace CatalogueLibrary.Data.Aggregation
{
    /// <summary>
    /// Each AggregateFilter can have 1 or more AggregateFilterParameters, these allows you to specify an SQL parameter that the user can adjust at runtime to change
    /// how a given filter works.  E.g. if you have a filter 'Prescribed after @startDate' you would have an AggregateFilterParamater called @startDate with an appropriate
    /// user friendly description.
    /// </summary>
    public class AggregateFilterParameter : VersionedDatabaseEntity, ISqlParameter
    {
        public int AggregateFilter_ID { get; set; }// changing this is required for cloning functionality i.e. clone parameter then point it to new parent

        public string ParameterSQL { get; set; }
        public string Value { get; set; }
        public string Comment { get; set; }

        public static int ParameterSQL_MaxLength = -1;
        public static int Value_MaxLength = -1;

        /// <summary>
        /// extracts the name ofthe parameter from the SQL
        /// </summary>
        [NoMappingToDatabase]
        public string ParameterName
        {
            get { return QuerySyntaxHelper.GetParameterNameFromDeclarationSQL(ParameterSQL); }
        }

        public AggregateFilterParameter(IRepository repository, string parameterSQL, IFilter parent)
        {
            if (!QuerySyntaxHelper.IsValidParameterName(parameterSQL))
                throw new ArgumentException("parameterSQL is not valid \"" + parameterSQL + "\"");

            repository.InsertAndHydrate(this,new Dictionary<string, object>
            {
                {"ParameterSQL", parameterSQL},
                {"AggregateFilter_ID", parent.ID}
            });
        }


        public AggregateFilterParameter(IRepository repository,DbDataReader r) : base(repository,r)
        {
            AggregateFilter_ID = int.Parse(r["AggregateFilter_ID"].ToString());
            ParameterSQL = r["ParameterSQL"] as string;
            Value = r["Value"] as string;
            Comment = r["Comment"] as string;
        }
        
        
        public override string ToString()
        {
            //return the name of the variable
            return ParameterName;
        }
    }
}

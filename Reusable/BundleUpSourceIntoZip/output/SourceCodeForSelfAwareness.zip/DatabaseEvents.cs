using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using CatalogueLibrary.Data;
using MapsDirectlyToDatabaseTable;
using ReusableLibraryCode;
using ReusableLibraryCode.Checks;

namespace Dashboard.DatabaseEvents
{

    public class DatabaseEvents: IDisposable
    {
        private readonly SqlConnectionStringBuilder _builder;
        private readonly Assembly _imapsDirectlyToDatabaseTablePoweredAssembly;
        private readonly ICheckNotifier _setupChecker;
        readonly Dictionary<SqlDependency,Type>  Dependencies = new Dictionary<SqlDependency,Type>();
        private SqlConnection _con;

        public event OnDatabaseEvent DatabaseEvent;

        public DatabaseEvents(SqlConnectionStringBuilder builder,Assembly imapsDirectlyToDatabaseTablePoweredAssembly, bool allowTurningBrokerOn, ICheckNotifier setupChecker)
        {
            _builder = builder;
            _imapsDirectlyToDatabaseTablePoweredAssembly = imapsDirectlyToDatabaseTablePoweredAssembly;
            _setupChecker = setupChecker;
            _con = new SqlConnection(builder.ConnectionString);
            _con.Open();

            try
            {
                SqlDependency.Start(builder.ConnectionString);
            }
            catch (Exception e)
            {
                if (e.Message.StartsWith("The SQL Server Service Broker for the current database is not enabled")
                    &&
                    allowTurningBrokerOn)
                {
                    TurnOnServiceBroker(builder);
                    SqlDependency.Start(builder.ConnectionString);//and try again
                }
                else
                    throw;
            }

            var types = _imapsDirectlyToDatabaseTablePoweredAssembly.GetTypes().Where(t => typeof (IMapsDirectlyToDatabaseTable).IsAssignableFrom(t) && !t.IsInterface).ToArray();
            
            foreach (Type type in types)
            {
                string typeName = type.Name;
                SqlDependency dependency = new SqlDependency();
                Dependencies.Add(dependency,type);

                dependency.OnChange += dependency_OnChange;
                //create a select *command -- except that we have to manually specify them ofcourse! because of SQL Server reasons
                string[] properties = TableRepository.GetPropertyInfos(type).Select(p => SqlSyntaxHelper.EnsureFullyQualified(_builder.InitialCatalog, typeName, p.Name)).ToArray();

                SqlCommand cmd = new SqlCommand("Select " + string.Join(",", properties) + " from dbo." + typeName, _con);

                dependency.AddCommandDependency(cmd);

                var r = cmd.ExecuteReader();

                r.Read();
                r.Close();
            }
            _con.Close();
        }

        private void TurnOnServiceBroker(SqlConnectionStringBuilder builder)
        {
            SqlCommand cmd = new SqlCommand("alter database "+builder.InitialCatalog+" set enable_broker with rollback immediate",_con);
            cmd.ExecuteNonQuery();
        }


        void dependency_OnChange(object sender, SqlNotificationEventArgs e)
        {
            if(e.Info == SqlNotificationInfo.Invalid
            &&
            e.Source == SqlNotificationSource.Statement
            &&
            e.Type == SqlNotificationType.Subscribe)
                _setupChecker.OnCheckPerformed(new CheckEventArgs("Dependency subscription for type " + Dependencies[(SqlDependency)sender] + " failed to register with SQL Server - it responded with Invalid Statement Subscribe for the command",CheckResult.Fail));

            if(DatabaseEvent == null)
                return;

            DatabaseEvent(this, Dependencies[(SqlDependency) sender],e.Info + " " + e.Source + " " + e.Type);
        }

        public void Dispose()
        {
            SqlDependency.Stop(_builder.ConnectionString);
        }
    }

    public delegate void OnDatabaseEvent(object sender, Type typeBeingAffected, string message);
}

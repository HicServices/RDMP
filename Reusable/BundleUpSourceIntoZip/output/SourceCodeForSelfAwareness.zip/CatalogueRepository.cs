using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using CatalogueLibrary.Data;
using CatalogueLibrary.Data.Aggregation;
using CatalogueLibrary.Data.Cohort;
using MapsDirectlyToDatabaseTable;
using ReusableLibraryCode;

namespace CatalogueLibrary.Repositories
{
    public class CatalogueRepository : TableRepository, ICatalogueRepository
    {
        public Linker Linker { get; set; }
        public AggregateForcedJoin AggregateForcedJoiner { get; set; }
        public TableInfoToCredentialsLinker TableInfoToCredentialsLinker { get; set; }
        public PasswordEncryptionKeyLocation PasswordEncryptionKeyLocation { get; set; }
        public JoinInfoFinder JoinInfoFinder { get; set; }
        public MEF MEF { get; set; }
        public OrphanKiller OrphanKiller { get; set; }

        public CatalogueRepository(DbConnectionStringBuilder catalogueConnectionString): base(null,catalogueConnectionString)
        {
            Linker = new Linker(this);
            AggregateForcedJoiner = new AggregateForcedJoin(this);
            TableInfoToCredentialsLinker = new TableInfoToCredentialsLinker(this);
            PasswordEncryptionKeyLocation = new PasswordEncryptionKeyLocation(this);
            JoinInfoFinder = new JoinInfoFinder(this);
            MEF = new MEF(this);
            OrphanKiller = new OrphanKiller(this);

            ObscureDependencyFinder = new CatalogueObscureDependencyFinder(this);
        }
        
        public IEnumerable<CatalogueItem> GetAllCatalogueItemsNamed(string name, bool ignoreCase)
        {
            string sql;
            if (ignoreCase)
                sql = "WHERE UPPER(Name)='" + name.ToUpper() + "'";
            else
                sql = "WHERE Name='" + name + "'";

            return GetAllObjects<CatalogueItem>(sql);
        }


        /// <summary>
        /// If the configuration is part of any aggregate container anywhere this method will return the order within that container
        /// </summary>
        /// <param name="configuration"></param>
        /// <returns></returns>
        public int? GetOrderIfExistsFor(AggregateConfiguration configuration)
        {
            //if(configuration.Repository != this)
            //    throw new NotSupportedException("AggregateConfiguration is from a different repository than this");
            
            // todo: can we be a little less strict here and just ensure the connection strings are the same?
            if (configuration.Repository != this)
                if (((CatalogueRepository)configuration.Repository).ConnectionString != ConnectionString)
                    throw new NotSupportedException("AggregateConfiguration is from a different repository than this with a different connection string");

            using (var con = GetConnection())
            {
                DbCommand cmd = DatabaseCommandHelper.GetCommand("SELECT [Order] FROM CohortAggregateContainer_AggregateConfiguration WHERE AggregateConfiguration_ID = @AggregateConfiguration_ID", con.Connection, con.Transaction);

                cmd.Parameters.Add(DatabaseCommandHelper.GetParameter("@AggregateConfiguration_ID", cmd));
                cmd.Parameters["@AggregateConfiguration_ID"].Value = configuration.ID;

                return DatabaseEntity.ObjectToNullableInt(cmd.ExecuteScalar());
            }
        }
        
        /// <summary>
        /// Returns Catalogue1.CatalogueItem1, Catalogue1.CatalogueItem2 etc, a CatalogueItem does not know the name of it's parent so 
        /// for performance reasons this is a big saver it means we only have database query instead of having to construct and dereference
        /// every CatalogueItem and Every Catalogue in the database.
        /// </summary>
        /// <returns></returns>
        public List<FriendlyNamedCatalogueItem> GetFullNameOfAllCatalogueItems()
        {
            List<FriendlyNamedCatalogueItem> toReturn = new List<FriendlyNamedCatalogueItem>();

            using (var con = GetConnection())
            {

                //get parent name and child name, seperate with . (after removing any dots that our users might have put into the name (bad user!))
                DbCommand cmd = DatabaseCommandHelper.GetCommand(@"SELECT REPLACE([Catalogue].Name,'.','') + '.' + REPLACE(CatalogueItem.Name,'.','') as FriendlyName, CatalogueItem.ID from Catalogue join CatalogueItem on Catalogue.ID = Catalogue_ID", con.Connection,con.Transaction);

                DbDataReader r = cmd.ExecuteReader();
                while (r.Read())
                {
                    toReturn.Add(new FriendlyNamedCatalogueItem(Convert.ToInt32(r["ID"]),r["FriendlyName"].ToString()));
                }
                //deals with crudy decimal/short types that SQL might throw at us
            }
            return toReturn;
        }
        
        public Catalogue[] GetAllCatalogues(bool includeDeprecatedCatalogues = false)
        {
            return GetAllObjects<Catalogue>().Where(cata => (!cata.IsDeprecated) || includeDeprecatedCatalogues).ToArray();
        }

        public Catalogue[] GetAllCataloguesWithAtLeastOneExtractableItem()
        {
            List<Catalogue> toReturn = new List<Catalogue>(GetAllCatalogues());
            
            for (int i = toReturn.Count - 1; i >= 0; i--)
                //if it doesn't have any ExtractionInformation, remove it
                if (toReturn[i].GetAllExtractionInformation(ExtractionCategory.Any).Length == 0)
                    toReturn.RemoveAt(i);

            return toReturn.ToArray();
        }

        


        public IEnumerable<CohortIdentificationConfiguration> GetAllCohortIdentificationConfigurationsWithDependencyOn(AggregateConfiguration aggregate)
        {
            //1 query to fetch all these
            //get all the ones that have a container system setup on them
            var allConfigurations = GetAllObjects<CohortIdentificationConfiguration>().Where(c => c.RootCohortAggregateContainer_ID != null).ToArray();

            foreach (CohortIdentificationConfiguration config in allConfigurations)
            {
                //get the root container
                //see if the root container (or any of it's children) contain the aggregate you are looking for
                if (config.RootCohortAggregateContainer.HasChild(aggregate))
                    yield return config;
            }
        }

        public IEnumerable<AnyTableSqlParameter> GetAllParametersForParentTable(IMapsDirectlyToDatabaseTable parent)
        {
            var type = parent.GetType();

            if (!AnyTableSqlParameter.IsSupportedType(type))
                throw new NotSupportedException("This table does not support parents of type " + type.Name);

            return GetAllObjects<AnyTableSqlParameter>("where ParentTable = '" + type.Name + "' and Parent_ID =" + parent.ID);
        }

        public ColumnInfo GetColumnInfoWithNameExactly(string name)
        {
            var columnInfos = SelectAllWhere<ColumnInfo>("SELECT * FROM ColumnInfo WHERE Name = @name","ID",
                new Dictionary<string, object>
                {
                    {"name", name}
                }).ToList();

            if (!columnInfos.Any())
                return null;

            if (columnInfos.Count > 1)
                throw new Exception("Found 2+ ColumnInfo named " + name);

            return columnInfos[0];
        }

        public TicketingSystemConfiguration GetTicketingSystem()
        {
            var configuration = GetAllObjects<TicketingSystemConfiguration>().Where(t => t.IsActive).ToArray();

            if (configuration.Length == 0)
                return null;

            if (configuration.Length == 1)
                return configuration[0];

            throw new NotSupportedException("There should only ever be one active ticketing system, something has gone very wrong, there are currently " + configuration.Length);
        }

        public IEnumerable<CacheProgress> GetAllCacheProgressWithoutAPermissionWindow()
        {
            return GetAllObjects<CacheProgress>().Where(p => p.PermissionWindow_ID == null);
        }

        public TableInfo GetTableWithNameApproximating(string tableName, string database)
        {
            int id;
            using (var con = GetConnection())
            {
                tableName = tableName.Trim(']', '[');

                if (tableName.Contains("."))
                    throw new ArgumentException("Must be a table name only must not have a database/schema prefix");

                //add a percent  and dot so that we are matching Bob..MyTable or Dave.MyTable (MySQL) but either way we are throwing out [ ] and definetly not matching Bob..SomePrefixTextMyTable
                var cmd = DatabaseCommandHelper.GetCommand("SELECT * FROM TableInfo WHERE " +
                    "REPLACE(REPLACE(Name,']',''),'[','') LIKE @nameToFind", con.Connection, con.Transaction);

                cmd.Parameters.Add(DatabaseCommandHelper.GetParameter("@nameToFind", cmd));
                cmd.Parameters["@nameToFind"].Value = database + "%..%" + tableName;

                DbDataReader r = cmd.ExecuteReader();
                try
                {
                    if (!r.Read())
                        return null;

                    id = Convert.ToInt32(r["ID"]);

                    if (r.Read())
                        throw new Exception("Found 2+ TableInfos named " + tableName);
                }
                finally
                {

                    r.Close();
                }
            }

            if (id == 0)
                throw new InvalidOperationException("A table was found, but it doesn't appear to have a valid ID");

            return GetObjectByID<TableInfo>(id);
        }

        protected override IMapsDirectlyToDatabaseTable ConstructEntity(Type t, DbDataReader reader)
        {
            // Preferred constructor
            var constructorInfo = t.GetConstructor(new[] { typeof(ICatalogueRepository), typeof(DbDataReader) });
            if (constructorInfo == null)
            {
                // Fallback constructor
                constructorInfo = t.GetConstructor(new[] { typeof(IRepository), typeof(DbDataReader) });
                if (constructorInfo == null)
                    throw new Exception("ConstructEntity<" + t.Name + "> requires that the specified IMapsDirectlyToDatabaseTable object implements the constructor IRepository, DbDataReader");
            }

            var toReturn = (IMapsDirectlyToDatabaseTable)constructorInfo.Invoke(new object[] { this, reader });

            toReturn.Repository = this;
            return toReturn;
        }
    }
}

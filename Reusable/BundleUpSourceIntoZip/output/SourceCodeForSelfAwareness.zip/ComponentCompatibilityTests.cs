using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Data;
using System.Linq;
using CatalogueLibrary.Data;
using CatalogueLibrary.DataFlowPipeline;
using NUnit.Framework;
using Tests.Common;

namespace DataLoadEngineTests.Integration.Pipeline
{
    public class ComponentCompatibilityTests :DatabaseTests
    {
        [Test]
        public void GetComponentsCompatibleWithBulkInsertContext()
        {
            Type[] array = CatalogueRepository.MEF.GetTypes<IDataFlowComponent<DataTable>>().ToArray();

            Assert.Greater(array.Count(),0);
        }

        [Test]
        public void HowDoesMEFHandleTypeNames()
        {

            string expected = "CatalogueLibrary.DataFlowPipeline.IDataFlowSource(System.Data.DataTable)";

            Assert.AreEqual(expected, CatalogueRepository.MEF.GetMEFNameForType(typeof(IDataFlowSource<DataTable>)));
        }

      
    }
}


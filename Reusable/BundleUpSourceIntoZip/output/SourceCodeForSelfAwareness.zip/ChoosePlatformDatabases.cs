using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using CatalogueLibrary.Data;
using CatalogueLibrary.Database;
using CatalogueManager.TestsAndSetup;
using CatalogueManager.TestsAndSetup.ServicePropogation;
using Diagnostics;
using Microsoft.Win32;
using RDMPObjectVisualisation;
using RDMPStartup;
using ReusableLibraryCode.Checks;
using ReusableUIComponents;
using MapsDirectlyToDatabaseTableUI;

namespace CatalogueManager.LocationsMenu
{
    /// <summary>
    /// All metadata in RDMP is stored in one of two main databases.  The Catalogue database records all the technical, descriptive, governance, data load, filtering logic etc about 
    /// your datasets (including where they are stored etc).  The Data Export Manager database stores all the extraction configurations you have created for releasing to researchers.
    /// 
    /// This window lets you tell the software where your Catalogue / Data Export Manager databases are or create new ones.  These connection strings are recorded in each users Registry.
    /// It is strongly advised that you use Integrated Security (Windows Security) for connecting rather than a username/password as this is the only case where Passwords are not encrypted
    /// (Since the encryption certificate location is stored in the Catalogue! - see PasswordEncryptionKeyLocationUI).
    /// 
    /// Only the Catalogue database is required, if you do not intend to do data extraction at this time then you can skip creating one.  
    /// 
    /// It is a good idea to run Check after configuring your connection string to ensure that the database is accessible and that the tables/columns in the database match the softwares
    /// expectations.  
    /// 
    /// IMPORTANT: if you configure your connection string wrongly it might take up to 30s for windows to timeout the network connection (e.g. if you specify the wrong server name). This is
    /// similar to if you type in a dodgy server name in Microsoft Windows Explorer.
    /// </summary>
    public partial class ChoosePlatformDatabases : RDMPForm
    {
        
        public ChoosePlatformDatabases()
        {
            InitializeComponent();
            
            RecentHistoryOfControls.GetInstance().HostControl(tbCatalogueConnectionString);
            RecentHistoryOfControls.GetInstance().HostControl(tbDataExportManagerConnectionString);

            gbSqlServer.Enabled = true;
        }

        protected override void OnLoad(EventArgs e)
        {
            if (VisualStudioDesignMode)
                return;

            if (RepositoryLocator.CatalogueRepository != null)
                tbCatalogueConnectionString.Text = RepositoryLocator.CatalogueRepository.ConnectionString;

            if (RepositoryLocator.DataExportRepository != null)
                tbDataExportManagerConnectionString.Text = RepositoryLocator.DataExportRepository.ConnectionString;
            
            base.OnLoad(e);

            BetterToolTip.SetToolTip(this, ToolTips.ChoosePlatformDatabase, Images.ChoosePlatformDatabases);
        }

        private bool SaveConnectionStringsToRegistry()
        {
            try
            {
                // save all the settings
                ((RegistryRepositoryFinder)RepositoryLocator).SetRegistryValue(RegistrySetting.Catalogue, tbCatalogueConnectionString.Text);
                ((RegistryRepositoryFinder)RepositoryLocator).SetRegistryValue(RegistrySetting.DataExportManager, tbDataExportManagerConnectionString.Text);
                
                return true;
            }
            catch (Exception exception)
            {
                checksUI1.OnCheckPerformed(new CheckEventArgs("Failed to save connection settings into registry",CheckResult.Fail,exception));
                return false;
            }
            
        }

        private void ChooseDatabase_KeyUp(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
                btnSaveAndClose_Click(null,null);

            if(e.KeyCode == Keys.Escape)
               this.Close();

        }
        private void tbCatalogueConnectionString_KeyUp(object sender, KeyEventArgs e)
        {
            //if user is doing a paste
            if (e.KeyCode == Keys.V && e.Control)
            {
                //check to see what he is pasting
                string toPaste = Clipboard.GetText();

                //he is pasting something with newlines
                if (toPaste.Contains(Environment.NewLine))
                {
                    //see if he is trying to paste two lines at once, in whichcase surpress Windows and paste it across the two text boxes
                    string[] toPasteArray = toPaste.Split(Environment.NewLine.ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
                    if (toPasteArray.Length == 2)
                    {
                        tbCatalogueConnectionString.Text = toPasteArray[0];
                        tbDataExportManagerConnectionString.Text = toPasteArray[1];
                        e.SuppressKeyPress = true;
                        return;
                    }
                }
            }
        }

        private void btnCreateNewCatalogue_Click(object sender, EventArgs e)
        {
            try
            {
                CreatePlatformDatabase dialog = new CreatePlatformDatabase(typeof(Class1).Assembly);
                dialog.ShowDialog();
                if (dialog.DatabaseConnectionString != null)
                    tbCatalogueConnectionString.Text = dialog.DatabaseConnectionString;
            }
            catch (Exception exception)
            {
                ExceptionViewer.Show(exception);
            }
        }


        private void btnCreateNewDataExportManagerDatabase_Click(object sender, EventArgs e)
        {
            try
            {
                CreatePlatformDatabase dialog = new CreatePlatformDatabase(typeof(DataExportManager2.Database.Class1).Assembly);
                dialog.ShowDialog();

                if (dialog.DatabaseConnectionString != null)
                    tbDataExportManagerConnectionString.Text = dialog.DatabaseConnectionString;
            }
            catch (Exception exception)
            {
                ExceptionViewer.Show(exception);
            }
        }

        private MissingFieldsChecker CreateMissingFieldsChecker(MissingFieldsChecker.ThingToCheck thingToCheck)
        {
            return new MissingFieldsChecker(thingToCheck, RepositoryLocator.CatalogueRepository, RepositoryLocator.DataExportRepository);
        }

        private void btnSaveAndClose_Click(object sender, EventArgs e)
        {
            //if save is succesful
            if(SaveConnectionStringsToRegistry())
            {
                try
                {
                    CreateMissingFieldsChecker(MissingFieldsChecker.ThingToCheck.Catalogue)
                        .Check(new ThrowImmediatelyCheckNotifier());
                }
                catch (Exception exception)
                {
                    bool launchDiagnostics = checksUI1.OnCheckPerformed(new CheckEventArgs("Catalogue database did not pass silent integrity checks, press the Check button to see the full check output",CheckResult.Fail,exception,"Launch diagnostics screen?"));
                    
                    if(launchDiagnostics)
                    {
                        var dialog = new DiagnosticsScreen(exception);
                        dialog.RepositoryLocator = RepositoryLocator;
                        dialog.ShowDialog(this);
                    }

                    return;
                }

                if(!string.IsNullOrWhiteSpace(tbDataExportManagerConnectionString.Text))
                    try
                    {
                        CreateMissingFieldsChecker(MissingFieldsChecker.ThingToCheck.DataExportManager).Check(new ThrowImmediatelyCheckNotifier());
                    }
                    catch (Exception exception)
                    {
                        bool launchDiagnostics = checksUI1.OnCheckPerformed(new CheckEventArgs("Data Export Manager database did not pass silent integrity checks, press the Check button to see the full check output", CheckResult.Fail, exception,"Launch diagnostics screen"));
                        
                        if (launchDiagnostics)
                        {
                            var dialog = new DiagnosticsScreen(exception);
                            dialog.RepositoryLocator = RepositoryLocator;
                            dialog.ShowDialog(this);
                        }

                        return;
                    }

                //integrity checks passed
                Close();
            }
        }

        private void btnCheckDataExportManager_Click(object sender, EventArgs e)
        {
            try
            {
                SaveConnectionStringsToRegistry();

                checksUI1.StartChecking(CreateMissingFieldsChecker(MissingFieldsChecker.ThingToCheck.DataExportManager));
            }
            catch (Exception exception)
            {
                checksUI1.OnCheckPerformed(new CheckEventArgs("Checking of Data Export Manager failed", CheckResult.Fail,
                    exception));
            }
        }

        private void btnCheckCatalogue_Click(object sender, EventArgs e)
        {
            try
            {
                //save the settings
                SaveConnectionStringsToRegistry();
            
                checksUI1.StartChecking(CreateMissingFieldsChecker(MissingFieldsChecker.ThingToCheck.Catalogue));
            }
            catch (Exception exception)
            {
                checksUI1.OnCheckPerformed(new CheckEventArgs("Checking of Catalogue Database failed", CheckResult.Fail,
                    exception));
            }

        }

        private void btnShowRegistry_Click(object sender, EventArgs e)
        {
            try
            {
                Registry.SetValue(@"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Applets\Regedit", "Lastkey", @"Computer\" + RegistryRepositoryFinder.RDMPRegistryRoot);
            }
            catch (Exception exception)
            {
                ExceptionViewer.Show("Could not set LastKey (makes regedit open at the correct registry key)",exception);
            }

            //give it time to take effect (windows be slow)
            Thread.Sleep(500);

            try
            {
                Process.Start("regedit.exe");
            }
            catch (Exception exception)
            {
                ExceptionViewer.Show("Regedit.exe crashed or could not be launched",exception);
            }
        }
    }
}

using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CatalogueLibrary.DataFlowPipeline;
using CatalogueLibrary.DataFlowPipeline.Requirements;
using LoadModules.Generic.Attachers;
using LoadModules.Generic.DataFlowSources;
using NUnit.Framework;
using ReusableLibraryCode.Checks;
using ReusableLibraryCode.Progress;

namespace DataLoadEngineTests.Integration.Pipeline.Sources
{
    public class DelimitedFileSourceTests
    {
        private const string filename = "DelimitedFileSourceTests.txt";

        private FileInfo CreateTestFile()
        {
            if(File.Exists(filename))
                File.Delete(filename);

            StringBuilder sb = new StringBuilder();

            sb.AppendLine("CHI,StudyID,Date");
            sb.AppendLine("0101010101,5,2001-01-05");

            File.WriteAllText(filename, sb.ToString());

            return new FileInfo(filename);
        }

        [Test]
        [ExpectedException(ExpectedMessage = "_fileToLoad was not set",MatchType=MessageMatch.Contains)]
        public void FileToLoadNotSet_Throws()
        {
            DelimitedFlatFileDataFlowSource source = new DelimitedFlatFileDataFlowSource();
            DataTable chunk = source.GetChunk(new ToConsoleDataLoadEventReciever(), new GracefulCancellationToken());
        }
        [Test]
        [ExpectedException(ExpectedMessage = "Separator has not been set", MatchType = MessageMatch.Contains)]
        public void SeparatorNotSet_Throws()
        {
            FileInfo testFile = CreateTestFile();
            DelimitedFlatFileDataFlowSource source = new DelimitedFlatFileDataFlowSource();
            source.PreInitialize(new FlatFileToLoad(testFile),new ToConsoleDataLoadEventReciever() );
            source.GetChunk(new ToConsoleDataLoadEventReciever(), new GracefulCancellationToken());
        }
        [Test]
        public void LoadCSVWithCorrectDatatypes_DatatypesAreCorrect()
        {

            FileInfo testFile = CreateTestFile();
            DelimitedFlatFileDataFlowSource source = new DelimitedFlatFileDataFlowSource();
            source.PreInitialize(new FlatFileToLoad(testFile), new ToConsoleDataLoadEventReciever());
            source.Separator = ",";
            source.StronglyTypeInput = true;//makes the source interpret the file types properly

            var chunk = source.GetChunk(new ToConsoleDataLoadEventReciever(), new GracefulCancellationToken());

            Assert.AreEqual(3,chunk.Columns.Count);
            Assert.AreEqual(1, chunk.Rows.Count);
            Assert.AreEqual("0101010101", chunk.Rows[0][0]);
            Assert.AreEqual(5, chunk.Rows[0][1]);
            Assert.AreEqual(new DateTime(2001 , 1 , 5), chunk.Rows[0][2]);//notice the strong typing (we are not looking for strings here)
            
            source.Dispose(new ToConsoleDataLoadEventReciever(), null);
        }

        [Test]
        public void OverrideDatatypes_ForcedFreakyTypesCorrect()
        {

            FileInfo testFile = CreateTestFile();
            DelimitedFlatFileDataFlowSource source = new DelimitedFlatFileDataFlowSource();
            source.PreInitialize(new FlatFileToLoad(testFile), new ToConsoleDataLoadEventReciever());
            source.Separator = ",";
            source.StronglyTypeInput = true;//makes the source interpret the file types properly
            
            source.ExplicitlyTypedColumns = new ExplicitTypingCollection();
            source.ExplicitlyTypedColumns.ExplicitTypesCSharp.Add("StudyID",typeof(string));

            //preview should be correct
            DataTable preview = source.TryGetPreview();
            Assert.AreEqual(typeof(string), preview.Columns["StudyID"].DataType);
            Assert.AreEqual("5", preview.Rows[0]["StudyID"]);

            //as should live run
            var chunk = source.GetChunk(new ToConsoleDataLoadEventReciever(), new GracefulCancellationToken());
            Assert.AreEqual(typeof(string), chunk.Columns["StudyID"].DataType);
            Assert.AreEqual("5", chunk.Rows[0]["StudyID"]);

            source.Dispose(new ToConsoleDataLoadEventReciever(), null);
        }

        [Test]
        [TestCase(null)]
        [TestCase(BehaviourOnUnderReadType.Ignore)]
        [TestCase(BehaviourOnUnderReadType.AppendNextLineToCurrentRow)]
        public void OverReadBehaviour(BehaviourOnUnderReadType? behaviour)
        {
            if (File.Exists(filename))
                File.Delete(filename);

            StringBuilder sb = new StringBuilder();

            sb.AppendLine("CHI,StudyID,Date");
            sb.AppendLine("0101010101,5,2001-01-05");
            sb.AppendLine("0101010101,5,2001-01-05");
            sb.AppendLine("0101010101,5,2001-01-05,fish,watafak");
            sb.AppendLine("0101010101,5,2001-01-05");
            sb.AppendLine("0101010101,5,2001-01-05");

            File.WriteAllText(filename, sb.ToString());

            var testFile = new FileInfo(filename);

            DelimitedFlatFileDataFlowSource source = new DelimitedFlatFileDataFlowSource();
            source.PreInitialize(new FlatFileToLoad(testFile), new ToConsoleDataLoadEventReciever());
            source.Separator = ",";

            if(behaviour.HasValue)
                source.UnderReadBehaviour = behaviour.Value;

            source.StronglyTypeInput = true;//makes the source interpret the file types properly

            var ex = Assert.Throws<FileLoadException>(() => source.TryGetPreview());

            Assert.IsTrue(ex.Message.Contains("overrun on line 4, it has too many columns (expected 3 columns but line had 5)"));

        }


    }
}

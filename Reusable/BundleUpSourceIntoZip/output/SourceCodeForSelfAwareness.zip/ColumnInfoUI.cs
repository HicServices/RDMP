using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Drawing;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using CatalogueLibrary.Data;
using CatalogueManager.ReflectionBasedUI;
using ReusableUIComponents;

namespace CatalogueManager.MainFormUITabs.SubComponents
{
    /// <summary>
    /// ColumnInfos are one of the core objects of the RDMP and serve to tie the virtual columns and transforms (CatalogueItems / ExtractionInformation) from the underlying database 
    /// implementation (TableInfo / ColumnInfo).  This is what allows you to (for example) migrate to a new table schema and still keep all your documentation and release history.
    /// 
    /// Each ColumnInfo is a record of the last known Name, Data Type, collation, primary key status etc of a column in your data repository.  This is periodically synchronized with 
    /// the data repository (e.g. before data loading) so you shouldn't need to change most of the properties offered by this control.
    /// </summary>
    public partial class ColumnInfoUI : UserControl
    {
        private ColumnInfo _columnInfo;
        private bool bLoading = false;

        public event EventHandler Saved;

        public ColumnInfoUI()
        {
            InitializeComponent();
        }

        public ColumnInfo ColumnInfo
        {
            get { return _columnInfo; }
            set
            {
                bLoading = true;
                _columnInfo = value;

                if (value == null)
                {
                    tbColumnInfoDescription.Text = "";
                    tbColumnInfoID.Text = "";
                    tbColumnInfoName.Text = "";
                    tbColumnInfoRegexPattern.Text = "";
                    tbColumnInfoSource.Text = "";
                    tbColumnInfoType.Text = "";
                    tbColumnInfoValidationRules.Text = "";
                    tbColumnInfoDigitisationSpecs.Text = "";
                    tbColumnInfoFormat.Text = "";
                    
                    cbxColumnInfoStatus.Text =  "";
                    cbIsPrimaryKey.Checked = false;
                }
                else
                {
                    tbColumnInfoDescription.Text = value.Description;
                    tbColumnInfoID.Text = value.ID.ToString();
                    tbColumnInfoName.Text = value.Name;
                    tbColumnInfoRegexPattern.Text = value.RegexPattern;
                    tbColumnInfoSource.Text = value.Source;
                    tbColumnInfoType.Text = value.Data_type;
                    tbColumnInfoValidationRules.Text = value.ValidationRules;
                    tbColumnInfoDigitisationSpecs.Text = value.Digitisation_specs;
                    tbColumnInfoFormat.Text = value.Format;
                    
                    cbxColumnInfoStatus.Text = value.Status == null ? "" : value.Status.ToString();
                    cbIsPrimaryKey.Checked = value.IsPrimaryKey;

                }

                bLoading = false;
            }

        }

        private void cbIsPrimaryKey_CheckedChanged(object sender, EventArgs e)
        {
            if (bLoading)
                return;
            ColumnInfo.IsPrimaryKey = cbIsPrimaryKey.Checked;
            ColumnInfo.SaveToDatabase();
        }

        private void tbColumnInfoName_TextChanged(object sender, EventArgs e)
        {
            if (bLoading)
                return;
            ReflectionPropertySetter.SetStringProperty((TextBox) sender, "Name", ColumnInfo);
        }

        private void tbColumnInfoType_TextChanged(object sender, EventArgs e)
        {
            if (bLoading)
                return;
            ReflectionPropertySetter.SetStringProperty((TextBox)sender, "Data_type", ColumnInfo);
        }

        private void tbColumnInfoFormat_TextChanged(object sender, EventArgs e)
        {
            if (bLoading)
                return;
            ReflectionPropertySetter.SetStringProperty((TextBox)sender, "Format", ColumnInfo);
        }

        private void tbColumnInfoDigitisationSpecs_TextChanged(object sender, EventArgs e)
        {
            if (bLoading)
                return;
            ReflectionPropertySetter.SetStringProperty((TextBox)sender, "Digitisation_specs", ColumnInfo);
        }

        private void tbColumnInfoSource_TextChanged(object sender, EventArgs e)
        {
            if (bLoading)
                return;
            ReflectionPropertySetter.SetStringProperty((TextBox)sender, "Source", ColumnInfo);
        }

        private void tbColumnInfoDescription_TextChanged(object sender, EventArgs e)
        {
            if (bLoading)
                return;
            ReflectionPropertySetter.SetStringProperty((TextBox)sender, "Description", ColumnInfo);
        }

        private void tbColumnInfoRegexPattern_TextChanged(object sender, EventArgs e)
        {
            if (bLoading)
                return;
            TextBox senderAsTextBox = (TextBox)sender;
            try
            {
                Regex r = new Regex(senderAsTextBox.Text);
                senderAsTextBox.ForeColor = Color.Black; //pattern was valid
            }
            catch (Exception)
            {
                senderAsTextBox.ForeColor = Color.Red; //pattern was invalid
                return;
            }

            ReflectionPropertySetter.SetStringProperty((TextBox)sender, "RegexPattern", ColumnInfo);
            

        }

        private void tbColumnInfoValidationRules_TextChanged(object sender, EventArgs e)
        {
            if (bLoading)
                return;
            ReflectionPropertySetter.SetStringProperty((TextBox)sender, "ValidationRules", ColumnInfo);
        }

        private void cbxColumnInfoStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
           if(bLoading)
               return;

            ColumnInfo.ColumnStatus selectedValue;

            //if they selected something an actual value (as opposed to DBNull)
            if (ColumnInfo.ColumnStatus.TryParse(((ComboBox)sender).Text, out selectedValue))
                ColumnInfo.Status = selectedValue;
            else
                ColumnInfo.Status = null;
            
        }

     
        private void btnColumnInfoSave_Click(object sender, EventArgs e)
        {
            if(ColumnInfo == null || bLoading)
                return;

            ColumnInfo.SaveToDatabase();
            
            if (Saved != null)
                Saved(this, new EventArgs());

        }

        protected override bool ProcessKeyPreview(ref Message m)
        {

            PreviewKey p = new PreviewKey(ref m, ModifierKeys);

            if (p.IsKeyDownMessage && p.e.KeyCode == Keys.S && p.e.Control)
            {
                btnColumnInfoSave_Click(null,null);
                p.Trap(this);
            }

            return base.ProcessKeyPreview(ref m);
        }
    }
}

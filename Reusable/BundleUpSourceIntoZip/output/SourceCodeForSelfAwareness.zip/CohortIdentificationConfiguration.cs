using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using CatalogueLibrary.Data.Aggregation;
using CatalogueLibrary.Repositories;
using MapsDirectlyToDatabaseTable;
using MapsDirectlyToDatabaseTable.Revertable;
using ReusableLibraryCode;

namespace CatalogueLibrary.Data.Cohort
{
    /// <summary>
    /// Cohort identification is the job identifying which patients fit certain study criteria.  E.g. "I want all patients who have been prescribed Diazepam for the first time after 2000
    /// and who are still alive today".  Every time the data analyst has a new project/cohort to identify he should create a new CohortIdentificationConfiguration, it is the entry point
    /// for cohort generation and includes a high level description of what the cohort requirements are, an optional ticket and is the hanging off point for all the 
    /// RootCohortAggregateContainers (the bit that provides the actual filtering/technical data about how the cohort is identified).
    /// </summary>
    public class CohortIdentificationConfiguration : DatabaseEntity, ISaveable, IDeleteable, IRevertable, ICollectSqlParameters
    {
        #region Properties
        public string Name { get; set; }
        public string Description { get; set; }
        public string Ticket { get; set; }
        public int? RootCohortAggregateContainer_ID { get; set; }
        public int? QueryCachingServer_ID { get; set; }
        #endregion

        public const string CICPrefix = "cic_";


        #region Relationships
        [NoMappingToDatabase]
        public CohortAggregateContainer RootCohortAggregateContainer {
            get { return 
                RootCohortAggregateContainer_ID == null?  null:
                Repository.GetObjectByID<CohortAggregateContainer>((int) RootCohortAggregateContainer_ID); }
        }

        [NoMappingToDatabase]
        public ExternalDatabaseServer QueryCachingServer {
            get
            {
                return QueryCachingServer_ID == null
                    ? null
                    : Repository.GetObjectByID<ExternalDatabaseServer>(QueryCachingServer_ID.Value);
            }
        }

        #endregion

        public CohortIdentificationConfiguration(IRepository repository, string name)
        {
            repository.InsertAndHydrate(this,new Dictionary<string, object>
            {
                {"Name", name}
            });
        }

        public CohortIdentificationConfiguration(IRepository repository,DbDataReader r) : base(repository,r)
        {
            Name = r["Name"].ToString();
            Description = r["Description"] as string;
            RootCohortAggregateContainer_ID = ObjectToNullableInt(r["RootCohortAggregateContainer_ID"]);
            Ticket = r["Ticket"] as string;
            QueryCachingServer_ID = ObjectToNullableInt(r["QueryCachingServer_ID"]);
        }
        
        public bool StillExists()
        {
            return HasLocalChanges().Evaluation != ChangeDescription.DatabaseCopyWasDeleted;
        }
        
        public override void DeleteInDatabase()
        {
            //container is the parent class even though this is a 1 to 1 and there is a CASCADE which will actually nuke ourselves when we delete the root container!
            if (RootCohortAggregateContainer_ID != null)
                RootCohortAggregateContainer.DeleteInDatabase();

            //shouldnt ever happen but double check anyway incase somebody removes the CASCADE
            if(StillExists())
                base.DeleteInDatabase();
        }

        public void CreateRootContainerIfNotExists()
        {
            //if it doesn't have one
            if (RootCohortAggregateContainer_ID == null)
            {
                //create a new one and record it's ID
                RootCohortAggregateContainer_ID = new CohortAggregateContainer(Repository,SetOperation.UNION).ID;

                //save us to database to cement the object
                SaveToDatabase();
            }
        }

        public override string ToString()
        {
            return Name;
        }

        public ISqlParameter[] GetAllParameters()
        {
            return ((CatalogueRepository)Repository).GetAllParametersForParentTable(this).ToArray();
        }


        public string GetNamingConventionPrefixForConfigurations()
        {
            string ticket = string.IsNullOrWhiteSpace(Ticket) ? "" : Ticket + "_";

            return  CICPrefix + ID + "_" + ticket;
        }

        public bool IsValidNamedConfiguration(AggregateConfiguration aggregate)
        {
            return aggregate.Name.StartsWith(GetNamingConventionPrefixForConfigurations());
        }

        public void EnsureNamingConvention(AggregateConfiguration aggregate)
        {
            //it is already valid
            if (IsValidNamedConfiguration(aggregate))
                return;

            //make it valid by sticking on the prefix
            aggregate.Name = GetNamingConventionPrefixForConfigurations() + aggregate.Name;
            
            //add 'Copy of' then 'Copy of Copy of'
            while (Repository.GetAllObjects<AggregateConfiguration>().Any(c => c.Name.Equals(aggregate.Name)))
                aggregate.Name = "Copy of " + aggregate.Name;

            aggregate.SaveToDatabase();
        }

        public AggregateConfiguration CreateCloneOfConfiguration(AggregateConfiguration toClone)
        {
            if(IsValidNamedConfiguration(toClone))
                throw new NotSupportedException("Configuration " + toClone + " already follows the naming convention which means it is likely that user thinks the configuration is already 'good to go' for this cohort identification activity - we do not want to clone and mangle it!");

            //two cases here either the import has a custom freaky CHI column (dimension) or it doesn't reference CHI at all if it is freaky we want to preserve it's freakyness
            ExtractionInformation underlyingExtractionInformation;
            IColumn extractionIdentifier = GetExtractionIdentifierFrom(toClone, out underlyingExtractionInformation);

            var cataRepo = (CatalogueRepository) Repository;

            
            using (var con = cataRepo.BeginNewTransactedConnection())
            {
                try
                {
                    //clone will not have axis or pivot or dimensions other than extraction identifier
                    var newConfiguration = cataRepo.CloneObjectInTable(toClone);

                    //make it's name follow the naming convention e.g. cic_105_LINK103_MyAggregate 
                    EnsureNamingConvention(newConfiguration);
            
                    //now clear it's pivot dimension, make it not extratcable and make it's countSQL basic/sane
                    newConfiguration.PivotOnDimensionID = null;
                    newConfiguration.IsExtractable = false;
                    newConfiguration.CountSQL = "count(*)";
            
                    //now clone it's AggregateForcedJoins
                    foreach (var t in cataRepo.AggregateForcedJoiner.GetAllForcedJoinsFor(toClone))
                        cataRepo.AggregateForcedJoiner.CreateLinkBetween(newConfiguration, t);

                    
                    //now give it 1 dimension which is the only IsExtractionIdentifier column 
                    var newDimension = new AggregateDimension(cataRepo, underlyingExtractionInformation, newConfiguration);

                    //the thing we were cloning had a freaky CHI column (probably had a collate or something involved in it or a masterchi) 
                    if (extractionIdentifier is AggregateDimension)
                    {
                        //preserve it's freakyness
                        newDimension.Alias = extractionIdentifier.Alias;
                        newDimension.SelectSQL = extractionIdentifier.SelectSQL;
                        newDimension.Order = extractionIdentifier.Order;
                        newDimension.SaveToDatabase();
                    }
                
                    //now rewire all it's filters
                    if(toClone.RootFilterContainer_ID != null) //if it has any filters
                    {
                        //get the tree
                        AggregateFilterContainer oldRootContainer = toClone.RootFilterContainer;

                        //clone the tree
                        var newRootContainer = oldRootContainer.DeepCloneEntireTreeRecursivelyIncludingFilters();
                        newConfiguration.RootFilterContainer_ID = newRootContainer.ID;
                    }

                    newConfiguration.SaveToDatabase();
                    cataRepo.EndTransactedConnection(true);

                    return newConfiguration;
                }
                catch (Exception e)
                {
                    cataRepo.EndTransactedConnection(false);//abandon
                    throw;
                }
            }
        }

        public AggregateConfiguration CreateNewEmptyConfigurationForCatalogue(Catalogue catalogue)
        {
            var extractionIdentifier = (ExtractionInformation)GetExtractionIdentifierFrom(catalogue);

            AggregateConfiguration configuration = new AggregateConfiguration(Repository,catalogue, "People in " + catalogue);
            EnsureNamingConvention(configuration);

            //make the extraction identifier column into the sole dimension on the new configuration
            new AggregateDimension(catalogue.Repository, extractionIdentifier, configuration);

            return configuration;
        }
        /// <summary>
        /// returns an underlying ExtractionInformation which IsExtractionIdentifier (e.g. a chi column).  The first pass approach is to look for a suitable AggregateDimension which
        /// has an underlying  ExtractionInformation which IsExtractionIdentifier but if it doesn't find one then it will look in the Catalogue for one instead.  The reason this is 
        /// complex is because you can have datasets with multiple IsExtractionIdentifier columns e.g. SMR02 (birth records) where there is both MotherCHI and BabyCHI which are both
        /// IsExtractionIdentifier - in this case the AggregateConfiguration would need a Dimension of one or the other (but not both!) - if it had neither then the method would throw
        /// when it checked Catalogue and found both.
        /// </summary>
        /// <param name="toClone"></param>
        /// <returns></returns>
        private IColumn GetExtractionIdentifierFrom(AggregateConfiguration toClone, out ExtractionInformation underlyingExtractionInformation)
        {
            //make sure it can be cloned before starting
            var existingExtractionIdentifierDimensions = toClone.AggregateDimensions.Where(d => d.IsExtractionIdentifier).ToArray();
            IColumn extractionIdentifier = null;

            if (existingExtractionIdentifierDimensions.Count() > 1)
                throw new NotSupportedException("Cannot clone the AggregateConfiguration " + toClone + " becuase it has multiple IsExtractionIdentifier dimensions (must be 0 or 1)");

            if (existingExtractionIdentifierDimensions.Count() == 1)
            {
                extractionIdentifier = existingExtractionIdentifierDimensions[0];
                underlyingExtractionInformation = existingExtractionIdentifierDimensions[0].ExtractionInformation;
            }
            else
            {
                //get the unique IsExtractionIdentifier from the cloned configurations parent catalogue
                underlyingExtractionInformation = 
                    (ExtractionInformation)GetExtractionIdentifierFrom(
                    toClone.Catalogue
                    );
                return underlyingExtractionInformation;
            }

            return extractionIdentifier;
        }
        
        private IColumn GetExtractionIdentifierFrom(Catalogue catalogue)
        {
            //the aggregate they are cloning does not have an extraction identifier but the dataset might still have one
            var catalogueCandidates = catalogue.GetAllExtractionInformation(ExtractionCategory.Any).Where(e => e.IsExtractionIdentifier).ToArray();

            if (catalogueCandidates.Count() != 1)
                throw new NotSupportedException("Cannot create AggregateConfiguration because the Catalogue "+catalogue+" has " + catalogueCandidates.Length + " IsExtractionIdentifier ExtractionInformations");

            return catalogueCandidates[0];
        }
    }
}

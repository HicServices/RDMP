using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using CatalogueLibrary;
using CatalogueLibrary.Data;
using CatalogueLibrary.Data.DataLoad;
using CatalogueLibrary.Data.EntityNaming;
using CatalogueLibrary.DataFlowPipeline;
using CatalogueLibrary.DataHelper;
using CatalogueLibrary.Repositories;
using DataLoadEngine.DatabaseManagement;
using DataLoadEngine.DatabaseManagement.EntityNaming;
using DataLoadEngine.DatabaseManagement.Operations;
using DataLoadEngine.DataFlowPipeline.Components.Anonymisation;
using MapsDirectlyToDatabaseTable;
using Microsoft.SqlServer.Management.Smo;
using NUnit.Framework;
using ReusableLibraryCode;
using ReusableLibraryCode.DatabaseHelpers.Discovery;
using ReusableLibraryCode.Progress;
using Rhino.Mocks;
using Tests.Common;
using Column = Microsoft.SqlServer.Management.Smo.Column;

namespace DataLoadEngineTests.Integration
{
    class DatabaseOperationTests : DatabaseTests
    {
        Stack<IDeleteable> toCleanUp = new Stack<IDeleteable>();

        [Test]
        // This no longer copies between servers, but the original test didn't guarantee that would happen anyway
        public void CloneDatabaseAndTable()
        {
            const string testLiveDatabaseName = "TEST";
            
            var testDb = DiscoveredServerICanCreateRandomDatabasesAndTablesOn.ExpectDatabase(testLiveDatabaseName);
            var raw = DiscoveredServerICanCreateRandomDatabasesAndTablesOn.ExpectDatabase(testLiveDatabaseName + "_RAW");

            foreach (DiscoveredDatabase db in new[] { raw ,testDb})
                if (db.Exists())
                {
                    foreach (DiscoveredTable table in db.DiscoverTables(true))
                        table.Drop();

                    db.Drop();
                }
        
            DiscoveredServerICanCreateRandomDatabasesAndTablesOn.CreateDatabase(testLiveDatabaseName);
            Assert.IsTrue(testDb.Exists());

            Server smoServer = new Server(DiscoveredServerICanCreateRandomDatabasesAndTablesOn.Name);
            Database smoDatabase = smoServer.Databases[testLiveDatabaseName];


            var smoTable = new Table(smoDatabase, "Table_1");
            smoTable.Columns.Add(new Column(smoTable, "Id", DataType.Int));
            smoTable.Create();

            var dbConfiguration = new HICDatabaseConfiguration(new StandardDatabaseHelper(testLiveDatabaseName, 
                new FixedStagingDatabaseNamer(testLiveDatabaseName),
                ServerICanCreateRandomDatabasesAndTablesOn.DataSource,
                ServerICanCreateRandomDatabasesAndTablesOn.DataSource));
            
            var cloner = new DatabaseCloner(dbConfiguration);
            try
            {
                cloner.CreateDatabaseForStage(LoadBubble.Raw);

                //confirm database appeared
                Assert.IsTrue(new DiscoveredServer(ServerICanCreateRandomDatabasesAndTablesOn).ExpectDatabase("TEST_RAW").Exists());

                //now create a catalogue and wire it up to the table TEST on the test database server 
                Catalogue cata = SetupATestCatalogue(ServerICanCreateRandomDatabasesAndTablesOn.DataSource, "TEST", "Table_1"); 

                //now clone the catalogue data structures to MachineName
                foreach (TableInfo tableInfo in cata.GetTableInfoList(false))
                    cloner.CreateTablesInDatabaseFromCatalogueInfo(tableInfo, LoadBubble.Raw,
                        new FixedStagingDatabaseNamer("TEST"));
                
                Assert.IsTrue(raw.Exists());
                Assert.IsTrue(raw.ExpectTable("Table_1").Exists());

            }
            finally
            {
                cloner.LoadCompletedSoDispose(ExitCodeType.Success, new ToConsoleDataLoadEventReciever());

                while (toCleanUp.Count > 0)
                    try
                    {
                        toCleanUp.Pop().DeleteInDatabase();
                    }
                    catch (Exception e)
                    {
                        //always clean up everything 
                        Console.WriteLine(e);
                    }

                smoServer.KillDatabase(smoDatabase.Name);
            }
        }

        private Catalogue SetupATestCatalogue(string server, string database, string table)
        {
            //create a new catalogue for test data (in the test data catalogue)
            var cat = new Catalogue(CatalogueRepository, "DeleteMe");
            TableInfoImporter importer = new TableInfoImporter(CatalogueRepository, server, database, table, DatabaseType.MicrosoftSQLServer);

            TableInfo tableInfo;
            ColumnInfo[] columnInfos;
            importer.DoImport(out tableInfo, out columnInfos);

            toCleanUp.Push(cat);
            toCleanUp.Push(tableInfo);

            //for each column we will add a new one to the 
            foreach (ColumnInfo col in columnInfos)
            {
                //create it with the same name
                var cataItem = new CatalogueItem(CatalogueRepository, cat, col.Name.Substring(col.Name.LastIndexOf(".") + 1).Trim('[', ']', '`'));
                toCleanUp.Push(cataItem);

                CatalogueRepository.Linker.AddLinkBetween(cataItem, col);

                toCleanUp.Push(col);
            }


            return cat;
        }

        [Test]
        [Ignore("Need to create ISD_SMR (or similar) test catalogue/load metadata entry")]
        public void TestCreatingISD_SMRStagingTablesOnCONSUS()
        {
            LoadMetadata loadMetadata = CatalogueRepository.GetAllObjects<LoadMetadata>("WHERE Name='ISD_SMR Full Load'").SingleOrDefault();
            Assert.IsNotNull(loadMetadata);
            ICatalogue[] catalogues = loadMetadata.GetAllCatalogues().ToArray();

            var server = loadMetadata.GetDistinctLiveDatabaseServer();

            string databaseName = catalogues.First().GetDatabaseName();
            var databaseConfiguration = new HICDatabaseConfiguration(new StandardDatabaseHelper(
                databaseName, new FixedStagingDatabaseNamer(databaseName),
                server.Name,
                server.Name));
            
            
            var cloner = new DatabaseCloner(databaseConfiguration);

            cloner.CreateTablesInDatabaseFromCatalogueInfo(catalogues, LoadBubble.Staging, new FixedStagingDatabaseNamer(databaseName),false);
            cloner.LoadCompletedSoDispose(ExitCodeType.Success, new ToConsoleDataLoadEventReciever());
        }

        [Test]
        [Ignore("Need to create isd_smr01 (or similar) test catalogue entry")]
        public void CreateANO_Identifiers_STAGING()
        {
            Catalogue cata = CatalogueRepository.GetAllObjects<Catalogue>("WHERE Name='isd_smr01'").SingleOrDefault();
            Assert.IsNotNull(cata);

            TableInfo tableInfo = cata.GetTableInfoList(false).Single();
            IdentifierDumper dumper = new IdentifierDumper(tableInfo, PreLoadDiscardedColumn.GetAllPreLoadDiscardedColumnsFor(tableInfo).ToArray());

            dumper.CreateSTAGINGTable();
            dumper.LoadCompletedSoDispose(ExitCodeType.Success, new ToConsoleDataLoadEventReciever());
        }

        [Test]
        public void TestDynamicPipelineEngineFactory()
        {
            var parentDir = new DirectoryInfo(".");

            var cacheProgress = MockRepository.GenerateStub<ICacheProgress>();
            cacheProgress.PipelineContextField = "DataExportManager2Library.ExtractionTime.ExtractionPipeline.ExtractionPipelineHost.Context";

            var factory = new DynamicPipelineEngineFactory(CatalogueRepository.MEF);
            var engine = factory.CreateFactory(cacheProgress.PipelineContextField);

            Assert.NotNull(engine);
        }

    }
}

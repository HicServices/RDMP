using System.Collections.Generic; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Data.Common;
using System.Diagnostics;

namespace ReusableLibraryCode.Performance
{
    public class ComprehensiveQueryPerformanceCounter
    {
        public BiDictionary<string,QueryPerformed> DictionaryOfQueries = new BiDictionary<string, QueryPerformed>();

        public ComprehensiveQueryPerformanceCounter()
        {
            
        }

        public void AddAudit(DbCommand cmd, string environmentDotStackTrace)
        {
            
            //is it a novel origin
            if (!DictionaryOfQueries.Firsts.Contains(environmentDotStackTrace))
                DictionaryOfQueries.Add(environmentDotStackTrace, new QueryPerformed(cmd.CommandText));

            var query = DictionaryOfQueries.GetByFirst(environmentDotStackTrace);
            query.IncrementSeenCount();
        }
    }
}

using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Data;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Windows.Forms;
using CatalogueLibrary.Data;
using CatalogueLibrary.Data.DataLoad;
using CatalogueLibrary.Repositories;
using MapsDirectlyToDatabaseTable;
using ReusableUIComponents;
using ReusableUIComponents.SqlDialogs;

namespace RDMPObjectVisualisation.DemandsInitializationUIs
{
    public partial class ArgumentUI<T> : UserControl where T : DatabaseEntity,IArgumentHost
    {
        private Argument _argument;
        private bool _bLoading;
        private T _parent;
        private Type _currentlySelectedSystemType;
        private CatalogueRepository _repository;
        public DataTable Preview { get; set; }

        private const string ClearSelection = "<<Clear Selection>>";

        public event EventHandler Saved;

        public ArgumentUI()
        {
            InitializeComponent();
        }

        public void SetProcessTaskArgument(CatalogueRepository catalogueRepository, T parent, Argument argument, DemandType demandType)
        {
            _repository = catalogueRepository; 
            _parent = parent;
            _bLoading = true;
            _argument = argument;
            btnSetSQL.Visible = false;
            cbxRelatedToLoadMetadata.Visible = false;

            if (argument == null)
            {
                tbID.Text = "";
                tbName.Text = "";
                tbName.Enabled = false;

                cbxValue.Enabled = false;
                cbxValue.Text = "";

                tbType.Text = "";

                tbDescription.Text = "";
            }
            else
            {
            
                tbID.Text = argument.ID.ToString();
                tbName.Text = argument.Name;
                tbName.Enabled = true;

                cbxValue.Enabled = true;

                Type valueAsSystemType = argument.GetSystemType();
                _currentlySelectedSystemType = valueAsSystemType;


                //only used with specific types of argument (See below for enabling visibility of these)
                btnLaunchCustomUI.Visible = false;
                btnSetSQL.Visible = false;
                cbxValue.Visible = false;
                cbValue.Visible = false;

                //if it is a custom UI driven class display the launch button only
                if (typeof(ICustomUIDrivenClass).IsAssignableFrom(valueAsSystemType) )
                {
                    btnLaunchCustomUI.Visible = true;
                }
                else
                //if it is SQL
                if (demandType == DemandType.SQL)
                {
                    if(typeof(string) != valueAsSystemType)
                        throw new NotSupportedException("Demanded type (of DemandsInitialization) was DemandType.SQL but the ProcessTaskArgument Property was of type " + valueAsSystemType + " (Expected String)");
                    
                    btnSetSQL.Visible = true;
                }
                else
                //if it is a bool
                if (typeof(bool) == valueAsSystemType)
                {
                    //display checkbox instead
                    cbValue.Visible = true;
                    cbValue.Checked = (bool)argument.GetValueAsSystemType();
                }
                else
                {
                    //its not a bool so use a dropdown/combo box
                    cbxValue.Visible = true;
                }

                //value is in IMapsDirectly type e.g .Catalogue/TableInfo or something
                if (typeof(IMapsDirectlyToDatabaseTable).IsAssignableFrom(valueAsSystemType))
                {
                    cbxValue.DataSource = null;
                    cbxValue.DropDownStyle = ComboBoxStyle.DropDownList;
                    cbxValue.Items.Clear();

                    //Populate dropdown with the appropriate types
                    if (valueAsSystemType == typeof(TableInfo))
                        cbxValue.Items.AddRange(GetAllTableInfosAssociatedWithLoadMetadata().ToArray());
                    else if (valueAsSystemType == typeof(ColumnInfo))
                    {
                        cbxRelatedToLoadMetadata.Visible = true;
                        cbxRelatedToLoadMetadata.Checked = true;
                        UpdateColumnInfoList();
                    }
                    else if (valueAsSystemType == typeof(PreLoadDiscardedColumn))
                        cbxValue.Items.AddRange(GetAllPreloadDiscardedColumnsAssociatedWithLoadMetadata().ToArray());
                    else if (valueAsSystemType == typeof(LoadProgress))
                        cbxValue.Items.AddRange(GetAllLoadScheduleAssociatedWithLoadMetadata().ToArray());
                    else if (valueAsSystemType == typeof(ExternalDatabaseServer))
                    {
                        var servers = Argument.Repository.GetAllObjects<ExternalDatabaseServer>();
                        cbxValue.Items.AddRange(servers.ToArray());
                    }
                    else
                        throw new Exception("Unexpected value type (although it is an IMapsDirectlyToDataTable, it was not one of the ones we were programmed to handle e.g. TableInfo)");
                    
                    cbxValue.Items.Add(ClearSelection);

                    //if we have a value it will be an ID
                    if (!string.IsNullOrWhiteSpace(argument.Value))
                        try
                        {
                            if (valueAsSystemType == typeof (ColumnInfo))
                                ProcessColumnInfoArgumentUI(argument);
                            else
                            {
                                //get the value as the object type e.g. Catlogue
                                cbxValue.Text = argument.GetValueAsSystemType().ToString();
                            }
                        }
                        catch (KeyNotFoundException e)//the object might have been deleted (it's ID is no longer in the table, if so offer to set the param to null for the user)
                        {
                            if (
                                MessageBox.Show(e.Message, "Set value for parameter " + argument.Name + " to Null?",
                                    MessageBoxButtons.YesNo) == DialogResult.Yes)
                            {
                                argument.Value = null;
                                argument.SaveToDatabase();
                                SetProcessTaskArgument(_repository, parent, argument, demandType);//relaunch method having fixed the null problem
                                return;
                            }
                        }

                }
                else
                    //type is an enum
                    if (typeof(Enum).IsAssignableFrom(argument.GetSystemType()))
                    {
                        cbxValue.DataSource = Enum.GetValues(argument.GetSystemType());
                        cbxValue.DropDownStyle = ComboBoxStyle.DropDownList;
                        cbxValue.Text = argument.Value;
                    }
                    else if (typeof (CatalogueRepository).IsAssignableFrom(valueAsSystemType))
                    {
                        cbxValue.Enabled = false;
                        cbxValue.Text = "<this value cannot be set manually>";
                    }
                    else //type is simple
                    {
                        cbxValue.DropDownStyle = ComboBoxStyle.Simple;
                        cbxValue.Text = argument.Value;
                    }

                tbType.Text = argument.Type;
                tbDescription.Text = argument.Description;

            }

            _bLoading = false;
        }

        /// <summary>
        /// Set the argument UI for a ColumnInfo arg, taking into account the ability to assign either related or global ColumnInfos and setting the checkbox/dropdown contents accordingly.
        /// </summary>
        /// <param name="argument"></param>
        private void ProcessColumnInfoArgumentUI(IArgument argument)
        {
            cbxValue.Text = argument.GetValueAsSystemType().ToString();

            // If the text value hasn't been set for a ColumnInfo, this is potentially because it is a global reference rather than a column info related to this particular LoadMetadata
            if (string.IsNullOrWhiteSpace(cbxValue.Text))
            {
                if (cbxRelatedToLoadMetadata.Checked)
                {
                    // The drop-down is only displaying ColumnInfos related to the LoadMetadata, so change the UI to display all ColumnInfos
                    cbxRelatedToLoadMetadata.Checked = false;
                    UpdateColumnInfoList();

                    cbxValue.Text = argument.GetValueAsSystemType().ToString();
                }

                // If we're here and still haven't set cbxValue.Text then the ColumnInfo isn't being loaded into the drop-down's list for either global or related ColumnInfos
                if (string.IsNullOrWhiteSpace(cbxValue.Text))
                    throw new InvalidOperationException("Cannot find ColumnInfo " + argument.GetValueAsSystemType() +
                                                        " in the global or LoadMetadata-related list of ColumnInfos");
            }
        }
        
        public Argument Argument
        {
            get { return _argument; }
        }
        
        private IEnumerable<TableInfo> GetTableInfosFromParentOrThrow()
        {
            if (Argument == null)
                throw new NullReferenceException("ProcessTaskArgument is null so cannot lookup tableinfos");

            var t = _parent as ITableInfoCollectionHost;

            if (t == null)
                throw new NotSupportedException("We are trying to configure arguments for a " + typeof(T).Name + " but it does not implement interface " + typeof(ITableInfoCollectionHost).Name + " which means we cannot support DemandsInitializations of types TableInfo or any derrivative objects (ColumnInfo,Prediscarded Columns etc).  Argument name was " + _argument.Name + " which is of type " + Argument.Type);

            return t.GetTableInfos();
        }

        private IEnumerable<TableInfo> GetAllTableInfosAssociatedWithLoadMetadata()
        {
           return GetTableInfosFromParentOrThrow();
        }
        
        private IEnumerable<ColumnInfo> GetAllColumnInfosAssociatedWithLoadMetadata()
        {
            if (Argument == null)
                throw new NullReferenceException("ProcessTaskArgument is null so cannot lookup columninfos");

            return GetTableInfosFromParentOrThrow().SelectMany(ti => ti.ColumnInfos);
        }
        private IEnumerable<PreLoadDiscardedColumn> GetAllPreloadDiscardedColumnsAssociatedWithLoadMetadata()
        {
            if (Argument == null)
                throw new NullReferenceException("ProcessTaskArgument is null so cannot lookup preload discarded columns");


            return GetTableInfosFromParentOrThrow().SelectMany(PreLoadDiscardedColumn.GetAllPreLoadDiscardedColumnsFor);
        }
        private IEnumerable<ILoadProgress> GetAllLoadScheduleAssociatedWithLoadMetadata()
        {
            var h = _parent as ILoadScheduleHost;

            if (h != null)
                return h.GetLoadSchedules();

            throw new NotSupportedException("Cannot populate LoadSchedule selection list because type " + typeof(T).Name + " does not support the " + typeof(ILoadScheduleHost).Name + " interface");

            
        }
        
        private void btnSave_Click(object sender, EventArgs e)
        {
            if(Argument != null)
                Argument.SaveToDatabase();

            if (Saved != null)
                Saved(this,new EventArgs());
        }

        protected override bool ProcessKeyPreview(ref Message m)
        {

            PreviewKey p = new PreviewKey(ref m, ModifierKeys);

            if (p.IsKeyDownMessage && p.e.KeyCode == Keys.S && p.e.Control)
            {
                //the process task argument has focus so let it deal with the save
                if (this.ContainsFocus)
                {
                    btnSave_Click(null, null);
                    p.Trap(this);
                }
            }

            return base.ProcessKeyPreview(ref m);
        }


        private void cbxValue_TextChanged(object sender, EventArgs e)
        {
            if(_bLoading)
                return;

            if (Argument != null)
            {
                //user chose to clear selection from a combo box
                if (cbxValue.Text == ClearSelection)
                    Argument.Value = null;
                else if (cbxValue.SelectedItem != null)
                    Argument.SetValue(cbxValue.SelectedItem);
                else
                    Argument.Value = cbxValue.Text;

                Argument.SaveToDatabase();
            
            
                try
                {
                    Argument.GetValueAsSystemType();
                    lblError.Visible = false;
                }
                catch (Exception exception)
                {
                    lblError.Visible = true;
                    lblError.Text = exception.Message;
                }
            }
        }

        private void cbValue_CheckedChanged(object sender, EventArgs e)
        {
            if (Argument != null)
            {
                Argument.SetValue(cbValue.Checked);
                Argument.SaveToDatabase();
            }

        }

        private void btnSetSQL_Click(object sender, EventArgs e)
        {
            if(Argument != null)
            {
                SetSQLDialog dialog = new SetSQLDialog(Argument.Value);
                DialogResult d = dialog.ShowDialog();

                if (d == DialogResult.OK)
                {
                    Argument.SetValue(dialog.Result);
                    Argument.SaveToDatabase();
                }
            }

        }

        private void btnLaunchCustomUI_Click(object sender, EventArgs e)
        {
            try
            {
                Type t = Argument.GetSystemType();

                string expectedUIClassName = t.FullName + "UI";
                
                Type UIType = _repository.MEF.GetTypeByNameFromAnyLoadedAssembly(expectedUIClassName);

                //if we did not find one with the exact name (including namespace), try getting it just by the end of it's name (ommit namespace)
                if (UIType == null)
                {
                    string shortUIClassName = t.Name + "UI";
                    var candidates = _repository.MEF.GetAllTypes().Where(type => type.Name.Equals(shortUIClassName)).ToArray();

                    if(candidates.Length > 1)
                        throw new Exception("Found " + candidates.Length + " classes called '" + shortUIClassName + "' : (" + string.Join(",", candidates.Select(c => c.Name)) + ")");

                    if (candidates.Length  == 0)
                        throw new Exception("Could not find UI class called " + shortUIClassName + " make sure that it exists, is public and is marked with class attribute [Export(typeof(ICustomUI<>))]");

                    UIType = candidates[0];
                }

                
                var objectSavedState = (ICustomUIDrivenClass)Argument.GetValueAsSystemType();

                var instance = Activator.CreateInstance(UIType);
                
                ICustomUI instanceAsCustomUI = (ICustomUI) instance;
                instanceAsCustomUI.SetGenericUnderlyingObjectTo(objectSavedState,Preview);
                ((Form)instanceAsCustomUI).ShowDialog();
                var result = instanceAsCustomUI.GetGenericFinalStateOfUnderlyingObject();

                Argument.SetValue(result);
                Argument.SaveToDatabase();
            }
            catch (Exception ex)
            {
                
                ExceptionViewer.Show(ex);
            }
            
        }

        private void cbRelatedToLoadMetadata_CheckedChanged(object sender, EventArgs e)
        {
            if (_currentlySelectedSystemType == typeof (ColumnInfo))
                UpdateColumnInfoList();
        }

        private void UpdateColumnInfoList()
        {
            cbxValue.Items.Clear();
            cbxValue.Items.AddRange(cbxRelatedToLoadMetadata.Checked
                ? GetAllColumnInfosAssociatedWithLoadMetadata().ToArray()
                : _repository.GetAllObjects<ColumnInfo>().ToArray());
        }
    }
}

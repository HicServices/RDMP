using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Input;
using Cursor = System.Windows.Forms.Cursor;

namespace ReusableUIComponents
{
    public class BetterToolTip : ToolTip
    {
        
        private readonly Control _hostControl;
        
        SolidBrush Black = new SolidBrush(Color.Black);
        SolidBrush Yellow = new SolidBrush(System.Drawing.SystemColors.Info);
        private int BORDER_THICKNESS = 2;
     
        private Font font;
        private StringFormat format = new StringFormat();

        /// <summary>
        /// Used to periodically check whether the cursor is within any of the subscribed controls
        /// </summary>
        Timer t = new Timer();

        /// <summary>
        /// Optional fallback documentation when no specific documentation is added to an instance of BetterToolTip
        /// </summary>
        public static Dictionary<Type, string> FallbackTooltips { get; set; }

        /// <summary>
        /// List of all the controls and thier associated images/text - can have text without image
        /// </summary>
        Dictionary<Control, string> textDictionary = new Dictionary<Control, string>();
        Dictionary<Control, Image> imageDictionary = new Dictionary<Control, Image>();

        /// <summary>
        /// The control that is currently showing
        /// </summary>
        private Control Showing = null;


        /// <summary>
        /// The STATIC BetterToolTip which is currently owning the screen and displaying itself
        /// </summary>
        private static BetterToolTip currentScreenOwner = null;
        private static object oLockCurrentScreenOwner = new object();
        
        /// <summary>
        /// Use SetToolTip overload to set the Image for the tooltip
        /// </summary>
        public BetterToolTip(Control hostControl)
        {
            _hostControl = hostControl;

            OwnerDraw = true;
            this.Popup += BetterToolTip_Popup;
            this.Draw += BetterToolTip_Draw;

            FontFamily fontFamily = new FontFamily("Arial");
            font = new Font(
               fontFamily,
               12,
               FontStyle.Regular,
               GraphicsUnit.Pixel);

            format.FormatFlags = StringFormatFlags.LineLimit;
            format.Alignment = StringAlignment.Near;
            format.LineAlignment = StringAlignment.Center;
            format.Trimming = StringTrimming.None;

            t.Interval = 200;
            t.Tick += t_Tick;
            t.Start();
            
            //put this in controls constructor
            //find parent Form

            hostControl.VisibleChanged+= (sender, args) =>
            {
                Form form;
                if (hostControl is Form)
                    form = (Form)hostControl;
                else
                    form = hostControl.FindForm();

                //If we are on a Form
                if (form != null)
                    form.Closing += (s2, a2) =>
                    {
                        t.Stop();
                    };    //stop ticking if form closes
            };

            SubscribeRecursivelyToAllFallbackToolTips(hostControl);
        }

        private void SubscribeRecursivelyToAllFallbackToolTips(Control hostControl)
        {
            if(FallbackTooltips == null)
                return;

            //subscribe to it's default fallback documentation if it has one
            var type = hostControl.GetType();
            if (FallbackTooltips.ContainsKey(type))
            {
                string text = FallbackTooltips[type];

                if (!string.IsNullOrEmpty(text))
                {
                    //double up the newlines for formatting
                    text = text.Replace("\r\n", "\r\n\r\n");
                    //put the class description in
                    text = type.Name + ":" + "\r\n" + text.Trim();

                    SetToolTip(hostControl, text);
                }
            }

            //now subscribe all the child controls too
            foreach (Control control in hostControl.Controls)
                SubscribeRecursivelyToAllFallbackToolTips(control);
        }


        protected override void Dispose(bool disposing)
        {
            t.Stop();
            t.Dispose();
            font.Dispose();
            format.Dispose();
            Black.Dispose();
            Yellow.Dispose();

            base.Dispose(disposing);
        }


        private void BetterToolTip_Draw(object sender, DrawToolTipEventArgs e)
        {
            e.Graphics.CompositingQuality = CompositingQuality.HighQuality;

            var image = imageDictionary.ContainsKey(e.AssociatedControl)?imageDictionary[e.AssociatedControl]:null;
            var text = textDictionary[e.AssociatedControl];
            
            e.Graphics.FillRectangle(Black, e.Bounds);

            var innerTipFullBounds = Rectangle.Inflate(e.Bounds, -BORDER_THICKNESS, -BORDER_THICKNESS);
            e.Graphics.FillRectangle(Yellow, innerTipFullBounds);

            //image rectangle
            if(image != null)
            {
                Rectangle imageRectangle = new Rectangle(new Point(e.Bounds.X + BORDER_THICKNESS, e.Bounds.Y + BORDER_THICKNESS), image.Size);
                e.Graphics.DrawImage(image, imageRectangle);

                Size textSize = TextRenderer.MeasureText(text, font, new Size(Math.Max(600, image.Width), 200), TextFormatFlags.WordBreak);
                Rectangle textRectangle = new Rectangle(imageRectangle.Left,imageRectangle.Bottom,textSize.Width,textSize.Height);
                e.Graphics.DrawString(text, font, Black, textRectangle, format);    
            }
            else
            {
                Rectangle textRectangle = new Rectangle(new Point(e.Bounds.X, e.Bounds.Y),GetControlBounds(text, image));
                textRectangle.Inflate(-BORDER_THICKNESS,-BORDER_THICKNESS);
                e.Graphics.DrawString(text, font, Black, textRectangle, format);    
            }
        }

        private Size GetControlBounds(string text, Image image)
        {
            Size textSize = MeasureText(text,image);

            if (image == null)
                return textSize;
            
            Size imageSize = new Size(image.Size.Width, image.Size.Height); 
            return new Size(imageSize.Width,imageSize.Height + textSize.Height);
        }

        private void BetterToolTip_Popup(object sender, PopupEventArgs e)
        {
            e.ToolTipSize = GetControlBounds(textDictionary[e.AssociatedControl], imageDictionary.ContainsKey(e.AssociatedControl) ? imageDictionary[e.AssociatedControl] : null);
            e.ToolTipSize = new Size(e.ToolTipSize.Width + (BORDER_THICKNESS * 2), e.ToolTipSize.Height + (BORDER_THICKNESS * 2));
        }

        public new void SetToolTip(Control c, string text)
        {
            if (textDictionary.ContainsKey(c))
                textDictionary[c] = textDictionary[c] + Environment.NewLine + text;
            else
                textDictionary.Add(c, text);
        }

        public void SetToolTip(Control c, string text, Image image)
        {
            image = ResizeImageIfRequiredToFitSmallScreens(image, text);
            imageDictionary.Add(c, image);

            SetToolTip(c, text);
        }

        private Image ResizeImageIfRequiredToFitSmallScreens(Image image, string text)
        {
            //work out size of text
            int heightOfText =  MeasureText(text,image).Height;


            //resize images that are too big
            int minWidthOfAnyScreen = int.MaxValue;
            int minHeightOfAnyScreen = int.MaxValue;

            //work out the smallest available screen size
            foreach (Screen screen in Screen.AllScreens)
            {
                minWidthOfAnyScreen = Math.Min(screen.WorkingArea.Width, minWidthOfAnyScreen);
                minHeightOfAnyScreen = Math.Min(screen.WorkingArea.Height, minHeightOfAnyScreen);
            }

            //to account for the border of the popup etc (including shadow effect etc)
            const int pixelPadding = 20;

            //height is off... maintain aspect ratio
            if (image.Height + heightOfText + pixelPadding > minHeightOfAnyScreen)
            {
                //space available / image height
                double resizeMultiplier = (((minHeightOfAnyScreen - pixelPadding) - heightOfText)* 1.0f) / (image.Height * 1.0f);

                
                image = new Bitmap(image,
                    new Size(
                    (int) (image.Width*resizeMultiplier),
                    (int) (image.Height*resizeMultiplier)));


                if(image.Height + heightOfText + pixelPadding > minHeightOfAnyScreen)
                    throw new Exception("Resize failed to produce an image that fits (Resize ratio was '" + resizeMultiplier + "' and current size is "+image.Height + " Screen Height of computers smallest screen is " + minHeightOfAnyScreen + " text for the tooltip was '" + text + "'");
            }

            //if it is still too wide
            if (image.Width > minWidthOfAnyScreen)
            {
                double resizeMultiplier = minWidthOfAnyScreen*1.0f/image.Width*1.0f;

                image = new Bitmap(image,
                    new Size(
                    (int)(image.Width * resizeMultiplier),
                    (int)(image.Height * resizeMultiplier)));
            }


            return image;
        }

        private Size MeasureText(string text,Image image)
        {
            return TextRenderer.MeasureText(text, font, new Size(Math.Max(600, image == null ? 0 : image.Width), 200),TextFormatFlags.WordBreak);
        }

        void t_Tick(object sender, EventArgs e)
        {
            bool showHelp = Keyboard.IsKeyDown(Key.F1);


            bool shouldAbandonBecauseHostDisposed = PruneDisposedControls();
            
            if(shouldAbandonBecauseHostDisposed)
                return;

            //if form is not visible do not show help
            if (!_hostControl.Visible)
                showHelp = false;

            //if form is not active do not show help
            if (_hostControl.FindForm() != Form.ActiveForm)
                showHelp = false;

            //if F1 is not down and we are currently showing, hide it
            if (!showHelp)
                if (Showing != null)
                {
                    Hide(Showing);//we are not required to show help but it is currently showing, so hide it

                    ClearCurrentScreenOwnerIfItIsUs();
                    Showing = null;
                    return;
                }
                else
                    return;//we are not required to show help and we are not currently showing help so good job


            //get all the controls which have boundaries containing the cursor
            List<Control> containers = textDictionary.Keys.Where(c => IsCursorInControl(c) && c.Visible).ToList();

            //if there are some controls that contain the cursor
            if(containers.Any())
            {
                //find the smallest control which contains the cursor (this is likely to be the innermost right?)
                Control smallestControl = containers.OrderBy(c=>c.Bounds.Width*c.Bounds.Height).First();
                
                //if we are already showing this one then do nothing
                if(Showing == smallestControl)
                    return;

                
                if (Showing != null)
                {
                    //we are currently showing a different one, so hide it
                    Hide(Showing);

                    //also since we are showing we are no longer now
                    ClearCurrentScreenOwnerIfItIsUs();
                }
                
                //now show the one we want to show

                //we are not currently showing this one so popup this one
                Showing = smallestControl;
                
                //popup help for it
                PopupHelpInCentreOfScreenForKey(smallestControl);
            }
            else
            {
                //we are required to show help but there are no controls which contain the cursor
                //if we are currently showing something
                if (Showing != null)
                {
                    Hide(Showing);//hide it

                    //if we are the current owner, clear that
                    ClearCurrentScreenOwnerIfItIsUs();

                    Showing = null;
                }
            }
        }

        private bool PruneDisposedControls()
        {
            //host control is disposed
            if(_hostControl.IsDisposed)
            {
                if (Showing != null)
                    Hide(Showing); //hide existing show

                //stop timer and return that we should stop everything
                t.Stop();
                return true;
            }
            
            //host is not disposed  but one or more of it's children might be, any disposed control should be removed from dictionaries
            foreach (Control c in textDictionary.Keys.ToArray())
                if (c.IsDisposed)
                    textDictionary.Remove(c);

            foreach (Control c in imageDictionary.Keys.ToArray())
                if (c.IsDisposed)
                    imageDictionary.Remove(c);

            return false;
        }

        private void ClearCurrentScreenOwnerIfItIsUs()
        {
            lock (oLockCurrentScreenOwner)
            {
                //also since we are showing we are no longer now
                if (currentScreenOwner == this)
                    currentScreenOwner = null;
            }
        }

        private void PopupHelpInCentreOfScreenForKey(Control c)
        {
            // How to pick which tool tip to show when mouse is over 2 controls (one control will be _hostControl the other is currentScreenOwner._hostControl
            // 3 possibilities:
            // 1. This is a child (hide the current owner and proceede with showing this)
            // 2. This is a parent (abandon showing this)
            // 3. The controls are siblings (See diagram below) in which case we must use the tool tip that is closest to the cusor since each are equally good candidates
            //
            //
            /*****************************************************************/
            /*      _________________________________________________________
            *      |Form____________________________________________________|
            *      |   ____________________
            *      |   |               ____|______________________
            *      |   |  Control A   |cur |                      | 
            *      |   |______________|____|      Control B       |
            *      |                  |___________________________|
            *      |_________________________________________________________
            * 
            * Where cur is the cursor
            * 
            * Control A is not the father or child of B so instead we must pick a prioritisation between the two in another way
            *                                                                                           */
            /*****************************************************************/

            lock (oLockCurrentScreenOwner)
            {
                if(currentScreenOwner != null && currentScreenOwner != this)
                {
                    var thisDistance = GetCursorDistanceFromCentreOfControl(_hostControl);
                    var currentOwnerDistance = GetCursorDistanceFromCentreOfControl(currentScreenOwner._hostControl);

                    //if this is a parent of the currently displaying one
                    if (
                        FormsHelper.GetAllChildControlsRecursively(this._hostControl).Contains(currentScreenOwner._hostControl)
                        ||
                        thisDistance < currentOwnerDistance //or this control is further from the centre
                        )
                    {
                        //cancel showing this!
                        Showing = null;
                        return;
                    }
                    else
                        //if this is a child of the currently displaying one
                        if (FormsHelper.GetAllChildControlsRecursively(currentScreenOwner._hostControl).Contains(this._hostControl) 
                            || 
                            thisDistance >= currentOwnerDistance //or both controls are siblings favour us if we are closer to the cursor (See diagram)
                            )
                        {
                            currentScreenOwner.Hide(currentScreenOwner.Showing);
                            currentScreenOwner.Showing = null;
                            currentScreenOwner = null;
                        }
                        else
                        {
                         
                         throw new Exception("How can the currently displaying control not be one of these?");
                        }

                    //this control is currently displaying becuase current owner is already us, is null or 
                    currentScreenOwner = this;
                }
            }

            

            //get what screen the Control is currently on
            var screen = Screen.FromControl(c);

            //get the bounds that the help popup wants to be (its size)
            Size desiredBounds = GetControlBounds(textDictionary[c], imageDictionary.ContainsKey(c)?imageDictionary[c]:null);

            //work out where we would have to display it in order for it to be in the centre of the screen
            var pos = new Point(
                screen.WorkingArea.X + (screen.WorkingArea.Width / 2) - (desiredBounds.Width / 2),
                screen.WorkingArea.Y + (screen.WorkingArea.Height / 2) - desiredBounds.Height / 2);


            //will image fit? if not then adjust it onto the screen
            pos.Y = Math.Max(pos.Y, 10);
            
            //work out how to turn those screen coordinates into  control relative coordinates

            //where is the top left of the control on the screen
            Point pointToScreen = c.PointToScreen(new Point(0, 0));
            
            //this acts as an offset for the screen coordinates
            pos.X -= pointToScreen.X;
            pos.Y -= pointToScreen.Y;
            
            Show(textDictionary[c], c, pos);
        }

        private bool IsCursorInControl(Control c)
        {
            Point position = Cursor.Position;

            Rectangle ControlBoundary = new Rectangle(c.PointToScreen(new Point(0, 0)), c.Size);
            return ControlBoundary.Contains(position);
        }

        private double GetCursorDistanceFromCentreOfControl(Control c)
        {
            Point position = Cursor.Position;

            Rectangle ControlBoundary = new Rectangle(c.PointToScreen(new Point(0, 0)), c.Size);


            Point centreOfControl = new Point(ControlBoundary.Left + ControlBoundary.Width,ControlBoundary.Bottom + ControlBoundary.Height);


            return Math.Sqrt(Math.Pow(position.X - centreOfControl.X, 2) + Math.Pow(position.Y - centreOfControl.Y, 2));
        }
    }
}

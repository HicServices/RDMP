using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Drawing;
using System.Windows.Documents;
using System.Windows.Forms;
using CatalogueLibrary.Data.Cohort;
using CatalogueManager.TestsAndSetup.ServicePropogation;
using CohortManager.UserFriendly.Events;
using CohortManagerLibrary.FreeText.Sentencing;

namespace CohortManager.UserFriendly
{
    /// <summary>
    /// Trimmed down version of CohortIdentificationConfigurationUI , allows users to type in thier cohort creation requests in text.  This is interpreted by the RDMP into specific datasets,
    /// filters and parameters to produce a cohort identification configuration. 
    ///  
    /// IMPORTANT: This is a work in progress as in it doesn't work yet.
    /// </summary>
    public partial class CohortManagerUserFriendlyMode : RDMPUserControl
    {
        public CohortIdentificationConfiguration CohortIdentificationConfiguration
        {
            get { return _cohortIdentificationConfiguration; }
            set
            {
                _cohortIdentificationConfiguration = value;

                inclusionExclusionContainersUI1.CohortIdentificationConfiguration = value;


                userFriendlyCohortSearchBox1.Enabled = value != null;
                inclusionExclusionContainersUI1.Enabled = value != null;

            userFriendlyCohortSearchBox1.Clear();
            }
        }
        
        //Constructor
        public CohortManagerUserFriendlyMode()
        {
            InitializeComponent();

            inclusionExclusionContainersUI1.CohortParagraphSelected += (s, p) => userFriendlyCohortSearchBox1.SetText(p);

            colorKey1.SetHorizontalMode();

            var highlighting = new CohortSentenceHighlighting();

            foreach (var kvp in highlighting.HighlightValues)
                colorKey1.AddColor(kvp.Value, kvp.Key.ToString());
        }

        private CohortIdentificationConfiguration _cohortIdentificationConfiguration;

        protected override void OnLoad(EventArgs e)
        {
            if(VisualStudioDesignMode)
                return;
            
            base.OnLoad(e);


            userFriendlyCohortSearchBox1.RepositoryLocator = RepositoryLocator;
            userFriendlyCohortSearchBox1.CreatedNewAggregate += textBox1_CreatedNewAggregate;
            userFriendlyCohortSearchBox1.DeletedAggregate += textBox1_DeletedAggregate;
            userFriendlyCohortSearchBox1.Focus();
        }

        void textBox1_DeletedAggregate(object sender, CohortAggregateEventArgs args)
        {
            inclusionExclusionContainersUI1.RemoveAggregate(args.Configuration);
        }

        void textBox1_CreatedNewAggregate(object sender, CohortAggregateEventArgs args)
        {
            inclusionExclusionContainersUI1.AddAggregate(new CohortSentence(args.Configuration));
        }
    }
}

using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Drawing;
using System.Windows.Forms;

namespace Dashboard.Raceway
{
    /// <summary>
    /// Part of DatsetRaceway, provides a continuous axis for DatasetRaceLane(s).  There will be one tick on the axis for each month that exists amongst any of the datasets you hold.  For
    /// example if you have 2 datasets 'Prescribing' and 'Biochemistry' in which records start in 2001 and run continuously till present in 'Prescribing' but 'Biochemistry' starts in 1995
    /// but both datasets contain some freaky dates in 1900-01-01 due to dirty data then the axis will have a single tick for 1900-01 and then continuous ticks from 1995 onwards.
    /// 
    /// In DatsetRaceway you can adjust the scope of the axis down from 'Entire History' to 'Last Decade',  'Last Year' or 'Last 6 months' if you just want to see how up-to-date each datset
    /// is in finer detail.
    /// </summary>
    public partial class DatasetRaceLaneXAxis : UserControl
    {
        private DateTime[] _buckets;

        public DatasetRaceLaneXAxis()
        {
            InitializeComponent();
        }

        public void SetupFor(DateTime[] buckets)
        {
            _buckets = buckets;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            if (_buckets == null)
                return;

            SolidBrush white = new SolidBrush(Color.FromKnownColor(KnownColor.White));
            SolidBrush black = new SolidBrush(Color.FromKnownColor(KnownColor.Black));
            e.Graphics.FillRectangle(white,e.ClipRectangle);

            float increment = (float)e.ClipRectangle.Width / _buckets.Length;
            
            //foreach bucket

            //if there is at least 20 pixels space for this label we will label each month explicitly
            if (increment > 20)
                for (int i = 0; i < _buckets.Length; i++)
                {
                    //create a rectangle that reflects this far along the control
                    RectangleF rect = new RectangleF(i* increment,e.ClipRectangle.Top,increment,Height);

                    var s = _buckets[i].ToString("yyyy-MM");

                    var font = FindFont(e.Graphics, s, rect.Size.ToSize(), Font);

                    e.Graphics.DrawRectangle(new Pen(Color.Black), new Rectangle((int)rect.X,(int)rect.Y,(int)rect.Width,(int)rect.Height));
                    e.Graphics.DrawString(s, font , black, rect);

                }
            else
            {
                //if there is less than 20 pixels space to draw each label we must draw only every 12th label
                
                //for every 12 buckets
                for (int i = 0; i < _buckets.Length; i+= 12)
                {
                    //create a rectangle that reflects this far along the control
                    RectangleF rectF = new RectangleF(i * increment, e.ClipRectangle.Top, increment*12, Height);

                    var s = _buckets[i].ToString("yyyy");

                    var size = rectF.Size.ToSize();

                    //give up trying to paint they have resized control so far down
                    if (size.Width == 0 || size.Height == 0)
                        return;

                    var font = FindFont(e.Graphics, s,size, Font);

                    e.Graphics.DrawRectangle(new Pen(Color.Black), new Rectangle((int)rectF.X, (int)rectF.Y, (int)rectF.Width, (int)rectF.Height));
                    e.Graphics.DrawString(s, font, black, rectF);
                }
            }

            base.OnPaint(e);
        }

        //This function checks the room size and your text and appropriate font for your text to fit in room
        //PreferedFont is the Font that you wish to apply
        //Room is your space in which your text should be in.
        //LongString is the string which it's bounds is more than room bounds.
        private Font FindFont(Graphics g, string longString, Size Room, Font PreferedFont)
        {
            //you should perform some scale functions!!!
            SizeF RealSize = g.MeasureString(longString, PreferedFont);
            float HeightScaleRatio = Room.Height / RealSize.Height;
            float WidthScaleRatio = Room.Width / RealSize.Width;
            float ScaleRatio = (HeightScaleRatio < WidthScaleRatio) ? ScaleRatio = HeightScaleRatio : ScaleRatio = WidthScaleRatio;
            float ScaleFontSize = PreferedFont.Size * ScaleRatio;
            return new Font(PreferedFont.FontFamily, ScaleFontSize);
        }
    }
}

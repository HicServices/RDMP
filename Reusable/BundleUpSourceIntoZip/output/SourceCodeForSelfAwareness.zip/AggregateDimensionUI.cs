using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using CatalogueLibrary.Data.Aggregation;
using CatalogueManager.MainFormUITabs;
using ScintillaNET;

namespace CatalogueManager.AggregationUIs
{
    /// <summary>
    /// Lets you specify a transform on one of your GROUP BY columns.  For example if you have a column [MyTable]..[DateOfRecord] you might want to GROUP BY Year([MyTable]..[DateOfRecord]).
    /// If you specify a transform then make sure to also add an Alias which describes the new content.  This control also lets you reorder and configure an AggregateContinuousDateAxis (see
    /// AggregateContinuousDateAxisUI.
    /// </summary>
    public partial class AggregateDimensionUI : UserControl
    {
        private AggregateDimension _aggregateDimension;

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Scintilla QueryEditor { get; set; }

        public event EventHandler Saved;

        public AggregateDimension AggregateDimension
        {
            get { return _aggregateDimension; }
            set
            {
                _aggregateDimension = value;

                if (value == null)
                {

                    tbID.Text = "";

                    tbAlias.Enabled = false;
                    tbAlias.Text = "";

                    tbOrder.Enabled = false;
                    tbOrder.Text = "";

                    //prevents bug in designer
                    if(QueryEditor == null)
                        return;

                    QueryEditor.IsReadOnly = true;
                    QueryEditor.Text = "";
                }
                else
                {
                    tbID.Text = value.ID.ToString();

                    tbAlias.Enabled = true;
                    tbAlias.Text = value.Alias;

                    tbOrder.Enabled = true;
                    tbOrder.Text = value.Order.ToString();

                    QueryEditor.IsReadOnly = false;
                    QueryEditor.Text = value.SelectSQL;

                }

                btnSave.Enabled = false;

                aggregateContinuousDateAxisUI1.Dimension = value;
            }

        }

        public AggregateDimensionUI()
        {
            InitializeComponent();

            #region Query Editor setup
            bool designMode = (LicenseManager.UsageMode == LicenseUsageMode.Designtime);
            if (designMode) //stop right here if in designer mode
                return;

            QueryEditor = new Scintilla();
            QueryEditor.Dock = DockStyle.Fill;
            QueryEditor.Scrolling.ScrollBars = ScrollBars.Both;
            QueryEditor.ConfigurationManager.Language = "mssql";
            QueryEditor.Margins[0].Width = 30; //allows display of line numbers

            QueryEditor.TextChanged += new EventHandler(QueryEditor_TextChanged);
            pSelectSQL.Controls.Add(QueryEditor);

            #endregion QueryEditor
        }

        private void QueryEditor_TextChanged(object sender, EventArgs e)
        {
            if(AggregateDimension != null)
            {
                AggregateDimension.SelectSQL = QueryEditor.Text;
                btnSave.Enabled = true;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if(!btnSave.Enabled)
                return;

            if(AggregateDimension != null)
            {
                AggregateDimension.SaveToDatabase();
                btnSave.Enabled = false;
            }

            if(Saved != null)
                Saved(this, new EventArgs());
        }

        private void tbAlias_TextChanged(object sender, EventArgs e)
        {
            if (AggregateDimension != null)
            {
                AggregateDimension.Alias = tbAlias.Text;
                btnSave.Enabled = true;
            }
        }

        private void tbOrder_TextChanged(object sender, EventArgs e)
        {
            if (AggregateDimension != null)
            {
                try
                {
                    AggregateDimension.Order = int.Parse(tbOrder.Text);
                    tbOrder.ForeColor = Color.Black;
                    btnSave.Enabled = true;
                }
                catch (Exception)
                {
                    tbOrder.ForeColor = Color.Red;
                }
            }
        }

    }
}

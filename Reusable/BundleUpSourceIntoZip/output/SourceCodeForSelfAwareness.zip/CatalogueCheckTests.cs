using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Linq;
using CatalogueLibrary.Data;
using NUnit.Framework;
using ReusableLibraryCode.Checks;
using Tests.Common;

namespace CatalogueLibraryTests.Integration
{
    public class CatalogueCheckTests:DatabaseTests
    {
        private Catalogue _cata;
        private ColumnInfo _c2;
        private ColumnInfo _c1;
        private TableInfo _tableInfo;
        private CatalogueItem _cataItem;

        [TestFixtureSetUp]
        public void CreateCatalogueEntities()
        {
            _cata = new Catalogue(CatalogueRepository, "fish");
            _cataItem = new CatalogueItem(CatalogueRepository, _cata, "c");
            _tableInfo = new TableInfo(CatalogueRepository, "table");
            _c1 = new ColumnInfo(CatalogueRepository, "col1", "varchar(10)", _tableInfo);
            _c2 = new ColumnInfo(CatalogueRepository, "col2","varchar(10)",_tableInfo);
        }

        [TestFixtureTearDown]
        public void CleanupCatalougeEntities()
        {
            _cata.DeleteInDatabase();
            _tableInfo.DeleteInDatabase();
        }


        [Test]
        public void MultipleColumnInfosMappingToOneCatalogueItem_Throws()
        {
            //2 associated columns
            CatalogueRepository.Linker.AddLinkBetween(_cataItem,_c1);
            CatalogueRepository.Linker.AddLinkBetween(_cataItem, _c2);
            
            //is not an error
            Assert.DoesNotThrow(() => _cataItem.Check(new ThrowImmediatelyCheckNotifier()));
            //but is a warning
            Assert.Throws<Exception>(() => _cataItem.Check(new ThrowImmediatelyCheckNotifier() { ThrowOnWarning = true }));

            //cleanup - ensure no warnings
            CatalogueRepository.Linker.DeleteLinkAllLinksFor(_cataItem);
            Assert.DoesNotThrow(() => _cataItem.Check(new ThrowImmediatelyCheckNotifier() { ThrowOnWarning = true }));

            //now make both columns associated AND extractable
            var e1 = new ExtractionInformation(CatalogueRepository, _cataItem, _c1, "fish");
            var e2 = new ExtractionInformation(CatalogueRepository, _cataItem, _c2, "fish");

            try
            {
                var notifier = new ToMemoryCheckNotifier();
                //now it throws as an ERROR not a warning
                _cataItem.Check(notifier);

                Assert.IsTrue(notifier.Messages.Any(m=>m.Message.Contains("while it only dodgy having 2+ associated columns for the same CatalogueItem, it is utterly forbidden to have 2+ EXTRACTABLE ones!:col1,col2")));
            }
            finally
            {
                //cleanup
                e1.DeleteInDatabase();
                e2.DeleteInDatabase();
                CatalogueRepository.Linker.DeleteLinkAllLinksFor(_cataItem);
            }
        }

        [Test]
        [ExpectedException(ExpectedMessage="The following invalid characters were found:'\\','.','#'",MatchType=MessageMatch.Contains)]
        public void CatalogueCheck_DodgyName()
        {
            //change in memory
            try {
                
                //catalogue is fine
                _cata.Check(new ThrowImmediatelyCheckNotifier());

                //name broken
                _cata.Name = @"c:\bob.txt#";
                _cata.Check(new ThrowImmediatelyCheckNotifier());
            }
            finally
            {
                //revert it and it is fine again
                _cata.RevertToDatabaseState();
                _cata.Check(new ThrowImmediatelyCheckNotifier());//should work 

            }

        }
    }
}

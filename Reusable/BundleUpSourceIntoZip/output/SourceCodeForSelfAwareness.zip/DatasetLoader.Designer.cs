using CatalogueManager.SimpleDialogs.SimpleFileImporting; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using ReusableLibraryCode.Progress;
using ReusableUIComponents.ChecksUI;
using ReusableUIComponents.Progress;

namespace DatasetLoaderUI
{
    partial class DatasetLoader
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DatasetLoader));
            this.label2 = new System.Windows.Forms.Label();
            this.cbxLoadMetadata = new System.Windows.Forms.ComboBox();
            this.btnLoadDataset = new System.Windows.Forms.Button();
            this.dlgFilePicker = new System.Windows.Forms.OpenFileDialog();
            this.btnShowDatasetFolder = new System.Windows.Forms.Button();
            this.gbLoadChecks = new System.Windows.Forms.GroupBox();
            this.btnRerunChecks = new System.Windows.Forms.Button();
            this.dataLoadEntireSystemStateCheckerUI1 = new ReusableUIComponents.ChecksUI.ChecksUI();
            this.cbSkipArchiving = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cbMigrateStagingToLive = new System.Windows.Forms.CheckBox();
            this.cbMigrateRAWToStaging = new System.Windows.Forms.CheckBox();
            this.btnViewLoadMetadata = new System.Windows.Forms.Button();
            this.gbLoadServers = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.tbRawServer = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.btnStartSingleThreadedLoad = new System.Windows.Forms.Button();
            this.btnAbortLoad = new System.Windows.Forms.Button();
            this.ddLoadSchedule = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.udDaysPerJob = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.btnRebuildCacheFromArchive = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnIterativeOnDemandLoad = new System.Windows.Forms.Button();
            this.btnOnDemandLoad = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.btnStartMultiThreadedLoad = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.tbMaxNumJobsPerStage = new System.Windows.Forms.TextBox();
            this.btnStopLoad = new System.Windows.Forms.Button();
            this.tbFilter = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnOneOffLoad = new System.Windows.Forms.Button();
            this.customDataProviderUI = new DatasetLoaderUI.CustomDataProviderUI();
            this.loadProgressUI1 = new ReusableUIComponents.Progress.ProgressUI();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.databaseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.changeCatalogueToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.refreshToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.testsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.launchDiagnosticsScreenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showPerformanceCounterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gbLoadChecks.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.gbLoadServers.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.udDaysPerJob)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(68, 15);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Load Metadata";
            // 
            // cbxLoadMetadata
            // 
            this.cbxLoadMetadata.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxLoadMetadata.Enabled = false;
            this.cbxLoadMetadata.FormattingEnabled = true;
            this.cbxLoadMetadata.Location = new System.Drawing.Point(156, 12);
            this.cbxLoadMetadata.Name = "cbxLoadMetadata";
            this.cbxLoadMetadata.Size = new System.Drawing.Size(408, 21);
            this.cbxLoadMetadata.TabIndex = 5;
            this.cbxLoadMetadata.SelectedIndexChanged += new System.EventHandler(this.cbxLoadMetadata_SelectedIndexChanged);
            // 
            // btnLoadDataset
            // 
            this.btnLoadDataset.Enabled = false;
            this.btnLoadDataset.Location = new System.Drawing.Point(139, 59);
            this.btnLoadDataset.Name = "btnLoadDataset";
            this.btnLoadDataset.Size = new System.Drawing.Size(101, 23);
            this.btnLoadDataset.TabIndex = 13;
            this.btnLoadDataset.Text = "Single Job Load";
            this.btnLoadDataset.UseVisualStyleBackColor = true;
            this.btnLoadDataset.Click += new System.EventHandler(this.btnLoadDataset_Click);
            // 
            // btnShowDatasetFolder
            // 
            this.btnShowDatasetFolder.Enabled = false;
            this.btnShowDatasetFolder.Location = new System.Drawing.Point(189, 58);
            this.btnShowDatasetFolder.Name = "btnShowDatasetFolder";
            this.btnShowDatasetFolder.Size = new System.Drawing.Size(148, 23);
            this.btnShowDatasetFolder.TabIndex = 9;
            this.btnShowDatasetFolder.Text = "Show dataset folder";
            this.btnShowDatasetFolder.UseVisualStyleBackColor = true;
            this.btnShowDatasetFolder.Click += new System.EventHandler(this.btnShowDatasetFolder_Click);
            // 
            // gbLoadChecks
            // 
            this.gbLoadChecks.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gbLoadChecks.Controls.Add(this.btnRerunChecks);
            this.gbLoadChecks.Controls.Add(this.dataLoadEntireSystemStateCheckerUI1);
            this.gbLoadChecks.Location = new System.Drawing.Point(9, 335);
            this.gbLoadChecks.Name = "gbLoadChecks";
            this.gbLoadChecks.Size = new System.Drawing.Size(677, 304);
            this.gbLoadChecks.TabIndex = 10;
            this.gbLoadChecks.TabStop = false;
            this.gbLoadChecks.Text = "Load checks";
            // 
            // btnRerunChecks
            // 
            this.btnRerunChecks.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRerunChecks.Location = new System.Drawing.Point(578, 278);
            this.btnRerunChecks.Name = "btnRerunChecks";
            this.btnRerunChecks.Size = new System.Drawing.Size(93, 23);
            this.btnRerunChecks.TabIndex = 1;
            this.btnRerunChecks.Text = "Re-run Checks";
            this.btnRerunChecks.UseVisualStyleBackColor = true;
            this.btnRerunChecks.Click += new System.EventHandler(this.btnRerunChecks_Click);
            // 
            // dataLoadEntireSystemStateCheckerUI1
            // 
            this.dataLoadEntireSystemStateCheckerUI1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataLoadEntireSystemStateCheckerUI1.Location = new System.Drawing.Point(3, 16);
            this.dataLoadEntireSystemStateCheckerUI1.Name = "dataLoadEntireSystemStateCheckerUI1";
            this.dataLoadEntireSystemStateCheckerUI1.Size = new System.Drawing.Size(671, 285);
            this.dataLoadEntireSystemStateCheckerUI1.TabIndex = 0;
            // 
            // cbSkipArchiving
            // 
            this.cbSkipArchiving.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cbSkipArchiving.AutoSize = true;
            this.cbSkipArchiving.Location = new System.Drawing.Point(20, 19);
            this.cbSkipArchiving.Name = "cbSkipArchiving";
            this.cbSkipArchiving.Size = new System.Drawing.Size(93, 17);
            this.cbSkipArchiving.TabIndex = 6;
            this.cbSkipArchiving.Text = "Skip archiving";
            this.cbSkipArchiving.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.cbMigrateStagingToLive);
            this.groupBox2.Controls.Add(this.cbMigrateRAWToStaging);
            this.groupBox2.Controls.Add(this.cbSkipArchiving);
            this.groupBox2.Location = new System.Drawing.Point(520, 39);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(166, 90);
            this.groupBox2.TabIndex = 16;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Load Process Flags";
            // 
            // cbMigrateStagingToLive
            // 
            this.cbMigrateStagingToLive.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cbMigrateStagingToLive.AutoSize = true;
            this.cbMigrateStagingToLive.Checked = true;
            this.cbMigrateStagingToLive.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbMigrateStagingToLive.Location = new System.Drawing.Point(20, 65);
            this.cbMigrateStagingToLive.Name = "cbMigrateStagingToLive";
            this.cbMigrateStagingToLive.Size = new System.Drawing.Size(135, 17);
            this.cbMigrateStagingToLive.TabIndex = 10;
            this.cbMigrateStagingToLive.Text = "Migrate Staging to Live";
            this.cbMigrateStagingToLive.UseVisualStyleBackColor = true;
            this.cbMigrateStagingToLive.CheckedChanged += new System.EventHandler(this.cbMigrateStagingToLive_CheckedChanged);
            // 
            // cbMigrateRAWToStaging
            // 
            this.cbMigrateRAWToStaging.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cbMigrateRAWToStaging.AutoSize = true;
            this.cbMigrateRAWToStaging.Checked = true;
            this.cbMigrateRAWToStaging.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbMigrateRAWToStaging.Location = new System.Drawing.Point(20, 42);
            this.cbMigrateRAWToStaging.Name = "cbMigrateRAWToStaging";
            this.cbMigrateRAWToStaging.Size = new System.Drawing.Size(141, 17);
            this.cbMigrateRAWToStaging.TabIndex = 9;
            this.cbMigrateRAWToStaging.Text = "Migrate RAW to Staging";
            this.cbMigrateRAWToStaging.UseVisualStyleBackColor = true;
            this.cbMigrateRAWToStaging.CheckedChanged += new System.EventHandler(this.cbMigrateRAWToStaging_CheckedChanged);
            // 
            // btnViewLoadMetadata
            // 
            this.btnViewLoadMetadata.Location = new System.Drawing.Point(343, 58);
            this.btnViewLoadMetadata.Name = "btnViewLoadMetadata";
            this.btnViewLoadMetadata.Size = new System.Drawing.Size(135, 23);
            this.btnViewLoadMetadata.TabIndex = 24;
            this.btnViewLoadMetadata.Text = "View Load Metadata";
            this.btnViewLoadMetadata.UseVisualStyleBackColor = true;
            this.btnViewLoadMetadata.Click += new System.EventHandler(this.btnViewLoadMetadata_Click);
            // 
            // gbLoadServers
            // 
            this.gbLoadServers.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gbLoadServers.Controls.Add(this.label10);
            this.gbLoadServers.Controls.Add(this.tbRawServer);
            this.gbLoadServers.Controls.Add(this.label13);
            this.gbLoadServers.Enabled = false;
            this.gbLoadServers.Location = new System.Drawing.Point(9, 267);
            this.gbLoadServers.Name = "gbLoadServers";
            this.gbLoadServers.Size = new System.Drawing.Size(683, 62);
            this.gbLoadServers.TabIndex = 32;
            this.gbLoadServers.TabStop = false;
            this.gbLoadServers.Text = "Override Load Servers (Will result in the use of Integrated Security)";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(97, 41);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(155, 13);
            this.label10.TabIndex = 12;
            this.label10.Text = "(Leave blank for local machine)";
            // 
            // tbRawServer
            // 
            this.tbRawServer.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbRawServer.Location = new System.Drawing.Point(97, 19);
            this.tbRawServer.Name = "tbRawServer";
            this.tbRawServer.Size = new System.Drawing.Size(571, 20);
            this.tbRawServer.TabIndex = 10;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(18, 22);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(66, 13);
            this.label13.TabIndex = 10;
            this.label13.Text = "Raw Server:";
            // 
            // btnStartSingleThreadedLoad
            // 
            this.btnStartSingleThreadedLoad.Enabled = false;
            this.btnStartSingleThreadedLoad.Location = new System.Drawing.Point(303, 59);
            this.btnStartSingleThreadedLoad.Name = "btnStartSingleThreadedLoad";
            this.btnStartSingleThreadedLoad.Size = new System.Drawing.Size(194, 23);
            this.btnStartSingleThreadedLoad.TabIndex = 44;
            this.btnStartSingleThreadedLoad.Text = "Iterative Single Job Load";
            this.btnStartSingleThreadedLoad.UseVisualStyleBackColor = true;
            this.btnStartSingleThreadedLoad.Click += new System.EventHandler(this.btnStartSingleThreadedLoad_Click);
            // 
            // btnAbortLoad
            // 
            this.btnAbortLoad.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnAbortLoad.Location = new System.Drawing.Point(336, 815);
            this.btnAbortLoad.Name = "btnAbortLoad";
            this.btnAbortLoad.Size = new System.Drawing.Size(117, 23);
            this.btnAbortLoad.TabIndex = 45;
            this.btnAbortLoad.Text = "Abort Load";
            this.btnAbortLoad.UseVisualStyleBackColor = true;
            this.btnAbortLoad.Click += new System.EventHandler(this.btnAbortLoad_Click);
            // 
            // ddLoadSchedule
            // 
            this.ddLoadSchedule.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddLoadSchedule.Enabled = false;
            this.ddLoadSchedule.FormattingEnabled = true;
            this.ddLoadSchedule.Location = new System.Drawing.Point(96, 12);
            this.ddLoadSchedule.Name = "ddLoadSchedule";
            this.ddLoadSchedule.Size = new System.Drawing.Size(132, 21);
            this.ddLoadSchedule.TabIndex = 48;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(11, 15);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 13);
            this.label4.TabIndex = 50;
            this.label4.Text = "Load Schedule";
            // 
            // udDaysPerJob
            // 
            this.udDaysPerJob.Location = new System.Drawing.Point(320, 13);
            this.udDaysPerJob.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.udDaysPerJob.Name = "udDaysPerJob";
            this.udDaysPerJob.Size = new System.Drawing.Size(54, 20);
            this.udDaysPerJob.TabIndex = 48;
            this.udDaysPerJob.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(248, 15);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 13);
            this.label3.TabIndex = 46;
            this.label3.Text = "Days per job";
            // 
            // splitContainer1
            // 
            this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer1.Location = new System.Drawing.Point(0, 27);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.btnRebuildCacheFromArchive);
            this.splitContainer1.Panel1.Controls.Add(this.groupBox3);
            this.splitContainer1.Panel1.Controls.Add(this.btnStopLoad);
            this.splitContainer1.Panel1.Controls.Add(this.tbFilter);
            this.splitContainer1.Panel1.Controls.Add(this.label1);
            this.splitContainer1.Panel1.Controls.Add(this.groupBox1);
            this.splitContainer1.Panel1.Controls.Add(this.customDataProviderUI);
            this.splitContainer1.Panel1.Controls.Add(this.btnAbortLoad);
            this.splitContainer1.Panel1.Controls.Add(this.groupBox2);
            this.splitContainer1.Panel1.Controls.Add(this.btnViewLoadMetadata);
            this.splitContainer1.Panel1.Controls.Add(this.btnShowDatasetFolder);
            this.splitContainer1.Panel1.Controls.Add(this.gbLoadServers);
            this.splitContainer1.Panel1.Controls.Add(this.cbxLoadMetadata);
            this.splitContainer1.Panel1.Controls.Add(this.label2);
            this.splitContainer1.Panel1.Controls.Add(this.gbLoadChecks);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.loadProgressUI1);
            this.splitContainer1.Size = new System.Drawing.Size(1409, 845);
            this.splitContainer1.SplitterDistance = 693;
            this.splitContainer1.TabIndex = 46;
            // 
            // btnRebuildCacheFromArchive
            // 
            this.btnRebuildCacheFromArchive.Location = new System.Drawing.Point(502, 131);
            this.btnRebuildCacheFromArchive.Name = "btnRebuildCacheFromArchive";
            this.btnRebuildCacheFromArchive.Size = new System.Drawing.Size(184, 23);
            this.btnRebuildCacheFromArchive.TabIndex = 10;
            this.btnRebuildCacheFromArchive.Text = "Rebuild cache from archive...";
            this.btnRebuildCacheFromArchive.UseVisualStyleBackColor = true;
            this.btnRebuildCacheFromArchive.Click += new System.EventHandler(this.btnRebuildCacheFromArchive_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox3.Controls.Add(this.tabControl1);
            this.groupBox3.Location = new System.Drawing.Point(10, 645);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(676, 164);
            this.groupBox3.TabIndex = 54;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Job Control";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(3, 16);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(670, 145);
            this.tabControl1.TabIndex = 43;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage1.Controls.Add(this.btnIterativeOnDemandLoad);
            this.tabPage1.Controls.Add(this.btnOnDemandLoad);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(662, 119);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "On Demand";
            // 
            // btnIterativeOnDemandLoad
            // 
            this.btnIterativeOnDemandLoad.Location = new System.Drawing.Point(330, 64);
            this.btnIterativeOnDemandLoad.Name = "btnIterativeOnDemandLoad";
            this.btnIterativeOnDemandLoad.Size = new System.Drawing.Size(165, 23);
            this.btnIterativeOnDemandLoad.TabIndex = 50;
            this.btnIterativeOnDemandLoad.Text = "Iterative On Demand Load";
            this.btnIterativeOnDemandLoad.UseVisualStyleBackColor = true;
            this.btnIterativeOnDemandLoad.Click += new System.EventHandler(this.btnIterativeOnDemandLoad_Click);
            // 
            // btnOnDemandLoad
            // 
            this.btnOnDemandLoad.Enabled = false;
            this.btnOnDemandLoad.Location = new System.Drawing.Point(127, 64);
            this.btnOnDemandLoad.Name = "btnOnDemandLoad";
            this.btnOnDemandLoad.Size = new System.Drawing.Size(137, 23);
            this.btnOnDemandLoad.TabIndex = 49;
            this.btnOnDemandLoad.Text = "Start On Demand Load";
            this.btnOnDemandLoad.UseVisualStyleBackColor = true;
            this.btnOnDemandLoad.Click += new System.EventHandler(this.btnOnDemandLoad_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage2.Controls.Add(this.ddLoadSchedule);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.btnLoadDataset);
            this.tabPage2.Controls.Add(this.udDaysPerJob);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.btnStartSingleThreadedLoad);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(662, 119);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Scheduled";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage3.Controls.Add(this.btnStartMultiThreadedLoad);
            this.tabPage3.Controls.Add(this.label7);
            this.tabPage3.Controls.Add(this.tbMaxNumJobsPerStage);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(662, 119);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Multi-threaded";
            // 
            // btnStartMultiThreadedLoad
            // 
            this.btnStartMultiThreadedLoad.Enabled = false;
            this.btnStartMultiThreadedLoad.Location = new System.Drawing.Point(327, 58);
            this.btnStartMultiThreadedLoad.Name = "btnStartMultiThreadedLoad";
            this.btnStartMultiThreadedLoad.Size = new System.Drawing.Size(254, 23);
            this.btnStartMultiThreadedLoad.TabIndex = 52;
            this.btnStartMultiThreadedLoad.Text = "Iterative Multi-Job Load (DO NOT USE!)";
            this.btnStartMultiThreadedLoad.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(87, 61);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(177, 13);
            this.label7.TabIndex = 50;
            this.label7.Text = "Maximum Number of Jobs per Stage";
            // 
            // tbMaxNumJobsPerStage
            // 
            this.tbMaxNumJobsPerStage.Location = new System.Drawing.Point(270, 58);
            this.tbMaxNumJobsPerStage.Multiline = true;
            this.tbMaxNumJobsPerStage.Name = "tbMaxNumJobsPerStage";
            this.tbMaxNumJobsPerStage.Size = new System.Drawing.Size(34, 20);
            this.tbMaxNumJobsPerStage.TabIndex = 51;
            this.tbMaxNumJobsPerStage.Text = "1";
            // 
            // btnStopLoad
            // 
            this.btnStopLoad.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnStopLoad.Location = new System.Drawing.Point(163, 815);
            this.btnStopLoad.Name = "btnStopLoad";
            this.btnStopLoad.Size = new System.Drawing.Size(117, 23);
            this.btnStopLoad.TabIndex = 53;
            this.btnStopLoad.Text = "Stop Load";
            this.btnStopLoad.UseVisualStyleBackColor = true;
            this.btnStopLoad.Click += new System.EventHandler(this.btnStopLoad_Click);
            // 
            // tbFilter
            // 
            this.tbFilter.Location = new System.Drawing.Point(156, 36);
            this.tbFilter.Name = "tbFilter";
            this.tbFilter.Size = new System.Drawing.Size(358, 20);
            this.tbFilter.TabIndex = 52;
            this.tbFilter.TextChanged += new System.EventHandler(this.tbFilter_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(111, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 13);
            this.label1.TabIndex = 51;
            this.label1.Text = "Filter";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnOneOffLoad);
            this.groupBox1.Location = new System.Drawing.Point(9, 68);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(171, 53);
            this.groupBox1.TabIndex = 49;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "One Off Loads";
            // 
            // btnOneOffLoad
            // 
            this.btnOneOffLoad.Location = new System.Drawing.Point(6, 25);
            this.btnOneOffLoad.Name = "btnOneOffLoad";
            this.btnOneOffLoad.Size = new System.Drawing.Size(148, 23);
            this.btnOneOffLoad.TabIndex = 9;
            this.btnOneOffLoad.Text = "Bulk Insert...";
            this.btnOneOffLoad.UseVisualStyleBackColor = true;
            this.btnOneOffLoad.Click += new System.EventHandler(this.btnOneOffLoad_Click);
            // 
            // customDataProviderUI
            // 
            this.customDataProviderUI.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.customDataProviderUI.Location = new System.Drawing.Point(9, 131);
            this.customDataProviderUI.LocationOfFlatFiles = null;
            this.customDataProviderUI.Name = "customDataProviderUI";
            this.customDataProviderUI.Size = new System.Drawing.Size(677, 130);
            this.customDataProviderUI.TabIndex = 47;
            // 
            // loadProgressUI1
            // 
            this.loadProgressUI1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.loadProgressUI1.Location = new System.Drawing.Point(0, 0);
            this.loadProgressUI1.Name = "loadProgressUI1";
            this.loadProgressUI1.Size = new System.Drawing.Size(708, 841);
            this.loadProgressUI1.TabIndex = 42;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.databaseToolStripMenuItem,
            this.testsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1409, 24);
            this.menuStrip1.TabIndex = 56;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // databaseToolStripMenuItem
            // 
            this.databaseToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.changeCatalogueToolStripMenuItem,
            this.refreshToolStripMenuItem});
            this.databaseToolStripMenuItem.Name = "databaseToolStripMenuItem";
            this.databaseToolStripMenuItem.Size = new System.Drawing.Size(70, 20);
            this.databaseToolStripMenuItem.Text = "Locations";
            // 
            // changeCatalogueToolStripMenuItem
            // 
            this.changeCatalogueToolStripMenuItem.Name = "changeCatalogueToolStripMenuItem";
            this.changeCatalogueToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.changeCatalogueToolStripMenuItem.Text = "Change Platform Databases...";
            this.changeCatalogueToolStripMenuItem.Click += new System.EventHandler(this.changeCatalogueToolStripMenuItem_Click);
            // 
            // refreshToolStripMenuItem
            // 
            this.refreshToolStripMenuItem.Name = "refreshToolStripMenuItem";
            this.refreshToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.refreshToolStripMenuItem.Text = "Refresh";
            this.refreshToolStripMenuItem.Click += new System.EventHandler(this.refreshToolStripMenuItem_Click);
            // 
            // testsToolStripMenuItem
            // 
            this.testsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.launchDiagnosticsScreenToolStripMenuItem,
            this.showPerformanceCounterToolStripMenuItem});
            this.testsToolStripMenuItem.Name = "testsToolStripMenuItem";
            this.testsToolStripMenuItem.Size = new System.Drawing.Size(80, 20);
            this.testsToolStripMenuItem.Text = "Diagnostics";
            // 
            // launchDiagnosticsScreenToolStripMenuItem
            // 
            this.launchDiagnosticsScreenToolStripMenuItem.Name = "launchDiagnosticsScreenToolStripMenuItem";
            this.launchDiagnosticsScreenToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.launchDiagnosticsScreenToolStripMenuItem.Text = "Launch Diagnostics Screen...";
            this.launchDiagnosticsScreenToolStripMenuItem.Click += new System.EventHandler(this.launchDiagnosticsScreenToolStripMenuItem_Click);
            // 
            // showPerformanceCounterToolStripMenuItem
            // 
            this.showPerformanceCounterToolStripMenuItem.Name = "showPerformanceCounterToolStripMenuItem";
            this.showPerformanceCounterToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.showPerformanceCounterToolStripMenuItem.Text = "Show Performance Counter...";
            this.showPerformanceCounterToolStripMenuItem.Click += new System.EventHandler(this.showPerformanceCounterToolStripMenuItem_Click);
            // 
            // DatasetLoader
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1409, 872);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.splitContainer1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "DatasetLoader";
            this.Text = "Dataset Loader";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.DatasetLoader_FormClosing);
            this.gbLoadChecks.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.gbLoadServers.ResumeLayout(false);
            this.gbLoadServers.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.udDaysPerJob)).EndInit();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbxLoadMetadata;
        private System.Windows.Forms.Button btnLoadDataset;
        private System.Windows.Forms.OpenFileDialog dlgFilePicker;
        private System.Windows.Forms.Button btnShowDatasetFolder;
        private System.Windows.Forms.GroupBox gbLoadChecks;
        private System.Windows.Forms.CheckBox cbSkipArchiving;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnViewLoadMetadata;
        private System.Windows.Forms.GroupBox gbLoadServers;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox tbRawServer;
        private System.Windows.Forms.Label label13;
        private ProgressUI loadProgressUI1;
        private System.Windows.Forms.CheckBox cbMigrateStagingToLive;
        private System.Windows.Forms.CheckBox cbMigrateRAWToStaging;
        private System.Windows.Forms.Button btnStartSingleThreadedLoad;
        private System.Windows.Forms.Button btnAbortLoad;
        private ChecksUI dataLoadEntireSystemStateCheckerUI1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown udDaysPerJob;
        private CustomDataProviderUI customDataProviderUI;
        private System.Windows.Forms.ComboBox ddLoadSchedule;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnOnDemandLoad;
        private System.Windows.Forms.Button btnRerunChecks;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem databaseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem changeCatalogueToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem testsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem launchDiagnosticsScreenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showPerformanceCounterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem refreshToolStripMenuItem;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnOneOffLoad;
        private System.Windows.Forms.TextBox tbFilter;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnIterativeOnDemandLoad;
        private System.Windows.Forms.Button btnStopLoad;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button btnStartMultiThreadedLoad;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tbMaxNumJobsPerStage;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnRebuildCacheFromArchive;
    }
}


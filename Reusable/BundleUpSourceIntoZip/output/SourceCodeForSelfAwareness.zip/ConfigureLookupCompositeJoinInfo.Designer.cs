using System.Windows.Forms; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved

namespace CatalogueManager.ExtractionUIs
{
    partial class ConfigureLookupCompositeJoinInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbCollate_Latin1_General_BIN = new System.Windows.Forms.CheckBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.cbxPrimaryKey = new System.Windows.Forms.ComboBox();
            this.cbxForeignKey = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pPreview = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.lbCompositeLookups = new System.Windows.Forms.ListBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.tbID = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // cbCollate_Latin1_General_BIN
            // 
            this.cbCollate_Latin1_General_BIN.AutoSize = true;
            this.cbCollate_Latin1_General_BIN.Checked = true;
            this.cbCollate_Latin1_General_BIN.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbCollate_Latin1_General_BIN.Location = new System.Drawing.Point(80, 81);
            this.cbCollate_Latin1_General_BIN.Name = "cbCollate_Latin1_General_BIN";
            this.cbCollate_Latin1_General_BIN.Size = new System.Drawing.Size(157, 17);
            this.cbCollate_Latin1_General_BIN.TabIndex = 18;
            this.cbCollate_Latin1_General_BIN.Text = "Collate Latin1_General_BIN";
            this.cbCollate_Latin1_General_BIN.UseVisualStyleBackColor = true;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(80, 104);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 17;
            this.btnAdd.Text = "Add As New";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // cbxPrimaryKey
            // 
            this.cbxPrimaryKey.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cbxPrimaryKey.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cbxPrimaryKey.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cbxPrimaryKey.Location = new System.Drawing.Point(80, 55);
            this.cbxPrimaryKey.Name = "cbxPrimaryKey";
            this.cbxPrimaryKey.Size = new System.Drawing.Size(535, 21);
            this.cbxPrimaryKey.TabIndex = 16;
            // 
            // cbxForeignKey
            // 
            this.cbxForeignKey.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cbxForeignKey.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cbxForeignKey.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cbxForeignKey.Location = new System.Drawing.Point(80, 32);
            this.cbxForeignKey.Name = "cbxForeignKey";
            this.cbxForeignKey.Size = new System.Drawing.Size(535, 21);
            this.cbxForeignKey.TabIndex = 15;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 13);
            this.label2.TabIndex = 13;
            this.label2.Text = "Foreign Key:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 58);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 13);
            this.label3.TabIndex = 14;
            this.label3.Text = "Primary Key:";
            // 
            // pPreview
            // 
            this.pPreview.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pPreview.Location = new System.Drawing.Point(8, 354);
            this.pPreview.Name = "pPreview";
            this.pPreview.Size = new System.Drawing.Size(1209, 228);
            this.pPreview.TabIndex = 19;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 336);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 13);
            this.label1.TabIndex = 20;
            this.label1.Text = "Preview:";
            // 
            // lbCompositeLookups
            // 
            this.lbCompositeLookups.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbCompositeLookups.FormattingEnabled = true;
            this.lbCompositeLookups.Location = new System.Drawing.Point(621, 32);
            this.lbCompositeLookups.Name = "lbCompositeLookups";
            this.lbCompositeLookups.Size = new System.Drawing.Size(596, 290);
            this.lbCompositeLookups.TabIndex = 21;
            this.lbCompositeLookups.SelectedIndexChanged += new System.EventHandler(this.lbCompositeLookups_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(614, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(98, 13);
            this.label4.TabIndex = 22;
            this.label4.Text = "Current Composites";
            // 
            // btnSave
            // 
            this.btnSave.Enabled = false;
            this.btnSave.Location = new System.Drawing.Point(162, 104);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 23;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnDelete.Location = new System.Drawing.Point(621, 325);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 24;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(52, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(21, 13);
            this.label5.TabIndex = 25;
            this.label5.Text = "ID:";
            // 
            // tbID
            // 
            this.tbID.Location = new System.Drawing.Point(79, 6);
            this.tbID.Name = "tbID";
            this.tbID.ReadOnly = true;
            this.tbID.Size = new System.Drawing.Size(123, 20);
            this.tbID.TabIndex = 26;
            // 
            // ConfigureLookupCompositeJoinInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1229, 594);
            this.Controls.Add(this.tbID);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lbCompositeLookups);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pPreview);
            this.Controls.Add(this.cbCollate_Latin1_General_BIN);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.cbxPrimaryKey);
            this.Controls.Add(this.cbxForeignKey);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Name = "ConfigureLookupCompositeJoinInfo";
            this.Text = "ConfigureLookupCompositeJoinInfo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox cbCollate_Latin1_General_BIN;
        private System.Windows.Forms.Button btnAdd;
        private ComboBox cbxPrimaryKey;
        private ComboBox cbxForeignKey;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel pPreview;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox lbCompositeLookups;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbID;
    }
}

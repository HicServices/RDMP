using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.ComponentModel;
using System.Linq;
using System.Windows.Forms;
using CatalogueLibrary.Data;
using CatalogueManager.TestsAndSetup.ServicePropogation;
using ReusableUIComponents;

namespace Dashboard.Overview
{
    /// <summary>
    /// Lists all the errors encountered by the automation service which loads all automated loads (See LoadPeriodicallyUI).  If there are records appearing in this control then you should
    /// go check on the automation process to see if it is still running and then investigate the failing loads manually in Dataset Loader application.
    /// </summary>
    public partial class DLEWindowsServiceExceptionsListUI : RDMPUserControl
    {
        public DLEWindowsServiceExceptionsListUI()
        {
            InitializeComponent();

        }

        protected override void OnLoad(EventArgs e)
        {
            if(VisualStudioDesignMode)
                return;

            try
            {
                
                //create list of unexplained exceptions
                DLEWindowsServiceException[] dleWindowsServiceExceptions = 
                    RepositoryLocator.CatalogueRepository.GetAllObjects<DLEWindowsServiceException>()//all exceptions
                    .Where(s => string.IsNullOrWhiteSpace(s.Explanation)).ToArray();//which have a blank explanation

                if (dleWindowsServiceExceptions.Length == 0)
                {
                    //if no errors just return (but show label)
                    lblNoErrors.Visible = true;
                    return;
                }

                tableLayoutPanel1.RowCount = dleWindowsServiceExceptions.Length;

                for (int i = 0; i < dleWindowsServiceExceptions.Length; i++)
                {
                    var c = new DLEWindowsServiceExceptionUI(dleWindowsServiceExceptions[i]);
                    c.Dock = DockStyle.Fill;
                    tableLayoutPanel1.Controls.Add(c, i, 0);
                }

                for (int i = 0; i < tableLayoutPanel1.RowStyles.Count; i++)
                    tableLayoutPanel1.RowStyles[i].SizeType = SizeType.AutoSize;
            }
            catch (Exception ex)
            {
                ExceptionViewer.Show(this.GetType().Name + " failed to load data", ex);
            }

            base.OnLoad(e);
        }
    }
}

using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using CatalogueLibrary.Data;
using MapsDirectlyToDatabaseTable;
using QuerySyntaxHelper = CatalogueLibrary.DataHelper.QuerySyntaxHelper;

namespace DataExportManager2Library.Data.DataTables
{
    public class DeployedExtractionFilterParameter: VersionedDatabaseEntity, ISqlParameter
    {
        #region Database Fields and support fields (max length, update etc)
        public int ExtractionFilter_ID { get; set; }// changing this is required for cloning functionality i.e. clone parameter then point it to new parent

        public string ParameterSQL { get; set; }
        public string Value { get; set; }
        public string Comment { get; set; }

        public static int ParameterSQL_MaxLength = -1;
        public static int Value_MaxLength = -1;
        #endregion

        //extracts the name ofthe parameter from the SQL
        [NoMappingToDatabase]
        public string ParameterName
        {
            get { return QuerySyntaxHelper.GetParameterNameFromDeclarationSQL(ParameterSQL); }
        }

        public DeployedExtractionFilterParameter(IRepository repository, string parameterSQL, IFilter parent)
        {
            Repository = repository;

            if (!QuerySyntaxHelper.IsValidParameterName(parameterSQL))
                throw new ArgumentException("parameterSQL is not valid \"" + parameterSQL + "\"");

            Repository.InsertAndHydrate(this, new Dictionary<string, object>
            {
                {"ParameterSQL", parameterSQL},
                {"ExtractionFilter_ID", parent.ID}
            });
        }

        public DeployedExtractionFilterParameter(IRepository repository, DbDataReader r) : base(repository, r)
        {
            ExtractionFilter_ID = int.Parse(r["ExtractionFilter_ID"].ToString());
            ParameterSQL = r["ParameterSQL"] as string;
            Value = r["Value"] as string;
            Comment = r["Comment"] as string;
        }
       
        public DeployedExtractionFilterParameter[] GetAllDeployedExtractionFilterParametersFor(IFilter extractionFilter)
        {
            // todo: check this has the same effect as the commented out code!
            return Repository.GetAllObjects<DeployedExtractionFilterParameter>(
                    "SELECT * FROM DeployedExtractionFilterParameter WHERE ExtractionFilter_ID=" + extractionFilter.ID)
                    .ToArray();
        }

        public override string ToString()
        {
            //return the name of the variable
            return ParameterName;
        }
    }
}

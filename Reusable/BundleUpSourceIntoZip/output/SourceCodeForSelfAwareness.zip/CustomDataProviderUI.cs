using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using CatalogueLibrary;
using DataLoadEngine.DataProvider;
using LoadModules.Generic.DataProvider;

namespace DatasetLoaderUI
{
    public partial class CustomDataProviderUI : UserControl
    {
        public IDataProvider DataProvider { get; private set; }
        public string LocationOfFlatFiles { get; set; }
        public List<IDataProvider> LoadQueue { get; private set; }

        public CustomDataProviderUI()
        {
            InitializeComponent();

            LoadQueue = new List<IDataProvider>();
        }

        public bool IsCustomProviderIndicated()
        {
            return cbUseCustomDataSource.Checked;
        }

        public bool IsCustomProviderSpecified()
        {
            return (rbSingleDataSource.Checked && DataProvider != null) || (rbMultiDataSource.Checked && LoadQueue.Any());
        }

        public bool IsSingleDataProvider()
        {
            return rbSingleDataSource.Checked;
        }

        public bool IsMultiDataProvider()
        {
            return rbMultiDataSource.Checked;
        }

        private void rbSingleDataSource_CheckedChanged(object sender, EventArgs e)
        {
            ddDataProvider.Enabled = true;
            btnConfigureDataProvider.Enabled = true;
            btnConfigureLoadQueue.Enabled = false;
        }

        private void rbMultiDataSource_CheckedChanged(object sender, EventArgs e)
        {
            ddDataProvider.Enabled = false;
            btnConfigureDataProvider.Enabled = false;
            btnConfigureLoadQueue.Enabled = true;
        }

        private void btnConfigureDataProvider_Click(object sender, EventArgs e)
        {
            var selectedDataProvider = ddDataProvider.SelectedItem as string;
            var dpControl = CreateDataProviderConfigurationControl(selectedDataProvider);

            if (dpControl == null)
            {
                DataProvider = new DoNothingDataProvider();
                return;
            }

            var dpDialog = new DataProviderDialog();

            if (dpControl.MinimumSize.Width > dpDialog.Width)
            {
                dpControl.Width = dpControl.MinimumSize.Width;
                dpDialog.Width = dpControl.MinimumSize.Width + 20;
            }
            else
            {
                dpControl.Width = dpDialog.Width - 20;
            }

            dpDialog.Height = dpDialog.Height + dpControl.MinimumSize.Height;

            dpDialog.MinimumSize = new Size(dpDialog.Width, dpDialog.Height);

            dpControl.Location = new Point(0, 0);
            dpControl.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            dpDialog.Controls.Add(dpControl);

            dpDialog.OnSaveDialog = (userControl, dialog) =>
            {
                DataProvider = userControl.DataProvider;
                dialog.Close();
            };

            dpDialog.StartPosition = FormStartPosition.CenterParent;
            dpDialog.ShowDialog();
        }

        private UserControl CreateDataProviderConfigurationControl(string selectedDataProvider)
        {
            DataProviderConfigurationControl control;

            if (selectedDataProvider == "File")
                control = new FileProviderConfiguration();
            else if (selectedDataProvider == "Archive File")
                control = new ArchiveFileProviderConfiguration();
            else if (selectedDataProvider.StartsWith("None"))
            {
                return null;
            }
            else throw new NotSupportedException();

            control.DataProvider = DataProvider;

            var hicProjectDirectory = new HICProjectDirectory(LocationOfFlatFiles, false);
            control.DestPath = hicProjectDirectory.ForLoading.FullName;

            return control;
        }

        private void cbDataProvider_SelectedIndexChanged(object sender, EventArgs e)
        {
            var item = ddDataProvider.SelectedItem as string;
            if (item == null) return;

            btnConfigureDataProvider.Enabled = true;

            if (item == "File")
                DataProvider = new FileProvider("", "");
            else if (item == "Archive File")
                DataProvider = new ArchiveFileProvider("", "");
            else if (item.StartsWith("None"))
                DataProvider = new DoNothingDataProvider();
        }

        private void cbUseCustomDataSource_CheckedChanged(object sender, EventArgs e)
        {
            gbDataSource.Enabled = cbUseCustomDataSource.Checked;

            if (!cbUseCustomDataSource.Checked)
                DataProvider = null;
        }

        private void btnConfigureLoadQueue_Click(object sender, EventArgs e)
        {
            var loadQueueConfig = new LoadQueueConfiguration();
            loadQueueConfig.DestPath = Path.Combine(LocationOfFlatFiles, "forLoading");
            loadQueueConfig.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
            loadQueueConfig.LoadQueue = LoadQueue;

            var form = new Form();
            form.StartPosition = FormStartPosition.CenterParent;
            form.Width = loadQueueConfig.MinimumSize.Width + (SystemInformation.FrameBorderSize.Width * 5);
            form.Height = loadQueueConfig.MinimumSize.Height + (SystemInformation.FrameBorderSize.Height * 5) + SystemInformation.CaptionHeight;
            form.MinimumSize = form.Size;

            form.Controls.Add(loadQueueConfig);
            form.ShowDialog();

            LoadQueue = loadQueueConfig.LoadQueue;
        }
    }
}

using DataExportManager2.CohortUI; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using DataExportManager2.ProjectUI;

namespace DataExportManager2
{
    partial class DataExportManagerMainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DataExportManagerMainForm));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tpCohortManagement = new System.Windows.Forms.TabPage();
            this.cohortManagement1 = new DataExportManager2.CohortUI.ExtractableCohortManagementUI();
            this.tpDataSetManagement = new System.Windows.Forms.TabPage();
            this.dataSetManagementUI1 = new DataExportManager2.DataSetUI.DataSetManagementUI();
            this.tpProjects = new System.Windows.Forms.TabPage();
            this.projectManagementUI1 = new DataExportManager2.ProjectUI.ProjectManagementUI();
            this.databaseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.changeCatalogueConnectionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.refreshAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.configurationPropertiesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.setHashingAlgorithmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.setReleaseDocumentDisclaimerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.diagnosticsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.launchDiagnosticsScreenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.tabControl1.SuspendLayout();
            this.tpCohortManagement.SuspendLayout();
            this.tpDataSetManagement.SuspendLayout();
            this.tpProjects.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tpCohortManagement);
            this.tabControl1.Controls.Add(this.tpDataSetManagement);
            this.tabControl1.Controls.Add(this.tpProjects);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 24);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1205, 720);
            this.tabControl1.TabIndex = 0;
            // 
            // tpCohortManagement
            // 
            this.tpCohortManagement.Controls.Add(this.cohortManagement1);
            this.tpCohortManagement.Location = new System.Drawing.Point(4, 22);
            this.tpCohortManagement.Name = "tpCohortManagement";
            this.tpCohortManagement.Padding = new System.Windows.Forms.Padding(3);
            this.tpCohortManagement.Size = new System.Drawing.Size(1197, 694);
            this.tpCohortManagement.TabIndex = 0;
            this.tpCohortManagement.Text = "Cohort Management";
            this.tpCohortManagement.UseVisualStyleBackColor = true;
            // 
            // cohortManagement1
            // 
            this.cohortManagement1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cohortManagement1.Location = new System.Drawing.Point(3, 3);
            this.cohortManagement1.Name = "cohortManagement1";
            this.cohortManagement1.Size = new System.Drawing.Size(1191, 688);
            this.cohortManagement1.TabIndex = 0;
            // 
            // tpDataSetManagement
            // 
            this.tpDataSetManagement.Controls.Add(this.dataSetManagementUI1);
            this.tpDataSetManagement.Location = new System.Drawing.Point(4, 22);
            this.tpDataSetManagement.Name = "tpDataSetManagement";
            this.tpDataSetManagement.Padding = new System.Windows.Forms.Padding(3);
            this.tpDataSetManagement.Size = new System.Drawing.Size(1197, 694);
            this.tpDataSetManagement.TabIndex = 1;
            this.tpDataSetManagement.Text = "DataSet Management";
            this.tpDataSetManagement.UseVisualStyleBackColor = true;
            // 
            // dataSetManagementUI1
            // 
            this.dataSetManagementUI1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataSetManagementUI1.Location = new System.Drawing.Point(3, 3);
            this.dataSetManagementUI1.Name = "dataSetManagementUI1";
            this.dataSetManagementUI1.Size = new System.Drawing.Size(1191, 688);
            this.dataSetManagementUI1.TabIndex = 0;
            // 
            // tpProjects
            // 
            this.tpProjects.Controls.Add(this.projectManagementUI1);
            this.tpProjects.Location = new System.Drawing.Point(4, 22);
            this.tpProjects.Name = "tpProjects";
            this.tpProjects.Padding = new System.Windows.Forms.Padding(3);
            this.tpProjects.Size = new System.Drawing.Size(1197, 694);
            this.tpProjects.TabIndex = 2;
            this.tpProjects.Text = "Data Export Projects";
            this.tpProjects.UseVisualStyleBackColor = true;
            // 
            // projectManagementUI1
            // 
            this.projectManagementUI1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.projectManagementUI1.Location = new System.Drawing.Point(3, 3);
            this.projectManagementUI1.Name = "projectManagementUI1";
            this.projectManagementUI1.Size = new System.Drawing.Size(1191, 688);
            this.projectManagementUI1.TabIndex = 0;
            // 
            // databaseToolStripMenuItem
            // 
            this.databaseToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.changeCatalogueConnectionToolStripMenuItem,
            this.refreshAllToolStripMenuItem,
            this.configurationPropertiesToolStripMenuItem});
            this.databaseToolStripMenuItem.Name = "databaseToolStripMenuItem";
            this.databaseToolStripMenuItem.Size = new System.Drawing.Size(67, 20);
            this.databaseToolStripMenuItem.Text = "Database";
            // 
            // changeCatalogueConnectionToolStripMenuItem
            // 
            this.changeCatalogueConnectionToolStripMenuItem.Name = "changeCatalogueConnectionToolStripMenuItem";
            this.changeCatalogueConnectionToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.changeCatalogueConnectionToolStripMenuItem.Text = "Change Platform Databases...";
            this.changeCatalogueConnectionToolStripMenuItem.Click += new System.EventHandler(this.changeCatalogueConnectionToolStripMenuItem_Click);
            // 
            // refreshAllToolStripMenuItem
            // 
            this.refreshAllToolStripMenuItem.Name = "refreshAllToolStripMenuItem";
            this.refreshAllToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.refreshAllToolStripMenuItem.Text = "Refresh All";
            this.refreshAllToolStripMenuItem.Click += new System.EventHandler(this.refreshAllToolStripMenuItem_Click);
            // 
            // configurationPropertiesToolStripMenuItem
            // 
            this.configurationPropertiesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.setHashingAlgorithmToolStripMenuItem,
            this.setReleaseDocumentDisclaimerToolStripMenuItem});
            this.configurationPropertiesToolStripMenuItem.Name = "configurationPropertiesToolStripMenuItem";
            this.configurationPropertiesToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.configurationPropertiesToolStripMenuItem.Text = "ConfigurationProperties";
            // 
            // setHashingAlgorithmToolStripMenuItem
            // 
            this.setHashingAlgorithmToolStripMenuItem.Name = "setHashingAlgorithmToolStripMenuItem";
            this.setHashingAlgorithmToolStripMenuItem.Size = new System.Drawing.Size(258, 22);
            this.setHashingAlgorithmToolStripMenuItem.Text = "Set Hashing Algorithm...";
            this.setHashingAlgorithmToolStripMenuItem.Click += new System.EventHandler(this.setHashingAlgorithmToolStripMenuItem_Click);
            // 
            // setReleaseDocumentDisclaimerToolStripMenuItem
            // 
            this.setReleaseDocumentDisclaimerToolStripMenuItem.Name = "setReleaseDocumentDisclaimerToolStripMenuItem";
            this.setReleaseDocumentDisclaimerToolStripMenuItem.Size = new System.Drawing.Size(258, 22);
            this.setReleaseDocumentDisclaimerToolStripMenuItem.Text = "Set Release Document Disclaimer...";
            this.setReleaseDocumentDisclaimerToolStripMenuItem.Click += new System.EventHandler(this.setReleaseDocumentDisclaimerToolStripMenuItem_Click);
            // 
            // diagnosticsToolStripMenuItem
            // 
            this.diagnosticsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.launchDiagnosticsScreenToolStripMenuItem});
            this.diagnosticsToolStripMenuItem.Name = "diagnosticsToolStripMenuItem";
            this.diagnosticsToolStripMenuItem.Size = new System.Drawing.Size(80, 20);
            this.diagnosticsToolStripMenuItem.Text = "Diagnostics";
            // 
            // launchDiagnosticsScreenToolStripMenuItem
            // 
            this.launchDiagnosticsScreenToolStripMenuItem.Name = "launchDiagnosticsScreenToolStripMenuItem";
            this.launchDiagnosticsScreenToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.launchDiagnosticsScreenToolStripMenuItem.Text = "Launch Diagnostics Screen...";
            this.launchDiagnosticsScreenToolStripMenuItem.Click += new System.EventHandler(this.launchDiagnosticsScreenToolStripMenuItem_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.databaseToolStripMenuItem,
            this.diagnosticsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1205, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1205, 744);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Data Export Manager";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.tabControl1.ResumeLayout(false);
            this.tpCohortManagement.ResumeLayout(false);
            this.tpDataSetManagement.ResumeLayout(false);
            this.tpProjects.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tpCohortManagement;
        private System.Windows.Forms.TabPage tpDataSetManagement;
        private ExtractableCohortManagementUI cohortManagement1;
        private DataSetUI.DataSetManagementUI dataSetManagementUI1;
        private System.Windows.Forms.TabPage tpProjects;
        private ProjectManagementUI projectManagementUI1;
        private System.Windows.Forms.ToolStripMenuItem databaseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem changeCatalogueConnectionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem diagnosticsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem launchDiagnosticsScreenToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem refreshAllToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem configurationPropertiesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem setReleaseDocumentDisclaimerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem setHashingAlgorithmToolStripMenuItem;
    }
}


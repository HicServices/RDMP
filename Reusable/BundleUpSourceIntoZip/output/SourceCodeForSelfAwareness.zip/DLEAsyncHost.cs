using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Threading;
using CatalogueLibrary;
using CatalogueLibrary.Data;
using CatalogueLibrary.Data.DataLoad;
using CatalogueLibrary.DataFlowPipeline;
using DataLoadEngine.Checks.Checkers;
using DataLoadEngine.LoadProcess;
using HIC.Logging;
using RDMPStartup;
using ReusableLibraryCode.Checks;
using ReusableLibraryCode.Progress;

namespace DLEWindowsService
{
    class DLEAsyncHost : ICheckNotifier, IDataLoadEventListener
    {
        private readonly RegistryRepositoryFinder _repositoryFinder;
        private bool _sleeping = false;

        public bool Stop
        {
            get { return _stop; }
            set
            {
                _stop = value;

                if (t != null && _stop && _sleeping)
                    t.Interrupt();//prevent it sleeping if it is, since it is time to stop
            }
        }

        Thread t;
        private bool _stop;

        public void Start()
        {
            Stop = false;

            t = new Thread(Run);
            t.Start();
        }
        
        LoadMetadata _loadMetadata = null;

        public DLEAsyncHost(RegistryRepositoryFinder repositoryFinder)
        {
            _repositoryFinder = repositoryFinder;
        }

        private void Run()
        {
            
            try
            {
                while (!Stop)
                {

                    //refresh list of push jobs
                    var dueLoads = _repositoryFinder.CatalogueRepository.GetAllObjects<LoadPeriodically>();

                    foreach (LoadPeriodically dueLoad in dueLoads)
                    {
                        if (Stop)
                            break;

                        //if it is not due, do not load it
                        if (!dueLoad.IsLoadDue())
                            continue;

                         _loadMetadata = dueLoad.LoadMetadata;

                        //load the main thing
                        LaunchLoad(_loadMetadata,dueLoad);

                    }

                    if(Stop)
                        return;

                    try
                    {
                        _sleeping = true;

                        //sleep a bit
                        Thread.Sleep(10000);
                    }
                    finally
                    {
                        _sleeping = false;
                    }
                }
            }
            catch (ThreadAbortException)
            {
                return;
            }
            catch (ThreadInterruptedException)
            {
                return;
            }
            catch (Exception e)
            {
                if (_loadMetadata != null)
                {
                    new DLEWindowsServiceException(_repositoryFinder.CatalogueRepository, e, _loadMetadata);
                    Environment.Exit(999);
                }
                else
                    throw;
            }
        }

        private void LaunchLoad(LoadMetadata loadMetadata, LoadPeriodically dueLoad)
        {
            _loadMetadata = loadMetadata;

            PreExecutionChecker p = new PreExecutionChecker(_loadMetadata,null);
            p.Check(this);

            var logManager = new LogManager(_loadMetadata.GetDistinctLoggingDatabaseSettings(false),
                ProgressLogging.GetInstance(), FatalErrorLogging.GetInstance(), RowErrorLogging.GetInstance());

            var _dataLoadProcess = new OnDemandDataLoadProcess(_loadMetadata, this, logManager);
            var exitCode = _dataLoadProcess.Run(new GracefulCancellationToken());

            if (dueLoad != null)
            {
                //load completed so save
                dueLoad.LastLoaded = DateTime.Now;
                dueLoad.SaveToDatabase();

                //there is another LoadMetadata to get launched after this one
                if (dueLoad.OnSuccessLaunchLoadMetadata_ID != null && exitCode == ExitCodeType.Success)
                {
                    LoadMetadata chainLoad = dueLoad.OnSuccessLaunchLoadMetadata;
                    LoadPeriodically chainLoadPeriodically = chainLoad.LoadPeriodically;

                    LaunchLoad(chainLoad, chainLoadPeriodically);
                }
            }


            
        }

        public bool OnCheckPerformed(CheckEventArgs args)
        {

            //if there is a proposed fix then accept it regardless of whether it was a Fail.
            if (!string.IsNullOrWhiteSpace(args.ProposedFix))
                return true;

            if (args.Result == CheckResult.Fail)
                throw new Exception("Failed check with message: " + args.Message, args.Ex);

            return true;
        }

        public void OnNotify(object sender, NotifyEventArgs e)
        {
            if (e.ProgressEventType == ProgressEventType.Error)
                new DLEWindowsServiceException(_repositoryFinder.CatalogueRepository,e.Exception ?? new Exception("Error reported to OnNotify" + e.Message), _loadMetadata);

            Console.WriteLine(sender + " sent message:" + e.Message);
        }
        
        public void OnProgress(object sender, ProgressEventArgs e)
        {
            
        }
    }
}

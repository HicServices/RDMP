using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Windows.Forms;

namespace ReusableUIComponents
{
    public class BetterToolTipForm: Form
    {
        public BetterToolTip BetterToolTip { get; set; }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            
            BetterToolTip = new BetterToolTip(this);

        }
    }
}

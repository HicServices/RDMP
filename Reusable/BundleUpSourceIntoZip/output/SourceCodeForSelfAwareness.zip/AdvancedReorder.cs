using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using CatalogueLibrary.Data;
using CatalogueLibrary.Repositories;
using MapsDirectlyToDatabaseTable;
using ReusableLibraryCode;
using ReusableUIComponents;


namespace CatalogueManager.ExtractionUIs
{
    /// <summary>
    /// This form allows partial or complete reordering of a datasets columns based on a list of column names
    /// pasted into the Desired Order listbox.  All items are cleaned such that the user should be able to paste in
    /// a list, the middle section of a SELECT statement or pretty much anything else.
    /// 
    /// Once a desired order is entered the class will attempt to find the first item in the desired order.  Assuming
    /// this item is found then the location of this field becomes the 'insertion' point for reordering and all fields 
    /// that the user pasted in are reordered into this point.
    /// 
    /// At any time you can look at the 'New Order' section to see the new order that columns will be in if you accept the
    /// reordering.
    /// 
    /// </summary>
    public partial class AdvancedReorder : BetterToolTipForm
    {
        private readonly Catalogue _catalogue;

        //the item in the original order that we want to start reordering at
        private int currentOrderStartReorderAtIndex = -1;

        /// <summary>
        /// This is a collection of all the items found in the desired order and thier ofset in the desired order relative to the first one
        /// </summary>
        private List<ExtractionInformation> itemsToReOrderAndOffsetRelativeToFirst;

        List<int> desiredColumnIndexesNotFound;
        private int indexOfStartOfReordingInNewOrderListbox;

        public AdvancedReorder(Catalogue catalogue)
        {
            _catalogue = catalogue;

            InitializeComponent();

            if (_catalogue == null)
                return;
            
            RefreshUIFromDatabase();
        }

        private void RefreshUIFromDatabase()
        {
            List<ExtractionInformation> info = new List<ExtractionInformation>(_catalogue.GetAllExtractionInformation(ExtractionCategory.Any));
            info.Sort();
            lbCurrentOrder.Items.AddRange(info.ToArray());
        }

        private void lbDesiredOrder_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                lock (oDrawLock)
                {
                    if(lbDesiredOrder.SelectedItem != null)
                        lbDesiredOrder.Items.Remove(lbDesiredOrder.SelectedItem);

                    RecomputeOrderAndHighlight();
                }
            }
            else
            if (e.KeyCode == Keys.V && e.Control)
            {
                lock (oDrawLock)
                {
                    lbDesiredOrder.Items.AddRange(UsefulStuff.GetInstance().GetArrayOfColumnNamesFromStringPastedInByUser(Clipboard.GetText()).ToArray());
                    RecomputeOrderAndHighlight();
                }
            }
        }
        
        private void RecomputeOrderAndHighlight()
        {
            WorkOutReOrderVariables();

            WorkOutNewOrderAndAddToNewOrderListbox(); 

            lbCurrentOrder.Invalidate();
        }

        /// <summary>
        /// Figures out what strings in the users desired order are actually in the extraction and computes 
        /// currentOrderStartReorderAtIndex and itemsToReOrderAndOfsetRelativeToFirst which are used for
        /// highlighting and to WorkOutNewOrderAndAddToNewOrderListbox
        /// </summary>
        private void WorkOutReOrderVariables()
        {
           
            desiredColumnIndexesNotFound = new List<int>();
            currentOrderStartReorderAtIndex = -1;

            //find the first item on the list
            if (lbDesiredOrder.Items.Count == 0)
                return;

            string startReorderingHere = lbDesiredOrder.Items[0].ToString();
            
           

            //find the location of the first item in the desired order
            for (int i = 0; i < lbCurrentOrder.Items.Count; i++)
            {
                var extractionInformation = lbCurrentOrder.Items[i] as ExtractionInformation;

                //if either the runtime name or the display (UI) name matches then it is found - may be both of these are the same value sometimes
                //but sometimes people give things wierdo names eh
                if (extractionInformation.GetRuntimeName().ToLower().Equals(startReorderingHere.ToLower()) || extractionInformation.ToString().ToLower().Equals(startReorderingHere.ToLower()))
                    currentOrderStartReorderAtIndex = i;
            }

            if (currentOrderStartReorderAtIndex == -1)
                desiredColumnIndexesNotFound.Add(0);

            //find the rest of the items in the desired order
            itemsToReOrderAndOffsetRelativeToFirst = new List<ExtractionInformation>();

            for (int i = 1; i < lbDesiredOrder.Items.Count; i++)
            {
                bool bFound = false;

                foreach (ExtractionInformation info in lbCurrentOrder.Items)
                {
                    //if either the runtime name or the display (UI) name matches then it is found - may be both of these are the same value sometimes
                    //but sometimes people give things wierdo names eh
                    if (info.GetRuntimeName().ToLower().Equals(lbDesiredOrder.Items[i].ToString().ToLower())
                        || info.ToString().ToLower().Equals(lbDesiredOrder.Items[i].ToString().ToLower()))
                    {
                        bFound = true;
                        itemsToReOrderAndOffsetRelativeToFirst.Add(info);
                    }
                }

                if (!bFound)
                    desiredColumnIndexesNotFound.Add(i);
            }

         
        }

        private void WorkOutNewOrderAndAddToNewOrderListbox()
        {
            lbNewOrder.Items.Clear();

            //for all the things that appear above the thing the user wants first in his dream order
            for (int i = 0;i < currentOrderStartReorderAtIndex;i++)
            {
                ExtractionInformation considerMoving = lbCurrentOrder.Items[i] as ExtractionInformation;

                //if it doesnt feature in the users dream list order then move it across
                if (!itemsToReOrderAndOffsetRelativeToFirst.Contains(considerMoving))
                    lbNewOrder.Items.Add(considerMoving);
            }

            //could not find the users desired reordering startcolumn
            if (currentOrderStartReorderAtIndex == -1)
                return;

            //move the first one in the users dream order across
            lbNewOrder.Items.Add(lbCurrentOrder.Items[currentOrderStartReorderAtIndex]);
            //record the location of the 'start reordering at' item in the new listbox so we can highlight it in the draw method
            indexOfStartOfReordingInNewOrderListbox = lbNewOrder.Items.Count-1;

            //move everything in the users dream list
            foreach (ExtractionInformation extractionInformation in itemsToReOrderAndOffsetRelativeToFirst)
                lbNewOrder.Items.Add(extractionInformation);

            //move everything that doesnt feature in the users dream list (but that occured after the first thing they wanted)

             //for all the things that appear above the thing the user wants first in his dream order
            for (int i = currentOrderStartReorderAtIndex+1; i < lbCurrentOrder.Items.Count; i++)
            {
                 ExtractionInformation considerMoving = lbCurrentOrder.Items[i] as ExtractionInformation;

                //if it doesnt feature in the users dream list order then move it across
                if (!itemsToReOrderAndOffsetRelativeToFirst.Contains(considerMoving))
                    lbNewOrder.Items.Add(considerMoving);
            }
        }

        private void lbCurrentOrder_DrawItem(object sender, DrawItemEventArgs e)
        {
            lock (oDrawLock)
            {
                var listBox = sender as ListBox;

                if(e.Index == -1)
                    return;

                if (sender == lbCurrentOrder)
                {
                    if (e.Index == currentOrderStartReorderAtIndex)
                        e.Graphics.FillRectangle(new SolidBrush(Color.LawnGreen), e.Bounds);
                    else
                        if (itemsToReOrderAndOffsetRelativeToFirst != null && itemsToReOrderAndOffsetRelativeToFirst.Contains(lbCurrentOrder.Items[e.Index] as ExtractionInformation))
                            e.Graphics.FillRectangle(new SolidBrush(Color.Purple), e.Bounds);
                        else
                            e.Graphics.FillRectangle(new SolidBrush(listBox.BackColor), e.Bounds);
                }

                if (sender == lbNewOrder)
                {
                    if (e.Index == indexOfStartOfReordingInNewOrderListbox)
                        e.Graphics.FillRectangle(new SolidBrush(Color.LawnGreen), e.Bounds);
                    else
                        if (itemsToReOrderAndOffsetRelativeToFirst != null 
                            && e.Index <= itemsToReOrderAndOffsetRelativeToFirst.Count + indexOfStartOfReordingInNewOrderListbox
                            && e.Index > indexOfStartOfReordingInNewOrderListbox)
                            e.Graphics.FillRectangle(new SolidBrush(Color.Purple), e.Bounds);
                        else
                            e.Graphics.FillRectangle(new SolidBrush(listBox.BackColor), e.Bounds);
                }

                e.Graphics.DrawString(listBox.Items[e.Index].ToString(), lbDesiredOrder.Font, new SolidBrush(Color.Black), e.Bounds);
                
            }
        }

        object oDrawLock = new object();


        private void lbDesiredOrder_DrawItem(object sender, DrawItemEventArgs e)
        {
            lock (oDrawLock)
            {
              if(e.Index == -1)
                return;

              if (lbDesiredOrder.SelectedIndex == e.Index || lbDesiredOrder.SelectedIndices.Contains(e.Index) || desiredColumnIndexesNotFound == null)
                 e.Graphics.FillRectangle(new SolidBrush(SystemColors.Highlight),e.Bounds );
             else
             if(desiredColumnIndexesNotFound.Contains(e.Index))
                 e.Graphics.FillRectangle(new SolidBrush(Color.Red),e.Bounds);
             else
                  e.Graphics.FillRectangle(new SolidBrush(lbDesiredOrder.BackColor),e.Bounds );

            e.Graphics.DrawString(lbDesiredOrder.Items[e.Index] as string,lbDesiredOrder.Font,new SolidBrush(lbDesiredOrder.ForeColor),e.Bounds );  
            }
            
        }

        private void btnSaveNewOrder_Click(object sender, EventArgs e)
        {

            for (int i = 0; i < lbNewOrder.Items.Count; i++)
            {
                ExtractionInformation info = (ExtractionInformation) lbNewOrder.Items[i];
                info.Order = i + 1;
                info.SaveToDatabase();
            }
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void AdvancedReorder_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                DialogResult = DialogResult.Cancel;
                this.Close();
            }
                
        }
    }
}

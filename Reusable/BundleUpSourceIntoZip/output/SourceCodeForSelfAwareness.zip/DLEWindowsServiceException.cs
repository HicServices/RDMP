using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Data.Common;
using CatalogueLibrary.Data.DataLoad;
using MapsDirectlyToDatabaseTable;
using ReusableLibraryCode;

namespace CatalogueLibrary.Data
{
    /// <summary>
    /// The DataLoadEngine windows service is an alternative to running DatasetLoaderUI manually and handles routine automated loading of LoadMetadatas
    /// Because the windows service does not have a visible UI it populates any errors it encounters into this table.
    /// </summary>
    public class DLEWindowsServiceException : DatabaseEntity
    {
        public string MachineName { get; set; }
        public string Exception { get; set; }
        public DateTime EventDate { get; private set; }

        public int LoadMetadata_ID { get; private set; }
        public string Explanation { get; set; }

        public DLEWindowsServiceException(IRepository repository, Exception e, LoadMetadata loadMetadata)
        {
            repository.InsertAndHydrate(this,new Dictionary<string, object>
            {
                {"MachineName", Environment.MachineName},
                {"LoadMetadata_ID", loadMetadata.ID},
                {"Exception", ExceptionHelper.ExceptionToListOfInnerMessages(e, true)}
            });
        }

        public DLEWindowsServiceException(IRepository repository,DbDataReader r) : base(repository,r)
        {
            LoadMetadata_ID = Convert.ToInt32(r["LoadMetadata_ID"]);
            MachineName = r["MachineName"].ToString();
            Exception = r["Exception"].ToString();
            EventDate = Convert.ToDateTime(r["EventDate"]);
            Explanation = r["Explanation"] as string; //as string because it can be null
        }
    }
}

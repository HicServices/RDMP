using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved

namespace DataLoadEngine.DataFlowPipeline.Components.Anonymisation
{
    public class ANOConfigurationException : Exception
    {
        public ANOConfigurationException(string message) : base(message)
        {
            
        }

        public ANOConfigurationException(string message, Exception innerException) : base(message, innerException)
        { 
            
        }
    }
}

namespace Dashboard.Raceway // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
{
    partial class DatasetRaceway
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.ddShowPeriod = new System.Windows.Forms.ComboBox();
            this.lblShow = new System.Windows.Forms.Label();
            this.cbIgnoreRowCounts = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tpGraph = new System.Windows.Forms.TabPage();
            this.tpData = new System.Windows.Forms.TabPage();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.datasetRaceLaneXAxis1 = new Dashboard.Raceway.DatasetRaceLaneXAxis();
            this.tabControl1.SuspendLayout();
            this.tpGraph.SuspendLayout();
            this.tpData.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.AutoScroll = true;
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1009, 409);
            this.tableLayoutPanel1.TabIndex = 0;
            this.tableLayoutPanel1.Resize += new System.EventHandler(this.tableLayoutPanel1_Resize);
            // 
            // ddShowPeriod
            // 
            this.ddShowPeriod.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ddShowPeriod.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddShowPeriod.FormattingEnabled = true;
            this.ddShowPeriod.Location = new System.Drawing.Point(46, 455);
            this.ddShowPeriod.Name = "ddShowPeriod";
            this.ddShowPeriod.Size = new System.Drawing.Size(219, 21);
            this.ddShowPeriod.TabIndex = 2;
            this.ddShowPeriod.SelectedIndexChanged += new System.EventHandler(this.ddShowPeriod_SelectedIndexChanged);
            // 
            // lblShow
            // 
            this.lblShow.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblShow.AutoSize = true;
            this.lblShow.Location = new System.Drawing.Point(3, 458);
            this.lblShow.Name = "lblShow";
            this.lblShow.Size = new System.Drawing.Size(37, 13);
            this.lblShow.TabIndex = 3;
            this.lblShow.Text = "Show:";
            // 
            // cbIgnoreRowCounts
            // 
            this.cbIgnoreRowCounts.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cbIgnoreRowCounts.AutoSize = true;
            this.cbIgnoreRowCounts.Location = new System.Drawing.Point(296, 457);
            this.cbIgnoreRowCounts.Name = "cbIgnoreRowCounts";
            this.cbIgnoreRowCounts.Size = new System.Drawing.Size(117, 17);
            this.cbIgnoreRowCounts.TabIndex = 4;
            this.cbIgnoreRowCounts.Text = "Ignore Row Counts";
            this.cbIgnoreRowCounts.UseVisualStyleBackColor = true;
            this.cbIgnoreRowCounts.CheckedChanged += new System.EventHandler(this.cbIgnoreRowCounts_CheckedChanged);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 481);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(271, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "(Buckets are only shown for months where there is data)";
            // 
            // tabControl1
            // 
            this.tabControl1.Alignment = System.Windows.Forms.TabAlignment.Right;
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tpGraph);
            this.tabControl1.Controls.Add(this.tpData);
            this.tabControl1.Location = new System.Drawing.Point(3, 3);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1042, 423);
            this.tabControl1.TabIndex = 6;
            // 
            // tpGraph
            // 
            this.tpGraph.Controls.Add(this.tableLayoutPanel1);
            this.tpGraph.Location = new System.Drawing.Point(4, 4);
            this.tpGraph.Name = "tpGraph";
            this.tpGraph.Padding = new System.Windows.Forms.Padding(3);
            this.tpGraph.Size = new System.Drawing.Size(1015, 415);
            this.tpGraph.TabIndex = 0;
            this.tpGraph.Text = "Graph";
            this.tpGraph.UseVisualStyleBackColor = true;
            // 
            // tpData
            // 
            this.tpData.Controls.Add(this.dataGridView1);
            this.tpData.Location = new System.Drawing.Point(4, 4);
            this.tpData.Name = "tpData";
            this.tpData.Padding = new System.Windows.Forms.Padding(3);
            this.tpData.Size = new System.Drawing.Size(1015, 415);
            this.tpData.TabIndex = 1;
            this.tpData.Text = "Data";
            this.tpData.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(3, 3);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1009, 409);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.ColumnAdded += new System.Windows.Forms.DataGridViewColumnEventHandler(this.dataGridView1_ColumnAdded);
            // 
            // datasetRaceLaneXAxis1
            // 
            this.datasetRaceLaneXAxis1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.datasetRaceLaneXAxis1.Location = new System.Drawing.Point(10, 432);
            this.datasetRaceLaneXAxis1.Name = "datasetRaceLaneXAxis1";
            this.datasetRaceLaneXAxis1.Size = new System.Drawing.Size(975, 23);
            this.datasetRaceLaneXAxis1.TabIndex = 1;
            // 
            // DatasetRaceway
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbIgnoreRowCounts);
            this.Controls.Add(this.lblShow);
            this.Controls.Add(this.ddShowPeriod);
            this.Controls.Add(this.datasetRaceLaneXAxis1);
            this.Name = "DatasetRaceway";
            this.Size = new System.Drawing.Size(1045, 494);
            this.tabControl1.ResumeLayout(false);
            this.tpGraph.ResumeLayout(false);
            this.tpData.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private Raceway.DatasetRaceLaneXAxis datasetRaceLaneXAxis1;
        private System.Windows.Forms.ComboBox ddShowPeriod;
        private System.Windows.Forms.Label lblShow;
        private System.Windows.Forms.CheckBox cbIgnoreRowCounts;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tpGraph;
        private System.Windows.Forms.TabPage tpData;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}

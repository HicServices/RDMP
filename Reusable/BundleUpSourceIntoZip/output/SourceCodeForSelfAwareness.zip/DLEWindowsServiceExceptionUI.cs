using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Windows.Forms;
using CatalogueLibrary.Data;
using ReusableUIComponents;

namespace Dashboard.Overview
{
    /// <summary>
    /// Describes a single error encountered by the routine data loading automation server (See DLEWindowsServiceExceptionsListUI).  
    /// 
    /// Clicking view exception will let you see the stack trace/source code (See ExceptionViewer).
    /// 
    /// Typing in an Explanation will resolve the error such that it no longer appears on the dashboard.  If you do this make sure you have fixed the underlying problem and relaunched the
    /// automation service (if required).
    /// </summary>
    public partial class DLEWindowsServiceExceptionUI : UserControl
    {
        private readonly DLEWindowsServiceException _dleWindowsServiceException;

        public DLEWindowsServiceExceptionUI(DLEWindowsServiceException dleWindowsServiceException)
        {
            _dleWindowsServiceException = dleWindowsServiceException;
            InitializeComponent();

            if (dleWindowsServiceException == null)
                return;
            
            pictureBox1.Image = string.IsNullOrWhiteSpace(dleWindowsServiceException.Explanation) ? imageList1.Images["Bad"] : imageList1.Images["Good"];
            
            lblDate.Text = dleWindowsServiceException.EventDate + "(" + dleWindowsServiceException.MachineName + ")";
        }

        private void btnViewException_Click(object sender, EventArgs e)
        {
            WideMessageBox.Show(_dleWindowsServiceException.Exception);
        }

        private void tbExplanation_TextChanged(object sender, EventArgs e)
        {
            _dleWindowsServiceException.Explanation = tbExplanation.Text;
            _dleWindowsServiceException.SaveToDatabase();
            pictureBox1.Image = string.IsNullOrWhiteSpace(_dleWindowsServiceException.Explanation) ? imageList1.Images["Bad"] : imageList1.Images["Good"];
        }
    }
}

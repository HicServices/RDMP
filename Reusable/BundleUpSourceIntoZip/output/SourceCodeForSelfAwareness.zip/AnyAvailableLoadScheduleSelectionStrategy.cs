using System.Collections.Generic; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Linq;
using CatalogueLibrary.Data;
using CatalogueLibrary.Data.DataLoad;

namespace DataLoadEngine.LoadProcess.Scheduling.Strategy
{
    public class AnyAvailableLoadScheduleSelectionStrategy : ILoadScheduleSelectionStrategy
    {
        private readonly ILoadMetadata _loadMetadata;

        public AnyAvailableLoadScheduleSelectionStrategy(ILoadMetadata loadMetadata)
        {
            _loadMetadata = loadMetadata;
        }

        public List<ILoadProgress> GetAllLoadProgresses(bool respectAndAcquire = true)
        {
            var loadSchedules = _loadMetadata.LoadProgresses.Where(schedule => 
                !schedule.LockedBecauseRunning  //it is available to run
                || 
                !respectAndAcquire//we don't care just give us it
                ).ToList();

            //if we want lock
            if(respectAndAcquire)
                loadSchedules.ForEach(schedule => schedule.Lock());//lock everything

            return loadSchedules;
        }
    }
}

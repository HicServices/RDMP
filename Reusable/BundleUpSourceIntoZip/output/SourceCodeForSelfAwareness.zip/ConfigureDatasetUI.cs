using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using CatalogueLibrary.Data;
using CatalogueLibrary.DataHelper;
using CatalogueLibrary.QueryBuilding;
using CatalogueManager;
using CatalogueManager.TestsAndSetup.ServicePropogation;
using DataExportManager2.ProjectUI.FilterConfiguration;
using DataExportManager2Library.Data;
using DataExportManager2Library.Data.DataTables;
using DataExportManager2Library.ExtractionTime;
using DataExportManager2Library.ExtractionTime.ExtractionPipeline;
using DataExportManager2Library.ExtractionTime.UserPicks;
using DataExportManager2Library.Repositories;
using MapsDirectlyToDatabaseTable;
using ReusableLibraryCode;
using ReusableUIComponents;
using ScintillaNET;
using Clipboard = System.Windows.Forms.Clipboard;
using QuerySyntaxHelper = CatalogueLibrary.DataHelper.QuerySyntaxHelper;

namespace DataExportManager2.ProjectUI
{
    /// <summary>
    /// Allows you to choose which columns you want to extract from a given dataset (Catalogue) for a specific research project extraction.  For example Researcher A wants prescribing
    /// dataset including all the Core columns but he also has obtained governance approval to recieve Supplemental column 'PrescribingGP' so the configuration would need to include this
    /// column.
    /// 
    /// On the left you can see all the available columns and transforms in the selected dataset (see ExtractionConfigurationUI for selecting datasets).  You can add these by selecting them
    /// and pressing the '>' button.  On the right the QueryBuilder will show you what the extraction SQL will be for the dataset when it is executed.  
    /// 
    /// Depending on which columns you have selected the QueryBuilder may be unable to generate a query (for example if you do not add the IsExtractionIdentifier column - See 
    /// ExtractionInformationUI).
    /// 
    /// You can click the 'Filters' button to configure extraction filters for the dataset.  For example a researcher might only have governance approval to recieve prescriptions for 
    /// specific drugs relevant to his research question and not all prescriptions.  This launches a DeployedExtractionFilterUI. 
    /// </summary>
    public partial class ConfigureDatasetUI : RDMPUserControl
    {
        private HICProjectSalt _salt;

        public ExtractionConfiguration ExtractionConfiguration
        {
            get { return _extractionConfiguration; }
            set
            {
                //if we are switching configurations clear the dataset
                if (_extractionConfiguration != null && _extractionConfiguration != value)
                    _extractableDataSet = null;

                _extractionConfiguration = value;
                RefreshUIFromDatabase();
            }
        }

        private ScintillaNET.Scintilla QueryEditor;

        private List<ExtractionInformation> ColumnsFromCatalogue = new List<ExtractionInformation>();
        private List<ConcreteColumn> ColumnsAlreadyInConfiguration = new List<ConcreteColumn>();

        private bool loading = false;

        /// <summary>
        /// populated by ExecuteDatasetExtraction.GetSQLCommandForFullExtractionSet, retained in order to query what line numbers stuff is on (e.g.
        /// when you were writting out SQL what line was the Join on? or what line was ColumnX)
        /// </summary>
        private QueryBuilder QueryBuilderLastUsed { get; set; }

        private ExtractableDataSet _extractableDataSet;
        public ExtractableDataSet ExtractableDataSet
        {
            get { return _extractableDataSet; }
            set {

                    if (VisualStudioDesignMode || QueryEditor == null)
                        return;

                    _extractableDataSet = value;

                    ColumnsFromCatalogue.Clear();
                    ColumnsAlreadyInConfiguration.Clear();
                
                

                    if (value != null)
                    {
                        if (ExtractionConfiguration == null)
                            throw new NullReferenceException(
                                "You must set ExtractionConfiguration before you set ExtractableDataSet");

                        if (_extractableDataSet.Catalogue_ID == null)
                            throw new NullReferenceException(
                                "A dataset must be associated with a Catalogue for it to be extracted");

                        try
                        {
                            _salt = new HICProjectSalt(ExtractionConfiguration.Project);
                        }
                        catch (Exception)
                        {
                            
                            throw new NullReferenceException("Unable to generate salt for dataset due to missing ProjectNumber");
                        }
                        

                        RefreshUIFromDatabase();
                        SaveColumnPositions();
                    }
                    else
                    {
                        lbSelectedColumns.Items.Clear();

                        bool before = QueryEditor.IsReadOnly;
                        QueryEditor.IsReadOnly = false;
                        QueryEditor.Text = "";
                        QueryEditor.IsReadOnly = before;
                    }
                }
        }

      
        //constructor
        public ConfigureDatasetUI()
        {
            InitializeComponent();

            if (VisualStudioDesignMode)
                return;
            
            BetterToolTip toolTip = new BetterToolTip(this);
            toolTip.SetToolTip(cbShowCohortColumns, ToolTips.ShowCustomCohortColumns,Images.ShowCustomCohortColumns);
            toolTip.SetToolTip(lblExtractionInformationDeleted, ToolTips.ExtractionInformationDeleted, Images.ExtractionInformationDeleted);
            toolTip.SetToolTip(lblExtractionInformationDeletedColor, ToolTips.ExtractionInformationDeleted, Images.ExtractionInformationDeleted);


            QueryEditor = new Scintilla();
            QueryEditor.Dock = DockStyle.Fill;
            QueryEditor.Scrolling.ScrollBars = ScrollBars.Both;
            QueryEditor.ConfigurationManager.Language = "mssql";
            QueryEditor.Margins[0].Width = 30; //allows display of line numbers

            QueryEditor.KeyDown += new KeyEventHandler(QueryEditor_KeyDown);
            QueryEditor.KeyUp += new KeyEventHandler(QueryEditor_KeyUp);
            QueryEditor.MouseUp += new MouseEventHandler(QueryEditor_MouseUp);
            
            gbQuery.Controls.Add(QueryEditor);

        }


        void QueryEditor_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Return || e.KeyCode == Keys.Enter)
                e.SuppressKeyPress = true;

            if (QueryEditor.Caret.Position < QueryEditor.Text.Length)
                if (QueryEditor.Text[QueryEditor.Caret.Position] == ',' && e.KeyCode == Keys.Delete)
                    e.SuppressKeyPress = true; //dont let them sneakily delete from the other side either

            if (QueryEditor.Caret.Position > 0)
                if (QueryEditor.Text[QueryEditor.Caret.Position-1] == ',' && QueryEditor.Text[QueryEditor.Caret.Position] == '\r') //don't let the user delete the last comma
                    if (e.KeyCode != Keys.Left && e.KeyCode != Keys.Right && e.KeyCode != Keys.Up && e.KeyCode != Keys.Down)
                        e.SuppressKeyPress = true;
        }

        private void QueryEditorSaveCurrentLineToExtractableColumn()
        {
            ConcreteColumn toUpdate = lbSelectedColumns.SelectedItem as ConcreteColumn;

            if(toUpdate == null)
                return;

            if (toUpdate.HashOnDataRelease)
            {
                //hashed fields must have Aliases so shouldnt be any null refs
                MessageBox.Show("Hashed fields ("+toUpdate.Alias+") cannot be modified outside of the Catalogue, changes will not be saved");
                return;
            }

            string currentLine  = QueryEditor.GetCurrentLine().Trim().TrimEnd(new char[] { ',', '\n', '\r' });

            string selectSQL;
            string alias;

            QuerySyntaxHelper.SplitLineIntoSelectSQLAndAlias(currentLine, out selectSQL, out alias);
            toUpdate.SelectSQL = selectSQL;
            toUpdate.Alias = alias;
            
            toUpdate.SaveToDatabase();
        }


        void QueryEditor_MouseUp(object sender, MouseEventArgs e)
        {
            UpdateQueryEditorReadonlyStatusAndSelectListboxItemIfNessesary();
        }

        /// <summary>
        /// This method looks at what line the user is editting and if it is a column then it enables editting, otherwise it disables editting.
        /// 
        /// if editting a column then it ensures that the listbox item selected is correctly coresponding to where the user is editting (important
        /// for QueryEditorSaveCurrentLineToExtractableColumn)
        /// </summary>
        private void UpdateQueryEditorReadonlyStatusAndSelectListboxItemIfNessesary()
        {
            if (loading)
                return;
            
            loading = true;
            if (QueryEditor.Lines.Current != null && QueryBuilderLastUsed != null)
            {
                try
                {
                    //allow user to edit the columns in the SQL but nothing else
                    if (QueryBuilderLastUsed.WhatIsOnLine(QueryEditor.Lines.Current.Number) == QueryComponent.QueryTimeColumn)
                    {
                        IColumn componentOnLine = (IColumn)QueryBuilderLastUsed.GetComponentOnLine(QueryEditor.Lines.Current.Number);

                        //dont let user edit hashed or Identification (CHI/PROCHI) columns
                        if(componentOnLine.HashOnDataRelease || componentOnLine.IsExtractionIdentifier)
                            QueryEditor.IsReadOnly = true;
                        else
                        {
                            QueryEditor.IsReadOnly = false;

                            // they are clicking or otherwise selecting a column in the query so select an equivillent one in 
                            for (int i = 0; i < lbSelectedColumns.Items.Count; i++)
                                if (((IColumn)lbSelectedColumns.Items[i]).ID == componentOnLine.ID)
                                    lbSelectedColumns.SelectedIndex = i;
                        }
                    }
                    else
                        QueryEditor.IsReadOnly = true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }

                if(QueryEditor.IsReadOnly)
                    lblEditting.Text = "Editting:" + QueryBuilderLastUsed.WhatIsOnLine(QueryEditor.Lines.Current.Number).ToString() + "(Readonly)";
                else
                    lblEditting.Text = "Editting:" + QueryBuilderLastUsed.WhatIsOnLine(QueryEditor.Lines.Current.Number).ToString();
            }

            

            loading = false;
        }

        private void lbSelectedColumns_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (loading)
                return;

            if (lbSelectedColumns.SelectedIndex != -1  && QueryBuilderLastUsed != null)
            {
                //use has selected a column in the listbox, let's try to select the same line in the SQL so he can know what he is supposed to be editting
                int equivalentLineInSQLEditor = QueryBuilderLastUsed.GetLineNumberForColumn((IColumn)lbSelectedColumns.SelectedItem);
                QueryEditor.Lines[equivalentLineInSQLEditor].Select();
                UpdateQueryEditorReadonlyStatusAndSelectListboxItemIfNessesary();
            }       
        }


        void QueryEditor_KeyUp(object sender, KeyEventArgs e)
        {
            UpdateQueryEditorReadonlyStatusAndSelectListboxItemIfNessesary();

            //if user is editting a bit of it
            if (!QueryEditor.IsReadOnly)
                QueryEditorSaveCurrentLineToExtractableColumn();
            
        }


        private void RegenerateCodeInQueryEditor()
        {
            try
            {
                loading = true;

                List<ConcreteColumn> cols =
                    new List<ConcreteColumn>(lbSelectedColumns.Items.Cast<ConcreteColumn>().ToArray());

                if(ExtractionConfiguration.Cohort_ID == null)
                    throw new Exception("No cohort has been defined for this ExtractionConfiguration");

                var cohort = ExtractionConfiguration.Cohort;

                //We are generating what the extraction SQL will be like, that only requires the dataset so empty bundle is fine
                ExtractionRequest request = new ExtractionRequest(ExtractionConfiguration, cohort, new ExtractableDatasetBundle(ExtractableDataSet), new List<IColumn>(cols), _salt, "", null);
                request.GenerateQueryBuilder();

                QueryBuilderLastUsed = (QueryBuilder)request.QueryBuilder;
                QueryBuilderLastUsed.Sort = true;
                QueryEditor.IsReadOnly=false;

                //get the SQL from the query builder and handle cases where there is a syntax exception by turning off syntax checking (so we can still show the generated SQL) but warning in msgbox
                try
                {
                    QueryEditor.Text = QueryBuilderLastUsed.SQL;
                }
                catch (SyntaxErrorException e)
                {
                    try
                    {
                        MessageBox.Show(e.Message, "Syntax Error");
                        QueryBuilderLastUsed.CheckSyntax = false;
                        QueryEditor.Text = QueryBuilderLastUsed.SQL;
                    }
                    catch (Exception ex)
                    {
                        QueryEditor.Text = ex.ToString();
                    }
                }

                QueryEditor.IsReadOnly = true;
            }
            catch (Exception ex)
            {
                QueryEditor.IsReadOnly = false;
                QueryEditor.Text = ex.ToString();
                QueryEditor.IsReadOnly = true;
            }
            finally
            {
                loading = false;    
            }
            
        }
        
        

        /// <summary>
        /// The left list contains ExtractionInformation from the Data Catalogue, this is columns in the database which could be extracted
        /// The right list contains ExtractableColumn which is a more advanced class that contains runtime configurations such as order to be outputed in etc.
        /// </summary>
        public void RefreshUIFromDatabase()
        {
            //clear the UI
            lbAvailableColumns.Items.Clear();
            lbSelectedColumns.Items.Clear();
            ColumnsAlreadyInConfiguration.Clear();
            ColumnsFromCatalogue.Clear();

            if (QueryEditor != null)
            {
                QueryEditor.IsReadOnly = false;
                QueryEditor.Text = "";
                QueryEditor.IsReadOnly = true;
            }


            if (_extractionConfiguration == null)
                return;

            if (_extractableDataSet == null)
                return;


            //get the catalogue and then all the items
            Catalogue cata;
            try
            {
                cata = _extractableDataSet.Catalogue;
            }
            catch (Exception)
            {
                //catalogue has probably been deleted!
                return;
            }
            
            //then get all the extractable columns from each item (some items have multiple extractable columns)

            ColumnsFromCatalogue.AddRange(cata.GetAllExtractionInformation(ExtractionCategory.Core));
                
            if(cbShowSupplemental.Checked)
                ColumnsFromCatalogue.AddRange(cata.GetAllExtractionInformation(ExtractionCategory.Supplemental));

            if (cbShowSpecialApproval.Checked)
                ColumnsFromCatalogue.AddRange(cata.GetAllExtractionInformation(ExtractionCategory.SpecialApprovalRequired));

            if (cbShowDeprecatedColumns.Checked)
                ColumnsFromCatalogue.AddRange(cata.GetAllExtractionInformation(ExtractionCategory.Deprecated));
            
            //sort it (get's default order)
            ColumnsFromCatalogue.Sort();

            var allExtractableColumns = ExtractionConfiguration.GetAllExtractableColumnsFor(ExtractableDataSet);
            
            //now get all the ExtractableColumns that are already configured for this configuration (previously)
            ColumnsAlreadyInConfiguration.AddRange(allExtractableColumns);

            ColumnsAlreadyInConfiguration.Sort();

            //add the stuff they have selected and configured into the UI
            foreach (ConcreteColumn item in ColumnsAlreadyInConfiguration)
            {
                if (string.IsNullOrWhiteSpace(item.SelectSQL))
                    if (DialogResult.Yes ==
                        MessageBox.Show("ExtractableColumn ID=" + item.ID + " has no extraction text, delete it?",
                                        "Broken Extraction Information", MessageBoxButtons.YesNo))
                    {
                        item.DeleteInDatabase(); //column is broken so delete it
                        RefreshUIFromDatabase(); //refresh the whole UI after the delete 
                        return;
                    }
                    else
                        continue; //column is broken so don't add it

                lbSelectedColumns.Items.Add(item);
            }

            //add the potential stuff (in the catalogue) that they could choose from
            foreach (ExtractionInformation info in ColumnsFromCatalogue)
            {
                //don't add stuff that we are already using
                if(!IsAlreadySelected(info))
                    lbAvailableColumns.Items.Add(info);
            }

            //add the stuff that is in the cohort table so they can pick these too
            if (ExtractionConfiguration.Cohort_ID != null)
            {
                var ec = ExtractionConfiguration.Cohort;

                try
                {
                    foreach (var cohortCustomColumn in ec.CustomCohortColumns)
                        if(
                            !IsAlreadySelected(cohortCustomColumn) &&
                        
                            //if the column has the same name as CHI (or whatever the private field is then don't add it)
                            !cohortCustomColumn.GetRuntimeName().ToLower().EndsWith(SqlSyntaxHelper.GetRuntimeName(ec.GetPrivateIdentifier()).ToLower())
                           
                            //if the show custom columns is checked
                            && cbShowCohortColumns.Checked 
                            )
                                //it can be legally added because its not selected or private
                                lbAvailableColumns.Items.Add(cohortCustomColumn);
                }
                catch (Exception e)
                {
                    ExceptionViewer.Show("Error occurred while trying to enumerate the custom cohort columns:" + e.Message,e);
                }
            }
                
            RegenerateCodeInQueryEditor();

        }

        

        /// <summary>
        /// Determines whether this potential extractable column (identified by the catalogue) is already selected and configured
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        private bool IsAlreadySelected(IColumn info)
        {
            //compare custom columns on select sql
            if (info is CohortCustomColumn)
                return ColumnsAlreadyInConfiguration.Any(ec => ec.SelectSQL == info.SelectSQL);
            
            
            //compare regular columns on thier ID in the catalogue
            return ColumnsAlreadyInConfiguration.OfType<ExtractableColumn>().Any(ec => ec.CatalogueExtractionInformation_ID == info.ID);
        }

    

        private void TryToPopulateSelectedColumnsListBoxWithTheFollowingColumnNames(string[] userDesiredColumns)
        {
            string couldNotFindColumns = "";
            int couldFind = 0;

            foreach (string toAdd in userDesiredColumns)
            {
                bool found = false;

                for (int i = 0; i < lbAvailableColumns.Items.Count;i++ )
                {
                    if (IsFuzzyMatch(lbAvailableColumns.Items[i] as ExtractionInformation,toAdd))
                    {
                        AddColumnToExtraction(lbAvailableColumns.Items[i] as ExtractionInformation);
                        found = true;
                        couldFind++;
                        break;
                    }
                }

                if (!found)
                    couldNotFindColumns += toAdd + Environment.NewLine;
            }

            MessageBox.Show("Found " + couldFind + "/" + userDesiredColumns.Length + ", could not find:" +
                            Environment.NewLine + couldNotFindColumns);

        }

        private bool IsFuzzyMatch(ExtractionInformation info, string toMatch)
        {
            char[] thingsToTrimOff = new char[] {']', ',', '\n', '\r'};

            if (!toMatch.StartsWith("."))
                toMatch = "." + toMatch;

            //verbatim match
            if (info.ToString().Equals(toMatch))
                return true;

            //ends with match (deals with the fact that we have TableInfo as prefix on the names of these columns
            if (info.ToString().EndsWith(toMatch))
                return true;

            //ends with match stripping ] deals with properly named columns
            if (info.ToString().TrimEnd(thingsToTrimOff).Equals(thingsToTrimOff))
                return true;

            return false;
        }

        /// <summary>
        /// The user has selected an extractable thing in the catalogue and opted to include it in the extraction
        /// So we have to convert it to an ExtractableColumn (which has configuration specific stuff - and lets
        /// data analyst override stuff for this extraction only)
        /// 
        /// Then add it to the right hand list
        /// </summary>
        /// <param name="item"></param>
        private void AddColumnToExtraction(IColumn item)
        {
            if (string.IsNullOrWhiteSpace(item.SelectSQL))
            {
                MessageBox.Show("IColumn ("+item.GetType().Name+") " + item + " has a blank value for SelectSQL, fix this in the CatalogueManager");
                return;
            }

            string query = "";
            query = item.SelectSQL;

            ExtractableColumn addMe;

            if (item is ExtractionInformation)
                addMe = new ExtractableColumn(ExtractableDataSet.Repository, ExtractableDataSet, ExtractionConfiguration, item as ExtractionInformation, -1, query);
            else
                addMe = new ExtractableColumn(ExtractableDataSet.Repository, ExtractableDataSet, ExtractionConfiguration, null, -1, query); // its custom column of some kind, not tied to a catalogue entry

            //Add new things you want to copy from the Catalogue here
            addMe.HashOnDataRelease = item.HashOnDataRelease;
            addMe.IsExtractionIdentifier = item.IsExtractionIdentifier;
            addMe.IsPrimaryKey = item.IsPrimaryKey;
            addMe.Order = item.Order;
            addMe.Alias = item.Alias;
            addMe.SaveToDatabase();

            ColumnsAlreadyInConfiguration.Add(addMe);

            int i;
            //work where to add it to the listbox
            for (i = 0; i < lbSelectedColumns.Items.Count; i++)
            {
                ConcreteColumn c = (ConcreteColumn) lbSelectedColumns.Items[i];
                if (c.Order <= addMe.Order)
                    continue;
                
                break;
            }

            lbSelectedColumns.Items.Insert(i,addMe);
        }

        
        private void btnInclude_Click(object sender, EventArgs e)
        {
            
            foreach (IColumn item in lbAvailableColumns.SelectedItems)
                AddColumnToExtraction(item);

            //remove from left box
            for (int i = lbAvailableColumns.SelectedIndices.Count - 1; i >= 0; i--)
                lbAvailableColumns.Items.RemoveAt(lbAvailableColumns.SelectedIndices[i]);

            SaveColumnPositions();
            RefreshUIFromDatabase();
        }

        private void btnExclude_Click(object sender, EventArgs e)
        {
            if (lbSelectedColumns.SelectedItem != null)
            {
                RemoveColumnFromExtraction(lbSelectedColumns.SelectedItem as ConcreteColumn);
                lbSelectedColumns.Items.Remove(lbSelectedColumns.SelectedItem);
                RefreshUIFromDatabase();
            }

        }
        
        private void btnExcludeAll_Click(object sender, EventArgs e)
        {
            for (int i = lbSelectedColumns.Items.Count - 1; i >= 0; i--)
            {
                RemoveColumnFromExtraction(lbSelectedColumns.Items[i] as ConcreteColumn);
            }

            RefreshUIFromDatabase();
        }

        private void RemoveColumnFromExtraction(ConcreteColumn concreteColumn)
        {
            if (concreteColumn != null)
                concreteColumn.DeleteInDatabase();
        }

        private void SaveColumnPositions()
        {
            int position = 0;
            foreach (ConcreteColumn col in lbSelectedColumns.Items)
            {
                col.Order = position++;
                col.SaveToDatabase();
            }
        }


        private void lbSelectedColumns_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.V && e.Control)
            {
                //the user is trying to paste in a list of headers, try to find them
                string toPaste = Clipboard.GetText();

                string[] userDesiredColumns = toPaste.Split(new char[] {'\n', '\r'}, StringSplitOptions.RemoveEmptyEntries);

                TryToPopulateSelectedColumnsListBoxWithTheFollowingColumnNames(userDesiredColumns);

                SaveColumnPositions();

                RefreshUIFromDatabase();

                RegenerateCodeInQueryEditor();
            }
        }

        private void btnFilters_Click(object sender, EventArgs e)
        {
            if (ExtractableDataSet == null)
            {
                MessageBox.Show("Select a dataset on the left");
                return;
            }

            DeployedExtractionFilterUI filterUI = new DeployedExtractionFilterUI(ExtractionConfiguration,ExtractableDataSet,_salt);
            filterUI.RepositoryLocator = RepositoryLocator;
            filterUI.ShowDialog();
            RefreshUIFromDatabase();
            
        }



        #region Drag and Drop reordering
        private void lbSelectedColumns_MouseDown(object sender, MouseEventArgs e)
        {
            if (this.lbSelectedColumns.SelectedItem == null) return;
            this.lbSelectedColumns.DoDragDrop(this.lbSelectedColumns.SelectedItem, DragDropEffects.Move);
        }

        
        private Point draggingOldLeftPoint;
        private Point draggingOldRightPoint;
        private ExtractionConfiguration _extractionConfiguration;

        private void lbSelectedColumns_DragOver(object sender, DragEventArgs e)
        {

            e.Effect = DragDropEffects.Move;
            int idxHoverOver = lbSelectedColumns.IndexFromPoint(lbSelectedColumns.PointToClient(new Point(e.X, e.Y)));

            Graphics g = lbSelectedColumns.CreateGraphics();

            int top = lbSelectedColumns.Font.Height * idxHoverOver;

            top += lbSelectedColumns.AutoScrollOffset.Y;

            //this seems to count up the number of items that have been skipped rather than the pixels... wierdo crazy
            int barpos = NativeMethods.GetScrollPos(lbSelectedColumns.Handle, Orientation.Vertical);
            barpos *= lbSelectedColumns.Font.Height;
            top -= barpos;


            //calculate where we should be drawing our horizontal line
            Point left = new Point(0, top);
            Point right = new Point(lbSelectedColumns.Width, top);

            //draw over the old one in the background colour (incase it has moved) - we don't want to leave trails
            g.DrawLine(new System.Drawing.Pen(lbSelectedColumns.BackColor, 2), draggingOldLeftPoint, draggingOldRightPoint);
            g.DrawLine(new System.Drawing.Pen(Color.Black, 2), left, right);

            draggingOldLeftPoint = left;
            draggingOldRightPoint = right;

        }

        private void lbSelectedColumns_DragDrop(object sender, DragEventArgs e)
        {
            Point point = lbSelectedColumns.PointToClient(new Point(e.X, e.Y));
            int index = this.lbSelectedColumns.IndexFromPoint(point);

            //if they are dragging it way down the bottom of the list
            if (index < 0)
                index = this.lbSelectedColumns.Items.Count;

            //get the thing they are dragging
            object data = e.Data.GetData(typeof(ConcreteColumn));

            //find original index because if we are dragging down then we will want to adjust the index so that insert point is correct even after removing the object further up the list
            int originalIndex = this.lbSelectedColumns.Items.IndexOf(data);

            this.lbSelectedColumns.Items.Remove(data);

            if (originalIndex < index)
                this.lbSelectedColumns.Items.Insert(Math.Max(0, index - 1), data);
            else
                this.lbSelectedColumns.Items.Insert(index, data);

            SaveColumnPositions();

            RegenerateCodeInQueryEditor();

        }


        #endregion

        
        private void btnSelectCore_Click(object sender, EventArgs e)
        {
            for(int i=0;i<lbAvailableColumns.Items.Count;i++)
            {
                ExtractionInformation column = lbAvailableColumns.Items[i] as ExtractionInformation;

                //could be a Cohort column! so check for null
                if (column != null)
                    if(column.ExtractionCategory == ExtractionCategory.Core)
                        lbAvailableColumns.SetSelected(i,true);
            }
        }

        private void cbAnyShowFieldsRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            RefreshUIFromDatabase();
        }

        private void lbAvailableColumns_DrawItem(object sender, DrawItemEventArgs e)
        {
            Graphics g = e.Graphics;

            // draw the background color you want
            g.FillRectangle(new SolidBrush(e.BackColor), e.Bounds);

            if (e.Index != -1)
                if (lbAvailableColumns.Items[e.Index] is CohortCustomColumn)
                {
                    CohortCustomColumn toDisplay = lbAvailableColumns.Items[e.Index] as CohortCustomColumn;
                    
                    g.DrawString(toDisplay.ToString(), e.Font, new SolidBrush(Color.Blue), new PointF(e.Bounds.X, e.Bounds.Y));
                }
                else
                {
                    ExtractionInformation toDisplay = lbAvailableColumns.Items[e.Index] as ExtractionInformation;

                    string textToDisplay = toDisplay.ToString();

                    if (toDisplay.ExtractionCategory == ExtractionCategory.Core)
                        g.DrawString(textToDisplay, e.Font, new SolidBrush(Color.Green), new PointF(e.Bounds.X, e.Bounds.Y));
                    else if (toDisplay.ExtractionCategory == ExtractionCategory.Supplemental)
                        g.DrawString(textToDisplay, e.Font, new SolidBrush(Color.Orange),
                                        new PointF(e.Bounds.X, e.Bounds.Y));
                    else if (toDisplay.ExtractionCategory == ExtractionCategory.Deprecated)
                        g.DrawString(textToDisplay, e.Font, new SolidBrush(Color.Red),
                                        new PointF(e.Bounds.X, e.Bounds.Y));
                    else if (toDisplay.ExtractionCategory == ExtractionCategory.SpecialApprovalRequired)
                        g.DrawString(textToDisplay, e.Font, new SolidBrush(Color.Tan),
                                        new PointF(e.Bounds.X, e.Bounds.Y));
                    
                }
        }

        private void lbSelectedColumns_DrawItem(object sender, DrawItemEventArgs e)
        {
             Graphics g = e.Graphics;

            // draw the background color you want
            g.FillRectangle(new SolidBrush(e.BackColor), e.Bounds);

            if (e.Index != -1)
            {
                var col = (ExtractableColumn)lbSelectedColumns.Items[e.Index];
                g.DrawString(col.ToString(), e.Font, new SolidBrush(col.HasOriginalExtractionInformationVanished()?Color.Red:Color.Black), new PointF(e.Bounds.X, e.Bounds.Y));
            }
        }    
    }
}

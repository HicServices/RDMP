using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using CatalogueLibrary.Data;
using CatalogueLibrary.Repositories;
using MapsDirectlyToDatabaseTable;
using ReusableLibraryCode.Checks;

namespace CatalogueLibrary.Reports
{

    public class DocumentationReportFormsAndControls: ICheckable
    {
        private readonly Type[] _formsAndControls;
        private readonly int _numberOfNewlinesPerParagraph;
        public Dictionary<Type, string> Summaries = new Dictionary<Type, string>();

        public DocumentationReportFormsAndControls(Type[] formsAndControls)
        {
            _formsAndControls = formsAndControls;
        }

        public void Check(ICheckNotifier notifier)
        {
            string zipArchive = "SourceCodeForSelfAwareness.zip";

            using (var z = ZipFile.Open(zipArchive,ZipArchiveMode.Read))
            {
                foreach (Type t in _formsAndControls)
                {
                    try
                    {
                        //spontaneous objects don't exist in the database.
                        notifier.OnCheckPerformed(new CheckEventArgs("Found Type " + t.Name, CheckResult.Success,null));
                    }
                    catch(Exception ex)
                    {
                        continue;
                    }

                    
                    string toFind;

                    //if it's a generic
                    if (t.Name.EndsWith("`1"))
                        toFind = t.Name.Substring(0, t.Name.Length - "`1".Length) + ".cs"; //trim off the tick 1
                    else
                        toFind = t.Name + ".cs";//its just regular
                    
                    var entries = z.Entries.Where(e => e.Name == toFind).ToArray();

                    if (entries.Length != 1)
                    {
                        notifier.OnCheckPerformed(
                            new CheckEventArgs("Found " + entries.Length + " files called " + toFind,
                                CheckResult.Fail));
                        continue;
                    }

                    string classSourceCode = new StreamReader(entries[0].Open()).ReadToEnd();

                    try
                    {
                        string definition = DocumentationReportMapsDirectlyToDatabase.GetSummaryFromContent(t, classSourceCode, notifier);

                        //somehow we have 2 copies of this?
                        if(Summaries.ContainsKey(t))
                            continue;

                        Summaries.Add(t, definition??"Not documented");
                    }
                    catch (Exception e)
                    {
                        notifier.OnCheckPerformed(
                            new CheckEventArgs("Failed to get definition for class " + t.FullName, CheckResult.Fail,
                                e));
                    }

                }
            }

        }
    }
}

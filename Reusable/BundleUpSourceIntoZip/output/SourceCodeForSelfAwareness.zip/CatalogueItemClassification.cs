using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Data.Common;
using MapsDirectlyToDatabaseTable;

namespace CatalogueLibrary.Data
{
    public class CatalogueItemClassification
    {
        public int CatalogueItem_ID;
        public int? ExtractionInformation_ID;
        public ExtractionCategory? ExtractionCategory;
        public bool IsPrimaryKey;
        public bool IsLookupDescription;
        public bool IsLookupForeignKey;
        public bool IsLookupPrimaryKey;
        public int ExtractionFilterCount;

        public CatalogueItemClassification(DbDataReader r)
        {
            CatalogueItem_ID = Convert.ToInt32(r[CatalogueItem_ID]);
            ExtractionInformation_ID = DatabaseEntity.ObjectToNullableInt(r["ExtractionInformation_ID"]);
            if (r["ExtractionCategory"] == DBNull.Value)
                ExtractionCategory = null;
            else
                ExtractionCategory = (ExtractionCategory) Enum.Parse(typeof (ExtractionCategory), r["ExtractionCategory"].ToString());

            IsPrimaryKey = Convert.ToBoolean(r["IsPrimaryKey"]);
            IsLookupDescription = Convert.ToBoolean(r["IsLookupDescription"]);
            IsLookupForeignKey = Convert.ToBoolean(r["IsLookupForeignKey"]);
            IsLookupPrimaryKey = Convert.ToBoolean(r["IsLookupPrimaryKey"]);
            ExtractionFilterCount = Convert.ToInt32(r["ExtractionFilterCount"]);
        }

    }
}

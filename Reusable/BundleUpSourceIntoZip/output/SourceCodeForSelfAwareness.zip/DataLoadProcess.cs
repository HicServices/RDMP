using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Diagnostics.Contracts;
using CatalogueLibrary;
using CatalogueLibrary.Data.DataLoad;
using CatalogueLibrary.DataFlowPipeline;
using DataLoadEngine.DatabaseManagement.EntityNaming;
using DataLoadEngine.DataProvider;
using DataLoadEngine.LoadPipeline;
using HIC.Logging;
using ReusableLibraryCode.Progress;

namespace DataLoadEngine.LoadProcess
{
    public abstract class DataLoadProcess : IDataLoadProcess
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="loadCancellationToken"></param>
        /// <returns></returns>
        /// <exception cref="OperationCanceledException">The data load has been cancelled</exception>
        public abstract ExitCodeType Run(GracefulCancellationToken loadCancellationToken);

        public IDataProvider DataProviderOverride { get; set; }

        protected readonly ILoadMetadata LoadMetadata;
        protected HICLoadConfigurationFlags LoadConfigurationFlags;
        protected readonly IDataLoadEventListener DataLoadEventListener;
        protected readonly ILogManager LogManager;
        protected readonly HICDatabaseConfiguration DatabaseConfiguration;
        protected MultiStageDataLoadProcess PipelineDataLoadProcess;

        public IDataLoadPipeline LoadPipeline
        {
            get { return PipelineDataLoadProcess == null ? null : PipelineDataLoadProcess.LoadPipeline; }
        }

        public ExitCodeType? ExitCode { get; private set; }

        public bool IsRunning
        {
            get { return PipelineDataLoadProcess != null && PipelineDataLoadProcess.IsRunning; }
        }

        protected DataLoadProcess(ILoadMetadata loadMetadata, HICDatabaseConfiguration databaseConfiguration, HICLoadConfigurationFlags loadConfigurationFlags, ILogManager logManager, IDataLoadEventListener dataLoadEventListener)
        {
            #region Contract Pre-conditions
            Contract.Requires<ArgumentNullException>(loadMetadata != null);
            Contract.Requires<ArgumentNullException>(databaseConfiguration != null);
            Contract.Requires<ArgumentNullException>(loadConfigurationFlags != null);
            #endregion

            LoadMetadata = loadMetadata;
            DatabaseConfiguration = databaseConfiguration;
            LoadConfigurationFlags = loadConfigurationFlags;
            DataLoadEventListener = dataLoadEventListener;
            LogManager = logManager;
            ExitCode = ExitCodeType.Success;
        }

        [ContractInvariantMethod]
        private void ObjectInvariant()
        {
            Contract.Invariant(LoadMetadata != null);
            Contract.Invariant(DatabaseConfiguration != null);
            Contract.Invariant(LoadConfigurationFlags != null); 
        }

        public void DisposeAllDisposables()
        {
            if (PipelineDataLoadProcess != null)
                PipelineDataLoadProcess.DisposeAllDisposables();
        }
    }
}

using BrightIdeasSoftware; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using CatalogueManager.MainFormUITabs.SubComponents;

namespace CatalogueManager.MainFormUITabs
{
    partial class CatalogueItemTab
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.tbFilter = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.lbCatalogueItems = new BrightIdeasSoftware.ObjectListView();
            this.olvColumn1 = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumn2 = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.label21 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.splitContainer4 = new System.Windows.Forms.SplitContainer();
            this.ci_tbID = new System.Windows.Forms.TextBox();
            this.lblSaved = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.ci_tbComments = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.ci_tbLimitations = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.ci_tbTopics = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.ci_tbAggregationMethod = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.ci_tbDescription = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.ci_tbResearchRelevance = new System.Windows.Forms.TextBox();
            this.ci_ddPeriodicity = new System.Windows.Forms.ComboBox();
            this.ci_tbStatisticalConsiderations = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.ci_tbName = new System.Windows.Forms.TextBox();
            this.splitContainer6 = new System.Windows.Forms.SplitContainer();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.ci_lbSelectedColumns = new System.Windows.Forms.ListBox();
            this.label61 = new System.Windows.Forms.Label();
            this.tableInfoCollection = new CatalogueManager.MainFormUITabs.SubComponents.TableInfoCollectionHost();
            this.label29 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.catalogueItemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.importToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cloneNewCatalogueItemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.descriptiveDataIntoCurrentCatalogueItemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.descriptiveDataFromAnotherCatalogueItemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteDelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.highlightDodgyNamesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.extractionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.catalogueToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.guessAssociatedColumnInfosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.markAllAssociatedColumnsExtractableToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteAllExtractionInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteAllAssociatedColumnInfosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteMISSINGAssociatedColumnsInfosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bulkProcessCatalogueItemsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.extractioncatalogueItemToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lbCatalogueItems)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).BeginInit();
            this.splitContainer4.Panel1.SuspendLayout();
            this.splitContainer4.Panel2.SuspendLayout();
            this.splitContainer4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer6)).BeginInit();
            this.splitContainer6.Panel1.SuspendLayout();
            this.splitContainer6.Panel2.SuspendLayout();
            this.splitContainer6.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer2
            // 
            this.splitContainer2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer2.Location = new System.Drawing.Point(0, 22);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.tbFilter);
            this.splitContainer2.Panel1.Controls.Add(this.label17);
            this.splitContainer2.Panel1.Controls.Add(this.label18);
            this.splitContainer2.Panel1.Controls.Add(this.label22);
            this.splitContainer2.Panel1.Controls.Add(this.lbCatalogueItems);
            this.splitContainer2.Panel1.Controls.Add(this.label21);
            this.splitContainer2.Panel1.Controls.Add(this.label2);
            this.splitContainer2.Panel1.Controls.Add(this.label15);
            this.splitContainer2.Panel1.Controls.Add(this.label16);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.splitContainer4);
            this.splitContainer2.Size = new System.Drawing.Size(1344, 845);
            this.splitContainer2.SplitterDistance = 213;
            this.splitContainer2.TabIndex = 135;
            // 
            // tbFilter
            // 
            this.tbFilter.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.tbFilter.Location = new System.Drawing.Point(60, 793);
            this.tbFilter.Name = "tbFilter";
            this.tbFilter.Size = new System.Drawing.Size(150, 20);
            this.tbFilter.TabIndex = 150;
            this.tbFilter.TextChanged += new System.EventHandler(this.tbFilter_TextChanged);
            // 
            // label17
            // 
            this.label17.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(31, 762);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(99, 13);
            this.label17.TabIndex = 149;
            this.label17.Text = "Lookup Description";
            // 
            // label18
            // 
            this.label18.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label18.BackColor = System.Drawing.Color.PowderBlue;
            this.label18.ForeColor = System.Drawing.Color.Blue;
            this.label18.Location = new System.Drawing.Point(15, 765);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(10, 10);
            this.label18.TabIndex = 148;
            // 
            // label22
            // 
            this.label22.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(31, 776);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(144, 13);
            this.label22.TabIndex = 147;
            this.label22.Text = "Extractable (But Deprecated)";
            // 
            // lbCatalogueItems
            // 
            this.lbCatalogueItems.AllColumns.Add(this.olvColumn1);
            this.lbCatalogueItems.AllColumns.Add(this.olvColumn2);
            this.lbCatalogueItems.AllowDrop = true;
            this.lbCatalogueItems.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbCatalogueItems.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.olvColumn1,
            this.olvColumn2});
            this.lbCatalogueItems.FullRowSelect = true;
            this.lbCatalogueItems.Location = new System.Drawing.Point(7, 10);
            this.lbCatalogueItems.Name = "lbCatalogueItems";
            this.lbCatalogueItems.ShowGroups = false;
            this.lbCatalogueItems.Size = new System.Drawing.Size(204, 732);
            this.lbCatalogueItems.TabIndex = 12;
            this.lbCatalogueItems.UseCompatibleStateImageBehavior = false;
            this.lbCatalogueItems.View = System.Windows.Forms.View.Details;
            this.lbCatalogueItems.SelectedIndexChanged += new System.EventHandler(this.ci_lbCatalogueItems_SelectedIndexChanged);
            this.lbCatalogueItems.DragDrop += new System.Windows.Forms.DragEventHandler(this.ci_lbCatalogueItems_DragDrop);
            this.lbCatalogueItems.DragEnter += new System.Windows.Forms.DragEventHandler(this.ci_lbCatalogueItems_DragEnter);
            this.lbCatalogueItems.KeyUp += new System.Windows.Forms.KeyEventHandler(this.ci_lbCatalogueItems_KeyUp);
            // 
            // olvColumn1
            // 
            this.olvColumn1.AspectName = "ToString";
            this.olvColumn1.FillsFreeSpace = true;
            this.olvColumn1.Text = "Name";
            // 
            // olvColumn2
            // 
            this.olvColumn2.AspectName = "";
            this.olvColumn2.Text = "Filters";
            this.olvColumn2.Width = 40;
            // 
            // label21
            // 
            this.label21.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label21.BackColor = System.Drawing.Color.Orange;
            this.label21.ForeColor = System.Drawing.Color.Blue;
            this.label21.Location = new System.Drawing.Point(15, 778);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(10, 10);
            this.label21.TabIndex = 146;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 796);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(32, 13);
            this.label2.TabIndex = 136;
            this.label2.Text = "Filter:";
            // 
            // label15
            // 
            this.label15.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(31, 749);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(60, 13);
            this.label15.TabIndex = 147;
            this.label15.Text = "Extractable";
            // 
            // label16
            // 
            this.label16.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label16.BackColor = System.Drawing.Color.SteelBlue;
            this.label16.ForeColor = System.Drawing.Color.Blue;
            this.label16.Location = new System.Drawing.Point(15, 752);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(10, 10);
            this.label16.TabIndex = 146;
            // 
            // splitContainer4
            // 
            this.splitContainer4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer4.Location = new System.Drawing.Point(0, 0);
            this.splitContainer4.Name = "splitContainer4";
            // 
            // splitContainer4.Panel1
            // 
            this.splitContainer4.Panel1.Controls.Add(this.ci_tbID);
            this.splitContainer4.Panel1.Controls.Add(this.lblSaved);
            this.splitContainer4.Panel1.Controls.Add(this.label28);
            this.splitContainer4.Panel1.Controls.Add(this.label27);
            this.splitContainer4.Panel1.Controls.Add(this.label26);
            this.splitContainer4.Panel1.Controls.Add(this.ci_tbComments);
            this.splitContainer4.Panel1.Controls.Add(this.label30);
            this.splitContainer4.Panel1.Controls.Add(this.ci_tbLimitations);
            this.splitContainer4.Panel1.Controls.Add(this.label31);
            this.splitContainer4.Panel1.Controls.Add(this.ci_tbTopics);
            this.splitContainer4.Panel1.Controls.Add(this.label32);
            this.splitContainer4.Panel1.Controls.Add(this.ci_tbAggregationMethod);
            this.splitContainer4.Panel1.Controls.Add(this.label33);
            this.splitContainer4.Panel1.Controls.Add(this.ci_tbDescription);
            this.splitContainer4.Panel1.Controls.Add(this.label34);
            this.splitContainer4.Panel1.Controls.Add(this.ci_tbResearchRelevance);
            this.splitContainer4.Panel1.Controls.Add(this.ci_ddPeriodicity);
            this.splitContainer4.Panel1.Controls.Add(this.ci_tbStatisticalConsiderations);
            this.splitContainer4.Panel1.Controls.Add(this.label35);
            this.splitContainer4.Panel1.Controls.Add(this.label36);
            this.splitContainer4.Panel1.Controls.Add(this.ci_tbName);
            // 
            // splitContainer4.Panel2
            // 
            this.splitContainer4.Panel2.Controls.Add(this.splitContainer6);
            this.splitContainer4.Panel2.Controls.Add(this.label29);
            this.splitContainer4.Size = new System.Drawing.Size(1127, 845);
            this.splitContainer4.SplitterDistance = 657;
            this.splitContainer4.TabIndex = 0;
            // 
            // ci_tbID
            // 
            this.ci_tbID.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ci_tbID.Location = new System.Drawing.Point(133, 38);
            this.ci_tbID.Name = "ci_tbID";
            this.ci_tbID.ReadOnly = true;
            this.ci_tbID.Size = new System.Drawing.Size(178, 20);
            this.ci_tbID.TabIndex = 0;
            // 
            // lblSaved
            // 
            this.lblSaved.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblSaved.AutoSize = true;
            this.lblSaved.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaved.Location = new System.Drawing.Point(526, 798);
            this.lblSaved.Name = "lblSaved";
            this.lblSaved.Size = new System.Drawing.Size(0, 13);
            this.lblSaved.TabIndex = 135;
            // 
            // label28
            // 
            this.label28.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(35, 41);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(92, 13);
            this.label28.TabIndex = 109;
            this.label28.Text = "Catalogue Item ID";
            // 
            // label27
            // 
            this.label27.Location = new System.Drawing.Point(3, 220);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(124, 113);
            this.label27.TabIndex = 111;
            this.label27.Text = "Statistical Concept and Methodology";
            // 
            // label26
            // 
            this.label26.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(92, 63);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(35, 13);
            this.label26.TabIndex = 113;
            this.label26.Text = "Name";
            // 
            // ci_tbComments
            // 
            this.ci_tbComments.AcceptsReturn = true;
            this.ci_tbComments.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ci_tbComments.Location = new System.Drawing.Point(133, 712);
            this.ci_tbComments.Multiline = true;
            this.ci_tbComments.Name = "ci_tbComments";
            this.ci_tbComments.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ci_tbComments.Size = new System.Drawing.Size(510, 84);
            this.ci_tbComments.TabIndex = 9;
            this.ci_tbComments.TextChanged += new System.EventHandler(this.ci_tbComments_TextChanged);
            // 
            // label30
            // 
            this.label30.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(24, 339);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(108, 13);
            this.label30.TabIndex = 117;
            this.label30.Text = "Research Relevance";
            // 
            // ci_tbLimitations
            // 
            this.ci_tbLimitations.AcceptsReturn = true;
            this.ci_tbLimitations.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ci_tbLimitations.Location = new System.Drawing.Point(133, 615);
            this.ci_tbLimitations.Multiline = true;
            this.ci_tbLimitations.Name = "ci_tbLimitations";
            this.ci_tbLimitations.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ci_tbLimitations.Size = new System.Drawing.Size(510, 91);
            this.ci_tbLimitations.TabIndex = 8;
            this.ci_tbLimitations.TextChanged += new System.EventHandler(this.ci_tbLimitations_TextChanged);
            // 
            // label31
            // 
            this.label31.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(67, 89);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(60, 13);
            this.label31.TabIndex = 119;
            this.label31.Text = "Description";
            // 
            // ci_tbTopics
            // 
            this.ci_tbTopics.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ci_tbTopics.Location = new System.Drawing.Point(133, 459);
            this.ci_tbTopics.Name = "ci_tbTopics";
            this.ci_tbTopics.Size = new System.Drawing.Size(510, 20);
            this.ci_tbTopics.TabIndex = 5;
            this.ci_tbTopics.TextChanged += new System.EventHandler(this.ci_tbTopics_TextChanged);
            // 
            // label32
            // 
            this.label32.Location = new System.Drawing.Point(6, 515);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(121, 94);
            this.label32.TabIndex = 121;
            this.label32.Text = "Aggregation ProcessPipelineData";
            // 
            // ci_tbAggregationMethod
            // 
            this.ci_tbAggregationMethod.AcceptsReturn = true;
            this.ci_tbAggregationMethod.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ci_tbAggregationMethod.Location = new System.Drawing.Point(133, 512);
            this.ci_tbAggregationMethod.Multiline = true;
            this.ci_tbAggregationMethod.Name = "ci_tbAggregationMethod";
            this.ci_tbAggregationMethod.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ci_tbAggregationMethod.Size = new System.Drawing.Size(510, 97);
            this.ci_tbAggregationMethod.TabIndex = 7;
            this.ci_tbAggregationMethod.TextChanged += new System.EventHandler(this.ci_tbAggregationMethod_TextChanged);
            // 
            // label33
            // 
            this.label33.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(79, 462);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(34, 13);
            this.label33.TabIndex = 124;
            this.label33.Text = "Topic";
            // 
            // ci_tbDescription
            // 
            this.ci_tbDescription.AcceptsReturn = true;
            this.ci_tbDescription.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ci_tbDescription.Location = new System.Drawing.Point(133, 86);
            this.ci_tbDescription.Multiline = true;
            this.ci_tbDescription.Name = "ci_tbDescription";
            this.ci_tbDescription.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ci_tbDescription.Size = new System.Drawing.Size(510, 122);
            this.ci_tbDescription.TabIndex = 2;
            this.ci_tbDescription.TextChanged += new System.EventHandler(this.ci_tbDescription_TextChanged);
            // 
            // label34
            // 
            this.label34.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(67, 493);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(55, 13);
            this.label34.TabIndex = 126;
            this.label34.Text = "Periodicity";
            // 
            // ci_tbResearchRelevance
            // 
            this.ci_tbResearchRelevance.AcceptsReturn = true;
            this.ci_tbResearchRelevance.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ci_tbResearchRelevance.Location = new System.Drawing.Point(133, 339);
            this.ci_tbResearchRelevance.Multiline = true;
            this.ci_tbResearchRelevance.Name = "ci_tbResearchRelevance";
            this.ci_tbResearchRelevance.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ci_tbResearchRelevance.Size = new System.Drawing.Size(510, 114);
            this.ci_tbResearchRelevance.TabIndex = 4;
            this.ci_tbResearchRelevance.TextChanged += new System.EventHandler(this.ci_tbResearchRelevance_TextChanged);
            // 
            // ci_ddPeriodicity
            // 
            this.ci_ddPeriodicity.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ci_ddPeriodicity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ci_ddPeriodicity.FormattingEnabled = true;
            this.ci_ddPeriodicity.Location = new System.Drawing.Point(133, 485);
            this.ci_ddPeriodicity.Name = "ci_ddPeriodicity";
            this.ci_ddPeriodicity.Size = new System.Drawing.Size(178, 21);
            this.ci_ddPeriodicity.TabIndex = 6;
            this.ci_ddPeriodicity.SelectedIndexChanged += new System.EventHandler(this.ci_ddPeriodicity_SelectedIndexChanged);
            // 
            // ci_tbStatisticalConsiderations
            // 
            this.ci_tbStatisticalConsiderations.AcceptsReturn = true;
            this.ci_tbStatisticalConsiderations.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ci_tbStatisticalConsiderations.Location = new System.Drawing.Point(133, 220);
            this.ci_tbStatisticalConsiderations.Multiline = true;
            this.ci_tbStatisticalConsiderations.Name = "ci_tbStatisticalConsiderations";
            this.ci_tbStatisticalConsiderations.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ci_tbStatisticalConsiderations.Size = new System.Drawing.Size(510, 113);
            this.ci_tbStatisticalConsiderations.TabIndex = 3;
            this.ci_tbStatisticalConsiderations.TextChanged += new System.EventHandler(this.ci_tbStatisticalConsiderations_TextChanged);
            // 
            // label35
            // 
            this.label35.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(66, 615);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(56, 13);
            this.label35.TabIndex = 127;
            this.label35.Text = "Limitations";
            // 
            // label36
            // 
            this.label36.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(66, 715);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(56, 13);
            this.label36.TabIndex = 129;
            this.label36.Text = "Comments";
            // 
            // ci_tbName
            // 
            this.ci_tbName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ci_tbName.Location = new System.Drawing.Point(133, 60);
            this.ci_tbName.Name = "ci_tbName";
            this.ci_tbName.Size = new System.Drawing.Size(505, 20);
            this.ci_tbName.TabIndex = 1;
            this.ci_tbName.TextChanged += new System.EventHandler(this.ci_tbName_TextChanged);
            // 
            // splitContainer6
            // 
            this.splitContainer6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer6.Location = new System.Drawing.Point(0, 0);
            this.splitContainer6.Name = "splitContainer6";
            // 
            // splitContainer6.Panel1
            // 
            this.splitContainer6.Panel1.Controls.Add(this.label20);
            this.splitContainer6.Panel1.Controls.Add(this.label19);
            this.splitContainer6.Panel1.Controls.Add(this.label11);
            this.splitContainer6.Panel1.Controls.Add(this.label12);
            this.splitContainer6.Panel1.Controls.Add(this.label9);
            this.splitContainer6.Panel1.Controls.Add(this.label10);
            this.splitContainer6.Panel1.Controls.Add(this.label7);
            this.splitContainer6.Panel1.Controls.Add(this.label8);
            this.splitContainer6.Panel1.Controls.Add(this.label4);
            this.splitContainer6.Panel1.Controls.Add(this.label5);
            this.splitContainer6.Panel1.Controls.Add(this.label3);
            this.splitContainer6.Panel1.Controls.Add(this.label6);
            this.splitContainer6.Panel1.Controls.Add(this.label62);
            this.splitContainer6.Panel1.Controls.Add(this.ci_lbSelectedColumns);
            // 
            // splitContainer6.Panel2
            // 
            this.splitContainer6.Panel2.Controls.Add(this.label61);
            this.splitContainer6.Panel2.Controls.Add(this.tableInfoCollection);
            this.splitContainer6.Size = new System.Drawing.Size(466, 845);
            this.splitContainer6.SplitterDistance = 247;
            this.splitContainer6.TabIndex = 134;
            // 
            // label20
            // 
            this.label20.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(19, 777);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(133, 13);
            this.label20.TabIndex = 155;
            this.label20.Text = "Special Approval Required";
            // 
            // label19
            // 
            this.label19.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label19.BackColor = System.Drawing.Color.Tan;
            this.label19.ForeColor = System.Drawing.Color.Blue;
            this.label19.Location = new System.Drawing.Point(3, 780);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(10, 10);
            this.label19.TabIndex = 154;
            // 
            // label11
            // 
            this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(19, 820);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(72, 13);
            this.label11.TabIndex = 153;
            this.label11.Text = "Not Extracted";
            // 
            // label12
            // 
            this.label12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label12.BackColor = System.Drawing.Color.SlateGray;
            this.label12.ForeColor = System.Drawing.Color.Blue;
            this.label12.Location = new System.Drawing.Point(3, 820);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(10, 10);
            this.label12.TabIndex = 152;
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(19, 791);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(116, 13);
            this.label9.TabIndex = 151;
            this.label9.Text = "Internal Only Extraction";
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label10.BackColor = System.Drawing.Color.Red;
            this.label10.ForeColor = System.Drawing.Color.Blue;
            this.label10.Location = new System.Drawing.Point(3, 794);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(10, 10);
            this.label10.TabIndex = 150;
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(19, 804);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 13);
            this.label7.TabIndex = 149;
            this.label7.Text = "Time Series Field";
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label8.BackColor = System.Drawing.Color.LightSeaGreen;
            this.label8.ForeColor = System.Drawing.Color.Blue;
            this.label8.Location = new System.Drawing.Point(3, 807);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(10, 10);
            this.label8.TabIndex = 148;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(19, 763);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(121, 13);
            this.label4.TabIndex = 147;
            this.label4.Text = "Supplemental Extraction";
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label5.BackColor = System.Drawing.Color.Orange;
            this.label5.ForeColor = System.Drawing.Color.Blue;
            this.label5.Location = new System.Drawing.Point(3, 763);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(10, 10);
            this.label5.TabIndex = 146;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(19, 749);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 13);
            this.label3.TabIndex = 145;
            this.label3.Text = "Core Extraction";
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label6.BackColor = System.Drawing.Color.Green;
            this.label6.ForeColor = System.Drawing.Color.Blue;
            this.label6.Location = new System.Drawing.Point(3, 749);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(10, 10);
            this.label6.TabIndex = 144;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(-2, 0);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(212, 13);
            this.label62.TabIndex = 133;
            this.label62.Text = "Associated Columns / ExtractionInformation";
            // 
            // ci_lbSelectedColumns
            // 
            this.ci_lbSelectedColumns.AllowDrop = true;
            this.ci_lbSelectedColumns.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ci_lbSelectedColumns.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawVariable;
            this.ci_lbSelectedColumns.ForeColor = System.Drawing.Color.SlateGray;
            this.ci_lbSelectedColumns.FormattingEnabled = true;
            this.ci_lbSelectedColumns.Location = new System.Drawing.Point(3, 16);
            this.ci_lbSelectedColumns.Name = "ci_lbSelectedColumns";
            this.ci_lbSelectedColumns.Size = new System.Drawing.Size(208, 721);
            this.ci_lbSelectedColumns.TabIndex = 132;
            this.ci_lbSelectedColumns.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.ci_lbSelectedColumns_DrawItem);
            this.ci_lbSelectedColumns.MeasureItem += new System.Windows.Forms.MeasureItemEventHandler(this.listBoxes_MeasureItem);
            this.ci_lbSelectedColumns.SelectedIndexChanged += new System.EventHandler(this.ci_lbSelectedColumns_SelectedIndexChanged);
            this.ci_lbSelectedColumns.DragDrop += new System.Windows.Forms.DragEventHandler(this.ci_lbSelectedColumns_DragDrop);
            this.ci_lbSelectedColumns.DragEnter += new System.Windows.Forms.DragEventHandler(this.ci_lbSelectedColumns_DragEnter);
            this.ci_lbSelectedColumns.KeyUp += new System.Windows.Forms.KeyEventHandler(this.ci_lbSelectedColumns_KeyUp);
            this.ci_lbSelectedColumns.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.ci_lbSelectedColumns_MouseDoubleClick);
            this.ci_lbSelectedColumns.MouseUp += new System.Windows.Forms.MouseEventHandler(this.ci_lbSelectedColumns_MouseUp);
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(4, 0);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(126, 13);
            this.label61.TabIndex = 131;
            this.label61.Text = "TableInfos / ColumnInfos";
            // 
            // tableInfoCollection
            // 
            this.tableInfoCollection.AllowDrag = false;
            this.tableInfoCollection.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableInfoCollection.EnableRightClick = true;
            this.tableInfoCollection.Location = new System.Drawing.Point(0, 16);
            this.tableInfoCollection.Name = "tableInfoCollection";
            this.tableInfoCollection.Size = new System.Drawing.Size(207, 821);
            this.tableInfoCollection.TabIndex = 130;
            // 
            // label29
            // 
            this.label29.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(3, 737);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(53, 13);
            this.label29.TabIndex = 114;
            this.label29.Text = "Problems:";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.catalogueItemToolStripMenuItem,
            this.extractionToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1344, 24);
            this.menuStrip1.TabIndex = 136;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // catalogueItemToolStripMenuItem
            // 
            this.catalogueItemToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.saveToolStripMenuItem,
            this.importToolStripMenuItem,
            this.deleteDelToolStripMenuItem,
            this.highlightDodgyNamesToolStripMenuItem});
            this.catalogueItemToolStripMenuItem.Name = "catalogueItemToolStripMenuItem";
            this.catalogueItemToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.catalogueItemToolStripMenuItem.Size = new System.Drawing.Size(97, 20);
            this.catalogueItemToolStripMenuItem.Text = "CatalogueItem";
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.newToolStripMenuItem.Text = "New (Ctrl+N)";
            this.newToolStripMenuItem.Click += new System.EventHandler(this.newToolStripMenuItem_Click);
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.saveToolStripMenuItem.Text = "Save (Ctrl+S)";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
            // 
            // importToolStripMenuItem
            // 
            this.importToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cloneNewCatalogueItemToolStripMenuItem,
            this.descriptiveDataIntoCurrentCatalogueItemToolStripMenuItem,
            this.descriptiveDataFromAnotherCatalogueItemToolStripMenuItem});
            this.importToolStripMenuItem.Name = "importToolStripMenuItem";
            this.importToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.importToolStripMenuItem.Text = "Import";
            // 
            // cloneNewCatalogueItemToolStripMenuItem
            // 
            this.cloneNewCatalogueItemToolStripMenuItem.Name = "cloneNewCatalogueItemToolStripMenuItem";
            this.cloneNewCatalogueItemToolStripMenuItem.Size = new System.Drawing.Size(461, 22);
            this.cloneNewCatalogueItemToolStripMenuItem.Text = "Clone an existing CatalogueItem...";
            this.cloneNewCatalogueItemToolStripMenuItem.Click += new System.EventHandler(this.cloneNewCatalogueItemToolStripMenuItem_Click);
            // 
            // descriptiveDataIntoCurrentCatalogueItemToolStripMenuItem
            // 
            this.descriptiveDataIntoCurrentCatalogueItemToolStripMenuItem.Name = "descriptiveDataIntoCurrentCatalogueItemToolStripMenuItem";
            this.descriptiveDataIntoCurrentCatalogueItemToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift) 
            | System.Windows.Forms.Keys.I)));
            this.descriptiveDataIntoCurrentCatalogueItemToolStripMenuItem.Size = new System.Drawing.Size(461, 22);
            this.descriptiveDataIntoCurrentCatalogueItemToolStripMenuItem.Text = "Descriptive data from another CatalogueItem... ";
            this.descriptiveDataIntoCurrentCatalogueItemToolStripMenuItem.Click += new System.EventHandler(this.descriptiveDataIntoCurrentCatalogueItemToolStripMenuItem_Click);
            // 
            // descriptiveDataFromAnotherCatalogueItemToolStripMenuItem
            // 
            this.descriptiveDataFromAnotherCatalogueItemToolStripMenuItem.Name = "descriptiveDataFromAnotherCatalogueItemToolStripMenuItem";
            this.descriptiveDataFromAnotherCatalogueItemToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.I)));
            this.descriptiveDataFromAnotherCatalogueItemToolStripMenuItem.Size = new System.Drawing.Size(461, 22);
            this.descriptiveDataFromAnotherCatalogueItemToolStripMenuItem.Text = "Descriptive data from another CatalogueItem... (Same Name Only)";
            this.descriptiveDataFromAnotherCatalogueItemToolStripMenuItem.Click += new System.EventHandler(this.descriptiveDataFromAnotherCatalogueItem_SameName_ToolStripMenuItem_Click);
            // 
            // deleteDelToolStripMenuItem
            // 
            this.deleteDelToolStripMenuItem.Name = "deleteDelToolStripMenuItem";
            this.deleteDelToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.deleteDelToolStripMenuItem.Text = "Delete (Del)";
            this.deleteDelToolStripMenuItem.Click += new System.EventHandler(this.deleteDelToolStripMenuItem_Click);
            // 
            // highlightDodgyNamesToolStripMenuItem
            // 
            this.highlightDodgyNamesToolStripMenuItem.Name = "highlightDodgyNamesToolStripMenuItem";
            this.highlightDodgyNamesToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.highlightDodgyNamesToolStripMenuItem.Text = "Highlight Dodgy Names";
            this.highlightDodgyNamesToolStripMenuItem.Click += new System.EventHandler(this.highlightDodgyNamesToolStripMenuItem_Click);
            // 
            // extractionToolStripMenuItem
            // 
            this.extractionToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.catalogueToolStripMenuItem,
            this.extractioncatalogueItemToolStripMenuItem1});
            this.extractionToolStripMenuItem.Name = "extractionToolStripMenuItem";
            this.extractionToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
            this.extractionToolStripMenuItem.Text = "Extraction";
            // 
            // catalogueToolStripMenuItem
            // 
            this.catalogueToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.guessAssociatedColumnInfosToolStripMenuItem,
            this.markAllAssociatedColumnsExtractableToolStripMenuItem,
            this.deleteAllExtractionInformationToolStripMenuItem,
            this.deleteAllAssociatedColumnInfosToolStripMenuItem,
            this.deleteMISSINGAssociatedColumnsInfosToolStripMenuItem,
            this.bulkProcessCatalogueItemsToolStripMenuItem});
            this.catalogueToolStripMenuItem.Name = "catalogueToolStripMenuItem";
            this.catalogueToolStripMenuItem.Size = new System.Drawing.Size(241, 22);
            this.catalogueToolStripMenuItem.Text = "Catalogue Items";
            this.catalogueToolStripMenuItem.Click += new System.EventHandler(this.catalogueToolStripMenuItem_Click);
            // 
            // guessAssociatedColumnInfosToolStripMenuItem
            // 
            this.guessAssociatedColumnInfosToolStripMenuItem.Name = "guessAssociatedColumnInfosToolStripMenuItem";
            this.guessAssociatedColumnInfosToolStripMenuItem.Size = new System.Drawing.Size(293, 22);
            this.guessAssociatedColumnInfosToolStripMenuItem.Text = "Guess Associated ColumnInfos";
            this.guessAssociatedColumnInfosToolStripMenuItem.Click += new System.EventHandler(this.guessAssociatedColumnInfosToolStripMenuItem_Click);
            // 
            // markAllAssociatedColumnsExtractableToolStripMenuItem
            // 
            this.markAllAssociatedColumnsExtractableToolStripMenuItem.Name = "markAllAssociatedColumnsExtractableToolStripMenuItem";
            this.markAllAssociatedColumnsExtractableToolStripMenuItem.Size = new System.Drawing.Size(293, 22);
            this.markAllAssociatedColumnsExtractableToolStripMenuItem.Text = "Mark All Associated Columns Extractable";
            this.markAllAssociatedColumnsExtractableToolStripMenuItem.Click += new System.EventHandler(this.markAllAssociatedColumnsExtractableToolStripMenuItem_Click);
            // 
            // deleteAllExtractionInformationToolStripMenuItem
            // 
            this.deleteAllExtractionInformationToolStripMenuItem.Name = "deleteAllExtractionInformationToolStripMenuItem";
            this.deleteAllExtractionInformationToolStripMenuItem.Size = new System.Drawing.Size(293, 22);
            this.deleteAllExtractionInformationToolStripMenuItem.Text = "Delete All Extraction Information";
            this.deleteAllExtractionInformationToolStripMenuItem.Click += new System.EventHandler(this.deleteAllExtractionInformationToolStripMenuItem_Click);
            // 
            // deleteAllAssociatedColumnInfosToolStripMenuItem
            // 
            this.deleteAllAssociatedColumnInfosToolStripMenuItem.Name = "deleteAllAssociatedColumnInfosToolStripMenuItem";
            this.deleteAllAssociatedColumnInfosToolStripMenuItem.Size = new System.Drawing.Size(293, 22);
            this.deleteAllAssociatedColumnInfosToolStripMenuItem.Text = "Delete All Associated ColumnInfos";
            this.deleteAllAssociatedColumnInfosToolStripMenuItem.Click += new System.EventHandler(this.deleteAllAssociatedColumnInfosToolStripMenuItem_Click);
            // 
            // deleteMISSINGAssociatedColumnsInfosToolStripMenuItem
            // 
            this.deleteMISSINGAssociatedColumnsInfosToolStripMenuItem.Name = "deleteMISSINGAssociatedColumnsInfosToolStripMenuItem";
            this.deleteMISSINGAssociatedColumnsInfosToolStripMenuItem.Size = new System.Drawing.Size(293, 22);
            this.deleteMISSINGAssociatedColumnsInfosToolStripMenuItem.Text = "Delete MISSING Associated ColumnsInfos";
            this.deleteMISSINGAssociatedColumnsInfosToolStripMenuItem.Click += new System.EventHandler(this.deleteMISSINGAssociatedColumnsInfosToolStripMenuItem_Click);
            // 
            // bulkProcessCatalogueItemsToolStripMenuItem
            // 
            this.bulkProcessCatalogueItemsToolStripMenuItem.Name = "bulkProcessCatalogueItemsToolStripMenuItem";
            this.bulkProcessCatalogueItemsToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.B)));
            this.bulkProcessCatalogueItemsToolStripMenuItem.Size = new System.Drawing.Size(293, 22);
            this.bulkProcessCatalogueItemsToolStripMenuItem.Text = "Bulk Process CatalogueItems";
            this.bulkProcessCatalogueItemsToolStripMenuItem.Click += new System.EventHandler(this.bulkProcessCatalogueItemsToolStripMenuItem_Click);
            // 
            // extractioncatalogueItemToolStripMenuItem1
            // 
            this.extractioncatalogueItemToolStripMenuItem1.Name = "extractioncatalogueItemToolStripMenuItem1";
            this.extractioncatalogueItemToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.E)));
            this.extractioncatalogueItemToolStripMenuItem1.Size = new System.Drawing.Size(241, 22);
            this.extractioncatalogueItemToolStripMenuItem1.Text = "Extraction Information...";
            this.extractioncatalogueItemToolStripMenuItem1.Click += new System.EventHandler(this.extractioncatalogueItemToolStripMenuItem1_Click);
            // 
            // CatalogueItemTab
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.splitContainer2);
            this.Controls.Add(this.menuStrip1);
            this.Name = "CatalogueItemTab";
            this.Size = new System.Drawing.Size(1344, 867);
            this.Leave += new System.EventHandler(this.CatalogueItemTab_Leave);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel1.PerformLayout();
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.lbCatalogueItems)).EndInit();
            this.splitContainer4.Panel1.ResumeLayout(false);
            this.splitContainer4.Panel1.PerformLayout();
            this.splitContainer4.Panel2.ResumeLayout(false);
            this.splitContainer4.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).EndInit();
            this.splitContainer4.ResumeLayout(false);
            this.splitContainer6.Panel1.ResumeLayout(false);
            this.splitContainer6.Panel1.PerformLayout();
            this.splitContainer6.Panel2.ResumeLayout(false);
            this.splitContainer6.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer6)).EndInit();
            this.splitContainer6.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer2;
        private ObjectListView lbCatalogueItems;
        private System.Windows.Forms.SplitContainer splitContainer4;
        private System.Windows.Forms.TextBox ci_tbID;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox ci_tbComments;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox ci_tbLimitations;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox ci_tbTopics;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox ci_tbAggregationMethod;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox ci_tbDescription;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox ci_tbResearchRelevance;
        private System.Windows.Forms.ComboBox ci_ddPeriodicity;
        private System.Windows.Forms.TextBox ci_tbStatisticalConsiderations;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox ci_tbName;
        private System.Windows.Forms.SplitContainer splitContainer6;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.ListBox ci_lbSelectedColumns;
        private System.Windows.Forms.Label label61;
        private TableInfoCollectionHost tableInfoCollection;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label lblSaved;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem catalogueItemToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem extractionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem catalogueToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteAllExtractionInformationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem guessAssociatedColumnInfosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem importToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cloneNewCatalogueItemToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem descriptiveDataIntoCurrentCatalogueItemToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem markAllAssociatedColumnsExtractableToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteDelToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem extractioncatalogueItemToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem deleteMISSINGAssociatedColumnsInfosToolStripMenuItem;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ToolStripMenuItem deleteAllAssociatedColumnInfosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem descriptiveDataFromAnotherCatalogueItemToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem highlightDodgyNamesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bulkProcessCatalogueItemsToolStripMenuItem;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private OLVColumn olvColumn1;
        private OLVColumn olvColumn2;
        private System.Windows.Forms.TextBox tbFilter;
    }
}

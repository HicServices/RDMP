using CatalogueManager.MainFormUITabs; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved

namespace CatalogueManager
{
    partial class CatalogueManagerMainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CatalogueManagerMainForm));
            this.tpTableInfo = new System.Windows.Forms.TabPage();
            this.tableInfoTab1 = new CatalogueManager.MainFormUITabs.TableInfoTab();
            this.tpCatalogues = new System.Windows.Forms.TabPage();
            this.catalogueAndItemsTab1 = new CatalogueManager.MainFormUITabs.CatalogueAndItemsTab();
            this.tabPane1 = new System.Windows.Forms.TabControl();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.databaseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.changeCatalogueToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.configureExternalServersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.setTicketingSystemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.adjustFileLocationsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.refreshToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadMetadataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.governanceManagementToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logViewerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.issuesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.generateReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.issueReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.databaseAccessComplexToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.metadataReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.governanceReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.serverSpecReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dITAExtractionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.testsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.launchDiagnosticsScreenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.generateTestDataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uploadPluginToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.showPerformanceCounterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clearAllAutocompleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.indexesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mi_CatalogueDatabaseIndexRebuild = new System.Windows.Forms.ToolStripMenuItem();
            this.mi_DataExportDatabaseIndexRebuild = new System.Windows.Forms.ToolStripMenuItem();
            this.openExeDirectoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.userManualToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.generateClassTableSummaryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.generateUserInterfaceDocumentationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tpTableInfo.SuspendLayout();
            this.tpCatalogues.SuspendLayout();
            this.tabPane1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tpTableInfo
            // 
            this.tpTableInfo.Controls.Add(this.tableInfoTab1);
            this.tpTableInfo.Location = new System.Drawing.Point(4, 22);
            this.tpTableInfo.Name = "tpTableInfo";
            this.tpTableInfo.Padding = new System.Windows.Forms.Padding(3);
            this.tpTableInfo.Size = new System.Drawing.Size(1337, 912);
            this.tpTableInfo.TabIndex = 2;
            this.tpTableInfo.Text = "TableInfos";
            this.tpTableInfo.UseVisualStyleBackColor = true;
            // 
            // tableInfoTab1
            // 
            this.tableInfoTab1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableInfoTab1.Location = new System.Drawing.Point(3, 3);
            this.tableInfoTab1.Name = "tableInfoTab1";
            this.tableInfoTab1.RepositoryLocator = null;
            this.tableInfoTab1.Size = new System.Drawing.Size(1331, 906);
            this.tableInfoTab1.TabIndex = 0;
            this.tableInfoTab1.VisualStudioDesignMode = true;
            // 
            // tpCatalogues
            // 
            this.tpCatalogues.Controls.Add(this.catalogueAndItemsTab1);
            this.tpCatalogues.Location = new System.Drawing.Point(4, 22);
            this.tpCatalogues.Name = "tpCatalogues";
            this.tpCatalogues.Padding = new System.Windows.Forms.Padding(3);
            this.tpCatalogues.Size = new System.Drawing.Size(1337, 912);
            this.tpCatalogues.TabIndex = 0;
            this.tpCatalogues.Text = "Catalogues / CatalogueItems";
            this.tpCatalogues.UseVisualStyleBackColor = true;
            this.tpCatalogues.Leave += new System.EventHandler(this.tpCatalogues_Leave);
            // 
            // catalogueAndItemsTab1
            // 
            this.catalogueAndItemsTab1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.catalogueAndItemsTab1.Location = new System.Drawing.Point(3, 3);
            this.catalogueAndItemsTab1.Name = "catalogueAndItemsTab1";
            this.catalogueAndItemsTab1.RepositoryLocator = null;
            this.catalogueAndItemsTab1.Size = new System.Drawing.Size(1331, 906);
            this.catalogueAndItemsTab1.TabIndex = 0;
            this.catalogueAndItemsTab1.VisualStudioDesignMode = true;
            // 
            // tabPane1
            // 
            this.tabPane1.Controls.Add(this.tpCatalogues);
            this.tabPane1.Controls.Add(this.tpTableInfo);
            this.tabPane1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabPane1.Location = new System.Drawing.Point(0, 24);
            this.tabPane1.Name = "tabPane1";
            this.tabPane1.SelectedIndex = 0;
            this.tabPane1.ShowToolTips = true;
            this.tabPane1.Size = new System.Drawing.Size(1345, 938);
            this.tabPane1.SizeMode = System.Windows.Forms.TabSizeMode.FillToRight;
            this.tabPane1.TabIndex = 54;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.databaseToolStripMenuItem,
            this.viewToolStripMenuItem,
            this.issuesToolStripMenuItem,
            this.testsToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1345, 24);
            this.menuStrip1.TabIndex = 55;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // databaseToolStripMenuItem
            // 
            this.databaseToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.changeCatalogueToolStripMenuItem,
            this.configureExternalServersToolStripMenuItem,
            this.setTicketingSystemToolStripMenuItem,
            this.adjustFileLocationsToolStripMenuItem,
            this.refreshToolStripMenuItem});
            this.databaseToolStripMenuItem.Name = "databaseToolStripMenuItem";
            this.databaseToolStripMenuItem.Size = new System.Drawing.Size(70, 20);
            this.databaseToolStripMenuItem.Text = "Locations";
            // 
            // changeCatalogueToolStripMenuItem
            // 
            this.changeCatalogueToolStripMenuItem.Name = "changeCatalogueToolStripMenuItem";
            this.changeCatalogueToolStripMenuItem.Size = new System.Drawing.Size(295, 22);
            this.changeCatalogueToolStripMenuItem.Text = "Change Platform Databases...";
            this.changeCatalogueToolStripMenuItem.Click += new System.EventHandler(this.changeCatalogueToolStripMenuItem_Click);
            // 
            // configureExternalServersToolStripMenuItem
            // 
            this.configureExternalServersToolStripMenuItem.Name = "configureExternalServersToolStripMenuItem";
            this.configureExternalServersToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.M)));
            this.configureExternalServersToolStripMenuItem.Size = new System.Drawing.Size(295, 22);
            this.configureExternalServersToolStripMenuItem.Text = "Manage Known External Servers...";
            this.configureExternalServersToolStripMenuItem.Click += new System.EventHandler(this.configureExternalServersToolStripMenuItem_Click);
            // 
            // setTicketingSystemToolStripMenuItem
            // 
            this.setTicketingSystemToolStripMenuItem.Name = "setTicketingSystemToolStripMenuItem";
            this.setTicketingSystemToolStripMenuItem.Size = new System.Drawing.Size(295, 22);
            this.setTicketingSystemToolStripMenuItem.Text = "Set Ticketing System...";
            this.setTicketingSystemToolStripMenuItem.Click += new System.EventHandler(this.setTicketingSystemToolStripMenuItem_Click);
            // 
            // adjustFileLocationsToolStripMenuItem
            // 
            this.adjustFileLocationsToolStripMenuItem.Name = "adjustFileLocationsToolStripMenuItem";
            this.adjustFileLocationsToolStripMenuItem.Size = new System.Drawing.Size(295, 22);
            this.adjustFileLocationsToolStripMenuItem.Text = "Adjust File Locations...";
            this.adjustFileLocationsToolStripMenuItem.Click += new System.EventHandler(this.adjustFileLocationsToolStripMenuItem_Click);
            // 
            // refreshToolStripMenuItem
            // 
            this.refreshToolStripMenuItem.Name = "refreshToolStripMenuItem";
            this.refreshToolStripMenuItem.Size = new System.Drawing.Size(295, 22);
            this.refreshToolStripMenuItem.Text = "Refresh All";
            this.refreshToolStripMenuItem.Click += new System.EventHandler(this.refreshToolStripMenuItem_Click);
            // 
            // viewToolStripMenuItem
            // 
            this.viewToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loadMetadataToolStripMenuItem,
            this.governanceManagementToolStripMenuItem,
            this.logViewerToolStripMenuItem});
            this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
            this.viewToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.viewToolStripMenuItem.Text = "View";
            // 
            // loadMetadataToolStripMenuItem
            // 
            this.loadMetadataToolStripMenuItem.Name = "loadMetadataToolStripMenuItem";
            this.loadMetadataToolStripMenuItem.Size = new System.Drawing.Size(220, 22);
            this.loadMetadataToolStripMenuItem.Text = "Load Metadata...";
            this.loadMetadataToolStripMenuItem.Click += new System.EventHandler(this.loadMetadataToolStripMenuItem_Click);
            // 
            // governanceManagementToolStripMenuItem
            // 
            this.governanceManagementToolStripMenuItem.Name = "governanceManagementToolStripMenuItem";
            this.governanceManagementToolStripMenuItem.Size = new System.Drawing.Size(220, 22);
            this.governanceManagementToolStripMenuItem.Text = "Governance Management...";
            this.governanceManagementToolStripMenuItem.Click += new System.EventHandler(this.governanceManagementToolStripMenuItem_Click);
            // 
            // logViewerToolStripMenuItem
            // 
            this.logViewerToolStripMenuItem.Name = "logViewerToolStripMenuItem";
            this.logViewerToolStripMenuItem.Size = new System.Drawing.Size(220, 22);
            this.logViewerToolStripMenuItem.Text = "Log Viewer...";
            this.logViewerToolStripMenuItem.Click += new System.EventHandler(this.logViewerToolStripMenuItem_Click);
            // 
            // issuesToolStripMenuItem
            // 
            this.issuesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.generateReportToolStripMenuItem});
            this.issuesToolStripMenuItem.Name = "issuesToolStripMenuItem";
            this.issuesToolStripMenuItem.Size = new System.Drawing.Size(59, 20);
            this.issuesToolStripMenuItem.Text = "Reports";
            // 
            // generateReportToolStripMenuItem
            // 
            this.generateReportToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.issueReportToolStripMenuItem,
            this.databaseAccessComplexToolStripMenuItem,
            this.metadataReportToolStripMenuItem,
            this.governanceReportToolStripMenuItem,
            this.serverSpecReportToolStripMenuItem,
            this.dITAExtractionToolStripMenuItem});
            this.generateReportToolStripMenuItem.Name = "generateReportToolStripMenuItem";
            this.generateReportToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.generateReportToolStripMenuItem.Text = "Generate...";
            // 
            // issueReportToolStripMenuItem
            // 
            this.issueReportToolStripMenuItem.Name = "issueReportToolStripMenuItem";
            this.issueReportToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.issueReportToolStripMenuItem.Text = "Issue Report";
            this.issueReportToolStripMenuItem.Click += new System.EventHandler(this.issueReportToolStripMenuItem_Click);
            // 
            // databaseAccessComplexToolStripMenuItem
            // 
            this.databaseAccessComplexToolStripMenuItem.Name = "databaseAccessComplexToolStripMenuItem";
            this.databaseAccessComplexToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.databaseAccessComplexToolStripMenuItem.Text = "Database Access Report...";
            this.databaseAccessComplexToolStripMenuItem.Click += new System.EventHandler(this.databaseAccessComplexToolStripMenuItem_Click);
            // 
            // metadataReportToolStripMenuItem
            // 
            this.metadataReportToolStripMenuItem.Name = "metadataReportToolStripMenuItem";
            this.metadataReportToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.metadataReportToolStripMenuItem.Text = "Metadata Report...";
            this.metadataReportToolStripMenuItem.Click += new System.EventHandler(this.metadataReportToolStripMenuItem_Click);
            // 
            // governanceReportToolStripMenuItem
            // 
            this.governanceReportToolStripMenuItem.Name = "governanceReportToolStripMenuItem";
            this.governanceReportToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.governanceReportToolStripMenuItem.Text = "Governance Report";
            this.governanceReportToolStripMenuItem.Click += new System.EventHandler(this.governanceReportToolStripMenuItem_Click);
            // 
            // serverSpecReportToolStripMenuItem
            // 
            this.serverSpecReportToolStripMenuItem.Name = "serverSpecReportToolStripMenuItem";
            this.serverSpecReportToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.serverSpecReportToolStripMenuItem.Text = "Server Spec Report";
            this.serverSpecReportToolStripMenuItem.Click += new System.EventHandler(this.serverSpecReportToolStripMenuItem_Click);
            // 
            // dITAExtractionToolStripMenuItem
            // 
            this.dITAExtractionToolStripMenuItem.Name = "dITAExtractionToolStripMenuItem";
            this.dITAExtractionToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.dITAExtractionToolStripMenuItem.Text = "DITA Extraction...";
            this.dITAExtractionToolStripMenuItem.Click += new System.EventHandler(this.dITAExtractionToolStripMenuItem_Click);
            // 
            // testsToolStripMenuItem
            // 
            this.testsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.launchDiagnosticsScreenToolStripMenuItem,
            this.generateTestDataToolStripMenuItem,
            this.uploadPluginToolStripMenuItem,
            this.toolStripSeparator1,
            this.showPerformanceCounterToolStripMenuItem,
            this.clearAllAutocompleteToolStripMenuItem,
            this.indexesToolStripMenuItem,
            this.openExeDirectoryToolStripMenuItem});
            this.testsToolStripMenuItem.Name = "testsToolStripMenuItem";
            this.testsToolStripMenuItem.Size = new System.Drawing.Size(80, 20);
            this.testsToolStripMenuItem.Text = "Diagnostics";
            // 
            // launchDiagnosticsScreenToolStripMenuItem
            // 
            this.launchDiagnosticsScreenToolStripMenuItem.Name = "launchDiagnosticsScreenToolStripMenuItem";
            this.launchDiagnosticsScreenToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D)));
            this.launchDiagnosticsScreenToolStripMenuItem.Size = new System.Drawing.Size(266, 22);
            this.launchDiagnosticsScreenToolStripMenuItem.Text = "Launch Diagnostics Screen...";
            this.launchDiagnosticsScreenToolStripMenuItem.Click += new System.EventHandler(this.launchDiagnosticsScreen_Click);
            // 
            // generateTestDataToolStripMenuItem
            // 
            this.generateTestDataToolStripMenuItem.Name = "generateTestDataToolStripMenuItem";
            this.generateTestDataToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.G)));
            this.generateTestDataToolStripMenuItem.Size = new System.Drawing.Size(266, 22);
            this.generateTestDataToolStripMenuItem.Text = "Generate Test Data...";
            this.generateTestDataToolStripMenuItem.Click += new System.EventHandler(this.generateTestDataToolStripMenuItem_Click);
            // 
            // uploadPluginToolStripMenuItem
            // 
            this.uploadPluginToolStripMenuItem.Name = "uploadPluginToolStripMenuItem";
            this.uploadPluginToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.U)));
            this.uploadPluginToolStripMenuItem.Size = new System.Drawing.Size(266, 22);
            this.uploadPluginToolStripMenuItem.Text = "Upload Plugin...";
            this.uploadPluginToolStripMenuItem.Click += new System.EventHandler(this.uploadPluginToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(263, 6);
            // 
            // showPerformanceCounterToolStripMenuItem
            // 
            this.showPerformanceCounterToolStripMenuItem.Name = "showPerformanceCounterToolStripMenuItem";
            this.showPerformanceCounterToolStripMenuItem.Size = new System.Drawing.Size(266, 22);
            this.showPerformanceCounterToolStripMenuItem.Text = "Show Performance Counter...";
            this.showPerformanceCounterToolStripMenuItem.Click += new System.EventHandler(this.showPerformanceCounterToolStripMenuItem_Click);
            // 
            // clearAllAutocompleteToolStripMenuItem
            // 
            this.clearAllAutocompleteToolStripMenuItem.Name = "clearAllAutocompleteToolStripMenuItem";
            this.clearAllAutocompleteToolStripMenuItem.Size = new System.Drawing.Size(266, 22);
            this.clearAllAutocompleteToolStripMenuItem.Text = "Clear All Autocomplete";
            this.clearAllAutocompleteToolStripMenuItem.Click += new System.EventHandler(this.clearAllAutocompleteToolStripMenuItem_Click);
            // 
            // indexesToolStripMenuItem
            // 
            this.indexesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mi_CatalogueDatabaseIndexRebuild,
            this.mi_DataExportDatabaseIndexRebuild});
            this.indexesToolStripMenuItem.Name = "indexesToolStripMenuItem";
            this.indexesToolStripMenuItem.Size = new System.Drawing.Size(266, 22);
            this.indexesToolStripMenuItem.Text = "Rebuild Indexes";
            // 
            // mi_CatalogueDatabaseIndexRebuild
            // 
            this.mi_CatalogueDatabaseIndexRebuild.Name = "mi_CatalogueDatabaseIndexRebuild";
            this.mi_CatalogueDatabaseIndexRebuild.Size = new System.Drawing.Size(270, 22);
            this.mi_CatalogueDatabaseIndexRebuild.Text = "Rebuild Catalogue Database Indexes";
            this.mi_CatalogueDatabaseIndexRebuild.Click += new System.EventHandler(this.mi_RebuildIndex_Click);
            // 
            // mi_DataExportDatabaseIndexRebuild
            // 
            this.mi_DataExportDatabaseIndexRebuild.Name = "mi_DataExportDatabaseIndexRebuild";
            this.mi_DataExportDatabaseIndexRebuild.Size = new System.Drawing.Size(270, 22);
            this.mi_DataExportDatabaseIndexRebuild.Text = "Rebuild Data Export Database Indexes";
            this.mi_DataExportDatabaseIndexRebuild.Click += new System.EventHandler(this.mi_RebuildIndex_Click);
            // 
            // openExeDirectoryToolStripMenuItem
            // 
            this.openExeDirectoryToolStripMenuItem.Name = "openExeDirectoryToolStripMenuItem";
            this.openExeDirectoryToolStripMenuItem.Size = new System.Drawing.Size(266, 22);
            this.openExeDirectoryToolStripMenuItem.Text = "Open exe Directory";
            this.openExeDirectoryToolStripMenuItem.Click += new System.EventHandler(this.openExeDirectoryToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.userManualToolStripMenuItem,
            this.generateClassTableSummaryToolStripMenuItem,
            this.generateUserInterfaceDocumentationToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // userManualToolStripMenuItem
            // 
            this.userManualToolStripMenuItem.Name = "userManualToolStripMenuItem";
            this.userManualToolStripMenuItem.Size = new System.Drawing.Size(291, 22);
            this.userManualToolStripMenuItem.Text = "Show User Manual";
            this.userManualToolStripMenuItem.Click += new System.EventHandler(this.userManualToolStripMenuItem_Click);
            // 
            // generateClassTableSummaryToolStripMenuItem
            // 
            this.generateClassTableSummaryToolStripMenuItem.Name = "generateClassTableSummaryToolStripMenuItem";
            this.generateClassTableSummaryToolStripMenuItem.Size = new System.Drawing.Size(291, 22);
            this.generateClassTableSummaryToolStripMenuItem.Text = "Generate Class/Table Summary";
            this.generateClassTableSummaryToolStripMenuItem.Click += new System.EventHandler(this.generateClassTableSummaryToolStripMenuItem_Click);
            // 
            // generateUserInterfaceDocumentationToolStripMenuItem
            // 
            this.generateUserInterfaceDocumentationToolStripMenuItem.Name = "generateUserInterfaceDocumentationToolStripMenuItem";
            this.generateUserInterfaceDocumentationToolStripMenuItem.Size = new System.Drawing.Size(291, 22);
            this.generateUserInterfaceDocumentationToolStripMenuItem.Text = "Generate User Interface Documentation...";
            this.generateUserInterfaceDocumentationToolStripMenuItem.Click += new System.EventHandler(this.generateUserInterfaceDocumentationToolStripMenuItem_Click);
            // 
            // CatalogueManagerMainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1345, 962);
            this.Controls.Add(this.tabPane1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "CatalogueManagerMainForm";
            this.Text = "CatalogueManager";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.CatalogueManager_Load);
            this.tpTableInfo.ResumeLayout(false);
            this.tpCatalogues.ResumeLayout(false);
            this.tabPane1.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabPage tpTableInfo;
        private System.Windows.Forms.TabPage tpCatalogues;
        private System.Windows.Forms.TabControl tabPane1;
        private TableInfoTab tableInfoTab1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem databaseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem changeCatalogueToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem refreshToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem issuesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem configureExternalServersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem testsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem launchDiagnosticsScreenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showPerformanceCounterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clearAllAutocompleteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openExeDirectoryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem setTicketingSystemToolStripMenuItem;
        private CatalogueAndItemsTab catalogueAndItemsTab1;
        private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem governanceManagementToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadMetadataToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem generateTestDataToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logViewerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem indexesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mi_CatalogueDatabaseIndexRebuild;
        private System.Windows.Forms.ToolStripMenuItem mi_DataExportDatabaseIndexRebuild;
        private System.Windows.Forms.ToolStripMenuItem adjustFileLocationsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uploadPluginToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem userManualToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem generateReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem issueReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem databaseAccessComplexToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem metadataReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem governanceReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem serverSpecReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dITAExtractionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem generateClassTableSummaryToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem generateUserInterfaceDocumentationToolStripMenuItem;


    }
}


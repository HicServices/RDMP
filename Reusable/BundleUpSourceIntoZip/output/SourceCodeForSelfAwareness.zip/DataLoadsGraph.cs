using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Threading;
using System.Windows.Forms;
using CatalogueLibrary.Data;
using CatalogueLibrary.Data.DataLoad;
using CatalogueManager.TestsAndSetup.ServicePropogation;
using HIC.Logging;
using HIC.Logging.PastEvents;
using ReusableUIComponents;

namespace Dashboard.Overview
{
    /// <summary>
    /// Displays a graph showing how many of your data loads passed the last time they were run and which data loads are currently failing.  This includes a division between data loads
    /// configured for automation (See LoadPeriodicallyUI) and those run manually.  If you have not configured any data loads yet then this control will be blank.
    /// </summary>
    public partial class DataLoadsGraph : RDMPUserControl
    {
        public DataLoadsGraph()
        {
            InitializeComponent();
        }

        public void RefreshChartAsync()
        {
            if (VisualStudioDesignMode)
                return;

            pbLoading.Visible = true;
            listView1.Items.Clear();

            Thread t = new Thread(() =>
            {
                try
                {
                    int countAutoLoadSuccesful = 0;
                    int countAutoLoadFailure = 0;
                    int countManualLoadSuccesful = 0;
                    int countManualLoadFailure = 0;

                    bool bSuppressErrors = false;



                    foreach (LoadMetadata metadata in RepositoryLocator.CatalogueRepository.GetAllObjects<LoadMetadata>())
                    {
                        try
                        {
                            LogManager logManager;

                            try
                            {
                                //get the logging connection
                                logManager = new LogManager(metadata.GetDistinctLoggingDatabaseSettings(), ProgressLogging.GetInstance(), FatalErrorLogging.GetInstance(), RowErrorLogging.GetInstance());
                            }
                            catch (NotSupportedException e)
                            {
                                //sometimes a load metadata won't have any catalogues so we can't process it's log history
                                if(e.Message.Contains("does not have any Catalogues associated with it"))
                                    continue;
                                
                                throw;
                            }

                            ArchivalDataLoadInfo archivalDataLoadInfo = logManager.GetLoadStatusOf(PastEventType.MostRecent, metadata.GetDistinctLoggingTask());

                            bool isAutomated = metadata.LoadPeriodically != null;

                            bool lastLoadWasError;
                            if (archivalDataLoadInfo == null)
                                continue; //has never been run (or has had test runs only)
                            else
                                lastLoadWasError = archivalDataLoadInfo.Errors.Any() || archivalDataLoadInfo.EndTime == null;

                            //while we were fetching data from database the form was closed
                            if (IsDisposed || !IsHandleCreated)
                                return;

                            if (isAutomated && lastLoadWasError)
                            {
                                countAutoLoadFailure++;
                                this.Invoke(new MethodInvoker(() =>
                                {
                                    ListViewItem i = new ListViewItem(metadata.ID.ToString());
                                    i.SubItems.Add(metadata.Name);
                                    i.SubItems.Add("Auto");
                                    listView1.Items.Add(i);

                                    ResizeColumns();
                                }));

                            }
                            if (isAutomated && !lastLoadWasError)
                                countAutoLoadSuccesful++;
                            if (!isAutomated && lastLoadWasError)
                            {
                                countManualLoadFailure++;

                                this.Invoke(new MethodInvoker(() =>
                                {
                                    ListViewItem i = new ListViewItem(metadata.ID.ToString());
                                    i.SubItems.Add(metadata.Name);
                                    i.SubItems.Add("Manual");
                                    listView1.Items.Add(i);

                                    ResizeColumns();
                                }));

                            }
                            if (!isAutomated && !lastLoadWasError)
                                countManualLoadSuccesful++;
                        }
                        catch (Exception e)
                        {
                            if (bSuppressErrors)
                                continue;

                            ExceptionViewer.Show("Could not process log history for load metadata " + metadata.Name + " (see inner exception for details)" ,e);
                            bSuppressErrors =
                                MessageBox.Show(
                                    "Would you like to suppress other errors generated while loading this DataLoadsGraph (only affects this run of the app)?",
                                    "Suppress", MessageBoxButtons.YesNo) == DialogResult.Yes;
                        }
                    }


                    //if there have been no loads at all ever
                    if (countAutoLoadFailure == 0 && countAutoLoadFailure == 0 && countManualLoadSuccesful == 0 && countManualLoadFailure == 0)
                    {
                        this.Invoke(new MethodInvoker(() =>
                        {
                            lblNoDataLoadsFound.Visible = true;
                            chart1.Visible = false;
                            pbLoading.Visible = false;
                        }));
                        
                        return;
                    }

                    DataTable dt = new DataTable();
                    dt.Columns.Add("Category");
                    dt.Columns.Add("NumberOfDataLoadsAtStatus");

                    dt.Rows.Add(new object[] { "Auto Successful", countAutoLoadSuccesful });
                    dt.Rows.Add(new object[] { "Auto Fail", countAutoLoadFailure });
                    dt.Rows.Add(new object[] { "Manual Successful", countManualLoadSuccesful });
                    dt.Rows.Add(new object[] { "Manual Fail", countManualLoadFailure });


                    this.Invoke(new MethodInvoker(() =>
                    {
                        chart1.Series[0].XValueMember = "Category";
                        chart1.Series[0].YValueMembers = "NumberOfDataLoadsAtStatus";

                        chart1.DataSource = dt;
                        chart1.DataBind();

                        chart1.Series[0].Points[0].Color = Color.Green;
                        chart1.Series[0].Points[1].Color = Color.Red;
                        chart1.Series[0].Points[2].Color = Color.Green;
                        chart1.Series[0].Points[3].Color = Color.Red;

                        pbLoading.Visible = false;
                    }));
                }
                catch (Exception e)
                {
                    this.Invoke(new MethodInvoker(() =>
                    {
                        pbTotalFailure.Visible = true;
                        pbLoading.Visible = false;
                    }));

                    ExceptionViewer.Show(this.GetType().Name + " failed to load data",e);
                }

            });
            t.SetApartmentState(ApartmentState.STA);
            t.Start();
        }

        private void ResizeColumns()
        {
            foreach (ColumnHeader column in listView1.Columns)
                column.Width = -2; //magical (apparently it resizes to max width of content or header)
        }
    }
}

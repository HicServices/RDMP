using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using CatalogueLibrary.Data;
using CatalogueLibrary.Data.Aggregation;
using CatalogueLibrary.Data.Cohort;
using CatalogueLibrary.DataHelper;
using CatalogueLibrary.QueryBuilding;
using CatalogueManager.ExtractionUIs.FilterUIs;
using CatalogueManager.MainFormUITabs;
using CatalogueManager.SimpleDialogs;
using CatalogueManager.SimpleDialogs.Revertable;
using MapsDirectlyToDatabaseTable.Revertable;
using ReusableUIComponents;
using ScintillaNET;
using IContainer = CatalogueLibrary.Data.IContainer;

namespace CatalogueManager.AggregationUIs
{
    /// <summary>
    /// Allows you to specify an SQL GROUP BY statement.  This is stored in the RDMP database as an AggregateConfiguration.  AggregateConfigurations (GROUP BY statements) are used to
    /// generate graphs that highlight interesting features of your datasets and are also the core entity behind cohort generation in Cohort Manager.  This form lets you decide whether
    /// an Aggregate is Extractable (which when ticked will make it come out in Data Export Manager extracts and accessible in the Metadata Report), DO NOT TICK EXTRACTABLE if your aggregate
    /// has identifiable data in it somehow.
    /// 
    /// You should ensure that your Name and Description accurately describe what the GROUP BY does.  At any time you can view what the GROUP BY does by selecting 'SQL Preview' tab.  Use the
    /// Dimensions tab to add other GROUP BY columns (including inventing transforms e.g. YEAR(Bob)).  Use the Filters tab to add WHERE blocks and AND/OR containers.  You can type in custom 
    /// COUNT sql e.g. count(distinct CHI) as UniquePatients.  You can also select a PIVOT column (adds multiple lines to a graph e.g. 1 per healthboard) - make sure your pivot column has only 
    /// a few unique values (i.e. make sure it is a categorical field).
    /// </summary>
    public partial class AggregateConfigurationUI : UserControl
    {
        private AggregateConfiguration _aggregateConfiguration;

        private bool bLoading = false;
        protected Scintilla QueryPreview { get; set; }
        protected Scintilla CountSql { get; set; }
        protected Scintilla HavingSql { get; set; }

        public event EventHandler ChangesSaved;

        public AggregateConfiguration AggregateConfiguration
        {
            get { return _aggregateConfiguration; }
            set
            {
                OfferChanceToSave();

                bLoading = true;

                _aggregateConfiguration = value;

                aggregateDimensionManagementTabUI1.AggregateConfiguration = value;
                aggregateFilterConfigurationTabUI1.AggregateConfiguration = value;
                aggregateGraph1.SetAggregateConfigurationButDontLoadGraphYet(value);

                btnSaveDescriptiveData.Enabled = false;
                
                if (value == null)
                {
                    Enabled = false;
                    tbName.Text = "";
                    tbDescription.Text = "";
                    tbCreated.Text = "";
                    tbID.Text = "";
                    
                    if (CountSql != null)//will be null in WindowsFormsDesigner mode
                      CountSql.Text = "";
                    
                    if (HavingSql != null)//will be null in WindowsFormsDesigner mode
                        HavingSql.Text = "";

                    cbIsExtractable.Enabled = false;
                    
                }
                else
                {
                    Enabled = true;
                    
                    tbName.Text = value.Name;
                    tbDescription.Text = value.Description;
                    tbCreated.Text = value.dtCreated.ToString();
                    tbID.Text = value.ID.ToString();
                    
                    if (CountSql != null)//will be null in WindowsFormsDesigner mode
                        CountSql.Text = value.CountSQL;

                    if (HavingSql != null)//will be null in WindowsFormsDesigner mode
                        HavingSql.Text = value.HavingSQL;

                    cbIsExtractable.Enabled = true;
                    cbIsExtractable.Checked = value.IsExtractable;

                    try
                    {
                        RefreshDimensions();
                    }
                    catch (Exception e)
                    {
                        ExceptionViewer.Show(e);
                    }

                }
                bLoading = false;
            }
        }

        private void RegenerateSQL()
        {
            if(AggregateConfiguration == null)
                return;
            
            QueryPreview.IsReadOnly = false;
            try
            {
                AggregateBuilder builder = AggregateConfiguration.GetQueryBuilder();
                QueryPreview.Text = builder.SQL;
            }
            catch (SyntaxErrorException e)
            {
                QueryPreview.Text = e.ToString();
            }
            catch (QueryBuildingException e)
            {
                QueryPreview.Text = e.ToString();
            }
            QueryPreview.IsReadOnly = true;
        }


        private void RefreshDimensions()
        {
            ddPivotDimension.Items.Clear();
            
            if (AggregateConfiguration != null)
                ddPivotDimension.Items.AddRange(AggregateConfiguration.AggregateDimensions.ToArray());
           RegenerateSQL();
        }

        public AggregateConfigurationUI()
        {
            InitializeComponent();
            
            //reset to the default for this UI control
            AggregateGraph.Timeout = 30;
            
            #region Query Editor setup
            bool designMode = (LicenseManager.UsageMode == LicenseUsageMode.Designtime);

            if (designMode) //dont add the QueryEditor if we are in design time (visual studio) because it breaks
                return;


            QueryPreview = new Scintilla();
            QueryPreview.Dock = DockStyle.Fill;
            QueryPreview.Scrolling.ScrollBars = ScrollBars.Both;
            QueryPreview.ConfigurationManager.Language = "mssql";
            QueryPreview.Margins[0].Width = 40; //allows display of line numbers
            QueryPreview.IsReadOnly = true;


            tpSqlPreview.Controls.Add(QueryPreview);

            CountSql = new Scintilla();
            CountSql.Dock = DockStyle.Fill;
            CountSql.Scrolling.ScrollBars = ScrollBars.Both;
            CountSql.ConfigurationManager.Language = "mssql";
            CountSql.Margins[0].Width = 40; //allows display of line numbers
            CountSql.IsReadOnly = false;
            CountSql.TextChanged += new EventHandler(CountSql_TextChanged);
            pCountSql.Controls.Add(CountSql);



            HavingSql = new Scintilla();
            HavingSql.Dock = DockStyle.Fill;
            HavingSql.Scrolling.ScrollBars = ScrollBars.Both;
            HavingSql.ConfigurationManager.Language = "mssql";
            HavingSql.Margins[0].Width = 40; //allows display of line numbers
            HavingSql.IsReadOnly = false;
            HavingSql.TextChanged += HavingSqlOnTextChanged;
            pHavingSQL.Controls.Add(HavingSql);
            #endregion

            aggregateDimensionManagementTabUI1.DimensionsRefreshed += RefreshDimensions;
        }

        protected override bool ProcessKeyPreview(ref Message m)
        {

            PreviewKey p = new PreviewKey(ref m, ModifierKeys);

            if (p.IsKeyDownMessage && p.e.KeyCode == Keys.S && p.e.Control)
            {
                //only use the save button on descriptive
                if(tabControl1.SelectedTab == tpDescriptive)
                {
                    btnbtnSaveDescriptiveData_Click(null,null);
                    p.Trap(this);
                }
            }

            return base.ProcessKeyPreview(ref m);
        }


        private void btnbtnSaveDescriptiveData_Click(object sender, EventArgs e)
        {
            if(_aggregateConfiguration != null)
            {
                _aggregateConfiguration.SaveToDatabase();
                btnSaveDescriptiveData.Enabled = false;
                
                if(ChangesSaved != null)
                    ChangesSaved(this, new EventArgs());
            }
        }

        private void tbName_TextChanged(object sender, EventArgs e)
        {
            if (_aggregateConfiguration != null && !bLoading)
            {
                if (string.IsNullOrWhiteSpace(tbName.Text))
                {
                    tbName.Text = "No Name";
                    tbName.SelectAll();
                }

                _aggregateConfiguration.Name = tbName.Text;
                
                btnSaveDescriptiveData.Enabled = true;
            }
        }

        private void tbDescription_TextChanged(object sender, EventArgs e)
        {
            if (_aggregateConfiguration != null && !bLoading)
            {
                _aggregateConfiguration.Description = tbDescription.Text;
                btnSaveDescriptiveData.Enabled = true;
            }
        }

        void CountSql_TextChanged(object sender, EventArgs e)
        {
            if (_aggregateConfiguration != null && !bLoading)
            {
                _aggregateConfiguration.CountSQL = CountSql.Text;
                btnSaveDescriptiveData.Enabled = true;
            }   
        }


        private void HavingSqlOnTextChanged(object sender, EventArgs eventArgs)
        {
            if (_aggregateConfiguration != null && !bLoading)
            {
                _aggregateConfiguration.HavingSQL = HavingSql.Text;
                btnSaveDescriptiveData.Enabled = true;
            }   
        }

        private void btnClearPivotDimension_Click(object sender, EventArgs e)
        {
            if (AggregateConfiguration != null)
            {
                AggregateConfiguration.PivotOnDimensionID = null;
                AggregateConfiguration.SaveToDatabase();
                ddPivotDimension.SelectedItem = null;
            }
        }

        private void ddPivotDimension_SelectedIndexChanged(object sender, EventArgs e)
        {
            var dimension = ddPivotDimension.SelectedItem as AggregateDimension;

            if (dimension != null && AggregateConfiguration != null)
            {
                EnsureCountHasAlias();

                AggregateConfiguration.PivotOnDimensionID = dimension.ID;
                AggregateConfiguration.SaveToDatabase();
            }
        }

        private void EnsureCountHasAlias()
        {
            int lines = CountSql.Lines.Cast<Line>().Count(line => !string.IsNullOrWhiteSpace(line.Text));

            if (lines > 1)
                MessageBox.Show("Make sure when using PIVOT you can only have 1 count column");
            else
                if(lines == 1)
                {
                    string col;
                    string alias;

                    QuerySyntaxHelper.SplitLineIntoSelectSQLAndAlias(CountSql.Lines[0].Text, out col, out alias);

                    if (string.IsNullOrWhiteSpace(alias))
                        CountSql.Text = col + " as MyCount";

                }
        }


        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            OfferChanceToSave();

            if (tabControl1.SelectedTab == tpSqlPreview)
                RegenerateSQL();
        }
        
        private void cbIsExtractable_CheckedChanged(object sender, EventArgs e)
        {
            if (AggregateConfiguration != null)
            {
                AggregateConfiguration.IsExtractable = cbIsExtractable.Checked;
                AggregateConfiguration.SaveToDatabase();
            }
        }

        public static void PopupOnNewForm(AggregateConfiguration config)
        {
            AggregateConfigurationUI ui = new AggregateConfigurationUI();
            ui.AggregateConfiguration = config;
            ui.Dock = DockStyle.Fill;

            Form f = new Form();
            f.Controls.Add(ui);
            f.WindowState = FormWindowState.Maximized;
            f.ShowDialog();
        }
        
        private void AggregateConfigurationUI_Load(object sender, EventArgs e)
        {
            if (ParentForm != null)
                ParentForm.Closing += (a,b) => OfferChanceToSave();
        }

        private void OfferChanceToSave()
        {
            if(OfferChanceToSaveDialog.ShowIfRequired(_aggregateConfiguration) != null)
                if(ChangesSaved != null)
                    ChangesSaved(this, new EventArgs());
        }

        private void btnLoadGraph_Click(object sender, EventArgs e)
        {
            aggregateGraph1.AggregateConfiguration = AggregateConfiguration;
        }

        private void tbTimeoutOnGraphCreation_TextChanged(object sender, EventArgs e)
        {
            try
            {
                AggregateGraph.Timeout = int.Parse(tbTimeoutOnGraphCreation.Text);
                tbTimeoutOnGraphCreation.ForeColor = Color.Black;
            }
            catch (Exception exception)
            {
                tbTimeoutOnGraphCreation.ForeColor = Color.Red;
            }
        }

        private void btnSaveGraph_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.FileName = "Chart.jpg";
            sfd.Filter = "Jpeg|*.jpg";
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                aggregateGraph1.chart1.SaveImage(sfd.FileName,ChartImageFormat.Jpeg);
            }
            
        }

        public void Save()
        {
            //if they want to save and there are legit differences
            if(AggregateConfiguration != null && AggregateConfiguration.HasLocalChanges().Evaluation != ChangeDescription.NoChanges)
                btnbtnSaveDescriptiveData_Click(null,null);
        }

        private void btnConfigureDeclareParameters_Click(object sender, EventArgs e)
        {
            ParameterCollectionUI.ShowAsDialog(AggregateConfiguration);
            aggregateFilterConfigurationTabUI1.RefreshGlobalParametersFromDatabase();
        }
    }
}

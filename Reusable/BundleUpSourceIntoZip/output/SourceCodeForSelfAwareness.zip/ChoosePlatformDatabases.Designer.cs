using ReusableUIComponents; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved

namespace CatalogueManager.LocationsMenu
{
    partial class ChoosePlatformDatabases
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.tbCatalogueConnectionString = new ReusableUIComponents.ConnectionStringTextBox();
            this.btnSaveAndClose = new System.Windows.Forms.Button();
            this.gbSqlServer = new System.Windows.Forms.GroupBox();
            this.btnCreateNewDataExportManagerDatabase = new System.Windows.Forms.Button();
            this.btnCreateNewCatalogue = new System.Windows.Forms.Button();
            this.tbDataExportManagerConnectionString = new ReusableUIComponents.ConnectionStringTextBox();
            this.btnCheckDataExportManager = new System.Windows.Forms.Button();
            this.btnCheckCatalogue = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.checksUI1 = new ReusableUIComponents.ChecksUI.ChecksUI();
            this.btnShowRegistry = new System.Windows.Forms.Button();
            this.gbSqlServer.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(83, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Catalogue:";
            // 
            // tbCatalogueConnectionString
            // 
            this.tbCatalogueConnectionString.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbCatalogueConnectionString.DatabaseType = ReusableLibraryCode.DatabaseType.MicrosoftSQLServer;
            this.tbCatalogueConnectionString.ForeColor = System.Drawing.Color.Black;
            this.tbCatalogueConnectionString.Location = new System.Drawing.Point(165, 19);
            this.tbCatalogueConnectionString.Name = "tbCatalogueConnectionString";
            this.tbCatalogueConnectionString.Size = new System.Drawing.Size(957, 20);
            this.tbCatalogueConnectionString.TabIndex = 1;
            this.tbCatalogueConnectionString.Text = "";
            this.tbCatalogueConnectionString.KeyUp += new System.Windows.Forms.KeyEventHandler(this.tbCatalogueConnectionString_KeyUp);
            // 
            // btnSaveAndClose
            // 
            this.btnSaveAndClose.Location = new System.Drawing.Point(473, 149);
            this.btnSaveAndClose.Name = "btnSaveAndClose";
            this.btnSaveAndClose.Size = new System.Drawing.Size(274, 23);
            this.btnSaveAndClose.TabIndex = 5;
            this.btnSaveAndClose.Text = "Save and Close";
            this.btnSaveAndClose.UseVisualStyleBackColor = true;
            this.btnSaveAndClose.Click += new System.EventHandler(this.btnSaveAndClose_Click);
            // 
            // gbSqlServer
            // 
            this.gbSqlServer.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gbSqlServer.Controls.Add(this.btnCreateNewDataExportManagerDatabase);
            this.gbSqlServer.Controls.Add(this.btnCreateNewCatalogue);
            this.gbSqlServer.Controls.Add(this.tbDataExportManagerConnectionString);
            this.gbSqlServer.Controls.Add(this.btnCheckDataExportManager);
            this.gbSqlServer.Controls.Add(this.btnCheckCatalogue);
            this.gbSqlServer.Controls.Add(this.label8);
            this.gbSqlServer.Controls.Add(this.tbCatalogueConnectionString);
            this.gbSqlServer.Controls.Add(this.label1);
            this.gbSqlServer.Location = new System.Drawing.Point(6, 12);
            this.gbSqlServer.Name = "gbSqlServer";
            this.gbSqlServer.Size = new System.Drawing.Size(1248, 131);
            this.gbSqlServer.TabIndex = 3;
            this.gbSqlServer.TabStop = false;
            this.gbSqlServer.Text = "Connection Strings (SQL Server)";
            // 
            // btnCreateNewDataExportManagerDatabase
            // 
            this.btnCreateNewDataExportManagerDatabase.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCreateNewDataExportManagerDatabase.Location = new System.Drawing.Point(1128, 58);
            this.btnCreateNewDataExportManagerDatabase.Name = "btnCreateNewDataExportManagerDatabase";
            this.btnCreateNewDataExportManagerDatabase.Size = new System.Drawing.Size(101, 23);
            this.btnCreateNewDataExportManagerDatabase.TabIndex = 6;
            this.btnCreateNewDataExportManagerDatabase.Text = "Create New...";
            this.btnCreateNewDataExportManagerDatabase.UseVisualStyleBackColor = true;
            this.btnCreateNewDataExportManagerDatabase.Click += new System.EventHandler(this.btnCreateNewDataExportManagerDatabase_Click);
            // 
            // btnCreateNewCatalogue
            // 
            this.btnCreateNewCatalogue.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCreateNewCatalogue.Location = new System.Drawing.Point(1128, 20);
            this.btnCreateNewCatalogue.Name = "btnCreateNewCatalogue";
            this.btnCreateNewCatalogue.Size = new System.Drawing.Size(101, 23);
            this.btnCreateNewCatalogue.TabIndex = 6;
            this.btnCreateNewCatalogue.Text = "Create New...";
            this.btnCreateNewCatalogue.UseVisualStyleBackColor = true;
            this.btnCreateNewCatalogue.Click += new System.EventHandler(this.btnCreateNewCatalogue_Click);
            // 
            // tbDataExportManagerConnectionString
            // 
            this.tbDataExportManagerConnectionString.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbDataExportManagerConnectionString.DatabaseType = ReusableLibraryCode.DatabaseType.MicrosoftSQLServer;
            this.tbDataExportManagerConnectionString.ForeColor = System.Drawing.Color.Black;
            this.tbDataExportManagerConnectionString.Location = new System.Drawing.Point(165, 73);
            this.tbDataExportManagerConnectionString.Name = "tbDataExportManagerConnectionString";
            this.tbDataExportManagerConnectionString.Size = new System.Drawing.Size(957, 20);
            this.tbDataExportManagerConnectionString.TabIndex = 5;
            this.tbDataExportManagerConnectionString.Text = "";
            // 
            // btnCheckDataExportManager
            // 
            this.btnCheckDataExportManager.Location = new System.Drawing.Point(165, 99);
            this.btnCheckDataExportManager.Name = "btnCheckDataExportManager";
            this.btnCheckDataExportManager.Size = new System.Drawing.Size(64, 23);
            this.btnCheckDataExportManager.TabIndex = 5;
            this.btnCheckDataExportManager.Text = "Check";
            this.btnCheckDataExportManager.UseVisualStyleBackColor = true;
            this.btnCheckDataExportManager.Click += new System.EventHandler(this.btnCheckDataExportManager_Click);
            // 
            // btnCheckCatalogue
            // 
            this.btnCheckCatalogue.Location = new System.Drawing.Point(165, 44);
            this.btnCheckCatalogue.Name = "btnCheckCatalogue";
            this.btnCheckCatalogue.Size = new System.Drawing.Size(64, 23);
            this.btnCheckCatalogue.TabIndex = 5;
            this.btnCheckCatalogue.Text = "Check";
            this.btnCheckCatalogue.UseVisualStyleBackColor = true;
            this.btnCheckCatalogue.Click += new System.EventHandler(this.btnCheckCatalogue_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(48, 76);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(111, 13);
            this.label8.TabIndex = 4;
            this.label8.Text = "Data Export Manager:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 192);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Result:";
            // 
            // checksUI1
            // 
            this.checksUI1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.checksUI1.Location = new System.Drawing.Point(6, 208);
            this.checksUI1.Name = "checksUI1";
            this.checksUI1.Size = new System.Drawing.Size(1257, 403);
            this.checksUI1.TabIndex = 10;
            // 
            // btnShowRegistry
            // 
            this.btnShowRegistry.Location = new System.Drawing.Point(6, 149);
            this.btnShowRegistry.Name = "btnShowRegistry";
            this.btnShowRegistry.Size = new System.Drawing.Size(211, 23);
            this.btnShowRegistry.TabIndex = 11;
            this.btnShowRegistry.Text = "Show Registry Keys (Launches regedit)";
            this.btnShowRegistry.UseVisualStyleBackColor = true;
            this.btnShowRegistry.Click += new System.EventHandler(this.btnShowRegistry_Click);
            // 
            // ChoosePlatformDatabases
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1266, 615);
            this.Controls.Add(this.btnShowRegistry);
            this.Controls.Add(this.checksUI1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.gbSqlServer);
            this.Controls.Add(this.btnSaveAndClose);
            this.KeyPreview = true;
            this.Name = "ChoosePlatformDatabases";
            this.Text = "Configure DataManagementPlatform Core Databases";
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.ChooseDatabase_KeyUp);
            this.gbSqlServer.ResumeLayout(false);
            this.gbSqlServer.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private ConnectionStringTextBox tbCatalogueConnectionString;
        private System.Windows.Forms.Button btnSaveAndClose;
        private System.Windows.Forms.GroupBox gbSqlServer;
        private System.Windows.Forms.Label label2;
        private ConnectionStringTextBox tbDataExportManagerConnectionString;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnCreateNewDataExportManagerDatabase;
        private System.Windows.Forms.Button btnCreateNewCatalogue;
        private System.Windows.Forms.Button btnCheckDataExportManager;
        private System.Windows.Forms.Button btnCheckCatalogue;
        private ReusableUIComponents.ChecksUI.ChecksUI checksUI1;
        private System.Windows.Forms.Button btnShowRegistry;
    }
}

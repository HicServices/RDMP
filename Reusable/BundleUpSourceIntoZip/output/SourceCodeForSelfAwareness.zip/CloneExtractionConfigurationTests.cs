using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CatalogueLibrary.Data;
using DataExportManager2.Tests.DataExtraction;
using DataExportManager2Library.Data;
using DataExportManager2Library.Data.DataTables;
using DataExportManager2Library.ExtractionTime.ExtractionPipeline;
using DataExportManager2Library.ExtractionTime.UserPicks;
using NUnit.Framework;
using Rhino.Mocks.Constraints;


namespace DataExportManager2.Tests.Cloning
{
    public class CloneExtractionConfigurationTests:TestsRequiringAnExtractionConfiguration
    {
        [Test]
        public void CloneWithFilters()
        {

            var filter = new ExtractionFilter(CatalogueRepository, "FilterByFish", _extractionInformations[0]);
            try
            {
                //setup a filter with a parameter
                filter.WhereSQL = "Fish = @fish";
                filter.CreateOrDeleteParametersBasedOnSQL(null);
                filter.SaveToDatabase();

                Assert.IsTrue(filter.ExtractionFilterParameters.Count()==1);

                //create a root container
                var container =  new FilterContainer(DataExportRepository);
                container.SetAsRootContainerFor(_configuration,_extractableDataSet);

                //create a filter
                var deployedFilter = new DeployedExtractionFilter(DataExportRepository, "FilterByFishDeployed",container);
                deployedFilter.CopyValuesOutOfCatalogueVersion(filter);
                deployedFilter.CreateOrDeleteParametersBasedOnSQL(null);

                var param = deployedFilter.ExtractionFilterParameters[0];
                param.Value = "'jormungander'";
                param.SaveToDatabase();

                ExtractionRequest request = new ExtractionRequest(_configuration,new ExtractableDatasetBundle(_extractableDataSet));
                request.GenerateQueryBuilder();
                Assert.AreEqual(@"DECLARE @fish AS VARCHAR(50);
SET @fish='jormungander';
--The ID of the cohort in [RDMP_Tests_CohortDatabase]..[Cohort]
DECLARE @CohortDefinitionID AS int;
SET @CohortDefinitionID=-599;
--The project number of project RDMP_Tests_ExtractionConfiguration
DECLARE @ProjectNumber as int;
SET @ProjectNumber=1;

SELECT DISTINCT 
[RDMP_Tests_CohortDatabase]..[Cohort].[ReleaseID] AS ReleaseID,
[RDMP_Tests_ScratchArea]..[TestTable].[Result]
FROM 
[RDMP_Tests_ScratchArea]..[TestTable] INNER JOIN [RDMP_Tests_CohortDatabase]..[Cohort] ON [RDMP_Tests_ScratchArea]..[TestTable].[PrivateID]=[RDMP_Tests_CohortDatabase]..[Cohort].[PrivateID] collate Latin1_General_BIN

WHERE
(
--FilterByFishDeployed
Fish = @fish
)
AND
[RDMP_Tests_CohortDatabase]..[Cohort].[cohortDefinition_id]=-599
",request.QueryBuilder.SQL);

                ExtractionConfiguration deepClone = _configuration.DeepCloneWithNewIDs();
                Assert.AreEqual(deepClone.Cohort_ID,_configuration.Cohort_ID);
                Assert.AreNotEqual(deepClone.ID,_configuration.ID);
                try
                {
                    ExtractionRequest request2 = new ExtractionRequest(deepClone, new ExtractableDatasetBundle(_extractableDataSet));
                    request2.GenerateQueryBuilder();
                
                    Assert.AreEqual(request.QueryBuilder.SQL,request2.QueryBuilder.SQL);

                }
                finally
                {
                    deepClone.DeleteInDatabase();
                }
            }
            finally 
            {
                
                filter.DeleteInDatabase();
            }

        }
    }
}

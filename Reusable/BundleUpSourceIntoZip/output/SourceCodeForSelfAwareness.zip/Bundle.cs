using System.Collections.Generic; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Linq;
using DataExportManager2.Interfaces.ExtractionTime.UserPicks;

namespace DataExportManager2Library.ExtractionTime.UserPicks
{
    /// <summary>
    /// Tracks the states of a number of objects that reflect an extractable set of objects
    /// </summary>
    public abstract class Bundle
    {
        public object[] Contents
        {
            get { return States.Keys.ToArray(); }
        }

        protected Bundle(object[] finalObjectsDoNotAddToThisLater)
        {
            //Add states for all objects
            States = new Dictionary<object, ExecuteDatasetExtractionState>();

            foreach (object o in finalObjectsDoNotAddToThisLater)
                States.Add(o, ExecuteDatasetExtractionState.NotLaunched);
        }

        public Dictionary<object, ExecuteDatasetExtractionState> States { get; private set; }

        public void SetAllStatesTo(ExecuteDatasetExtractionState state)
        {
            foreach (var k in States.Keys.ToArray())
                States[k] = state;
        }

        public void DropContent(object toDrop)
        {
            //remove the state information
            States.Remove(toDrop);

            //tell child to remove the object too
            OnDropContent(toDrop);
        }
        protected abstract void OnDropContent(object toDrop);
    }
}

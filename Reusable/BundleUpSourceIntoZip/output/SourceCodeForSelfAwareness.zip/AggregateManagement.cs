using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Linq;
using System.Windows.Forms;
using CatalogueLibrary.Data;
using CatalogueLibrary.Data.Aggregation;
using CatalogueLibrary.Data.Cohort;
using CatalogueLibrary.Repositories;
using CatalogueManager.TestsAndSetup.ServicePropogation;
using Diagnostics;
using Message = System.ServiceModel.Channels.Message;

namespace CatalogueManager.AggregationUIs
{
    /// <summary>
    /// Allows you to view all the 'GROUP BY' aggregates (AggregateConfigurations) associated with a given dataset (Catalogue).  This includes all the sets which have been used in cohort
    /// identification.  For example a dataset called Prescribing might have 2 general aggregates 'prescriptions per year' and 'most commonly prescribed medications', then it might have
    /// some cohort identification aggregates e.g. 'People who have ever been prescribed beta blockers after 2001'.
    /// 
    /// 
    /// </summary>
    public partial class AggregateManagement : RDMPForm
    {
        public Catalogue Catalogue { get; set; }

        public AggregateManagement(Catalogue catalogue)
        {
            Catalogue = catalogue;
            InitializeComponent();

            saveToolStripMenuItem.Enabled = false;

            aggregateConfigurationUI1.ChangesSaved += aggregateConfigurationUI1_ChangesSaved;    
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            if(VisualStudioDesignMode)
                return;

            RefreshUIFromDatabase();
        }



        void aggregateConfigurationUI1_ChangesSaved(object sender, EventArgs e)
        {
            RefreshUIFromDatabase();
        }

        private void RefreshUIFromDatabase()
        {
            AggregateConfiguration toReselect = lbAggregates.SelectedItem as AggregateConfiguration;
            
            lbAggregates.Items.Clear();

            lbAggregates.Items.AddRange(
                Catalogue.AggregateConfigurations.Where(config =>  //Add all configurations 
                    !config.IsCohortIdentificationAggregate         //which are not associated with cohort identification
                    ||
                    cbShowCohortSpecificAggregates.Checked  //or if the user wants to see them anyway
                ).ToArray()
                
                );

            if(toReselect != null)
                for (int i = 0; i < lbAggregates.Items.Count; i++)
                    if (((AggregateConfiguration) lbAggregates.Items[i]).ID == toReselect.ID)
                        lbAggregates.SelectedIndex = i;
        }


        private void lbAggregates_SelectedIndexChanged(object sender, EventArgs e)
        {
            aggregateConfigurationUI1.AggregateConfiguration = lbAggregates.SelectedItem as AggregateConfiguration;

            saveToolStripMenuItem.Enabled = aggregateConfigurationUI1.AggregateConfiguration != null;
        }

        private void lbAggregates_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                var configuration = lbAggregates.SelectedItem as AggregateConfiguration;

                if(configuration != null)
                {
                    var cataRepo = ((CatalogueRepository) configuration.Repository);

                    //if the configuration has any dependants then we cannot delete it
                    var dependants = cataRepo.GetAllCohortIdentificationConfigurationsWithDependencyOn(configuration).ToArray();
                    if (dependants.Any())
                    {
                        MessageBox.Show("Cannot delete Aggregate because the following cohort identification configurations are reliant on it:" +string.Join(",", dependants.Select(d => d.Name)),"Cannot Delete");
                        return;
                    }

                    if (MessageBox.Show("Confirm deleting " + configuration.Name, "Delete?", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        configuration.DeleteInDatabase();
                        aggregateConfigurationUI1.AggregateConfiguration = null;
                        RefreshUIFromDatabase();
                    }
                }
            }
        }

        private void newAggregateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new AggregateConfiguration(Catalogue.Repository,Catalogue, Guid.NewGuid().ToString());
            RefreshUIFromDatabase();
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            aggregateConfigurationUI1.Save();

        }

        private void cbShowCohortSpecificAggregates_CheckedChanged(object sender, EventArgs e)
        {
            RefreshUIFromDatabase();
        }
    }
}

using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Text.RegularExpressions;

namespace HIC.Common.Validation.Constraints.Primary
{
    public class Alpha : PrimaryConstraint
    {
        public const string RegExp = @"^[A-Za-z]+$";

        public Alpha()
        {
            Name = "alpha";
        }

        public override Type GetCompatibleType()
        {
            return typeof (string);
        }

        override public ValidationFailure Validate(object value)
        {
            if (value == null)
                return null;

            ValidationFailure result = base.Validate(value);
			
			if(result!=null)
				return result;

            var text = (string)value;
            var match = Regex.Match(text, RegExp);

            if (!match.Success)
            {
                return CreateValidationException("Value [" + value + "] contains characters other than alphabetic");
            }

            return null;

        }

        public override void RenameColumn(string originalName, string newName)
        {
            
        }

        public override string GetHumanReadable()
        {
            return Name + " checks to see if input strings contain nothing but characters by using pattern " + RegExp;
        }
    }
}

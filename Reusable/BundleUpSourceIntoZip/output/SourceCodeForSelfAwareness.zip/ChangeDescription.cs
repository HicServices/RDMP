namespace MapsDirectlyToDatabaseTable.Revertable // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
{
    public enum ChangeDescription
    {
        DatabaseCopyWasDeleted,
        DatabaseCopyDifferent,
        NoChanges
    }
}

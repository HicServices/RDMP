using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dashboard.CatalogueSummary.DataQualityReporting.SubComponents
{
    /// <summary>
    /// Part of ColumnStatesChart, shows what proportion of a given column in the dataset is passing/failing validation.  See ColumnStatesChart for a description of the use case.
    /// </summary>
    public partial class ConsequenceBar : UserControl
    {
        public ConsequenceBar()
        {
            InitializeComponent();
            
        }

        public static Color CorrectColor = Color.Green;
        public static Color MissingColor = Color.Orange;
        public static Color WrongColor = Color.IndianRed;
        public static Color InvalidColor = Color.Red;
        
        public static Color HasValuesColor = Color.Black;
        public static Color IsNullColor = Color.LightGray;

        public double Correct { get; set; }
        public double Invalid { get; set; }
        public double Missing { get; set; }
        public double Wrong { get; set; }
        public double DBNull { get; set; }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            base.OnPaintBackground(e);
            
            //Control looks like this:
            //note that because null count is completely seperate from consequence it has it's own microbar

            /*****************************************************************/
            //        |.............................|################|,,,,,,,,|
            //Correct |..... Missing................|### Wrong ######|,Invalid|
            //        |.............................|################|,,,,,,,,|
            //        |.............................|################|,,,,,,,,|
            ////////////////////////////////////////////////////////////////////
            //.......Nulls Rectangle............|         Not Nulls Rectangle
            /******************************************************************/

            SolidBrush bCorrect = new SolidBrush(CorrectColor);
            SolidBrush bMissing = new SolidBrush(MissingColor);
            SolidBrush bWrong = new SolidBrush(WrongColor);
            SolidBrush bInvalid = new SolidBrush(InvalidColor);

            SolidBrush bValues = new SolidBrush(HasValuesColor);
            SolidBrush bNulls = new SolidBrush(IsNullColor);

            double totalRecords = Correct + Missing + Invalid + Wrong;
            
            int heightOfNullsBarStart = (int) (Height * 0.8);
            int heightOfNullsBar = (int) (Height/5.0);
            

            //draw the nulls bar
            double valuesRatio = 1 - (DBNull / totalRecords);
            int midPointOfNullsBar = (int) (valuesRatio*Width);

            //values
            e.Graphics.FillRectangle(bValues,new Rectangle(0,heightOfNullsBarStart,midPointOfNullsBar,heightOfNullsBar));
            e.Graphics.FillRectangle(bNulls,new Rectangle(midPointOfNullsBar,heightOfNullsBarStart,Width-midPointOfNullsBar,heightOfNullsBar));
            
            
            //draw the main bar
            int correctRightPoint = (int) (((Correct)/totalRecords)*Width);

            int missingWidth = (int) ((Missing/totalRecords)*Width);
            int missingRightPoint = correctRightPoint + missingWidth;

            int wrongWidth = (int) ((Wrong/totalRecords)*Width);
            int wrongRightPoint =  missingRightPoint + wrongWidth;

            int invalidWidth = (int)((Invalid / totalRecords) * Width);
            
            e.Graphics.FillRectangle(bCorrect,new Rectangle(0,0,correctRightPoint,heightOfNullsBarStart));
            e.Graphics.FillRectangle(bMissing, new Rectangle(correctRightPoint, 0, missingWidth, heightOfNullsBarStart));
            e.Graphics.FillRectangle(bWrong, new Rectangle(missingRightPoint, 0, wrongWidth, heightOfNullsBarStart));
            e.Graphics.FillRectangle(bInvalid, new Rectangle(wrongRightPoint, 0, invalidWidth, heightOfNullsBarStart));

           

        }
    }
}

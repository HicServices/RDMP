using CatalogueManager.ExtractionUIs.FilterUIs; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved

namespace DataExportManager2.ProjectUI.FilterConfiguration
{
    partial class DeployedExtractionFilterUI : IContainerTreeChangeOrchestrator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pQueryPreview = new System.Windows.Forms.Panel();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.filterTreeUI = new CatalogueManager.ExtractionUIs.FilterUIs.FilterTreeUI();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pQueryPreview
            // 
            this.pQueryPreview.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pQueryPreview.Location = new System.Drawing.Point(255, 3);
            this.pQueryPreview.Name = "pQueryPreview";
            this.pQueryPreview.Size = new System.Drawing.Size(851, 381);
            this.pQueryPreview.TabIndex = 0;
            // 
            // splitContainer1
            // 
            this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.filterTreeUI);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.pQueryPreview);
            this.splitContainer1.Size = new System.Drawing.Size(1113, 807);
            this.splitContainer1.SplitterDistance = 412;
            this.splitContainer1.TabIndex = 7;
            // 
            // filterTreeUI
            // 
            this.filterTreeUI.AutoSize = true;
            this.filterTreeUI.ChangeOrchestrator = null;
            this.filterTreeUI.ContainerConstructor = null;
            this.filterTreeUI.Dock = System.Windows.Forms.DockStyle.Fill;
            this.filterTreeUI.GlobalFilterParameters = null;
            this.filterTreeUI.Location = new System.Drawing.Point(0, 0);
            this.filterTreeUI.Name = "filterTreeUI";
            this.filterTreeUI.Size = new System.Drawing.Size(1109, 408);
            this.filterTreeUI.TabIndex = 7;
            // 
            // DeployedExtractionFilterUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1113, 807);
            this.Controls.Add(this.splitContainer1);
            this.Name = "DeployedExtractionFilterUI";
            this.Text = "DeployedExtractionFilterUI";
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pQueryPreview;
        private FilterTreeUI filterTreeUI;
        private System.Windows.Forms.SplitContainer splitContainer1;
    }
}

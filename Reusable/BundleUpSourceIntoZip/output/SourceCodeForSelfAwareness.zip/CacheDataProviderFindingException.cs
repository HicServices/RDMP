using System;

namespace DataLoadEngine.Job.Scheduling.Exceptions
{
    public class CacheDataProviderFindingException : Exception
    {
        public CacheDataProviderFindingException(string msg):base(msg)
        {
            
        }
    }
}

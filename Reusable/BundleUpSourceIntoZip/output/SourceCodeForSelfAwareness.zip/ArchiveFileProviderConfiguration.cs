using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.IO;
using System.Windows.Forms;
using DataLoadEngine.DataProvider;
using LoadModules.Generic.DataProvider;

namespace DatasetLoaderUI
{
    public partial class ArchiveFileProviderConfiguration : DataProviderConfigurationControl
    {
        public override IDataProvider DataProvider
        {
            get
            {
                return new ArchiveFileProvider(string.Join(";", dlgFilePicker.FileNames), DestPath);
            }

            set
            {
                var provider = value as ArchiveFileProvider;
                if (provider == null)
                    throw new Exception("You must provide an ArchiveFileProvider to this configuration object");

                if (!provider.SourceFilepath.Contains(";"))
                {
                    if (provider.SourceFilepath != "")
                        dlgFilePicker.InitialDirectory = Path.GetDirectoryName(provider.SourceFilepath);
                }
                dlgFilePicker.FileName = provider.SourceFilepath;
                dlgFilePicker.Multiselect = true;
            }
        }

        public ArchiveFileProviderConfiguration()
        {
            InitializeComponent();
        }

        private void btnSelectFile_Click(object sender, System.EventArgs e)
        {
            if (dlgFilePicker.ShowDialog() == DialogResult.OK)
            {
                tbSelectedFile.Text = dlgFilePicker.SafeFileName;
            }
        }
    }
}

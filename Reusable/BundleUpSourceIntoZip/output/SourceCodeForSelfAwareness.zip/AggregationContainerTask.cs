using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Linq;
using System.Threading;
using CatalogueLibrary.Data;
using CatalogueLibrary.Data.Cohort;
using MapsDirectlyToDatabaseTable;
using ReusableLibraryCode.DataAccess;

namespace CohortManagerLibrary.Execution
{
    /// <summary>
    /// The runtime/compile time wrapper for CohortAggregateContainer. UNION,EXCEPT,INTERSECT containers with 0 or more AggregationConfiguration within them - also optionally with other sub containers in them!
    /// </summary>
    public class AggregationContainerTask : Compileable,IOrderable
    {
        public CohortAggregateContainer Container { get; set; }

        public AggregationContainerTask(CohortAggregateContainer container, CohortCompiler compiler):base(compiler)
        {
            Container = container;
        }

        public override string GetCatalogueName()
        {
            return "";
        }

        public override IMapsDirectlyToDatabaseTable Child { get { return Container; } }
        
        public override IDataAccessPoint[] GetDataAccessPoints()
        {

            var cataIDs = Container.GetAggregateConfigurations().Select(c => c.Catalogue_ID).Distinct().ToList();

            //if this container does not have any configurations
            if (!cataIDs.Any())//try looking at the subcontainers
            {
                var subcontainers =  Container.GetSubContainers().FirstOrDefault(subcontainer => subcontainer.GetAggregateConfigurations().Any());
                if(subcontainers != null)
                    cataIDs = subcontainers.GetAggregateConfigurations().Select(c => c.Catalogue_ID).Distinct().ToList();
            }

            //none of the subcontainers have any catalogues either!
            if(!cataIDs.Any())
                throw new Exception("Aggregate Container " + Container.ID + " does not have any datasets in it and neither does an of its direct subcontainers have any, how far down the tree do you expect me to look!");

            var catas = Container.Repository.GetAllObjectsInIDList<Catalogue>(cataIDs);

            return catas.SelectMany(c => c.GetTableInfoList(false)).ToArray();
        }
    }
}
 

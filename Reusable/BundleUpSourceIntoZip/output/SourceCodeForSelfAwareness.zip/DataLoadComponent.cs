using CatalogueLibrary; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using CatalogueLibrary.Data.DataLoad;
using CatalogueLibrary.DataFlowPipeline;
using DataLoadEngine.Job;
using ReusableLibraryCode.Progress;

namespace DataLoadEngine.LoadPipeline.Components
{
    public abstract class DataLoadComponent :  ILoadComponent<IDataLoadJob>
    {
        public bool SkipComponent { get; set; }
        public string Description { get; set; }
        public bool DisposeImmediately { get; set; }

        public abstract ProcessExitCode Run(IDataLoadJob job, GracefulCancellationToken cancellationToken);
        public abstract void LoadCompletedSoDispose(ExitCodeType exitCode,IDataLoadEventListener postDataLoadEventListener);

        protected DataLoadComponent()
        {
            SkipComponent = false;
            DisposeImmediately = false;
        }

        protected bool Skip(IDataLoadJob job)
        {
            if (!SkipComponent) return false;

            job.OnNotify(this, new NotifyEventArgs(ProgressEventType.Warning, "Skipped load component: " + Description));
            return true;
        }

        public virtual void SetDisposeImmediately()
        {
            DisposeImmediately = true;
        }
    }
}

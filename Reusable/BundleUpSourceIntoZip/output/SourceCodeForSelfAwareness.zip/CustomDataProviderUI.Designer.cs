namespace DatasetLoaderUI // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
{
    partial class CustomDataProviderUI
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbDataSource = new System.Windows.Forms.GroupBox();
            this.cbUseCustomDataSource = new System.Windows.Forms.CheckBox();
            this.tbMultiArchiveDir = new System.Windows.Forms.TextBox();
            this.rbMultiArchiveDir = new System.Windows.Forms.RadioButton();
            this.btnConfigureDataProvider = new System.Windows.Forms.Button();
            this.ddDataProvider = new System.Windows.Forms.ComboBox();
            this.btnConfigureLoadQueue = new System.Windows.Forms.Button();
            this.rbSingleDataSource = new System.Windows.Forms.RadioButton();
            this.rbMultiDataSource = new System.Windows.Forms.RadioButton();
            this.gbDataSource.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbDataSource
            // 
            this.gbDataSource.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gbDataSource.Controls.Add(this.tbMultiArchiveDir);
            this.gbDataSource.Controls.Add(this.rbMultiArchiveDir);
            this.gbDataSource.Controls.Add(this.btnConfigureDataProvider);
            this.gbDataSource.Controls.Add(this.ddDataProvider);
            this.gbDataSource.Controls.Add(this.btnConfigureLoadQueue);
            this.gbDataSource.Controls.Add(this.rbSingleDataSource);
            this.gbDataSource.Controls.Add(this.rbMultiDataSource);
            this.gbDataSource.Enabled = false;
            this.gbDataSource.Location = new System.Drawing.Point(0, 25);
            this.gbDataSource.MinimumSize = new System.Drawing.Size(252, 101);
            this.gbDataSource.Name = "gbDataSource";
            this.gbDataSource.Size = new System.Drawing.Size(426, 104);
            this.gbDataSource.TabIndex = 38;
            this.gbDataSource.TabStop = false;
            this.gbDataSource.Text = "Data source";
            // 
            // cbUseCustomDataSource
            // 
            this.cbUseCustomDataSource.AutoSize = true;
            this.cbUseCustomDataSource.Location = new System.Drawing.Point(0, 3);
            this.cbUseCustomDataSource.Name = "cbUseCustomDataSource";
            this.cbUseCustomDataSource.Size = new System.Drawing.Size(294, 17);
            this.cbUseCustomDataSource.TabIndex = 45;
            this.cbUseCustomDataSource.Text = "Use custom data source (i.e. override catalogue settings)";
            this.cbUseCustomDataSource.UseVisualStyleBackColor = true;
            this.cbUseCustomDataSource.CheckedChanged += new System.EventHandler(this.cbUseCustomDataSource_CheckedChanged);
            // 
            // tbMultiArchiveDir
            // 
            this.tbMultiArchiveDir.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbMultiArchiveDir.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.tbMultiArchiveDir.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.FileSystem;
            this.tbMultiArchiveDir.Location = new System.Drawing.Point(118, 75);
            this.tbMultiArchiveDir.Name = "tbMultiArchiveDir";
            this.tbMultiArchiveDir.Size = new System.Drawing.Size(300, 20);
            this.tbMultiArchiveDir.TabIndex = 44;
            // 
            // rbMultiArchiveDir
            // 
            this.rbMultiArchiveDir.AutoSize = true;
            this.rbMultiArchiveDir.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.rbMultiArchiveDir.Location = new System.Drawing.Point(10, 76);
            this.rbMultiArchiveDir.Name = "rbMultiArchiveDir";
            this.rbMultiArchiveDir.Size = new System.Drawing.Size(102, 17);
            this.rbMultiArchiveDir.TabIndex = 40;
            this.rbMultiArchiveDir.Text = "Multi Archive Dir";
            this.rbMultiArchiveDir.UseVisualStyleBackColor = true;
            // 
            // btnConfigureDataProvider
            // 
            this.btnConfigureDataProvider.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnConfigureDataProvider.Location = new System.Drawing.Point(354, 17);
            this.btnConfigureDataProvider.Name = "btnConfigureDataProvider";
            this.btnConfigureDataProvider.Size = new System.Drawing.Size(64, 23);
            this.btnConfigureDataProvider.TabIndex = 39;
            this.btnConfigureDataProvider.Text = "Configure Load Queue";
            this.btnConfigureDataProvider.UseVisualStyleBackColor = true;
            this.btnConfigureDataProvider.Click += new System.EventHandler(this.btnConfigureDataProvider_Click);
            // 
            // ddDataProvider
            // 
            this.ddDataProvider.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ddDataProvider.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddDataProvider.FormattingEnabled = true;
            this.ddDataProvider.Items.AddRange(new object[] {
            "File",
            "Archive File",
            "None (Skips all loading tasks)"});
            this.ddDataProvider.Location = new System.Drawing.Point(118, 19);
            this.ddDataProvider.Name = "ddDataProvider";
            this.ddDataProvider.Size = new System.Drawing.Size(230, 21);
            this.ddDataProvider.TabIndex = 36;
            this.ddDataProvider.SelectedIndexChanged += new System.EventHandler(this.cbDataProvider_SelectedIndexChanged);
            // 
            // btnConfigureLoadQueue
            // 
            this.btnConfigureLoadQueue.Enabled = false;
            this.btnConfigureLoadQueue.Location = new System.Drawing.Point(118, 46);
            this.btnConfigureLoadQueue.Name = "btnConfigureLoadQueue";
            this.btnConfigureLoadQueue.Size = new System.Drawing.Size(125, 23);
            this.btnConfigureLoadQueue.TabIndex = 33;
            this.btnConfigureLoadQueue.Text = "Configure Load Queue";
            this.btnConfigureLoadQueue.UseVisualStyleBackColor = true;
            this.btnConfigureLoadQueue.Click += new System.EventHandler(this.btnConfigureLoadQueue_Click);
            // 
            // rbSingleDataSource
            // 
            this.rbSingleDataSource.AutoSize = true;
            this.rbSingleDataSource.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.rbSingleDataSource.Checked = true;
            this.rbSingleDataSource.Location = new System.Drawing.Point(58, 22);
            this.rbSingleDataSource.Name = "rbSingleDataSource";
            this.rbSingleDataSource.Size = new System.Drawing.Size(54, 17);
            this.rbSingleDataSource.TabIndex = 8;
            this.rbSingleDataSource.TabStop = true;
            this.rbSingleDataSource.Text = "Single";
            this.rbSingleDataSource.UseVisualStyleBackColor = true;
            this.rbSingleDataSource.CheckedChanged += new System.EventHandler(this.rbSingleDataSource_CheckedChanged);
            // 
            // rbMultiDataSource
            // 
            this.rbMultiDataSource.AutoSize = true;
            this.rbMultiDataSource.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.rbMultiDataSource.Location = new System.Drawing.Point(65, 49);
            this.rbMultiDataSource.Name = "rbMultiDataSource";
            this.rbMultiDataSource.Size = new System.Drawing.Size(47, 17);
            this.rbMultiDataSource.TabIndex = 9;
            this.rbMultiDataSource.Text = "Multi";
            this.rbMultiDataSource.UseVisualStyleBackColor = true;
            this.rbMultiDataSource.CheckedChanged += new System.EventHandler(this.rbMultiDataSource_CheckedChanged);
            // 
            // CustomDataProviderUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.cbUseCustomDataSource);
            this.Controls.Add(this.gbDataSource);
            this.Name = "CustomDataProviderUI";
            this.Size = new System.Drawing.Size(426, 132);
            this.gbDataSource.ResumeLayout(false);
            this.gbDataSource.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbDataSource;
        private System.Windows.Forms.TextBox tbMultiArchiveDir;
        private System.Windows.Forms.RadioButton rbMultiArchiveDir;
        private System.Windows.Forms.Button btnConfigureDataProvider;
        private System.Windows.Forms.ComboBox ddDataProvider;
        private System.Windows.Forms.Button btnConfigureLoadQueue;
        private System.Windows.Forms.RadioButton rbSingleDataSource;
        private System.Windows.Forms.RadioButton rbMultiDataSource;
        private System.Windows.Forms.CheckBox cbUseCustomDataSource;

    }
}

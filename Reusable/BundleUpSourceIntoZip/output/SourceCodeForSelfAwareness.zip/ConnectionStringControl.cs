using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Data.SqlClient;
using System.Linq;
using System.Windows.Forms;
using ReusableLibraryCode;
using ReusableLibraryCode.DatabaseHelpers.Discovery;

namespace ReusableUIComponents
{
    /// <summary>
    /// Lets you type in the credentials to a server.  This is a reusable component.
    /// </summary>
    public partial class ConnectionStringControl : UserControl
    {
        private SqlConnectionStringBuilder _builder;

        public ConnectionStringControl(bool includeDatabase)
        {
            InitializeComponent();
            cbxDatabase.Visible = includeDatabase;
            lblDatabase.Visible = includeDatabase;
        }

        public string ConnectionString {
            get
            {
                if (_builder == null)
                    _builder = new SqlConnectionStringBuilder();

                _builder.DataSource = tbServer.Text;
                _builder.UserID = tbUsername.Text;
                _builder.IntegratedSecurity = string.IsNullOrWhiteSpace(tbUsername.Text);
                _builder.Password = tbPassword.Text;

                if (cbxDatabase.SelectedItem != null)
                    _builder.InitialCatalog = cbxDatabase.SelectedItem as string;

                return _builder.ConnectionString;
            }
            set
            {
                _builder = new SqlConnectionStringBuilder(value);

                tbServer.Text = _builder.DataSource;
                tbUsername.Text = _builder.UserID;
                tbPassword.Text = _builder.Password;
                GetDatabases();
                cbxDatabase.SelectedItem = _builder.InitialCatalog;
            }
        }

        private void GetDatabases()
        {
            try
            {
                cbxDatabase.Items.Clear();

                if (string.IsNullOrWhiteSpace(tbServer.Text)) return;

                var builder = new SqlConnectionStringBuilder
                {
                    DataSource = tbServer.Text,
                    IntegratedSecurity = string.IsNullOrWhiteSpace(tbUsername.Text),
                    UserID = tbUsername.Text,
                    Password = tbPassword.Text
                };

                var dbs = new DiscoveredServer(builder).DiscoverDatabases().Select(d => d.GetRuntimeName()).ToArray();
                cbxDatabase.Items.AddRange(dbs);
                lblError.Text = "Databases Loaded Successfully";
            }
            catch (Exception exception)
            {
                lblError.Text = exception.Message;
            }
        }

        private void tbPassword_Leave(object sender, EventArgs e)
        {
            GetDatabases();
        }
    }
}

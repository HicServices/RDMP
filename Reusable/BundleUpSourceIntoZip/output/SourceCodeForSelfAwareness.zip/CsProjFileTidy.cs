using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using Microsoft.SqlServer.Management.Smo;

namespace CatalogueLibraryTests.SourceCodeEvaluation
{
    internal class CsProjFileTidy
    {

        private Dictionary<string, int> _expectedToSee = new Dictionary<string,int>();

        public List<string> UntidyMessages { get; set; }

        private string _expectedRootNamespace;
        private DirectoryInfo _root;

        //these class files are excused from having 2+ class files in them or 0
        private string[] Whitelist = new[] { "Attributes.cs", "AssemblyInfo.cs", "Annotations.cs", "StageArgs.cs" };

        public CsProjFileTidy(FileInfo csProjFile)
        {
            UntidyMessages = new List<string>();

            _root = csProjFile.Directory;
            _expectedRootNamespace = csProjFile.Name.Replace(".csproj","");

            //e.g. <Compile Include="Overview\OverviewScreen.Designer.cs"
            string allText = File.ReadAllText(csProjFile.FullName);
            Regex r = new Regex(@"\<Compile Include=\""(.*)\""",RegexOptions.Compiled);

            foreach (Match m in r.Matches(allText))
                _expectedToSee.Add(Path.Combine(csProjFile.Directory.FullName, m.Groups[1].Value), 0);

            RecursivelyProcessSubfolders(csProjFile.Directory);

            foreach (KeyValuePair<string, int> kvp in _expectedToSee.Where(kvp => kvp.Value == 0))
                UntidyMessages.Add("Did not find .cs file in subdirectories of the .csproj file:" + kvp.Key);
        }

        private void RecursivelyProcessSubfolders(DirectoryInfo directory)
        {
            foreach (FileInfo enumerateFile in directory.EnumerateFiles("*.cs"))
            {
                if (_expectedToSee.ContainsKey(enumerateFile.FullName))
                {

                    _expectedToSee[enumerateFile.FullName]++;
                    ConfirmClassNameAndNamespaces(enumerateFile);
                }
                else
                    UntidyMessages.Add("FAIL: Unexpected .cs file found that is not referenced by project:" + enumerateFile.FullName);
            }

            foreach (var dir in directory.EnumerateDirectories())
            {
                if(dir.Name.Equals("bin") || dir.Name.Equals("obj"))
                    continue;

                RecursivelyProcessSubfolders(dir);
            }
        }

        private void ConfirmClassNameAndNamespaces(FileInfo csFile)
        {
            if(Whitelist.Contains(csFile.Name))
                return;

            string contents = File.ReadAllText(csFile.FullName);

            Regex rNamespace = new Regex(@"^namespace ([A-Za-z0-9.]*)", RegexOptions.Multiline);
            Regex rPublicClasses = new Regex(@"^\s*public class ([A-Za-z0-9_]*)", RegexOptions.Multiline);

            var classes = rPublicClasses.Matches(contents);
            var namespaces = rNamespace.Matches(contents);

            if(namespaces.Count == 0)
                UntidyMessages.Add("FAIL: .cs file does not have any namespaces listed in it:" + csFile.FullName);
            else if (namespaces.Count > 1)
                UntidyMessages.Add("FAIL: .cs file has more than 1 namespaces listed in it!:" + csFile.FullName);
            else
            {
                string subspace = GetSubspace(csFile);
                string expectedNamespace = _expectedRootNamespace + subspace;

                string actualNamespace = namespaces[0].Groups[1].Value;

                if(!actualNamespace.Equals(expectedNamespace))
                    UntidyMessages.Add("Expected file " + csFile.FullName + " to have namespace " + expectedNamespace + " but it's listed namespace is " + actualNamespace);

            }
            

            //it's probably a enum or interface or delegates file
            if(classes.Count ==0)
                return;

            if(classes.Count > 1)
            {
                //The only files allowed 2+ class files in them are tests and factories
                if (csFile.Name.Contains("Test") || csFile.Name.Contains("Factory"))
                    return;
                
                UntidyMessages.Add("FAIL: .cs file contains 2+ classes " + csFile.FullName);
            }
            else
            {
                if(!csFile.Name.Equals(classes[0].Groups[1].Value + ".cs"))
                    UntidyMessages.Add("File " + csFile.FullName + " contains a class is called " + classes[0].Groups[1].Value + " (does not match file name of file)");
            }

        }

        private string GetSubspace(FileInfo csFile)
        {
            string reltive = csFile.FullName.Replace(_root.FullName, "");

            //trim off the "\myclass.cs" bit
            reltive = reltive.Substring(0, reltive.Length - (csFile.Name.Length + 1));
            return reltive.Replace('\\', '.');
        }
    }
}

using CohortManager.SubComponents; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved

namespace CohortManager
{
    partial class CohortManagerMainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CohortManagerMainForm));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.refreshToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.refreshAllCataloguesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.diagnosticsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.launchDiagnosticsScreenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showPerformanceCounterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cbUserFriendly = new System.Windows.Forms.CheckBox();
            this.cohortIdentificationConfigurationUI1 = new CohortManager.SubComponents.CohortIdentificationConfigurationUI();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.refreshToolStripMenuItem,
            this.diagnosticsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1475, 24);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.openToolStripMenuItem,
            this.saveToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.newToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.newToolStripMenuItem.Text = "New";
            this.newToolStripMenuItem.Click += new System.EventHandler(this.newToolStripMenuItem_Click);
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.openToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.openToolStripMenuItem.Text = "Open...";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.saveToolStripMenuItem.Text = "Save";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
            // 
            // refreshToolStripMenuItem
            // 
            this.refreshToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.refreshAllCataloguesToolStripMenuItem});
            this.refreshToolStripMenuItem.Name = "refreshToolStripMenuItem";
            this.refreshToolStripMenuItem.Size = new System.Drawing.Size(58, 20);
            this.refreshToolStripMenuItem.Text = "Refresh";
            // 
            // refreshAllCataloguesToolStripMenuItem
            // 
            this.refreshAllCataloguesToolStripMenuItem.Name = "refreshAllCataloguesToolStripMenuItem";
            this.refreshAllCataloguesToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.refreshAllCataloguesToolStripMenuItem.Text = "Refresh All Catalogues";
            this.refreshAllCataloguesToolStripMenuItem.Click += new System.EventHandler(this.refreshAllCataloguesToolStripMenuItem_Click);
            // 
            // diagnosticsToolStripMenuItem
            // 
            this.diagnosticsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.launchDiagnosticsScreenToolStripMenuItem,
            this.showPerformanceCounterToolStripMenuItem});
            this.diagnosticsToolStripMenuItem.Name = "diagnosticsToolStripMenuItem";
            this.diagnosticsToolStripMenuItem.Size = new System.Drawing.Size(80, 20);
            this.diagnosticsToolStripMenuItem.Text = "Diagnostics";
            // 
            // launchDiagnosticsScreenToolStripMenuItem
            // 
            this.launchDiagnosticsScreenToolStripMenuItem.Name = "launchDiagnosticsScreenToolStripMenuItem";
            this.launchDiagnosticsScreenToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D)));
            this.launchDiagnosticsScreenToolStripMenuItem.Size = new System.Drawing.Size(266, 22);
            this.launchDiagnosticsScreenToolStripMenuItem.Text = "Launch Diagnostics Screen...";
            this.launchDiagnosticsScreenToolStripMenuItem.Click += new System.EventHandler(this.launchDiagnosticsScreenToolStripMenuItem_Click);
            // 
            // showPerformanceCounterToolStripMenuItem
            // 
            this.showPerformanceCounterToolStripMenuItem.Name = "showPerformanceCounterToolStripMenuItem";
            this.showPerformanceCounterToolStripMenuItem.Size = new System.Drawing.Size(266, 22);
            this.showPerformanceCounterToolStripMenuItem.Text = "Show Performance Counter...";
            this.showPerformanceCounterToolStripMenuItem.Click += new System.EventHandler(this.showPerformanceCounterToolStripMenuItem_Click);
            // 
            // cbUserFriendly
            // 
            this.cbUserFriendly.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cbUserFriendly.AutoSize = true;
            this.cbUserFriendly.Location = new System.Drawing.Point(1360, 1);
            this.cbUserFriendly.Name = "cbUserFriendly";
            this.cbUserFriendly.Size = new System.Drawing.Size(117, 17);
            this.cbUserFriendly.TabIndex = 6;
            this.cbUserFriendly.Text = "User Friendly Mode";
            this.cbUserFriendly.UseVisualStyleBackColor = true;
            this.cbUserFriendly.CheckedChanged += new System.EventHandler(this.cbUserFriendly_CheckedChanged);
            // 
            // cohortIdentificationConfigurationUI1
            // 
            this.cohortIdentificationConfigurationUI1.Configuration = null;
            this.cohortIdentificationConfigurationUI1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cohortIdentificationConfigurationUI1.Location = new System.Drawing.Point(0, 24);
            this.cohortIdentificationConfigurationUI1.Name = "cohortIdentificationConfigurationUI1";
            this.cohortIdentificationConfigurationUI1.RepositoryLocator = null;
            this.cohortIdentificationConfigurationUI1.Size = new System.Drawing.Size(1475, 726);
            this.cohortIdentificationConfigurationUI1.TabIndex = 5;
            this.cohortIdentificationConfigurationUI1.VisualStudioDesignMode = true;
            // 
            // CohortManagerMainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1475, 750);
            this.Controls.Add(this.cbUserFriendly);
            this.Controls.Add(this.cohortIdentificationConfigurationUI1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "CohortManagerMainForm";
            this.Text = "CohortManagerMainForm";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private CohortIdentificationConfigurationUI cohortIdentificationConfigurationUI1;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem refreshToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem refreshAllCataloguesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem diagnosticsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showPerformanceCounterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem launchDiagnosticsScreenToolStripMenuItem;
        private System.Windows.Forms.CheckBox cbUserFriendly;
    }
}


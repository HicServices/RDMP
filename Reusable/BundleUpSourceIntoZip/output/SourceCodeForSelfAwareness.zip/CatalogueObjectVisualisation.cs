using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Specialized;
using System.Drawing;
using CatalogueLibrary.Data;
using CatalogueLibrary.Data.DataLoad;
using ReusableUIComponents.Dependencies.Models;

namespace CatalogueManager.ObjectVisualisation
{
    public class CatalogueObjectVisualisation : IObjectVisualisation
    {
        private static readonly object o = new object();
        private static CatalogueObjectVisualisation _instance;

        public static CatalogueObjectVisualisation GetInstance()
        {
            lock (o)
            {
                if (_instance == null)
                    _instance = new CatalogueObjectVisualisation();
            }
            return _instance;
        }

        private CatalogueObjectVisualisation()
        {

        }

        public string[] GetNameAndType(object toRender)
        {
            var idPropertyInfo = toRender.GetType().GetProperty("ID");
            string idAsString = null;
            if (idPropertyInfo != null)
                idAsString = idPropertyInfo.GetValue(toRender).ToString();

            string[] nameAndType = new string[3];
            nameAndType[0] = toRender.ToString();
            nameAndType[1] = " (" + toRender.GetType().Name + (idAsString != null ? " ID=" + idAsString : "") + ")";
            nameAndType[2] = toRender.GetType().Name;
            return nameAndType;

        }

        //The dictionary has space for 3 segments of information. The first entry in the dictionary
        //is placed in the Rich Textbox (hence why description is almost always the first entry)
        public OrderedDictionary EntityInformation(object toRender)
        {
            OrderedDictionary informationToReturn = new OrderedDictionary();

            if (toRender.GetType() == typeof(Catalogue))
            {
                informationToReturn.Add("Description: ", ((Catalogue)toRender).Description);
            }
            if (toRender.GetType() == typeof(CatalogueItem))
            {
                informationToReturn.Add("Description: ", ((CatalogueItem)toRender).Description);
                informationToReturn.Add("Comments: ", ((CatalogueItem)toRender).Comments);
            }
            if (toRender.GetType() == typeof(TableInfo))
            {
                informationToReturn.Add("Store Type:  ", ((TableInfo)toRender).DatabaseType);
            }

            if (toRender.GetType() == typeof(ColumnInfo))
            {
                informationToReturn.Add("Description: ", ((ColumnInfo)toRender).Description);
            }

            if (toRender.GetType() == typeof(ExtractionInformation))
            {
                informationToReturn.Add("Select SQL: ", ((ExtractionInformation)toRender).SelectSQL);
                informationToReturn.Add("Extraction Category: ", ((ExtractionInformation)toRender).ExtractionCategory.ToString());
            }

            if (toRender.GetType() == typeof(LoadMetadata))
            {
                informationToReturn.Add("Description: ", ((LoadMetadata)toRender).Description);
            }

            if (toRender.GetType() == typeof(ExtractionFilter))
            {
                informationToReturn.Add("Description: ", ((ExtractionFilter)toRender).Description);
            }

            if (toRender.GetType() == typeof(ExtractionFilterParameter))
            {
                informationToReturn.Add("Parameter SQL: ", ((ExtractionFilterParameter)toRender).ParameterSQL);
                informationToReturn.Add("Parameter Name: ", ((ExtractionFilterParameter)toRender).ParameterName);
            }

            if (toRender.GetType() == typeof(Lookup))
            {
                informationToReturn.Add("Description: ", ((Lookup)toRender).Description.ToString());
                informationToReturn.Add("Primary Key: ", ((Lookup)toRender).PrimaryKey.ToString());
                informationToReturn.Add("Foreign Key: ", ((Lookup)toRender).ForeignKey.ToString());
            }

            return informationToReturn;
        }

        public ColorResponse GetColor(object toRender, ColorRequest request)
        {
            if (request.IsHighlighted)
                return new ColorResponse(KnownColor.LightPink, KnownColor.White);

            if (toRender is ExtractionInformation)
                if (((ExtractionInformation)toRender).IsProperTransform())
                    return new ColorResponse(KnownColor.LawnGreen, KnownColor.White);

            return new ColorResponse(KnownColor.LightBlue, KnownColor.White);
        }


        public Bitmap GetImage(object toRender)
        {
            if (toRender.GetType() == typeof(Catalogue))
                return OVImages.Catalogue;

            if (toRender.GetType() == typeof(CatalogueItem))
                return OVImages.CatalogueItem;

            if (toRender.GetType() == typeof(TableInfo))
                return OVImages.TableInfo;

            if (toRender.GetType() == typeof(ColumnInfo))
                return OVImages.ColumnInfo;

            if (toRender.GetType() == typeof(ExtractionInformation))
                return OVImages.ExtractionInformation;

            if (toRender.GetType() == typeof(LoadMetadata))
                return OVImages.LoadMetadata;

            if (toRender.GetType() == typeof(ExtractionFilter))
                return OVImages.ExtractionFilter;

            if (toRender.GetType() == typeof(ExtractionFilterParameter))
                return OVImages.ExtractionFilterParameter;

            if (toRender.GetType() == typeof(Lookup))
                return OVImages.Lookup;

            throw new NotSupportedException("Did not know what image to serve for object of type " + toRender.GetType().FullName);

        }
    }


}

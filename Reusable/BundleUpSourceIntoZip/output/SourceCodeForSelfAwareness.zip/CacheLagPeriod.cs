using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved

namespace CatalogueLibrary.Data
{
    /// <summary>
    /// Created this because TimeSpans can't handle months and I didn't want to go to the hassle of importing an entire library such as NodaTime just to be able to deal with months.
    /// 
    /// Serialises to/from simple string representation of duration + type, where type is month (m) or day (d)
    /// </summary>
    public class CacheLagPeriod
    {
        public enum PeriodType
        {
            Month,
            Day
        };

        public int Duration { get; set; }
        public PeriodType Type { get; set; }

        // if a null/empty string is passed in to the constructor then there is no lag period, create it as '0d'
        private const int DefaultDuration = 0;
        private const PeriodType DefaultType = PeriodType.Day;

        public CacheLagPeriod(string cacheLagPeriod)
        {
            var type = cacheLagPeriod.Substring(cacheLagPeriod.Length - 1);
            SetTypeFromString(type);

            Duration = string.IsNullOrWhiteSpace(cacheLagPeriod)
                ? DefaultDuration
                : Convert.ToInt32(cacheLagPeriod.Substring(0, cacheLagPeriod.Length - 1));
        }

        public CacheLagPeriod(int duration, PeriodType type)
        {
            Duration = duration;
            Type = type;
        }

        private void SetTypeFromString(string type)
        {
            if (string.IsNullOrWhiteSpace(type))
            {
                Type = DefaultType;
                return;
            }

            switch (type)
            {
                case "m": 
                    Type = PeriodType.Month;
                    break;
                case "d":
                    Type = PeriodType.Day;
                    break;
                default:
                    throw new Exception("Period type must be either Month (m) or Day (d)");
            }
        }

        public override string ToString()
        {
            var s = Duration.ToString();
            switch (Type)
            {
                case PeriodType.Month:
                    s += "m";
                    break;
                case PeriodType.Day:
                    s += "d";
                    break;
                default:
                    throw new ArgumentOutOfRangeException();
            }

            return s;
        }

        public DateTime CalculateStartOfLagPeriodFrom(DateTime dt)
        {
            switch (Type)
            {
                case PeriodType.Month:
                    return dt.AddMonths(Duration*-1);
                case PeriodType.Day:
                    return dt.AddDays(Duration*-1);
                default:
                    throw new ArgumentOutOfRangeException();
            }
        }

        public bool TimeIsWithinPeriod(DateTime time)
        {
            return time >= CalculateStartOfLagPeriodFrom(DateTime.Now);
        }
    }
}

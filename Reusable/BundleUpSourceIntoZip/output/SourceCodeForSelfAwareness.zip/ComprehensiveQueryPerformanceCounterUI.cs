using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Documents;
using System.Windows.Forms;
using CsvHelper;
using EnvDTE;
using ReusableLibraryCode.Performance;
using Process = System.Diagnostics.Process;

namespace ReusableUIComponents.Performance
{
    /// <summary>
    /// Part of CatalogueLibraryPerformanceCounterUI.  Allows you to view all the unique commands sent to the RDMP database during performance logging.  This includes stack traces of ever
    /// location a command was sent and the number of times it was sent.
    /// </summary>
    public partial class ComprehensiveQueryPerformanceCounterUI : UserControl
    {
        public ComprehensiveQueryPerformanceCounterUI()
        {
            InitializeComponent();
        }

        private ComprehensiveQueryPerformanceCounter _performanceCounter;

        public void LoadState(ComprehensiveQueryPerformanceCounter performanceCounter)
        {
            _performanceCounter = performanceCounter;

            int row = 0;

            foreach (var query in performanceCounter.DictionaryOfQueries.Seconds.OrderByDescending(q=>q.TimesSeen))
            {
                

                Label l = new Label();
                l.Dock = DockStyle.Fill;
                l.Text = query.QueryText;

                LinkLabel link = new LinkLabel();
                string stackTrace = performanceCounter.DictionaryOfQueries.GetBySecond(query);
                link.Text = "Location";
                link.Tag = stackTrace;
                link.LinkClicked += link_LinkClicked;
                link.Dock = DockStyle.Fill;

                Label time = new Label();
                time.Text = "Called " + query.TimesSeen + " times";
                time.Dock = DockStyle.Fill;

                tableLayoutPanel1.Controls.Add(l,0,row);
                tableLayoutPanel1.Controls.Add(link, 1, row);
                tableLayoutPanel1.Controls.Add(time,2,row);
                
                if (row >= 500)
                {
                    MessageBox.Show("Stopping at 500 rows! you have a lot of queries audited!");
                    break;
                }
                row++;
            }


            
            tableLayoutPanel1.RowCount = row;

            for (int i = 0; i < tableLayoutPanel1.RowStyles.Count; i++)
                tableLayoutPanel1.RowStyles[i].SizeType = SizeType.AutoSize;
        }

        void link_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            var ll = (LinkLabel) sender;
            ExceptionViewerStackTraceWithHyperlinks viewer = new ExceptionViewerStackTraceWithHyperlinks(ll.Tag.ToString());
            viewer.ShowDialog();
        }

        private void btnSaveToCSV_Click(object sender, EventArgs e)
        {
            string toOpen;
            try
            {
                using(SaveFileDialog sfd = new SaveFileDialog())
                {

                    sfd.OverwritePrompt = true;
                    sfd.Filter = "CSV File|*.csv";
                    
                    if(sfd.ShowDialog() == DialogResult.OK)
                    {
                        using(CsvWriter writer = new CsvWriter(new IndentedTextWriter(new StreamWriter(sfd.OpenFile()))))
                        {
                            writer.WriteRecords(
                                from p in _performanceCounter.DictionaryOfQueries.Seconds select new
                                {
                                    p.QueryText,
                                    p.TimesSeen,
                                    StackTrace = _performanceCounter.DictionaryOfQueries.GetBySecond(p)
                                }
                                );
                        }
                    }
                    toOpen = sfd.FileName;
                }

                try
                {
                    Process.Start(toOpen);
                }
                catch (Exception exception)
                {
                    //oh well couldn't open it nevermind
                }
            }
            catch (Exception exception)
            {
                ExceptionViewer.Show(exception);
            }
        }
    }
}

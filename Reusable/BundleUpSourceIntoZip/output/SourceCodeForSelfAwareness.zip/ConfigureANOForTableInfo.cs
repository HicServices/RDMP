using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using CatalogueLibrary.Data;
using CatalogueLibrary.Data.DataLoad;
using CatalogueManager.DataLoadUIs.ANOUIs.ANOTableManagement;
using CatalogueManager.SimpleDialogs;

//http://download.microsoft.com/download/A/D/E/ADEFBFFF-2165-4F63-BB29-DCE891B95CC7/VisualBasicPowerPacksSetup.exe
using CatalogueManager.TestsAndSetup.ServicePropogation;
using DataLoadEngine.DataFlowPipeline.Components.Anonymisation;
using Microsoft.VisualBasic.PowerPacks;
using ReusableLibraryCode.Checks;
using ReusableUIComponents;
using ReusableUIComponents.ChecksUI;

namespace CatalogueManager.DataLoadUIs.ANOUIs
{
    /// <summary>
    /// This window has 2 use cases.  In the first case you are trying to convert a table full of data into an anonymous form by substituting identifiable categorical data (e.g.
    /// PatientIdentifiers) into an anonymous format.  In this case you should right click each categorical field you want to anonymise and create a new ANOTable / reuse an existing
    /// ANOTable.
    /// 
    /// The second use case is when you have no data loaded in your table and you have manually created the database structure yourself to have the correct types to recieve ANO formatted
    /// data (e.g. you created a column called ANOPatientId which is a varchar(12).  In this case you likely want to reuse some existing ANOTables without having to migrate any data. To
    /// do this add the ANOTables you need to the form and drag and drop the ANO columns onto thier corresponding ANOTables.  This will only work if you have correctly configured your 
    /// data types to match the expected ANOTable formats.
    /// </summary>
    public partial class ConfigureANOForTableInfo : RDMPForm
    {
        private readonly TableInfo _tableInfo;
        ShapeContainer canvas = new ShapeContainer();
        
        /// <summary>
        /// tracks the indexes of ColumnInfos known to associate with ANOTables to the DraggableANOTable that is associated with them
        /// </summary>
        readonly List<Association> associations = new List<Association>();

        public ConfigureANOForTableInfo(TableInfo tableInfo)
        {
            _tableInfo = tableInfo;
            InitializeComponent();

            // Set the form as the parent of the ShapeContainer.
            canvas.Parent = splitContainer1.Panel1;

            
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            
            if (_tableInfo == null)
                return;

            SetupAssociations();

            BetterToolTip.SetToolTip(this, ToolTips.ANOTablesConfiguration, Images.ANOTablesConfiguration);
        }

        private void SetupAssociations()
        {

            ColumnInfo[] columnInfos = _tableInfo.ColumnInfos.ToArray();

            //add the columninfos
            lbColumnInfos.Items.Clear();
            lbColumnInfos.Items.AddRange(columnInfos);
            
            //clear away any current draggables 
            associations.Clear();
            canvas.Shapes.Clear();
            foreach(var draggable in this.splitContainer1.Panel1.Controls.OfType<DraggableANOTable>().ToArray())
                this.splitContainer1.Panel1.Controls.Remove(draggable);


            //add the anotables - and record when adding them what controls are what (we could get by Tag but that will be a pain)
            foreach (int? anoTableID in columnInfos.Select(c => c.ANOTable_ID).Distinct())
            {
                if (anoTableID == null)
                    continue;

                DraggableANOTable draggableAnoTable = AddToDiagram(RepositoryLocator.CatalogueRepository.GetObjectByID<ANOTable>((int) anoTableID));
                
                for(int i =0;i<lbColumnInfos.Items.Count;i++)
                    if (((ColumnInfo) lbColumnInfos.Items[i]).ANOTable_ID == anoTableID)
                        AddNewAssociation(new Association(lbColumnInfos, (ColumnInfo) lbColumnInfos.Items[i], i,
                            new LineShape(canvas), draggableAnoTable));
            }
        }

        private void AddNewAssociation(Association association)
        {
            associations.Add(association);
            association.SelfDestructed += association_SelfDestructed;
            lbColumnInfos.Invalidate();
        }

        void association_SelfDestructed(object selfDestructor)
        {
            //association has blown itself up so stop tracking it
            associations.Remove((Association)selfDestructor);
            lbColumnInfos.Invalidate();
        }
        
        private void btnAddANOTableToDiagram_Click(object sender, EventArgs e)
        {
            var repo = RepositoryLocator.CatalogueRepository;
            var allAnoTables = repo.GetAllObjects<ANOTable>();

            IEnumerable<ANOTable> alreadyOnUI = splitContainer1.Panel1.Controls.OfType<DraggableANOTable>().Select(d=>(ANOTable)d.Tag).ToArray();

            //offer only those that are not already on the UI
            var selecter = new SelectIMapsDirectlyToDatabaseTableDialog(allAnoTables.Where(a => !alreadyOnUI.Any(existing => existing.ID == a.ID)), false, false);

            if (selecter.ShowDialog() == DialogResult.OK)
                AddToDiagram((ANOTable) selecter.Selected);
        }

        private int addedSoFar = 0;


        private DraggableANOTable AddToDiagram(ANOTable anoTable)
        {
            DraggableANOTable anoTableUI = new DraggableANOTable(anoTable,_tableInfo);
            anoTableUI.Location = new Point(btnAddANOTableToDiagram.Right + 50, 100 + (addedSoFar *50));
            addedSoFar++;
            this.splitContainer1.Panel1.Controls.Add(anoTableUI);
            anoTableUI.AssociationRequested += anoTableUI_AssociationRequested;
            return anoTableUI;
        }

        void anoTableUI_AssociationRequested(ColumnInfo columnInfo, DraggableANOTable draggableAnoTable)
        {
            int indexColumnInfoOfByID = -1;
            for (int i = 0; i < lbColumnInfos.Items.Count; i++)
                if (((ColumnInfo) lbColumnInfos.Items[i]).ID == columnInfo.ID)
                    indexColumnInfoOfByID = i;

            if(indexColumnInfoOfByID == -1)
                throw new Exception("DraggableANOTableUI requested to form an association with a ColumnInfo that is not in our listbox, how did that happen?");

            //see if there is already an association with a different table
            var existingAssociation = associations.FirstOrDefault(assoc => assoc.ColumnInfo.ID == columnInfo.ID);

            if (existingAssociation != null)
                existingAssociation.SelfDestruct();

            //actually make the change in database!
            columnInfo.ANOTable_ID = ((ANOTable) draggableAnoTable.Tag).ID;
            columnInfo.SaveToDatabase();

            AddNewAssociation(new Association(lbColumnInfos, columnInfo, indexColumnInfoOfByID, new LineShape(canvas),draggableAnoTable));
        }

       

        //Close form when user presses Escape
        private void ConfigureANOForTableInfo_KeyUp(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Escape)
                this.Close();
        }

        #region Listbox item draw code (Colors)
        private void lbColumnInfos_DrawItem(object sender, DrawItemEventArgs e)
        {
            Graphics g = e.Graphics;

            Association associationIfAny = associations.SingleOrDefault(assoc=>assoc.IndexInListbox == e.Index);
            
            // draw the background color you want
            if(associationIfAny == null)
            {

                g.FillRectangle(new SolidBrush(e.BackColor), e.Bounds); //draw the normal colour
                
                if (e.Index != -1)
                  g.DrawString(lbColumnInfos.Items[e.Index].ToString(), e.Font, new SolidBrush(lbColumnInfos.ForeColor), //draw text in normal colour
                    new PointF(e.Bounds.X, e.Bounds.Y));
            }
            else
            {

                g.FillRectangle(new SolidBrush(associationIfAny.DraggableAnoTable.Color), e.Bounds); //draw the association colour
                if (e.Index != -1)
                    g.DrawString(lbColumnInfos.Items[e.Index].ToString(), e.Font,
                        new SolidBrush(InvertMeAColour(associationIfAny.DraggableAnoTable.Color)),
                        //draw text in inversion of association colour
                        new PointF(e.Bounds.X, e.Bounds.Y));
            }
        }

        const int RGBMAX = 255;
        Color InvertMeAColour(Color ColourToInvert)
        {
            return Color.FromArgb(RGBMAX - ColourToInvert.R,
              RGBMAX - ColourToInvert.G, RGBMAX - ColourToInvert.B);
        }
        #endregion

        private void lbColumnInfos_MouseDown(object sender, MouseEventArgs e)
        {
            if (lbColumnInfos.SelectedItem == null)
                return;

            if(e.Button == MouseButtons.Right)
                return;

            lbColumnInfos.DoDragDrop(lbColumnInfos.SelectedItem, DragDropEffects.Copy);
        }

        private void btnManageANOTables_Click(object sender, EventArgs e)
        {
            ManageANOTables dialog = new ManageANOTables();
            dialog.RepositoryLocator = RepositoryLocator;
            dialog.ShowDialog(this);
        }


        ContextMenuStrip RightClickMenu = new ContextMenuStrip();
        private void lbColumnInfos_MouseUp(object sender, MouseEventArgs e)
        {
            if(e.Button == MouseButtons.Right)
            {
                int indexFromPoint = lbColumnInfos.IndexFromPoint(e.Location);
                if(indexFromPoint != -1)
                {
                    var c = (ColumnInfo)lbColumnInfos.Items[indexFromPoint];
                    RightClickMenu = new ContextMenuStrip();
                    RightClickMenu.Items.Add("Create NEW ANOConfiguration for " + c.GetRuntimeName(), null, delegate
                    {
                        RightClickMenu_CreateNEWANOTableFromColumnInfo(c,indexFromPoint);
                    });
                    RightClickMenu.Show(PointToScreen(e.Location));
                }
            }
        }

        private void RightClickMenu_CreateNEWANOTableFromColumnInfo(ColumnInfo columnInfo,int index)
        {
            //if it is a suitable conversion target
            if(ConvertColumnInfoIntoANOColumnInfo.IsSuitableConvertionTarget(columnInfo,checksUI1))
            {
                var dialog = new ConvertColumnInfoIntoANOColumnInfo(columnInfo);
                dialog.RepositoryLocator = RepositoryLocator;
                dialog.ShowDialog();
                SetupAssociations();
            }
        }

        private void btnCheckANOConfigurations_Click(object sender, EventArgs e)
        {
            checksUI1.Clear();
            try
            {
                ANOTableInfoSynchronizer synchronizer = new ANOTableInfoSynchronizer(_tableInfo);
                synchronizer.Synchronize(checksUI1);
            }
            catch (Exception exception)
            {
                checksUI1.OnCheckPerformed(new CheckEventArgs("ANOTableInfoSynchronizer checking failed", CheckResult.Fail, exception));
            }
            
            try
            {
                foreach (ColumnInfo col in lbColumnInfos.Items)
                    col.Check(checksUI1);
            }
            catch (Exception exception)
            {
                checksUI1.OnCheckPerformed(new CheckEventArgs("ANOTableInfoSynchronizer checking failed", CheckResult.Fail, exception));
            }
        }
    }
}

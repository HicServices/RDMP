using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using CatalogueLibrary.Data;
using CatalogueLibrary.Data.Aggregation;
using CatalogueLibrary.Data.Cohort;
using MapsDirectlyToDatabaseTable;
using ReusableLibraryCode.DataAccess;

namespace CohortManagerLibrary.Execution
{
    /// <summary>
    /// A single AggregationConfiguration being executed by a CohortCompiler
    /// </summary>
    public class AggregationTask:Compileable, IOrderable
    {
        public AggregateConfiguration Aggregate { get; private set; }

        private string _catalogueName;
        private CohortIdentificationConfiguration _cohortIdentificationConfiguration;

        public AggregationTask(AggregateConfiguration aggregate, CohortCompiler compiler): base(compiler)
        {
            Aggregate = aggregate;
            _catalogueName = aggregate.Catalogue.Name;
            _cohortIdentificationConfiguration = compiler.CohortIdentificationConfiguration;
        }


        public override string GetCatalogueName()
        {
            return _catalogueName;
        }

        public override IMapsDirectlyToDatabaseTable Child
        {
            get { return Aggregate; }
        }


        public override string ToString()
		{
            string name = Aggregate.ToString();


            string expectedTrimStart = _cohortIdentificationConfiguration.GetNamingConventionPrefixForConfigurations();

            if (name.StartsWith(expectedTrimStart))
                return name.Substring(expectedTrimStart.Length);

            //todo they don't follow the naming convention? why
            return name;
        }

        public override IDataAccessPoint[] GetDataAccessPoints()
        {
            return Aggregate.Catalogue.GetTableInfoList(false);
        }

        public bool IsCacheableWhenFinished()
        {
            string cacheStatus = GetCachedQueryUseCount();
            return cacheStatus.StartsWith("0") || cacheStatus.Equals("Unknown");
        }
    }
}

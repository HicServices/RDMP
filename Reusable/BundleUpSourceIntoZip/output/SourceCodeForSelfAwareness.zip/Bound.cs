using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using HIC.Common.Validation.UIAttributes;

namespace HIC.Common.Validation.Constraints.Secondary
{
    public abstract class Bound : SecondaryConstraint
    {
        [ExpectsColumnNameAsInput]
        public string LowerFieldName { get; set; }
        [ExpectsColumnNameAsInput]
        public string UpperFieldName { get; set; }

        public bool Inclusive { get; set; }

        protected object LookupFieldNamed(string name, object[] otherColumns, object[] otherColumnNames)
        {
            for (int i = 0; i < otherColumnNames.Length; i++)
                if (otherColumnNames[i].Equals(name))
                    return otherColumns[i];

            if (!string.IsNullOrWhiteSpace(name))
                SignalThatFieldWasNotFound(name);

            return null;
        }

        private void SignalThatFieldWasNotFound(string name)
        {
            throw new MissingFieldException("Validation failed: Comparator field [" + name +
                                                "] not found in dictionary.");
        }

        public override void RenameColumn(string originalName, string newName)
        {
            if (LowerFieldName != null)
                if (LowerFieldName.EndsWith(originalName))
                    LowerFieldName = newName;

            if (UpperFieldName != null)
                if (UpperFieldName.EndsWith(originalName))
                    UpperFieldName = newName;
        }

        public override string GetHumanReadable()
        {
            string result = "";

            if (LowerFieldName != null )
                if(Inclusive)
                    result += " >=" + LowerFieldName;
                else
                    result += " >" + LowerFieldName;
            
            if (UpperFieldName != null )
                if (Inclusive)
                    result += " <=" + UpperFieldName;
                else
                    result += " <" + UpperFieldName;

            return result;
        }
    }
}

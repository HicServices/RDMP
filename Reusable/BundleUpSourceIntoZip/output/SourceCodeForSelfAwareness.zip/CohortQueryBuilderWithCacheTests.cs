using System.Data; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Data.SqlClient;
using CatalogueLibrary.Data;
using CohortManagerLibrary.QueryBuilding;
using MapsDirectlyToDatabaseTable.Versioning;
using NUnit.Framework;
using QueryCaching.Aggregation;
using ReusableLibraryCode.Checks;
using ReusableLibraryCode.DatabaseHelpers.Discovery;
using Tests.Common;

namespace CohortManagerTests.cs
{
    public class CohortQueryBuilderWithCacheTests : ComplexCohortIdentificationTests
    {
        private readonly string _scratchDatabaseName = TestDatabaseNames.GetConsistentName("ScratchArea");
        private SqlConnectionStringBuilder queryCacheBuilder;
        private ExternalDatabaseServer externalDatabaseServer;

        public CohortQueryBuilderWithCacheTests()
        {
            HowMuchDoICare = CarePolice.IDontCareAboutAnythingOrAnyone;

        }

        [TestFixtureSetUp]
        public void SetUpCache()
        {
            queryCacheBuilder = new SqlConnectionStringBuilder(ServerICanCreateRandomDatabasesAndTablesOn.ConnectionString);
            queryCacheBuilder.InitialCatalog = "RDMP_Tests_QueryCache";
            
            MasterDatabaseScriptExecutor executor = new MasterDatabaseScriptExecutor(queryCacheBuilder.ConnectionString);

            executor.CreateAndPatchDatabase(typeof(CachedAggregateConfigurationResultsManager).Assembly,new ThrowImmediatelyCheckNotifier());
            
            externalDatabaseServer = new ExternalDatabaseServer(CatalogueRepository, "QueryCacheForUnitTests");
            
            externalDatabaseServer.Server = queryCacheBuilder.DataSource;
            externalDatabaseServer.Database = queryCacheBuilder.InitialCatalog;
            externalDatabaseServer.SaveToDatabase();


        }

        [TestFixtureTearDown]
        public void DropDatabases()
        {
            
            new DiscoveredServer(queryCacheBuilder).ExpectDatabase(queryCacheBuilder.InitialCatalog).ForceDrop();
            externalDatabaseServer.DeleteInDatabase();
        }

        [Test]
        public void TestGettingAggregateJustFromConfig_DistinctCHISelect()
        {

            CachedAggregateConfigurationResultsManager manager = new CachedAggregateConfigurationResultsManager( externalDatabaseServer);
            
            cohortIdentificationConfiguration.QueryCachingServer_ID = externalDatabaseServer.ID;
            cohortIdentificationConfiguration.SaveToDatabase();
            

            CohortQueryBuilder builder = new CohortQueryBuilder(cohortIdentificationConfiguration);
            cohortIdentificationConfiguration.CreateRootContainerIfNotExists();
            cohortIdentificationConfiguration.RootCohortAggregateContainer.AddChild(aggregate1,0);
            try
            {
                Assert.AreEqual(@"
(
	--UnitTestAggregate1
	SELECT distinct
	[RDMP_Tests_ScratchArea]..[BulkData].[chi] 
	FROM 
	[RDMP_Tests_ScratchArea]..[BulkData]
)
", builder.SQL);

                using(SqlConnection con= new SqlConnection(ServerICanCreateRandomDatabasesAndTablesOn.ConnectionString))
                {
                    con.Open();

                    SqlDataAdapter da = new SqlDataAdapter(builder.SQL,con);
                    var dt = new DataTable();
                    da.Fill(dt);

                    manager.CommitResults(aggregate1, AggregateOperation.IndexedExtractionIdentifierList, @"--UnitTestAggregate1
SELECT distinct
[RDMP_Tests_ScratchArea]..[BulkData].[chi] 
FROM 
[RDMP_Tests_ScratchArea]..[BulkData]",dt,null);    
                }


                CohortQueryBuilder builderCached = new CohortQueryBuilder(cohortIdentificationConfiguration);

                Assert.AreEqual(@"
(
	--Cached:UnitTestAggregate1
	select * from [RDMP_Tests_QueryCache]..[IndexedExtractionIdentifierList_AggregateConfiguration"+aggregate1.ID+@"]

)
", builderCached.SQL);

            }
            finally
            {
                cohortIdentificationConfiguration.RootCohortAggregateContainer.RemoveChild(aggregate1);
                
            }

        }
    }
}

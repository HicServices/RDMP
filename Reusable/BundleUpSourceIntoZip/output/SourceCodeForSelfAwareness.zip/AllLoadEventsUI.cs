using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Threading;
using System.Windows.Forms;
using CatalogueLibrary.Data.DataLoad;
using HIC.Logging;
using HIC.Logging.PastEvents;
using ReusableUIComponents;

namespace Dashboard.CatalogueSummary.LoadEvents
{
    /// <summary>
    /// Shows two LoadEventsTreeView controls, one for loads audited in the Live logging server and one for loads audited in the Test logging server (if you have one).  See 
    /// LoadEventsTreeView for a description of the full logging functionality.
    /// </summary>
    public partial class AllLoadEventsUI : UserControl
    {
        private LoadMetadata _loadMetadata;

        //constructor
        public AllLoadEventsUI()
        {
            InitializeComponent();

            liveLoads.IsTestServerInterrogation = false;
            testLoads.IsTestServerInterrogation = true;
        }


        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public LoadMetadata LoadMetadata
        {
            get { return _loadMetadata; }
            set
            {
                _loadMetadata = value;

                liveLoads.LoadMetadata = value;
                
                if (value != null && _loadMetadata.AreLiveAndTestLoggingDifferent())
                {
                    testLoads.LoadMetadata = value;

                    if(!tabControl1.TabPages.Contains(tabPage2))
                        tabControl1.TabPages.Add(tabPage2);
                }
                else
                {
                    tabControl1.TabPages.Remove(tabPage2);
                }
            }
        }


        private void tbFilter_TextChanged(object sender, EventArgs e)
        {
            testLoads.ApplyFilter(tbFilter.Text);
            liveLoads.ApplyFilter(tbFilter.Text);
        }
    }
}

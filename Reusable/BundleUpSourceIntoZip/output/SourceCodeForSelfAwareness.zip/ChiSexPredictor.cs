using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Globalization;
using HIC.Common.Validation.Constraints.Primary;

namespace HIC.Common.Validation.Constraints.Secondary.Predictor
{
    class ChiSexPredictor : IPredictor
    {
        public Type GetCompatibleType()
        {
            return typeof (string);
        }

        public void Predict(object oChi, string targetColumnName, object[] otherColumns, string[] otherColumnNames)
        {
            
            PerformChecks(oChi, targetColumnName);

            var genderValue = RetrieveGenderValue(targetColumnName, otherColumns, otherColumnNames);

            if (genderValue == null) // Null is valid
                return;

            char sex;

            var s = genderValue as string;
            if (s != null)
                sex = s.ToCharArray()[0];
            else
                if (genderValue is char) //todo Unreachable code!
                    sex = (char)genderValue;
                else
                    throw new ArgumentException("Gender must be a string or char, gender value is a " + genderValue.GetType());

            var sChi = (string)oChi;

            if (sChi.Length == 10)
            {
                var sexDigit = (int)Char.GetNumericValue(sChi, 8);

                bool isvalid = true;

                if (sex.ToString(CultureInfo.InvariantCulture).ToUpper() != "M" && sex.ToString(CultureInfo.InvariantCulture).ToUpper() != "F") // Pass as valid if sex is not strictly specified
                    return;

                if (sexDigit % 2 == 0 && sex == 'M')
                    isvalid = false;

                if (sexDigit % 2 == 1 && sex == 'F')
                    isvalid = false;

                if (!isvalid)
                    throw new PredictionException("CHI sex indicator (" + sexDigit + ")  did not match associated sex field (" + sex + ")");
            }

            //invalid chi, who cares
        }

        private static object RetrieveGenderValue(string targetColumnName, object[] otherColumns, string[] otherColumnNames)
        {
            object genderValue = null;

            bool found = false;
            for (int i = 0; i < otherColumnNames.Length; i++)
            {
                if (otherColumnNames[i].Equals(targetColumnName))
                {
                    found = true;
                    genderValue = otherColumns[i];
                }
            }

            if (!found)
                throw new MissingFieldException("Could not predict gender because fields passed did not contain one called " +
                                                targetColumnName);
            return genderValue;
        }

        private static void PerformChecks(object value, string targetColumnName)
        {
            string errorReport;

            if (value.GetType() != typeof (string))
                throw new ArgumentException("Could not predict gender because supplied chi was not a string");

            if (!Chi.IsValidChiNumber((string) value, out errorReport))
                throw new PredictionException("Validation failed: CHI is invalid.");

            if (targetColumnName == null)
                throw new MissingFieldException("No target field name was supplied.");
        }
    }
}

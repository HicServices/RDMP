using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using CatalogueLibrary.Data;
using DataExportManager2.Interfaces.ExtractionTime.UserPicks;

namespace DataExportManager2Library.ExtractionTime.UserPicks
{
    public class BundledLookupTable : IBundledLookupTable
    {
        public TableInfo TableInfo { get; set; }

        public BundledLookupTable(TableInfo tableInfo)
        {
            if(!tableInfo.IsLookupTable())
                throw new Exception("TableInfo " + tableInfo + " is not a lookup table");

            TableInfo = tableInfo;
        }

        public override string ToString()
        {
            return TableInfo.ToString();
        }
    }
}

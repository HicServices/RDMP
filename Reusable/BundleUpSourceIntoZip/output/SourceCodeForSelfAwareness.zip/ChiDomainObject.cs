﻿namespace HIC.Common.Validation.Tests.TestData
{
    public class ChiDomainObject
    {
        public string chi { get; set; }

        public ChiDomainObject(string chi)
        {
            this.chi = chi;
        }

    }
}
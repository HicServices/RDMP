namespace HIC.Common.Validation.Tests.TestData // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
{
    public class ChiDomainObject
    {
        public string chi { get; set; }

        public ChiDomainObject(string chi)
        {
            this.chi = chi;
        }

    }
}

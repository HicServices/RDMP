using System.IO; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using CatalogueLibrary.Repositories;

namespace CatalogueLibrary.Data.Cache
{
    public class CacheLayoutFactory
    {
        private readonly MEF _mefPlugins;

        public CacheLayoutFactory(MEF mefPlugins)
        {
            _mefPlugins = mefPlugins;
        }

        public ICacheLayout Create(string typeName, DirectoryInfo rootDirectory)
        {
            return _mefPlugins.FactoryCreateA<ICacheLayout, DirectoryInfo>(typeName, rootDirectory);
        }
    }
}

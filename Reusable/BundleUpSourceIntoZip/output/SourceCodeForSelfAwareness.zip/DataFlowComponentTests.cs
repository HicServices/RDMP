using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Data;
using CatalogueLibrary.DataFlowPipeline;
using LoadModules.Generic.DataFlowOperations;
using NUnit.Framework;
using ReusableLibraryCode.Progress;

namespace DataLoadEngineTests.Unit
{
    class DataFlowComponentTests
    {
        [Test]
        public void ColumnRenamer_NoMatchingColumnAtRuntime()
        {
            var renamer = new ColumnRenamer
            {
                ColumnNameToFind = "DoesNotExist",
                ReplacementName = "ReplacementName"
            };

            var cts = new GracefulCancellationTokenSource();
            var toProcess = new DataTable();
            toProcess.Columns.Add("Column1");

            var ex = Assert.Throws<InvalidOperationException>(() => renamer.ProcessPipelineData( toProcess, new ToConsoleDataLoadEventReciever(), cts.Token));
            Assert.IsTrue(ex.Message.Contains("does not exist in the supplied data table"));
        }

        [Test]
        public void ColumnRenamer_Successful()
        {
            var renamer = new ColumnRenamer
            {
                ColumnNameToFind = "ToFind",
                ReplacementName = "ReplacementName"
            };

            var cts = new GracefulCancellationTokenSource();
            var toProcess = new DataTable();
            toProcess.Columns.Add("ToFind");

            var processed = renamer.ProcessPipelineData( toProcess, new ToConsoleDataLoadEventReciever(), cts.Token);

            Assert.AreEqual(1, processed.Columns.Count);
            Assert.AreEqual("ReplacementName", processed.Columns[0].ColumnName);
        }
    }
}

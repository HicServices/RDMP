using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using MapsDirectlyToDatabaseTable;
using ReusableLibraryCode;
using QuerySyntaxHelper = CatalogueLibrary.DataHelper.QuerySyntaxHelper;

namespace CatalogueLibrary.Data.Aggregation
{
    /// <summary>
    /// This class allows you to associate a specific extractioninformation for use in aggregate generation.  For example a dataset might have a date field AdmissionDate which you
    /// want to create an aggregate configuration (when patients were admitted) over time.  However the class also allows you to specify new SelectSQL which can change how the field
    /// is extracted e.g. you might want to change "[MyDatabase].[MyTable].[AdmissionDate]" into "YEAR([MyDatabase].[MyTable].[AdmissionDate]) as AdmissionDate" 
    /// </summary>
    public class AggregateDimension : VersionedDatabaseEntity, ISaveable, IDeleteable, IColumn
    {
        public int AggregateConfiguration_ID { get; set; }
        public int ExtractionInformation_ID { get; set; }

        public string Alias { get; set; }
        public string SelectSQL { get; set; }
        public int Order { get; set; }

        //IExtractableColumn stuff (which references the underlying extractionInformation - does not appear in table but fetches it from the other objects table)
        private ExtractionInformation _extractionInformation;



        [NoMappingToDatabase]
        public bool HashOnDataRelease { get{CacheExtractionInformation(); return _extractionInformation.HashOnDataRelease; } }

        [NoMappingToDatabase]
        public bool IsExtractionIdentifier { get { CacheExtractionInformation(); return _extractionInformation.IsExtractionIdentifier; } }
        [NoMappingToDatabase]
        public bool IsPrimaryKey { get { CacheExtractionInformation(); return _extractionInformation.IsPrimaryKey; } }
        [NoMappingToDatabase]
        public ColumnInfo ColumnInfo { get { CacheExtractionInformation(); return _extractionInformation.ColumnInfo; } }

        #region Relationships
        [NoMappingToDatabase]
        public AggregateContinuousDateAxis AggregateContinuousDateAxis
        {
            get
            {
                return Repository.GetAllObjectsWithParent<AggregateContinuousDateAxis>(this).SingleOrDefault();
            }
        }

        [NoMappingToDatabase]
        public ExtractionInformation ExtractionInformation {get { return Repository.GetObjectByID<ExtractionInformation>(ExtractionInformation_ID); }
        }

        #endregion

        public AggregateDimension(IRepository repository, ExtractionInformation basedOnColumn, AggregateConfiguration configuration)
        {
            object alias = DBNull.Value;
            if (basedOnColumn.Alias != null) alias = basedOnColumn.Alias;

            repository.InsertAndHydrate(this,new Dictionary<string, object>
            {
                {"AggregateConfiguration_ID", configuration.ID},
                {"ExtractionInformation_ID", basedOnColumn.ID},
                {"SelectSQL", basedOnColumn.SelectSQL},
                {"Alias", alias},
                {"Order", basedOnColumn.Order}
            });
        }

        public AggregateDimension(IRepository repository,DbDataReader r) : base(repository,r)
        {
            AggregateConfiguration_ID = int.Parse(r["AggregateConfiguration_ID"].ToString());
            ExtractionInformation_ID = int.Parse(r["ExtractionInformation_ID"].ToString());
            
            SelectSQL = r["SelectSQL"] as string;
            Alias = r["Alias"] as string;

            Order = int.Parse(r["Order"].ToString());
        }
    
        public string GetRuntimeName()
        {
            return QuerySyntaxHelper.GetRuntimeName(this);
        }

        public override string ToString()
        {
            return GetRuntimeName();
        }
        
        private void CacheExtractionInformation()
        {
            if (_extractionInformation == null)
                //there is a cascade delete on the relationship between extraction informations down into dimensions that should prevent the user deleting the extraction information and it leaving an orphans defined in an aggregate.
                _extractionInformation = Repository.GetObjectByID<ExtractionInformation>(ExtractionInformation_ID);
        }

    }
}

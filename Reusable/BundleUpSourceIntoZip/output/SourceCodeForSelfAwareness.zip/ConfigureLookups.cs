using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Windows.Forms;
using CatalogueLibrary.Data;
using CatalogueLibrary.DataHelper;
using CatalogueLibrary.Repositories;
using ReusableUIComponents;
using ScintillaNET;

namespace CatalogueManager.ExtractionUIs
{
    /// <summary>
    /// A Lookup in RDMP is a relationship between three columns.  The 'Foreign Key' column must come from a normal dataset table e.g. 'Prescribing.DrugCode', the 'Primary Key' must come
    /// from a different table (ususally prefixed z_ to indicate it is a lookup table) e.g. 'z_DrugsLookup.DrugCode' and then a 'Description' column from the same table e.g. 
    /// 'z_DrugsLookup.DrugName'.  This is maintained in the RDMP Catalogue database and does not result in any changes / constraints on your actual data repository.  
    /// 
    /// While it might seem redundant to have to configure this logic in the RDMP aswell as (if you choose to) constraints in your data repository, this approach allows for 
    /// flexibility when it comes to incomplete/corrupt lookup tables (common in the research data management domain) as well as letting us bundle lookups with data extracts etc.
    /// 
    /// This window is a low level alternative to AdvancedLookupConfiguration (the recommended way of creating these Lookup relationships), this form lets you explicitly create a Lookup
    /// relationship using the supplied columns.  First of all you should make sure that the column you right clicked to activate the Form is the Description column.  Then select the
    /// 'Primary Key' and 'Foreign Key' as described above.  
    /// 
    /// If you have a particularly insane database design you can configure composite joins (where there are multiple columns that make up a composite 'Foreign Key' / 'Primary Key'.  For 
    /// example if there was crossover in 'DrugCode' between two countries then the Lookup relationship would need 'Primary Key' Prescribing.DrugCode + Prescribing.Country and the 
    /// 'Foreign Key' would need to be z_DrugsLookup.DrugCode + z_DrugsLookup.Country.
    /// </summary>
    public partial class ConfigureLookups : BetterToolTipForm
    {
        private readonly ColumnInfo _descriptionColumn;
        private readonly CatalogueRepository _catalogueRepository;

        private readonly Scintilla QueryPreview;
        private Lookup _lastSelectedLookup;

        private Lookup LastSelectedLookup
        {
            get { return _lastSelectedLookup; }
            set
            {
                if (value != null)
                {
                    tbID.Text = value.ID.ToString();
                    cbxForeignKey.Text = value.ForeignKey.ToString();
                    cbxPrimaryKey.Text = value.PrimaryKey.ToString();
                    ddLookupExtractionJoinType.Text = value.ExtractionJoinType.ToString();
                    cbCollate_Latin1_General_BIN.Checked = !string.IsNullOrWhiteSpace(value.Collation);
                    btnSave.Enabled = true;
                }
                else
                {
                    tbID.Text = "";
                    cbxForeignKey.Text = "";
                    cbxPrimaryKey.Text = "";
                    ddLookupExtractionJoinType.Text = "";
                    btnSave.Enabled = false;
                }

                _lastSelectedLookup = value;
            }
        }

        public ConfigureLookups(ColumnInfo descriptionColumn)
        {
            _descriptionColumn = descriptionColumn;
            InitializeComponent();

            if (descriptionColumn == null)
                return;

            _catalogueRepository = (CatalogueRepository) descriptionColumn.Repository;

            //add all columns in our entire database to this combo box (eek)
            cbxForeignKey.AutoCompleteList.AddRange(_catalogueRepository.GetAllObjects<ColumnInfo>());

            //add only the columns that are in the same table for join key 2
            TableInfo parent = descriptionColumn.TableInfo;
            cbxPrimaryKey.AutoCompleteList.AddRange(parent.ColumnInfos);

            object[] fields = Enum.GetValues(typeof(ExtractionJoinType))
                      .Cast<object>()
                      .ToArray();

            ddLookupExtractionJoinType.Items.AddRange(fields);

            RefreshListbox();

            #region Query Editor setup
            bool designMode = (LicenseManager.UsageMode == LicenseUsageMode.Designtime);

            if (designMode) //dont add the QueryEditor if we are in design time (visual studio) because it breaks
                return;


            QueryPreview = new Scintilla();
            QueryPreview.Dock = DockStyle.Fill;
            QueryPreview.Scrolling.ScrollBars = ScrollBars.Both;
            QueryPreview.ConfigurationManager.Language = "mssql";
            QueryPreview.Margins[0].Width = 40; //allows display of line numbers
            QueryPreview.IsReadOnly = true;


            pPreview.Controls.Add(QueryPreview);

            #endregion
        }

        private void RefreshListbox()
        {
            Lookup toReselect = null;

            if (lbLookups.SelectedItem != null)
                toReselect = lbLookups.SelectedItem as Lookup;

            lbLookups.Items.Clear();
            lbLookups.Items.AddRange(_descriptionColumn.GetAllLookupForColumnInfoWhereItIsA(LookupType.Description));

            if (toReselect != null)
                for (int i = 0; i < lbLookups.Items.Count; i++ )
                {
                    Lookup candidateForReselection = lbLookups.Items[i] as Lookup;

                    //ever lookup should match on description at the very least
                    Debug.Assert(candidateForReselection.Description.ID == toReselect.Description.ID);

                    if (candidateForReselection.ForeignKey.ID == toReselect.ForeignKey.ID && candidateForReselection.PrimaryKey.ID == toReselect.PrimaryKey.ID)
                        lbLookups.SelectedIndex = i;
                }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string collation = null;

            if (cbCollate_Latin1_General_BIN.Checked)
                collation = "Latin1_General_BIN";

            try
            {
                if(cbxForeignKey.SelectedItem!=null && cbxPrimaryKey.SelectedItem != null && ddLookupExtractionJoinType.SelectedItem != null)
                    new Lookup(_catalogueRepository,_descriptionColumn, cbxForeignKey.SelectedItem as ColumnInfo, cbxPrimaryKey.SelectedItem as ColumnInfo, (ExtractionJoinType)ddLookupExtractionJoinType.SelectedItem, collation);
                
                RefreshListbox();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if(lbLookups.SelectedItem is Lookup)
                ((Lookup)lbLookups.SelectedItem).DeleteInDatabase();

            RefreshListbox();
        }

        private void cbxJoinKey1_SelectedIndexChanged(object sender, EventArgs e)
        {
            GeneratePreviewFromCurrentValues();
        }

        private void cbxJoinKey2_SelectedIndexChanged(object sender, EventArgs e)
        {
            GeneratePreviewFromCurrentValues();
        }
        private void cbxLookupExtractionJoinType_SelectedIndexChanged(object sender, EventArgs e)
        {
            GeneratePreviewFromCurrentValues();
        }

        private void cbCollate_Latin1_General_BIN_CheckedChanged(object sender, EventArgs e)
        {
            GeneratePreviewFromCurrentValues();
        }

        private void GeneratePreviewFromCurrentValues()
        {
          
            QueryPreview.IsReadOnly = false;

            if (LastSelectedLookup != null)
                //this method handles nulls
                QueryPreview.Text =
                    "SELECT " + Environment.NewLine +
                    _descriptionColumn.Name + Environment.NewLine +
                    "FROM " + Environment.NewLine +
                    JoinHelper.GetJoinSQL(LastSelectedLookup);
            else
                QueryPreview.Text = "";

            QueryPreview.IsReadOnly = true;
        }

        private void lbLookups_SelectedIndexChanged(object sender, EventArgs e)
        {
            cbxForeignKey.SuppressAutoComplete = true;
            cbxPrimaryKey.SuppressAutoComplete = true;

            
            LastSelectedLookup = lbLookups.SelectedItem as Lookup;
            GeneratePreviewFromCurrentValues();

            cbxForeignKey.SuppressAutoComplete = false;
            cbxPrimaryKey.SuppressAutoComplete = false;

            
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string collation = null;

            if (cbCollate_Latin1_General_BIN.Checked)
                collation = "Latin1_General_BIN";

            try
            {
                LastSelectedLookup.PrimaryKey_ID = ((ColumnInfo)cbxPrimaryKey.SelectedItem).ID;
                LastSelectedLookup.ForeignKey_ID = ((ColumnInfo)cbxForeignKey.SelectedItem).ID;
                LastSelectedLookup.Collation = collation;
                LastSelectedLookup.ExtractionJoinType = (ExtractionJoinType)ddLookupExtractionJoinType.SelectedItem;

                LastSelectedLookup.SaveToDatabase();
                RefreshListbox();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        private void btnAddCompositeJoin_Click(object sender, EventArgs e)
        {
            Lookup l = lbLookups.SelectedItem as Lookup;
            if (l == null)
            {
                MessageBox.Show("Select a Lookup from the listbox above");
                return;
            }
            else
            {
                ConfigureLookupCompositeJoinInfo dialog = new ConfigureLookupCompositeJoinInfo(l);
                dialog.ShowDialog(this);
                this.RefreshListbox();
            }
        }


    }
}

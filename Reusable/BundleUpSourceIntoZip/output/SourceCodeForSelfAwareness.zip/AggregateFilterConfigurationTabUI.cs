using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CatalogueLibrary.Data;
using CatalogueLibrary.Data.Aggregation;
using CatalogueLibrary.Data.Cohort;
using CatalogueLibrary.Repositories;
using CatalogueManager.ExtractionUIs.FilterUIs;
using CatalogueManager.SimpleDialogs;
using IContainer = CatalogueLibrary.Data.IContainer;

namespace CatalogueManager.AggregationUIs
{
    /// <summary>
    /// Allows you to configure all the WHERE conditions which relate to your GROUP BY (Aggregate).  Start by creating either an AND or an OR container.  Then add one or more Filters.
    /// Each Filter is a single line of WHERE logic which is seperated by the Operator of the Container it is in.  For example if you had a filter 'Deleted = 0' and a filter 'YEAR(Date)>2000'
    /// in an OR container your aggregate (GROUP BY) would only show records after 2000 which have not been flagged as Deleted.
    /// 
    /// Where possible you should import Filters from the Catalogue to use since the model of the RDMP is to curate WHERE logic at Catalogue level and reuse it at Data Export and Aggregation
    /// level (This approach creates 1 'master' implementation of each reusable filter which can be centrally managed and documented).
    /// 
    /// Finally there is a button at the bottom of the form that lets you create a 'shortcut' to the filter tree of another Aggregate.  This means that all the AND/OR containers and Filters 
    /// will be copied verbatim from the target aggregate into this one every time it is run.  This allows you to create several different aggregates which all target the same root aggregate
    /// (e.g. a cohort identification aggregate).  The primary purpose of this functionality is to reduce duplication and allow you to produce different views/graphs and sums/totals for sets
    ///  you are using in cohort identification.
    /// </summary>
    public partial class AggregateFilterConfigurationTabUI : UserControl, IContainerTreeChangeOrchestrator
    {
        private AggregateConfiguration _aggregateConfiguration;
        private Catalogue _catalogue;
        private CatalogueRepository _repository;

        public AggregateConfiguration AggregateConfiguration
        {
            get { return _aggregateConfiguration; }
            set
            {
                _aggregateConfiguration = value;

                if (value == null)
                {
                    filterTreeUI1.Enabled = false;
                    filterTreeUI1.Clear();
                    btnCreateShortcutToExistingFilterConfigurationInAnotherAggregate.Enabled = false;
                    
                    EnableFilterModifications(false);
                }
                else
                {
                    _catalogue = value.Catalogue;
                    _repository = (CatalogueRepository) _catalogue.Repository;

                    btnCreateShortcutToExistingFilterConfigurationInAnotherAggregate.Enabled = true;
                    filterTreeUI1.Clear();
                    
                    //add the root filter to the tree component that lets you build AND/OR etc trees and edit filters
                    if (value.RootFilterContainer_ID != null)
                        filterTreeUI1.SetRootContainerTo(value.RootFilterContainer);
                    
                    //list of the columns the user might want to use in his filters (helper only they can type whatever they want really)
                    filterTreeUI1.SetInsertColumnCollection(_catalogue.GetAllExtractionInformation(ExtractionCategory.Any));

                    filterTreeUI1.extractionFilterUI1.Catalogue = _catalogue;

                    EnableFilterModifications(value.OverrideFiltersByUsingParentAggregateConfigurationInstead_ID == null);

                    RefreshGlobalParametersFromDatabase();
                }

            }
        }

        public AggregateFilterConfigurationTabUI()
        {
            InitializeComponent();

            filterTreeUI1.ChangeOrchestrator = this;
            filterTreeUI1.ContainerConstructor =
                () =>
                new AggregateFilterContainer(_repository,FilterContainerOperation.AND);
            filterTreeUI1.Enabled = false;
        }

        public void RefreshGlobalParametersFromDatabase()
        {
            filterTreeUI1.GlobalFilterParameters = AggregateConfiguration.Parameters.ToArray();
        }

        public IContainer CreateNewContainerInDatabase()
        {
            return
                new AggregateFilterContainer(_repository,FilterContainerOperation.AND);
        }

        public IContainer AssertNoCurrentRootThenCreateNewRootContainer()
        {
            if (AggregateConfiguration == null)
                throw new NullReferenceException("No Aggregation Configuration is selected");

            if (AggregateConfiguration.RootFilterContainer_ID != null)
                throw new Exception("Cannot create a new Root Container because it already has one");

            var newRoot = new AggregateFilterContainer(_repository,FilterContainerOperation.AND);
            AggregateConfiguration.RootFilterContainer_ID = newRoot.ID;
            AggregateConfiguration.SaveToDatabase();


            return newRoot;
        }

        public IFilter CreateNewEmptyFilter()
        {
            return new AggregateFilter(_repository,Guid.NewGuid().ToString());
        }

        public IEnumerable<IFilter> ImportFiltersFromCatalogue()
        {
            if (_catalogue == null)
                return new IFilter[0];

            FilterImporter importer = new FilterImporter(_catalogue, 
                s=>new AggregateFilter(_repository,s),
                (s,f)=>new AggregateFilterParameter(_repository,s,f));

            importer.ShowDialog();

            if (importer.DialogResult == DialogResult.OK)
                return importer.Imported;

            //user said no or something
            return new IFilter[0];
        }
        
        private void EnableFilterModifications(bool value)
        {
            filterTreeUI1.Enabled = value;
        }

        private void btnCreateShortcutToExistingFilterConfigurationInAnotherAggregate_Click(object sender, EventArgs e)
        {
            if (AggregateConfiguration != null)
            {
                if (AggregateConfiguration.RootFilterContainer_ID != null)
                {
                    MessageBox.Show("Cannot make this AggregateConfiguration into a shortcut because it already has it's own Filters, you must delete the existing filters before you can set it up as a shortcut ");
                    return;    
                }

                if(AggregateConfiguration.OverrideFiltersByUsingParentAggregateConfigurationInstead_ID != null)
                {
                    var parent = AggregateConfiguration.OverrideFiltersByUsingParentAggregateConfigurationInstead;

                    if(MessageBox.Show("Your AggregateConfiguration is already a shortcut (it uses the Filters tree of '" + parent.Name + "', do you want to change to a different one?","Confirm Changing Parent",MessageBoxButtons.YesNoCancel ) != DialogResult.Yes)
                        return;
                }
                
                var others
                    =
                    //get all configurations
                    _repository.GetAllObjects<AggregateConfiguration>().Where(a =>
                        //which are not themselves already shortcuts!
                        a.OverrideFiltersByUsingParentAggregateConfigurationInstead_ID == null
                        &&
                        //and which have a filter set!
                        a.RootFilterContainer_ID != null)
                        //and are not ourself!
                        .Except(new []{AggregateConfiguration}).ToArray();

                SelectIMapsDirectlyToDatabaseTableDialog dialog = new SelectIMapsDirectlyToDatabaseTableDialog(others,true,false);

                if(dialog.ShowDialog() == DialogResult.OK)
                {

                    if (dialog.Selected == null)
                    {
                        AggregateConfiguration.OverrideFiltersByUsingParentAggregateConfigurationInstead_ID = null;
                        EnableFilterModifications(true);
                    }
                    else
                    {
                        AggregateConfiguration.OverrideFiltersByUsingParentAggregateConfigurationInstead_ID = ((AggregateConfiguration)dialog.Selected).ID;
                        EnableFilterModifications(false);
                    }
                    
                    AggregateConfiguration.SaveToDatabase();
                }
            }
        }

    }
}

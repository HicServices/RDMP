using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.ComponentModel;
using System.ComponentModel.Composition;
using System.Data.SqlClient;
using CatalogueLibrary;
using CatalogueLibrary.Data;
using CatalogueLibrary.Data.DataLoad;
using DataLoadEngine.Mutilators;
using ReusableLibraryCode;
using ReusableLibraryCode.Checks;
using ReusableLibraryCode.DatabaseHelpers.Discovery;
using ReusableLibraryCode.Progress;

namespace LoadModules.Generic.Mutilators
{
    public enum DilutionOperation
    {
        Left4OfPostcodes = 1,
        RoundDateToMiddleOfQuarter=2,
    }

    [Description("This operation MUST only appear in AdjustSTAGING.  It works in concert with PreLoadDiscardedColumns.  Create a PreLoadDiscardedColumn with Destination=Dilution, this operation can then be used to mutilate the value (for example cutting off the ends of postcodes).  The pristene (un-mutilated) value will be stored in the IdentifierDump along with all the other dumped columns but the LIVE will also contain the mutilated value")]
    public class Dilution : IPluginMutilateDataTables
    {

        [DemandsInitialization("Column which is to be diluted, must have Destination=Dilution - i.e. not Destination=Oblivion or StoreInIdentifierDump")]
        public PreLoadDiscardedColumn ColumnToDilute { get; set; }
        
        [DemandsInitialization("Dilution Operation to be performed on the column")]
        public DilutionOperation Operation { get; set; }

        
        public void Check(ICheckNotifier notifier)
        {
            if (ColumnToDilute == null)
            {
                notifier.OnCheckPerformed(new CheckEventArgs("ColumnToDilute is null", CheckResult.Fail, null));
                return;
            }
            
            //confirm type safety
            if (Operation == DilutionOperation.RoundDateToMiddleOfQuarter &&
                !ColumnToDilute.SqlDataType.ToLower().Contains("date"))
                notifier.OnCheckPerformed(new CheckEventArgs(
                    "ColumnToDilute '" + ColumnToDilute.RuntimeColumnName +
                    "' has a date related operation configured (" + Operation + ") but it's datatype is " +
                    ColumnToDilute.SqlDataType, CheckResult.Fail, null));

            if (ColumnToDilute.Destination != DiscardedColumnDestination.Dilute)
                notifier.OnCheckPerformed(new CheckEventArgs("ColumnToDilute '" + ColumnToDilute.GetRuntimeName() +"' is not marked as DiscardedColumnDestination.Dilute", CheckResult.Fail, null));

        }

        public bool DisposeImmediately { get; set; }
        public void LoadCompletedSoDispose(ExitCodeType exitCode, IDataLoadEventListener postLoadEventsListener)
        {
            
        }
        
        private DiscoveredDatabase _dbInfo;
        private LoadStage _loadStage;
        private TableInfo _tableInfo;

        public void Initialize(DiscoveredDatabase dbInfo, LoadStage loadStage)
        {
            _dbInfo = dbInfo;
            _loadStage = loadStage;
            _tableInfo = ColumnToDilute.TableInfo;
        }

        public string DatabaseServer { get; private set; }
        public string DatabaseName { get; private set; }

        public ProcessExitCode Mutilate(IDataLoadEventListener job)
        {
            if (_loadStage != LoadStage.AdjustStaging)
            {
                job.OnNotify(this, new NotifyEventArgs(ProgressEventType.Error, "Dilution can ONLY occur in load stage AdjustStaging, it is currently configured as load stage: " + _loadStage));
                return ProcessExitCode.Failure;
            }
            var con =_dbInfo.Server.GetConnection();

            con.Open();
            
            UsefulStuff.ExecuteBatchNonQuery(GetMutilationSql(), con, 5000);

            con.Close();
            return ProcessExitCode.Success;
        }

        private string GetMutilationSql()
        {
            switch (Operation)
            {
                case DilutionOperation.Left4OfPostcodes:
                    throw new NotImplementedException();
                case DilutionOperation.RoundDateToMiddleOfQuarter:
                    return GetRoundDatesSql();
                default:
                    throw new ArgumentOutOfRangeException();
            }
        }

        private string GetRoundDatesSql()
        {
            return String.Format(@"IF OBJECT_ID('dbo.RoundDateToMiddleOfQuarter') IS NOT NULL
  DROP FUNCTION RoundDateToMiddleOfQuarter
GO

CREATE FUNCTION RoundDateToMiddleOfQuarter
(
	-- Add the parameters for the function here
	@DOB date
)
RETURNS date
AS
BEGIN
	-- Declare the return variable here
	DECLARE @anonDOB date

	-- Add the T-SQL statements to compute the return value here
      IF MONTH(@DOB) IN (1,2,3)
	    SET @anonDOB =   LEFT(@DOB, 4) + '0215'
      ELSE IF MONTH(@DOB) IN (4,5,6)
	    SET @anonDOB = LEFT(@DOB, 4) + '0515' 
      ELSE IF MONTH(@DOB) IN (7,8,9)
	    SET @anonDOB = LEFT(@DOB, 4) + '0815' 
	  ELSE IF MONTH(@DOB)IN (10,11,12)
	    SET @anonDOB = LEFT(@DOB, 4) + '1115' 
     ELSE SET @anonDOB = NULL
	
	-- Return the result of the function
	RETURN @anonDOB
END
GO

UPDATE {0} SET {1}=dbo.RoundDateToMiddleOfQuarter({1})
GO",
   _tableInfo.GetRuntimeName(_loadStage), ColumnToDilute.GetRuntimeName());
        }
    }
}

using System.Data.Common; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using CatalogueLibrary.DataHelper;
using MapsDirectlyToDatabaseTable;

namespace CatalogueLibrary.Data
{
    public abstract class ConcreteColumn : VersionedDatabaseEntity, IColumn
    {
        protected ConcreteColumn(IRepository repository, DbDataReader r):base(repository,r)
        {
            
        }

        protected ConcreteColumn()
        {
            
        }

        public string GetRuntimeName()
        {
            return QuerySyntaxHelper.GetRuntimeName(this);
        }

        #region Relationships

        [NoMappingToDatabase]
        public abstract ColumnInfo ColumnInfo { get; set; }

        #endregion

        public int Order { get; set; }
        
        private string _selectSql;

        /// <summary>
        /// Do not use this in SELECT commands, instead use GetExtractionSelectSQL as this method will deal with cases where SelectSQL is null
        /// </summary>
        public string SelectSQL
        {
            get { return _selectSql; }
            set
            {
                _selectSql = value;

                //never allow annoying whitespace on this field
                if (!string.IsNullOrWhiteSpace(_selectSql))
                    _selectSql = _selectSql.Trim();

            }
        }
        public string Alias { get; set; }
        public bool HashOnDataRelease { get; set; }
        public bool IsExtractionIdentifier { get; set; }
        public bool IsPrimaryKey { get; set; }
    }
}

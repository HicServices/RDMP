namespace ReusableUIComponents.ChecksUI
{
    public delegate void AllChecksCompleteHandler(object sender, AllChecksCompleteHandlerArgs args);
}
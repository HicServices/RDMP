using Dashboard.CatalogueSummary; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using Dashboard.Overview;

namespace Dashboard
{
    partial class DashboardMainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DashboardMainForm));
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.ci_lbCatalogues = new CatalogueManager.MainFormUITabs.SubComponents.CatalogueCollectionHost();
            this.catalogueSummaryScreen1 = new Dashboard.CatalogueSummary.CatalogueSummaryScreen();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tpOverview = new System.Windows.Forms.TabPage();
            this.overviewScreen1 = new Dashboard.Overview.OverviewScreen();
            this.tpByCatalogue = new System.Windows.Forms.TabPage();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.locationsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.refreshAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tpOverview.SuspendLayout();
            this.tpByCatalogue.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(3, 3);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.ci_lbCatalogues);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.catalogueSummaryScreen1);
            this.splitContainer1.Size = new System.Drawing.Size(1327, 753);
            this.splitContainer1.SplitterDistance = 263;
            this.splitContainer1.TabIndex = 0;
            // 
            // ci_lbCatalogues
            // 
            this.ci_lbCatalogues.Collection = null;
            this.ci_lbCatalogues.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ci_lbCatalogues.Location = new System.Drawing.Point(0, 0);
            this.ci_lbCatalogues.Name = "ci_lbCatalogues";
            this.ci_lbCatalogues.Size = new System.Drawing.Size(259, 749);
            this.ci_lbCatalogues.TabIndex = 12;
            // 
            // catalogueSummaryScreen1
            // 
            this.catalogueSummaryScreen1.Catalogue = null;
            this.catalogueSummaryScreen1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.catalogueSummaryScreen1.Location = new System.Drawing.Point(0, 0);
            this.catalogueSummaryScreen1.Name = "catalogueSummaryScreen1";
            this.catalogueSummaryScreen1.Size = new System.Drawing.Size(1056, 749);
            this.catalogueSummaryScreen1.TabIndex = 0;
            this.catalogueSummaryScreen1.Load += new System.EventHandler(this.catalogueSummaryScreen1_Load);
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tpOverview);
            this.tabControl1.Controls.Add(this.tpByCatalogue);
            this.tabControl1.Location = new System.Drawing.Point(0, 27);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1341, 785);
            this.tabControl1.TabIndex = 1;
            // 
            // tpOverview
            // 
            this.tpOverview.Controls.Add(this.overviewScreen1);
            this.tpOverview.Location = new System.Drawing.Point(4, 22);
            this.tpOverview.Name = "tpOverview";
            this.tpOverview.Padding = new System.Windows.Forms.Padding(3);
            this.tpOverview.Size = new System.Drawing.Size(1333, 759);
            this.tpOverview.TabIndex = 0;
            this.tpOverview.Text = "Overview";
            this.tpOverview.UseVisualStyleBackColor = true;
            // 
            // overviewScreen1
            // 
            this.overviewScreen1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.overviewScreen1.Location = new System.Drawing.Point(3, 3);
            this.overviewScreen1.Name = "overviewScreen1";
            this.overviewScreen1.RepositoryLocator = null;
            this.overviewScreen1.Size = new System.Drawing.Size(1327, 753);
            this.overviewScreen1.TabIndex = 0;
            this.overviewScreen1.VisualStudioDesignMode = true;
            // 
            // tpByCatalogue
            // 
            this.tpByCatalogue.Controls.Add(this.splitContainer1);
            this.tpByCatalogue.Location = new System.Drawing.Point(4, 22);
            this.tpByCatalogue.Name = "tpByCatalogue";
            this.tpByCatalogue.Padding = new System.Windows.Forms.Padding(3);
            this.tpByCatalogue.Size = new System.Drawing.Size(1333, 759);
            this.tpByCatalogue.TabIndex = 1;
            this.tpByCatalogue.Text = "By Catalogue";
            this.tpByCatalogue.UseVisualStyleBackColor = true;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.locationsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1341, 24);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // locationsToolStripMenuItem
            // 
            this.locationsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.refreshAllToolStripMenuItem});
            this.locationsToolStripMenuItem.Name = "locationsToolStripMenuItem";
            this.locationsToolStripMenuItem.Size = new System.Drawing.Size(70, 20);
            this.locationsToolStripMenuItem.Text = "Locations";
            // 
            // refreshAllToolStripMenuItem
            // 
            this.refreshAllToolStripMenuItem.Name = "refreshAllToolStripMenuItem";
            this.refreshAllToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.refreshAllToolStripMenuItem.Text = "Refresh All";
            this.refreshAllToolStripMenuItem.Click += new System.EventHandler(this.refreshAllToolStripMenuItem_Click);
            // 
            // DashboardMainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1341, 812);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "DashboardMainForm";
            this.Text = "DashboardMainForm";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tpOverview.ResumeLayout(false);
            this.tpByCatalogue.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private CatalogueManager.MainFormUITabs.SubComponents.CatalogueCollectionHost ci_lbCatalogues;
        private CatalogueSummaryScreen catalogueSummaryScreen1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tpOverview;
        private System.Windows.Forms.TabPage tpByCatalogue;
        private OverviewScreen overviewScreen1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem locationsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem refreshAllToolStripMenuItem;
    }
}


using CatalogueManager.AggregationUIs; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using CatalogueManager.LocationsMenu.Ticketing;
using CatalogueManager.MainFormUITabs.SubComponents;
using CohortManager.Results;

namespace CohortManager.SubComponents
{
    partial class CohortIdentificationConfigurationUI
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.queryCachingServerSelector = new CatalogueManager.AggregationUIs.QueryCachingServerSelector();
            this.btnConfigureGlobalParameters = new System.Windows.Forms.Button();
            this.ticket = new CatalogueManager.LocationsMenu.Ticketing.TicketingControl();
            this.tbDescription = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.cbShowProjectSpecificAggregates = new System.Windows.Forms.CheckBox();
            this.catalogueCollection1 = new CatalogueManager.MainFormUITabs.SubComponents.CatalogueCollectionHost();
            this.splitContainer4 = new System.Windows.Forms.SplitContainer();
            this.containersUI = new CohortManager.SubComponents.ConfigureCohortContainersUI();
            this.cohortQueryBuilderUI1 = new CohortManager.Results.CohortQueryBuilderUI();
            this.cohortIdentificationExecutionResultsUI1 = new CohortManager.Results.CohortIdentificationExecutionResultsUI();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).BeginInit();
            this.splitContainer4.Panel1.SuspendLayout();
            this.splitContainer4.Panel2.SuspendLayout();
            this.splitContainer4.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer2
            // 
            this.splitContainer2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.splitContainer1);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.splitContainer4);
            this.splitContainer2.Size = new System.Drawing.Size(1456, 831);
            this.splitContainer2.SplitterDistance = 415;
            this.splitContainer2.TabIndex = 4;
            // 
            // splitContainer1
            // 
            this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.queryCachingServerSelector);
            this.splitContainer1.Panel1.Controls.Add(this.btnConfigureGlobalParameters);
            this.splitContainer1.Panel1.Controls.Add(this.ticket);
            this.splitContainer1.Panel1.Controls.Add(this.tbDescription);
            this.splitContainer1.Panel1.Controls.Add(this.label3);
            this.splitContainer1.Panel1.Controls.Add(this.tbName);
            this.splitContainer1.Panel1.Controls.Add(this.label2);
            this.splitContainer1.Panel1.Controls.Add(this.tbID);
            this.splitContainer1.Panel1.Controls.Add(this.label1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer3);
            this.splitContainer1.Size = new System.Drawing.Size(1454, 413);
            this.splitContainer1.SplitterDistance = 534;
            this.splitContainer1.TabIndex = 2;
            // 
            // queryCachingServerSelector
            // 
            this.queryCachingServerSelector.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.queryCachingServerSelector.AutoSize = true;
            this.queryCachingServerSelector.Enabled = false;
            this.queryCachingServerSelector.Location = new System.Drawing.Point(4, 328);
            this.queryCachingServerSelector.Name = "queryCachingServerSelector";
            this.queryCachingServerSelector.Size = new System.Drawing.Size(528, 81);
            this.queryCachingServerSelector.TabIndex = 47;
            // 
            // btnConfigureGlobalParameters
            // 
            this.btnConfigureGlobalParameters.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnConfigureGlobalParameters.Location = new System.Drawing.Point(69, 289);
            this.btnConfigureGlobalParameters.Name = "btnConfigureGlobalParameters";
            this.btnConfigureGlobalParameters.Size = new System.Drawing.Size(177, 23);
            this.btnConfigureGlobalParameters.TabIndex = 46;
            this.btnConfigureGlobalParameters.Text = "Configure Global Parameters";
            this.btnConfigureGlobalParameters.UseVisualStyleBackColor = true;
            this.btnConfigureGlobalParameters.Click += new System.EventHandler(this.btnConfigureGlobalParameters_Click);
            // 
            // ticket
            // 
            this.ticket.Location = new System.Drawing.Point(18, 68);
            this.ticket.Name = "ticket";
            this.ticket.Size = new System.Drawing.Size(314, 62);
            this.ticket.TabIndex = 1;
            this.ticket.TicketText = "";
            this.ticket.TicketTextChanged += new System.EventHandler(this.ticket_TicketTextChanged);
            // 
            // tbDescription
            // 
            this.tbDescription.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbDescription.Location = new System.Drawing.Point(69, 136);
            this.tbDescription.Multiline = true;
            this.tbDescription.Name = "tbDescription";
            this.tbDescription.Size = new System.Drawing.Size(449, 147);
            this.tbDescription.TabIndex = 1;
            this.tbDescription.TextChanged += new System.EventHandler(this.tbDescription_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 133);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Description";
            // 
            // tbName
            // 
            this.tbName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbName.Location = new System.Drawing.Point(56, 42);
            this.tbName.Name = "tbName";
            this.tbName.Size = new System.Drawing.Size(462, 20);
            this.tbName.TabIndex = 1;
            this.tbName.TextChanged += new System.EventHandler(this.tbName_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Name";
            // 
            // tbID
            // 
            this.tbID.Location = new System.Drawing.Point(56, 16);
            this.tbID.Name = "tbID";
            this.tbID.ReadOnly = true;
            this.tbID.Size = new System.Drawing.Size(100, 20);
            this.tbID.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(18, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID";
            // 
            // splitContainer3
            // 
            this.splitContainer3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Name = "splitContainer3";
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.containersUI);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.cbShowProjectSpecificAggregates);
            this.splitContainer3.Panel2.Controls.Add(this.catalogueCollection1);
            this.splitContainer3.Size = new System.Drawing.Size(916, 413);
            this.splitContainer3.SplitterDistance = 521;
            this.splitContainer3.TabIndex = 1;
            // 
            // cbShowProjectSpecificAggregates
            // 
            this.cbShowProjectSpecificAggregates.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cbShowProjectSpecificAggregates.AutoSize = true;
            this.cbShowProjectSpecificAggregates.Location = new System.Drawing.Point(197, 266);
            this.cbShowProjectSpecificAggregates.Name = "cbShowProjectSpecificAggregates";
            this.cbShowProjectSpecificAggregates.Size = new System.Drawing.Size(187, 17);
            this.cbShowProjectSpecificAggregates.TabIndex = 1;
            this.cbShowProjectSpecificAggregates.Text = "Show Project Specific Aggregates";
            this.cbShowProjectSpecificAggregates.UseVisualStyleBackColor = true;
            this.cbShowProjectSpecificAggregates.CheckedChanged += new System.EventHandler(this.cbShowProjectSpecificAggregates_CheckedChanged);
            // 
            // catalogueCollection1
            // 
            this.catalogueCollection1.AutoSize = true;
            this.catalogueCollection1.Collection = null;
            this.catalogueCollection1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.catalogueCollection1.Location = new System.Drawing.Point(0, 0);
            this.catalogueCollection1.Name = "catalogueCollection1";
            this.catalogueCollection1.Size = new System.Drawing.Size(387, 409);
            this.catalogueCollection1.TabIndex = 0;
            // 
            // splitContainer4
            // 
            this.splitContainer4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer4.Location = new System.Drawing.Point(0, 0);
            this.splitContainer4.Name = "splitContainer4";
            // 
            // splitContainer4.Panel1
            // 
            this.splitContainer4.Panel1.Controls.Add(this.cohortQueryBuilderUI1);
            // 
            // splitContainer4.Panel2
            // 
            this.splitContainer4.Panel2.Controls.Add(this.cohortIdentificationExecutionResultsUI1);
            this.splitContainer4.Size = new System.Drawing.Size(1454, 410);
            this.splitContainer4.SplitterDistance = 702;
            this.splitContainer4.TabIndex = 1;
            // 
            // containersUI
            // 
            this.containersUI.Configuration = null;
            this.containersUI.Dock = System.Windows.Forms.DockStyle.Fill;
            this.containersUI.Location = new System.Drawing.Point(0, 0);
            this.containersUI.Name = "containersUI";
            this.containersUI.Size = new System.Drawing.Size(517, 409);
            this.containersUI.TabIndex = 0;
            // 
            // cohortQueryBuilderUI1
            // 
            this.cohortQueryBuilderUI1.Configuration = null;
            this.cohortQueryBuilderUI1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cohortQueryBuilderUI1.Location = new System.Drawing.Point(0, 0);
            this.cohortQueryBuilderUI1.Name = "cohortQueryBuilderUI1";
            this.cohortQueryBuilderUI1.Size = new System.Drawing.Size(698, 406);
            this.cohortQueryBuilderUI1.TabIndex = 0;
            // 
            // cohortIdentificationExecutionResultsUI1
            // 
            this.cohortIdentificationExecutionResultsUI1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cohortIdentificationExecutionResultsUI1.Location = new System.Drawing.Point(0, 0);
            this.cohortIdentificationExecutionResultsUI1.Name = "cohortIdentificationExecutionResultsUI1";
            this.cohortIdentificationExecutionResultsUI1.Size = new System.Drawing.Size(744, 406);
            this.cohortIdentificationExecutionResultsUI1.TabIndex = 0;
            this.cohortIdentificationExecutionResultsUI1.TaskExecution = null;
            // 
            // CohortIdentificationConfigurationUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.splitContainer2);
            this.Name = "CohortIdentificationConfigurationUI";
            this.Size = new System.Drawing.Size(1456, 831);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel2.ResumeLayout(false);
            this.splitContainer3.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            this.splitContainer4.Panel1.ResumeLayout(false);
            this.splitContainer4.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).EndInit();
            this.splitContainer4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private CohortQueryBuilderUI cohortQueryBuilderUI1;
        private CatalogueCollectionHost catalogueCollection1;
        private System.Windows.Forms.TextBox tbDescription;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbID;
        private System.Windows.Forms.Label label1;
        private TicketingControl ticket;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private ConfigureCohortContainersUI containersUI;
        private System.Windows.Forms.SplitContainer splitContainer4;
        private Results.CohortIdentificationExecutionResultsUI cohortIdentificationExecutionResultsUI1;
        private System.Windows.Forms.Button btnConfigureGlobalParameters;
        private System.Windows.Forms.CheckBox cbShowProjectSpecificAggregates;
        private QueryCachingServerSelector queryCachingServerSelector;
    }
}

using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Data;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using CatalogueLibrary.Data;
using CatalogueLibrary.Data.DataLoad;
using CatalogueLibrary.Repositories;
using ReusableUIComponents;

namespace RDMPObjectVisualisation.DemandsInitializationUIs
{
    public partial class ArgumentCollection<T> : UserControl where T : DatabaseEntity,IArgumentHost
    {
        
        public Dictionary<string, DemandType> DemandTypeDictionary = new Dictionary<string, DemandType>();
        private Type _argumentsAreFor;
        private T _parent;
        private CatalogueRepository _catalogueRepository;


        public ArgumentCollection()
        {
            InitializeComponent();
        }

        public DataTable Preview
        {
            get { return _argumentUI1.Preview; }
            set { _argumentUI1.Preview = value; }
        }

        /// <summary>
        /// Reconfigures this UI (can be called multiple times throughout controls lifetime) to facilitate the population of DemandsInitialization
        /// properties on an underlying type (e.g. if your collection is ProcessTask and your argument type is ProcessTaskArgument then your underlying type could
        /// be AnySeparatorFileAttacher or MDFAttacher).  Note that while T is IArgumentHost, it also should be tied to one or more interfaces (e.g. IAttacher) and able to host
        /// any child of that interface of which argumentsAreForUnderlyingType is the currently configured concrete class (e.g. AnySeparatorFileAttacher).
        /// </summary>
        /// <param name="catalogueRepository"></param>
        /// <param name="parent"></param>
        /// <param name="argumentsAreForUnderlyingType"></param>
        public void Setup(CatalogueRepository catalogueRepository, T parent,Type argumentsAreForUnderlyingType)
        {
            Contract.Requires<ArgumentNullException>(catalogueRepository != null);
            
            _parent = parent;
            _argumentsAreFor = argumentsAreForUnderlyingType;
            _catalogueRepository = catalogueRepository;

            RefreshArgumentList();
        }

        private void lbProcessTaskArguments_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                var arg = lbProcessTaskArguments.SelectedItem as Argument;

                if (arg == null)
                    _argumentUI1.SetProcessTaskArgument(_catalogueRepository, _parent, null, DemandType.Unspecified);
                else
                {
                    if (DemandTypeDictionary.ContainsKey(arg.Name))
                        _argumentUI1.SetProcessTaskArgument(_catalogueRepository, _parent, arg, DemandTypeDictionary[arg.Name]);
                    else
                    {

                        _argumentUI1.SetProcessTaskArgument(_catalogueRepository, _parent, arg, DemandType.Unspecified);
                        MessageBox.Show("Did not know what DemandType is required for property called " + arg.Name +
                                        " possibly it no longer is demanded by the underlying class? Proceeding with DemandType.Unspecified");
                    }
                }
            }
            catch (Exception exception)
            {
                ExceptionViewer.Show(exception);
            }
        }


        private void RefreshArgumentList()
        {
            if(_parent == null)
            {
                lbProcessTaskArguments.Items.Clear();
                _argumentUI1.SetProcessTaskArgument(_catalogueRepository, _parent, null, DemandType.Unspecified);
                return;
            }

            var toReselect = lbProcessTaskArguments.SelectedItem as Argument;

            lbProcessTaskArguments.Items.Clear();
            DemandTypeDictionary.Clear();

            if (_argumentsAreFor != null)
            {
               
                    //parameters that already exist
                    var existing = _parent.GetAllArguments().Cast<Argument>().ToList();
                    List<string> required = new List<string>();

                    foreach (PropertyInfo propertyInfo in _argumentsAreFor.GetProperties())
                        foreach (DemandsInitialization attribute in propertyInfo.GetCustomAttributes(typeof(CatalogueLibrary.Data.DemandsInitialization), true))
                        {
                            //found a tagged attribute - it might already exist though
                            required.Add(propertyInfo.Name);

                            //record the name of the property and the type it requires
                            DemandTypeDictionary.Add(propertyInfo.Name, attribute.DemandType);

                            var argument = existing.SingleOrDefault(arg => arg.Name.Equals(propertyInfo.Name));

                            if (argument == null)//it doesnt exist - so create it
                            {
                                var newArgument = (Argument)_parent.CreateNewArgument();

                                newArgument.Name = propertyInfo.Name;
                                
                                try
                                {
                                    newArgument.SetType(propertyInfo.PropertyType);
                                }
                                catch (Exception e)
                                {
                                    ExceptionViewer.Show("Problem determining argument " + propertyInfo.Name + " on class " + _argumentsAreFor.FullName,e);
                                }

                                newArgument.Description = attribute.Description;
                                newArgument.SaveToDatabase();
                                existing.Add(newArgument);
                            }
                            else
                            {
                                //it does exist but check it hasn't had a type descync
                                if (argument.GetSystemType() != propertyInfo.PropertyType)
                                    if (MessageBox.Show("Argument '" + argument.Name + "' is of Type '" +
                                                        argument.GetSystemType() + "' in Catalogue but is of Type '" +
                                                        propertyInfo.PropertyType + "' in underlying class '" +
                                                        _argumentsAreFor.Name +
                                                        "'.  Do you want to resolve this by changing the type of argument " +
                                                        argument.Name + " to Type " + propertyInfo.PropertyType + "?",
                                        "Fix Argument Type Desynchronisation?", MessageBoxButtons.YesNo) == DialogResult.Yes)
                                    {
                                        //user wants to fix the problem
                                        argument.SetType(propertyInfo.PropertyType);
                                        argument.SaveToDatabase();
                                    }
                            }
                        }

                    foreach (var argumentsNotRequired in existing.Where(e => !required.Any(r => r.Equals(e.Name))))
                    {
                        if (MessageBox.Show("Argument " + argumentsNotRequired.Name + " is not required, delete it?", "Delete superfluous argument?", MessageBoxButtons.YesNo) == DialogResult.Yes)
                            argumentsNotRequired.DeleteInDatabase();
                    }
                }


            _argumentUI1.SetProcessTaskArgument(_catalogueRepository, _parent, null, DemandType.Unspecified);
            lbProcessTaskArguments.Items.AddRange(_parent.GetAllArguments().ToArray());
         
            lbProcessTaskArguments.SelectedItem = toReselect;
        }

        public void Clear()
        {
            //pass null to clear it
            Setup(_catalogueRepository, default(T),null);
        }

        /// <summary>
        /// T must be an IArgumentHost e.g.  ProcessTask or PipelineComponent, these two classes act as persistence wrappers for thier host type (which can be any type of anything - any plugin)
        /// then you must also pass the underlying type that is being wrapped e.g. basically the constructor arguments to this class :)
        /// </summary>
        /// <param name="catalogueRepository"></param>
        /// <param name="newComp"></param>
        /// <param name="argumentsAreForUnderlyingType"></param>
        /// <param name="previewIfAny">If you have a data table that approximates what the pipeline will look like at the time the component T is reached then pass it in here otherwise pass null</param>
        public static void ShowDialogIfAnyArgs(CatalogueRepository catalogueRepository, T newComp, Type argumentsAreForUnderlyingType,DataTable previewIfAny)
        {
            Form f = new Form();
            var argCollection = new ArgumentCollection<T>();
            argCollection.Setup(catalogueRepository, newComp, argumentsAreForUnderlyingType);
            argCollection.Dock = DockStyle.Fill;
            
            bool areAnyDemandsInitializations =
                //get all properties
                argumentsAreForUnderlyingType.GetProperties()
                //any of them have custom attribute collections which contain a [DemandsInitialization]?
                .Any(p => p.GetCustomAttributes(typeof (CatalogueLibrary.Data.DemandsInitialization)).Any());

            if (!areAnyDemandsInitializations)
                return;

            f.Controls.Add(argCollection);

            Button ok = new Button();
            ok.Text = "Ok";
            ok.Dock = DockStyle.Bottom;
            ok.Click += (s, e) => f.Close();
            f.Controls.Add(ok);
            f.Text = "Set Arguments For Type:" + argumentsAreForUnderlyingType.Name + " (you can always change these later)";

            argCollection.Setup(catalogueRepository, newComp, argumentsAreForUnderlyingType);
            argCollection.Preview = previewIfAny;
            
            f.Width = 800;
            f.Height = 700;
            f.ShowDialog();


        }
    }
}

using System.Collections.Generic; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Data.Common;
using CatalogueLibrary.Data;
using DataExportManager2.Interfaces.Data.DataTables;
using MapsDirectlyToDatabaseTable;

namespace DataExportManager2Library.Data.DataTables
{
    public class DataUser : VersionedDatabaseEntity, IDataUser
    {
        public string Forename { get; set; }
        public string Surname { get; set; }
        public string Email { get; set; }
        
        public static int Forename_MaxLength = -1;
        public static int Surname_MaxLength = -1;
        public static int Email_MaxLength = -1;

        public DataUser(IRepository repository, string forename, string surname)
        {
            Repository = repository;
            Repository.InsertAndHydrate(this, new Dictionary<string, object>
            {
                {"Forename", forename},
                {"Surname", surname}
            });
        }

        public DataUser(IRepository repository, DbDataReader r) : base(repository, r)
        {
            Forename = r["Forename"] as string;
            Surname = r["Surname"] as string;
            Email = r["Email"] as string;
        }

        public override string ToString()
        {
            return Forename + " " + Surname;
        }

        public void RegisterAsDataUserOnProject(Project project)
        {
            Repository.InsertAndReturnID<DataUser>(new Dictionary<string, object>
            {
                {"Project_ID", project.ID},
                {"DataUser_ID", ID}
            });
        }

        public void UnRegisterAsDataUserOnProject(Project project)
        {
            Repository.Delete("DELETE FROM Project_DataUser WHERE Project_ID=@Project_ID AND DataUser_ID=@DataUser_ID;", 
                new Dictionary<string, object>
                {
                    {"Project_ID", project.ID},
                    {"DataUser_ID", ID}
                });
        }
    }
}

namespace CatalogueManager.AggregationUIs // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
{
    partial class AggregateDimensionUI
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tbAlias = new System.Windows.Forms.TextBox();
            this.tbOrder = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbID = new System.Windows.Forms.TextBox();
            this.pSelectSQL = new System.Windows.Forms.Panel();
            this.btnSave = new System.Windows.Forms.Button();
            this.aggregateContinuousDateAxisUI1 = new CatalogueManager.AggregationUIs.AggregateContinuousDateAxisUI();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Select SQL:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 154);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(32, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Alias:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 178);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Order:";
            // 
            // tbAlias
            // 
            this.tbAlias.Location = new System.Drawing.Point(41, 151);
            this.tbAlias.Name = "tbAlias";
            this.tbAlias.Size = new System.Drawing.Size(216, 20);
            this.tbAlias.TabIndex = 1;
            this.tbAlias.TextChanged += new System.EventHandler(this.tbAlias_TextChanged);
            // 
            // tbOrder
            // 
            this.tbOrder.Location = new System.Drawing.Point(41, 175);
            this.tbOrder.Name = "tbOrder";
            this.tbOrder.Size = new System.Drawing.Size(123, 20);
            this.tbOrder.TabIndex = 1;
            this.tbOrder.TextChanged += new System.EventHandler(this.tbOrder_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 4);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(21, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "ID:";
            // 
            // tbID
            // 
            this.tbID.Location = new System.Drawing.Point(45, 1);
            this.tbID.Name = "tbID";
            this.tbID.ReadOnly = true;
            this.tbID.Size = new System.Drawing.Size(111, 20);
            this.tbID.TabIndex = 1;
            // 
            // pSelectSQL
            // 
            this.pSelectSQL.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pSelectSQL.Location = new System.Drawing.Point(74, 29);
            this.pSelectSQL.Name = "pSelectSQL";
            this.pSelectSQL.Size = new System.Drawing.Size(765, 110);
            this.pSelectSQL.TabIndex = 2;
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(41, 201);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 3;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // aggregateContinuousDateAxisUI1
            // 
            this.aggregateContinuousDateAxisUI1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.aggregateContinuousDateAxisUI1.Dimension = null;
            this.aggregateContinuousDateAxisUI1.Location = new System.Drawing.Point(514, 145);
            this.aggregateContinuousDateAxisUI1.Name = "aggregateContinuousDateAxisUI1";
            this.aggregateContinuousDateAxisUI1.Size = new System.Drawing.Size(325, 165);
            this.aggregateContinuousDateAxisUI1.TabIndex = 4;
            // 
            // AggregateDimensionUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.Controls.Add(this.aggregateContinuousDateAxisUI1);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.pSelectSQL);
            this.Controls.Add(this.tbOrder);
            this.Controls.Add(this.tbID);
            this.Controls.Add(this.tbAlias);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "AggregateDimensionUI";
            this.Size = new System.Drawing.Size(842, 320);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbAlias;
        private System.Windows.Forms.TextBox tbOrder;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbID;
        private System.Windows.Forms.Panel pSelectSQL;
        private System.Windows.Forms.Button btnSave;
        private AggregateContinuousDateAxisUI aggregateContinuousDateAxisUI1;
    }
}

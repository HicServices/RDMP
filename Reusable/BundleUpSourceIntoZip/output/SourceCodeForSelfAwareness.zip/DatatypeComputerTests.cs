using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using NUnit.Framework;
using ReusableLibraryCode.DataTableExtension;

namespace DataExportManager2.Tests
{
    public class DatatypeComputerTests
    {

        [Test]
        public void TestDatatypeComputer_decimal()
        {
            DataTypeComputer t = new DataTypeComputer();
            t.AdjustToCompensateForValue("1.5");
            t.AdjustToCompensateForValue("299.99");
            t.AdjustToCompensateForValue(null);
            t.AdjustToCompensateForValue(DBNull.Value);

            Assert.AreEqual(typeof(decimal),t.CurrentEstimate);
        }

        [Test]
        public void TestDatatypeComputer_Int()
        {
            DataTypeComputer t = new DataTypeComputer();
            t.AdjustToCompensateForValue("15");
            t.AdjustToCompensateForValue("299");
            t.AdjustToCompensateForValue(null);
            t.AdjustToCompensateForValue(DBNull.Value);

            Assert.AreEqual(typeof(int),t.CurrentEstimate);
        }

        [Test]
        public void TestDatatypeComputer_IntAnddecimal_MustUsedecimal()
        {
            DataTypeComputer t = new DataTypeComputer();
            t.AdjustToCompensateForValue("15");
            t.AdjustToCompensateForValue("29.9");
            t.AdjustToCompensateForValue("200");
            t.AdjustToCompensateForValue(null);
            t.AdjustToCompensateForValue(DBNull.Value);

            Assert.AreEqual(t.CurrentEstimate, typeof(decimal));
            Assert.AreEqual("decimal(4,1)",t.GetSqlDBType());
        }

        [Test]
        public void TestDatatypeComputer_DateTime()
        {
            DataTypeComputer t = new DataTypeComputer();
            t.AdjustToCompensateForValue("01/01/2001");
            t.AdjustToCompensateForValue(null);

            Assert.AreEqual(t.CurrentEstimate, typeof(DateTime));
            Assert.AreEqual("datetime2",t.GetSqlDBType());

        }

        [Test]
        public void TestDatatypeComputer_PreeceedingZeroes()
        {
            DataTypeComputer t = new DataTypeComputer();
            t.AdjustToCompensateForValue("1.5");
            t.AdjustToCompensateForValue("00299.99");
            t.AdjustToCompensateForValue(null);
            t.AdjustToCompensateForValue(DBNull.Value);

            Assert.AreEqual(typeof(string), t.CurrentEstimate);
        }

        [Test]
        public void TestDatatypeComputer_Doubles()
        {
            DataTypeComputer t = new DataTypeComputer();
            t.AdjustToCompensateForValue(299.99);
            
            Assert.AreEqual(typeof(double), t.CurrentEstimate);

            Assert.AreEqual(2, t.numbersAfterDecimalPlace);
            Assert.AreEqual(3, t.numbersBeforeDecimalPlace);
        }

        [Test]
        public void TestDatatypeComputer_Bool()
        {
            DataTypeComputer t = new DataTypeComputer();
            t.AdjustToCompensateForValue(true);
            t.AdjustToCompensateForValue(false);

            Assert.AreEqual(typeof(bool), t.CurrentEstimate);

            Assert.AreEqual(-1, t.numbersAfterDecimalPlace);
            Assert.AreEqual(-1, t.numbersBeforeDecimalPlace);
        }

        [Test]
        public void TestDatatypeComputer_MixedIntTypes()
        {
            DataTypeComputer t = new DataTypeComputer();
            t.AdjustToCompensateForValue((Int16)5);
            var ex = Assert.Throws<Exception>(()=>t.AdjustToCompensateForValue((Int32)1000));

            Assert.IsTrue(ex.Message.Contains("We were adjusting to compensate for object 1000 which is of Type System.Int32 , we were previously passed a System.Int16 type, is your column of mixed type? this is unacceptable"));
        }
        [Test]
        public void TestDatatypeComputer_Int16s()
        {
            DataTypeComputer t = new DataTypeComputer();
            t.AdjustToCompensateForValue((Int16)5);
            t.AdjustToCompensateForValue((Int16)10);
            t.AdjustToCompensateForValue((Int16)15);
            t.AdjustToCompensateForValue((Int16)30);
            t.AdjustToCompensateForValue((Int16)200);

            Assert.AreEqual(typeof(Int16), t.CurrentEstimate);

            Assert.AreEqual(3, t.numbersBeforeDecimalPlace);
            Assert.AreEqual(-1, t.numbersAfterDecimalPlace);
            

        }
        [Test]
        public void TestDatatypeComputer_Byte()
        {
            DataTypeComputer t = new DataTypeComputer();
            t.AdjustToCompensateForValue(new byte[5]);

            Assert.AreEqual(typeof(byte[]), t.CurrentEstimate);

            Assert.AreEqual(-1, t.numbersAfterDecimalPlace);
            Assert.AreEqual(-1, t.numbersBeforeDecimalPlace);
        }

        [Test]
        public void TestDatatypeComputer_NumberOfDecimalPlaces()
        {
            DataTypeComputer t = new DataTypeComputer();
            t.AdjustToCompensateForValue("111111111.11111111111115");
            
            Assert.AreEqual(typeof(decimal), t.CurrentEstimate);
            Assert.AreEqual(9, t.numbersBeforeDecimalPlace);
            Assert.AreEqual(14, t.numbersAfterDecimalPlace);
        }


        [Test]
        public void TestDatatypeComputer_FallbackOntoVarcharFromFloat()
        {
            DataTypeComputer t = new DataTypeComputer();
            t.AdjustToCompensateForValue("15.5");
            t.AdjustToCompensateForValue("F");

            Assert.AreEqual(typeof(string), t.CurrentEstimate);
            Assert.AreEqual("varchar(4)",t.GetSqlDBType());
        }

    }
}

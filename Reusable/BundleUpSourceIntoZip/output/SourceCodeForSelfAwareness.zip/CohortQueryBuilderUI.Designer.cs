namespace CohortManager.Results // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
{
    partial class CohortQueryBuilderUI
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tpSelectedSQL = new System.Windows.Forms.TabControl();
            this.tpSQL = new System.Windows.Forms.TabPage();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tpSelectedSQL.SuspendLayout();
            this.SuspendLayout();
            // 
            // tpSelectedSQL
            // 
            this.tpSelectedSQL.Alignment = System.Windows.Forms.TabAlignment.Bottom;
            this.tpSelectedSQL.Controls.Add(this.tpSQL);
            this.tpSelectedSQL.Controls.Add(this.tabPage1);
            this.tpSelectedSQL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tpSelectedSQL.Location = new System.Drawing.Point(0, 0);
            this.tpSelectedSQL.Name = "tpSelectedSQL";
            this.tpSelectedSQL.SelectedIndex = 0;
            this.tpSelectedSQL.Size = new System.Drawing.Size(746, 588);
            this.tpSelectedSQL.TabIndex = 1;
            // 
            // tpSQL
            // 
            this.tpSQL.Location = new System.Drawing.Point(4, 4);
            this.tpSQL.Name = "tpSQL";
            this.tpSQL.Padding = new System.Windows.Forms.Padding(3);
            this.tpSQL.Size = new System.Drawing.Size(738, 562);
            this.tpSQL.TabIndex = 1;
            this.tpSQL.Text = "Full SQL";
            this.tpSQL.UseVisualStyleBackColor = true;
            // 
            // tabPage1
            // 
            this.tabPage1.Location = new System.Drawing.Point(4, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(738, 562);
            this.tabPage1.TabIndex = 2;
            this.tabPage1.Text = "Selected Task Only SQL";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // CohortQueryBuilderUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tpSelectedSQL);
            this.Name = "CohortQueryBuilderUI";
            this.Size = new System.Drawing.Size(746, 588);
            this.tpSelectedSQL.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tpSelectedSQL;
        private System.Windows.Forms.TabPage tpSQL;
        private System.Windows.Forms.TabPage tabPage1;
    }
}

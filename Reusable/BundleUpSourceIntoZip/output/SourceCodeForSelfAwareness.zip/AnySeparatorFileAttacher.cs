using System.ComponentModel; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using CatalogueLibrary;
using CatalogueLibrary.Data;
using ReusableLibraryCode.DatabaseHelpers.Discovery;

namespace LoadModules.Generic.Attachers
{
    [Description(
        @"Sets up parent to load with the specified separator
Arguments: See Parent
"
        )]
    public class AnySeparatorFileAttacher : DelimitedFlatFileAttacher
    {
        [DemandsInitialization("The file separator e.g. comma for CSV")]
        public string Separator
        {
            get { return _source.Separator; }
            set { _source.Separator = value; }
        }

        public AnySeparatorFileAttacher() : base('A')
        {
        }

        public AnySeparatorFileAttacher(IHICProjectDirectory hicProjectDirectory, DiscoveredDatabase dbInfo) : base(hicProjectDirectory, dbInfo,'A')
        {
        }

    }
}

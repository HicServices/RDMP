using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReusableLibraryCode.DatabaseHelpers.Discovery
{
    public class DiscoveredParameter
    {
        public string ParameterName { get; set; }
        public DiscoveredParameter(string parameterName)
        {
            ParameterName = parameterName;
        }

        public DiscoveredDataType DataType { get; set; }
    }
}

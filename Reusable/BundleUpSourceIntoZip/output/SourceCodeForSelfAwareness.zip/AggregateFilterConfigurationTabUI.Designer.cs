namespace CatalogueManager.AggregationUIs // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
{
    partial class AggregateFilterConfigurationTabUI
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AggregateFilterConfigurationTabUI));
            this.filterTreeUI1 = new CatalogueManager.ExtractionUIs.FilterUIs.FilterTreeUI();
            this.btnCreateShortcutToExistingFilterConfigurationInAnotherAggregate = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // filterTreeUI1
            // 
            this.filterTreeUI1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.filterTreeUI1.ChangeOrchestrator = null;
            this.filterTreeUI1.ContainerConstructor = null;
            this.filterTreeUI1.GlobalFilterParameters = null;
            this.filterTreeUI1.Location = new System.Drawing.Point(0, 3);
            this.filterTreeUI1.Name = "filterTreeUI1";
            this.filterTreeUI1.Size = new System.Drawing.Size(1205, 710);
            this.filterTreeUI1.TabIndex = 6;
            // 
            // btnCreateShortcutToExistingFilterConfigurationInAnotherAggregate
            // 
            this.btnCreateShortcutToExistingFilterConfigurationInAnotherAggregate.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnCreateShortcutToExistingFilterConfigurationInAnotherAggregate.Image = ((System.Drawing.Image)(resources.GetObject("btnCreateShortcutToExistingFilterConfigurationInAnotherAggregate.Image")));
            this.btnCreateShortcutToExistingFilterConfigurationInAnotherAggregate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCreateShortcutToExistingFilterConfigurationInAnotherAggregate.Location = new System.Drawing.Point(311, 714);
            this.btnCreateShortcutToExistingFilterConfigurationInAnotherAggregate.Name = "btnCreateShortcutToExistingFilterConfigurationInAnotherAggregate";
            this.btnCreateShortcutToExistingFilterConfigurationInAnotherAggregate.Size = new System.Drawing.Size(560, 23);
            this.btnCreateShortcutToExistingFilterConfigurationInAnotherAggregate.TabIndex = 8;
            this.btnCreateShortcutToExistingFilterConfigurationInAnotherAggregate.Text = "Make This AggregateConfiguration\'s Filters Into A Shortcut To A Different Aggrega" +
    "teConfiguration\'s Filters";
            this.btnCreateShortcutToExistingFilterConfigurationInAnotherAggregate.UseVisualStyleBackColor = true;
            this.btnCreateShortcutToExistingFilterConfigurationInAnotherAggregate.Click += new System.EventHandler(this.btnCreateShortcutToExistingFilterConfigurationInAnotherAggregate_Click);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 738);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1205, 41);
            this.label1.TabIndex = 9;
            this.label1.Text = resources.GetString("label1.Text");
            // 
            // AggregateFilterConfigurationTabUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnCreateShortcutToExistingFilterConfigurationInAnotherAggregate);
            this.Controls.Add(this.filterTreeUI1);
            this.Name = "AggregateFilterConfigurationTabUI";
            this.Size = new System.Drawing.Size(1208, 779);
            this.ResumeLayout(false);

        }

        #endregion

        private ExtractionUIs.FilterUIs.FilterTreeUI filterTreeUI1;
        private System.Windows.Forms.Button btnCreateShortcutToExistingFilterConfigurationInAnotherAggregate;
        private System.Windows.Forms.Label label1;
    }
}

using System.Drawing; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using CatalogueLibrary.Data;
using Microsoft.VisualBasic.PowerPacks;
using ReusableUIComponents;

namespace CatalogueManager.DataLoadUIs.ANOUIs
{
    public delegate void SelfDestructHandler(object sender);
    class Association
    {
        private readonly BetterListBox _listbox;

        public ColumnInfo ColumnInfo { get; set; }
        public  int IndexInListbox { get; set; }

        public LineShape Line { get; set; }
        public DraggableANOTable DraggableAnoTable{ get; set; }

        public event SelfDestructHandler SelfDestructed;

        public Association(BetterListBox listbox, ColumnInfo columnInfo, int indexInListbox, LineShape line, DraggableANOTable anotable)
        {
            _listbox = listbox;
            ColumnInfo = columnInfo;
            IndexInListbox = indexInListbox;
            Line = line;
            DraggableAnoTable = anotable;

            anotable.MouseUp += anotableControl_MouseUp;
            listbox.Scroll += listbox_Scroll;

            line.BorderStyle = DashStyle.Solid;
            Line.BorderColor = anotable.Color;
            Line.SelectionColor = Color.Red;
            Line.KeyUp += Line_KeyUp;

            //initializes left end of line
            listbox_Scroll(null,null);
            Line.EndPoint = new System.Drawing.Point(DraggableAnoTable.Left, DraggableAnoTable.Top + (DraggableAnoTable.Height/2));        

        }

        void Line_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
                SelfDestruct();
        }

        void listbox_Scroll(object Sender, BetterListBoxScrollArgs e)
        {
            //if user scrolled the item off the top of the screen
            if (IndexInListbox < _listbox.TopIndex)
                Line.StartPoint = new System.Drawing.Point(_listbox.Right, _listbox.Top);
            else
                Line.StartPoint = GetPixelLocationOfIndex();
        }

        private Point GetPixelLocationOfIndex()
        {
            int indexOffsetFromTop = IndexInListbox - _listbox.TopIndex;
            int pixelOffsetFromTop = indexOffsetFromTop*_listbox.ItemHeight;

            bool isOffBottom = pixelOffsetFromTop > _listbox.Height;

            if (isOffBottom)
                return new Point(_listbox.Right, _listbox.Bottom);
            else
                return new Point(_listbox.Right, pixelOffsetFromTop + (_listbox.ItemHeight)); //draw line from half way through item
        }

        void anotableControl_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            //control was dragged so move line to keep up
            Line.EndPoint = new System.Drawing.Point(DraggableAnoTable.Left, DraggableAnoTable.Top + (DraggableAnoTable.Height / 2));        
        }

        private bool _hasSelfDestructed = false;

        public void SelfDestruct()
        {      
            //has already self destructed
            if (_hasSelfDestructed)
                return;

            ColumnInfo.ANOTable_ID = null;
            ColumnInfo.SaveToDatabase();
            Line.Parent.Shapes.Remove(Line);

            _hasSelfDestructed = true;
            SelfDestructed(this);
        }
    }
}

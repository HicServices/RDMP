namespace CohortManager.UserFriendly.Events // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
{
    public delegate void CohortAggregateEventHandler(object sender, CohortAggregateEventArgs args);
}

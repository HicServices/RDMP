using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using CatalogueLibrary.Data.Aggregation;
using ReusableLibraryCode.DatabaseHelpers.Discovery;

namespace QueryCaching.Aggregation.Arguments
{
    /// <summary>
    /// Request to cache an AggregateConfiguration that results in a DataTable suitable for producing a useful graph (e.g. 'number of records per year in 
    /// Biochemistry by healthboard').  Should not contain patient identifiers.
    /// 
    /// Serves as an input to CachedAggregateConfigurationResultsManager.
    ///</summary>
    public class CacheCommitExtractableAggregate : CacheCommitArguments
    {
        public CacheCommitExtractableAggregate(AggregateConfiguration configuration, string sql, DataTable results, int timeout)
            : base(AggregateOperation.ExtractableAggregateResults, configuration, sql, results, timeout)
        {
            if (results.Columns.Count == 0)
                throw new ArgumentException("The DataTable that you claimed was an " + Operation + " had zero columns and therefore cannot be cached");

            string[] suspectDimensions =
                configuration.AggregateDimensions
                    .Where(d => d.IsExtractionIdentifier || d.HashOnDataRelease)
                    .Select(d => d.GetRuntimeName())
                    .ToArray();
            if (suspectDimensions.Any())
                throw new NotSupportedException("Aggregate " + configuration +
                                                " contains dimensions marked as IsExtractionIdentifier or HashOnDataRelease (" +
                                                string.Join(",", suspectDimensions) +
                                                ") so the aggregate cannot be cached.  This would/could result in private patient identifiers appearing on your website!");

            if (!configuration.IsExtractable)
                throw new NotSupportedException("Aggregate " + configuration + " is not marked as IsExtractable therefore cannot be cached for publication on website");
            
        }

        public override void CommitTableDataCompleted(DiscoveredTable resultingTable)
        {
            //no need to do anything here we dont need index or anything else
        }
    }
}
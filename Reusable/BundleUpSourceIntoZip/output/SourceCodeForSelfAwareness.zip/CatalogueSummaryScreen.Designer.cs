using Dashboard.CatalogueSummary.LoadEvents; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved

namespace Dashboard.CatalogueSummary
{
    partial class CatalogueSummaryScreen
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tpSummary = new System.Windows.Forms.TabPage();
            this.unpopulatedDescriptionsGraph = new Dashboard.GoodBadCataloguePieChart();
            this.unresolvedTicketsGraph = new Dashboard.GoodBadCataloguePieChart();
            this._allLoadEventsListView1 = new Dashboard.CatalogueSummary.LoadEvents.AllLoadEventsUI();
            this.lblLoadMetadata = new System.Windows.Forms.Label();
            this.tpDataQuality = new System.Windows.Forms.TabPage();
            this.evaluationTrackBar1 = new Dashboard.CatalogueSummary.DataQualityReporting.SubComponents.EvaluationTrackBar();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.timePeriodicityChart1 = new Dashboard.CatalogueSummary.DataQualityReporting.TimePeriodicityChart();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.columnStatesChart1 = new Dashboard.CatalogueSummary.DataQualityReporting.ColumnStatesChart();
            this.rowStatePieChart1 = new Dashboard.CatalogueSummary.DataQualityReporting.RowStatePieChart();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.dqePivotCategorySelector1 = new Dashboard.CatalogueSummary.DataQualityReporting.SubComponents.DQEPivotCategorySelector();
            this.tabControl1.SuspendLayout();
            this.tpSummary.SuspendLayout();
            this.tpDataQuality.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tpSummary);
            this.tabControl1.Controls.Add(this.tpDataQuality);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1115, 692);
            this.tabControl1.TabIndex = 0;
            // 
            // tpSummary
            // 
            this.tpSummary.Controls.Add(this.unpopulatedDescriptionsGraph);
            this.tpSummary.Controls.Add(this.unresolvedTicketsGraph);
            this.tpSummary.Controls.Add(this._allLoadEventsListView1);
            this.tpSummary.Controls.Add(this.lblLoadMetadata);
            this.tpSummary.Location = new System.Drawing.Point(4, 22);
            this.tpSummary.Name = "tpSummary";
            this.tpSummary.Padding = new System.Windows.Forms.Padding(3);
            this.tpSummary.Size = new System.Drawing.Size(1107, 666);
            this.tpSummary.TabIndex = 0;
            this.tpSummary.Text = "Catalogue Summary";
            this.tpSummary.UseVisualStyleBackColor = true;
            // 
            // unpopulatedDescriptionsGraph
            // 
            this.unpopulatedDescriptionsGraph.AllCataloguesMode = false;
            this.unpopulatedDescriptionsGraph.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.unpopulatedDescriptionsGraph.Catalogue = null;
            this.unpopulatedDescriptionsGraph.Location = new System.Drawing.Point(447, 7);
            this.unpopulatedDescriptionsGraph.Name = "unpopulatedDescriptionsGraph";
            this.unpopulatedDescriptionsGraph.PieType = Dashboard.CataloguePieChartType.Issues;
            this.unpopulatedDescriptionsGraph.Size = new System.Drawing.Size(293, 191);
            this.unpopulatedDescriptionsGraph.TabIndex = 4;
            // 
            // unresolvedTicketsGraph
            // 
            this.unresolvedTicketsGraph.AllCataloguesMode = false;
            this.unresolvedTicketsGraph.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.unresolvedTicketsGraph.Catalogue = null;
            this.unresolvedTicketsGraph.Location = new System.Drawing.Point(746, 7);
            this.unresolvedTicketsGraph.Name = "unresolvedTicketsGraph";
            this.unresolvedTicketsGraph.PieType = Dashboard.CataloguePieChartType.Issues;
            this.unresolvedTicketsGraph.Size = new System.Drawing.Size(293, 191);
            this.unresolvedTicketsGraph.TabIndex = 4;
            // 
            // _allLoadEventsListView1
            // 
            this._allLoadEventsListView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this._allLoadEventsListView1.Location = new System.Drawing.Point(11, 281);
            this._allLoadEventsListView1.Name = "_allLoadEventsListView1";
            this._allLoadEventsListView1.Size = new System.Drawing.Size(1028, 338);
            this._allLoadEventsListView1.TabIndex = 3;
            // 
            // lblLoadMetadata
            // 
            this.lblLoadMetadata.AutoSize = true;
            this.lblLoadMetadata.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLoadMetadata.Location = new System.Drawing.Point(7, 258);
            this.lblLoadMetadata.Name = "lblLoadMetadata";
            this.lblLoadMetadata.Size = new System.Drawing.Size(63, 20);
            this.lblLoadMetadata.TabIndex = 2;
            this.lblLoadMetadata.Text = "Loads:";
            // 
            // tpDataQuality
            // 
            this.tpDataQuality.Controls.Add(this.evaluationTrackBar1);
            this.tpDataQuality.Controls.Add(this.splitContainer1);
            this.tpDataQuality.Location = new System.Drawing.Point(4, 22);
            this.tpDataQuality.Name = "tpDataQuality";
            this.tpDataQuality.Padding = new System.Windows.Forms.Padding(3);
            this.tpDataQuality.Size = new System.Drawing.Size(1107, 666);
            this.tpDataQuality.TabIndex = 1;
            this.tpDataQuality.Text = "Data Quality";
            this.tpDataQuality.UseVisualStyleBackColor = true;
            // 
            // evaluationTrackBar1
            // 
            this.evaluationTrackBar1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.evaluationTrackBar1.Evaluations = null;
            this.evaluationTrackBar1.Location = new System.Drawing.Point(6, 589);
            this.evaluationTrackBar1.Name = "evaluationTrackBar1";
            this.evaluationTrackBar1.Size = new System.Drawing.Size(1098, 71);
            this.evaluationTrackBar1.TabIndex = 4;
            this.evaluationTrackBar1.EvaluationSelected += new Dashboard.CatalogueSummary.DataQualityReporting.SubComponents.EvaluationSelectedHandler(this.evaluationTrackBar1_EvaluationSelected);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer1.Location = new System.Drawing.Point(3, 3);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.timePeriodicityChart1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer3);
            this.splitContainer1.Size = new System.Drawing.Size(1101, 580);
            this.splitContainer1.SplitterDistance = 290;
            this.splitContainer1.TabIndex = 3;
            // 
            // timePeriodicityChart1
            // 
            this.timePeriodicityChart1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.timePeriodicityChart1.Location = new System.Drawing.Point(0, 0);
            this.timePeriodicityChart1.Name = "timePeriodicityChart1";
            this.timePeriodicityChart1.Size = new System.Drawing.Size(1097, 286);
            this.timePeriodicityChart1.TabIndex = 0;
            // 
            // splitContainer2
            // 
            this.splitContainer2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.columnStatesChart1);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.rowStatePieChart1);
            this.splitContainer2.Size = new System.Drawing.Size(918, 282);
            this.splitContainer2.SplitterDistance = 471;
            this.splitContainer2.TabIndex = 0;
            // 
            // columnStatesChart1
            // 
            this.columnStatesChart1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.columnStatesChart1.Location = new System.Drawing.Point(0, 0);
            this.columnStatesChart1.Name = "columnStatesChart1";
            this.columnStatesChart1.Size = new System.Drawing.Size(467, 278);
            this.columnStatesChart1.TabIndex = 2;
            // 
            // rowStatePieChart1
            // 
            this.rowStatePieChart1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rowStatePieChart1.Location = new System.Drawing.Point(0, 0);
            this.rowStatePieChart1.Name = "rowStatePieChart1";
            this.rowStatePieChart1.Size = new System.Drawing.Size(439, 278);
            this.rowStatePieChart1.TabIndex = 1;
            // 
            // splitContainer3
            // 
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Name = "splitContainer3";
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.dqePivotCategorySelector1);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.splitContainer2);
            this.splitContainer3.Size = new System.Drawing.Size(1097, 282);
            this.splitContainer3.SplitterDistance = 175;
            this.splitContainer3.TabIndex = 1;
            // 
            // dqePivotCategorySelector1
            // 
            this.dqePivotCategorySelector1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dqePivotCategorySelector1.Location = new System.Drawing.Point(0, 0);
            this.dqePivotCategorySelector1.Name = "dqePivotCategorySelector1";
            this.dqePivotCategorySelector1.Size = new System.Drawing.Size(175, 282);
            this.dqePivotCategorySelector1.TabIndex = 0;
            // 
            // CatalogueSummaryScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tabControl1);
            this.Name = "CatalogueSummaryScreen";
            this.Size = new System.Drawing.Size(1115, 692);
            this.tabControl1.ResumeLayout(false);
            this.tpSummary.ResumeLayout(false);
            this.tpSummary.PerformLayout();
            this.tpDataQuality.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tpSummary;
        private System.Windows.Forms.Label lblLoadMetadata;
        private AllLoadEventsUI _allLoadEventsListView1;
        private GoodBadCataloguePieChart unresolvedTicketsGraph;
        private GoodBadCataloguePieChart unpopulatedDescriptionsGraph;
        private System.Windows.Forms.TabPage tpDataQuality;
        private DataQualityReporting.TimePeriodicityChart timePeriodicityChart1;
        private DataQualityReporting.RowStatePieChart rowStatePieChart1;
        private DataQualityReporting.ColumnStatesChart columnStatesChart1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private DataQualityReporting.SubComponents.EvaluationTrackBar evaluationTrackBar1;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private DataQualityReporting.SubComponents.DQEPivotCategorySelector dqePivotCategorySelector1;
    }
}

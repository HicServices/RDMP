using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.IO;
using System.Linq;
using CatalogueLibrary;
using CatalogueLibrary.Data;
using CatalogueLibrary.Data.Cache;
using CatalogueLibrary.Data.DataLoad;
using CatalogueLibrary.DataFlowPipeline;
using CatalogueLibrary.Repositories;
using DataLoadEngine.DataProvider;
using DataLoadEngine.Job;
using DataLoadEngine.Job.Scheduling;
using LoadModules.Generic.FileOperations;
using ReusableLibraryCode.Checks;
using ReusableLibraryCode.Progress;

namespace LoadModules.Generic.DataProvider
{
    public abstract class CachedFileRetriever : ICachedDataProvider
    {
        [DemandsInitialization("The file extension for the archived cache files")]
        public CacheArchiveType CacheArchiveType { get; set; }

        [DemandsInitialization("The date format used in the filename of the archived cache files")]
        public string CacheDateFormat { get; set; }

        [DemandsInitialization("Whether to unarchive the files into the ForLoading folder, or just copy them as is")]
        public bool ExtractFilesFromArchive { get; set; }

        [DemandsInitialization("The path of the class which implements the cache layout")]
        public string CacheLayoutType { get; set; }

        //[DemandsInitialization("The full class name of the CachePathResolver class")]
        //public string CachePathResolverType { get; set; }

        [DemandsInitialization("Built-in property which ensures this plugin can access core framework functionality.")]
        public CatalogueRepository CatalogueRepository { get; set; }

        protected Dictionary<DateTime, FileInfo> Jobs = null;

        public abstract ProcessExitCode Fetch(IDataLoadJob dataLoadJob, GracefulCancellationToken cancellationToken);
        public abstract ILoadCachePathResolver CreateResolver(ILoadProgress loadProgress);

        #region Events
        public event CacheFileNotFoundHandler CacheFileNotFound;
        protected virtual void OnCacheFileNotFound(string message, Exception ex)
        {
            CacheFileNotFoundHandler handler = CacheFileNotFound;
            if (handler != null) handler(this, message, ex);
        }
        #endregion

        private ICacheLayout CreateCacheLayout(ScheduledDataLoadJob job, CacheLayoutFactory cacheLayoutFactory)
        {
            var cacheLayout = cacheLayoutFactory.Create(CacheLayoutType, job.HICProjectDirectory.Cache);
            cacheLayout.ArchiveType = CacheArchiveType;
            cacheLayout.DateFormat = CacheDateFormat;
            return cacheLayout;
        }

        protected static ScheduledDataLoadJob ConvertToScheduledJob(IDataLoadJob dataLoadJob)
        {
            var scheduledJob = dataLoadJob as ScheduledDataLoadJob;

            if (scheduledJob == null)
                throw new Exception("CachedFileRetriever can only be used in conjunction with a ScheduledDataLoadJob");

            return scheduledJob;
        }

        protected Dictionary<DateTime, FileInfo> GetDataLoadWorkload(ScheduledDataLoadJob job)
        {
            var cacheLayout = CreateCacheLayout(job, new CacheLayoutFactory(CatalogueRepository.MEF));
            cacheLayout.Resolver = CreateResolver(job.LoadProgress);
            
            cacheLayout.CheckCacheFilesAvailability();

            var workload = new Dictionary<DateTime, FileInfo>();
            foreach (var date in job.DatesToRetrieve)
            {
                var fileInfo = cacheLayout.GetArchiveFileInfoForDate(date);
                if (!fileInfo.Exists)
                    OnCacheFileNotFound("Could not find cached file '" + fileInfo.FullName + "' for date " + date + " in cache at " + job.HICProjectDirectory.Cache.FullName, null);

                workload.Add(date, fileInfo);
            }

            return workload;
        }

        protected void ExtractJobs(IDataLoadJob dataLoadJob)
        {
            // check to see if forLoading has anything in it and bail if it does
            if (dataLoadJob.HICProjectDirectory.ForLoading.EnumerateFileSystemInfos().Any())
            {
                dataLoadJob.OnNotify(this, new NotifyEventArgs(ProgressEventType.Warning, "ForLoading already has files, skipping extraction"));
                return;
            }

            //extract all the jobs into the forLoading directory
            foreach (KeyValuePair<DateTime, FileInfo> job in Jobs)
            {
                if (job.Value == null)
                    continue;

                if (ExtractFilesFromArchive)
                {
                    var extractor = CreateExtractor(CacheArchiveType);
                    extractor.Extract(job, dataLoadJob.HICProjectDirectory.ForLoading, dataLoadJob);
                }
                else
                {
                    dataLoadJob.OnNotify(this, new NotifyEventArgs(ProgressEventType.Information, "Archive identified:" + job.Value.FullName));

                    // just copy the archives across
                    var relativePath = GetPathRelativeToCacheRoot(dataLoadJob.HICProjectDirectory.Cache, job.Value);
                    var absolutePath = Path.Combine(dataLoadJob.HICProjectDirectory.ForLoading.FullName, relativePath);
                    if (!Directory.Exists(absolutePath))
                        Directory.CreateDirectory(absolutePath);

                    var destFileName = Path.Combine(absolutePath, job.Value.Name);
                    job.Value.CopyTo(destFileName);
                }
            }
        }

        private string GetPathRelativeToCacheRoot(DirectoryInfo cacheRoot, FileInfo fileInCache)
        {
            Contract.Requires<ArgumentException>(fileInCache.Directory != null, "The cache file cannot have a null directory");

            return fileInCache.Directory.FullName.Replace(cacheRoot.FullName, "").TrimStart(Path.DirectorySeparatorChar);
        }

        private IArchivedFileExtractor CreateExtractor(CacheArchiveType cacheArchiveType)
        {
            switch (cacheArchiveType)
            {
                case CacheArchiveType.None:
                    throw new Exception("At this stage a cache archive type must be specified");
                case CacheArchiveType.Zip:
                    return new ZipExtractor();
                case CacheArchiveType.Tar:
                    return new TarExtractor();
                default:
                    throw new ArgumentOutOfRangeException("cacheArchiveType");
            }
        }

        public string GetDescription()
        {
            return "Fetches all the ILoadSchedules in the ILoadMetadata, it then selects the first scheduled task which has work to be done (e.g. data is cached but not yet loaded).  Cached data is unzipped to the forLoading directory.  The Dispose method (which should be called after the entire DataLoad has completed succesfully) will clear out the cached file(s) that were loaded and update the schedule to indicate the succesful loading of data";
        }

        public IDataProvider Clone()
        {
            throw new NotImplementedException();
        }

        public bool Validate(IHICProjectDirectory destination)
        {
            if (destination.Cache == null)
                throw new NullReferenceException("Destination " + destination.RootPath.FullName + " does not have a 'Cache' folder");

            if (!destination.Cache.Exists)
                throw new DirectoryNotFoundException(destination.Cache.FullName);

            return true;
        }

        public bool DisposeImmediately { get; set; }

        public void LoadCompletedSoDispose(ExitCodeType exitCode, IDataLoadEventListener postLoadEventListener)
        {
        }

        public virtual void Check(ICheckNotifier notifier)
        {
            // Check that we can see an instance of the CacheLayout class (we need a valid HICProjectDirectory to create one, so can't go that far)
            if (CatalogueRepository.MEF.GetTypeByNameFromAnyLoadedAssembly(CacheLayoutType) == null)
                notifier.OnCheckPerformed(new CheckEventArgs("The type specified for CacheLayoutType (" + CacheLayoutType + ") in the CachedFileRetriever component cannot be located. Please ensure that the name is correct and that any dependent projects have been fully built.", CheckResult.Fail));
            else
                notifier.OnCheckPerformed(new CheckEventArgs("Found " + CacheLayoutType, CheckResult.Success));
        }
    }

    public delegate void CacheFileNotFoundHandler(object sender, string message, Exception ex);
}

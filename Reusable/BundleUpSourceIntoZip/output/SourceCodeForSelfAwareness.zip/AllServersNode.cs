namespace CatalogueLibrary.Nodes
{
    public class AllServersNode:SingletonNode
    {
        public AllServersNode():base("Data Repository Servers")
        {
            
        }
    }
}

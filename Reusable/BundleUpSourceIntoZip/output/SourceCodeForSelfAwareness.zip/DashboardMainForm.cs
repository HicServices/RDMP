using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CatalogueLibrary.Data;
using CatalogueLibrary.Data.Aggregation;
using CatalogueLibrary.Repositories;
using CatalogueManager.LocationsMenu;
using CatalogueManager.SimpleDialogs;
using CatalogueManager.TestsAndSetup.ServicePropogation;
using RDMPStartup;
using ReusableUIComponents;

namespace Dashboard
{
    /// <summary>
    /// Main window for the RDMP Dashboard which tells you about the healthiness of your datasets including the validation results (data quality), the quality of your metadata (how many
    /// extractable columns in your datasets are missing descriptions), any expired governance (your approval to hold a dataset has expired - See GovernanceUI) and the status of the
    /// data load engine (which loads are passing / failing etc).
    /// 
    /// The 'By Catalogue' tab shows you a breakdown of the healthiness of each dataset (See CatalogueSummaryScreen)
    /// The 'Overview' tab gives you a high level summary of all the things going wrong (or right) with your datasets (See OverviewScreen)
    /// </summary>
    public partial class DashboardMainForm : RDMPForm
    {
        public DashboardMainForm()
        {

            InitializeComponent();
            
            ci_lbCatalogues.SelectedCatalogueChanged += ci_lbCatalogues_SelectedCatalogueChanged;
        }


        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            if (VisualStudioDesignMode)
                return;

            //ci_lbCatalogues.CatalogueCollection.AdjustCatalogues += AdjustCatalogues;
            try
            {
                ci_lbCatalogues.Collection = new ObservableCollection<Catalogue>(RepositoryLocator.CatalogueRepository.GetAllCatalogues(true));
            }
            catch (Exception ex)
            {
                ExceptionViewer.Show(ex);
                LaunchDatabaseSettingsChangeDialog();
                try
                {
                    ci_lbCatalogues.Collection = new ObservableCollection<Catalogue>(RepositoryLocator.CatalogueRepository.GetAllCatalogues(true));
                }
                catch (Exception)
                {
                    return;
                }
            }
        }

        private void LaunchDatabaseSettingsChangeDialog()
        {
            var dialog = new ChoosePlatformDatabases();
            dialog.RepositoryLocator = RepositoryLocator;
            dialog.ShowDialog(this);
        }

        void ci_lbCatalogues_SelectedCatalogueChanged(object sender, EventArgs e)
        {
            catalogueSummaryScreen1.Catalogue = ci_lbCatalogues.SelectedCatalogue;
        }
        
        private void catalogueSummaryScreen1_Load(object sender, EventArgs e)
        {

        }

        private void refreshAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            

            try
            {
                overviewScreen1.RefreshAll();
                var prevC = catalogueSummaryScreen1.Catalogue;

                catalogueSummaryScreen1.Catalogue = null;
                ci_lbCatalogues.Collection = new ObservableCollection<Catalogue>(RepositoryLocator.CatalogueRepository.GetAllCatalogues(true));
                catalogueSummaryScreen1.Catalogue = prevC;
            }
            catch (Exception exception)
            {
                ExceptionViewer.Show(exception);
            }


        }
    }
}

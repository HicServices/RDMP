namespace ReusableUIComponents.Dependencies.Models // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
{
    public class ColorRequest
    {
        public ColorRequest(bool isHighlighted)
        {
            IsHighlighted = isHighlighted;
        }

        public bool IsHighlighted { get; set; }
    }
}

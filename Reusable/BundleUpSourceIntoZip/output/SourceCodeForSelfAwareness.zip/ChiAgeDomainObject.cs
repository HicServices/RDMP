namespace HIC.Common.Validation.Tests.TestData // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
{

    public class ChiAgeDomainObject
    {
        public string chi { get; set; }
        public int age { get; set; }

        public ChiAgeDomainObject(string chi, int age)
        {
            this.chi = chi;
            this.age = age;
        }

    }
}

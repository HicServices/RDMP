using System.Collections.Generic; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Data.Common;
using CatalogueLibrary.Data;
using CatalogueLibrary.DataHelper;
using MapsDirectlyToDatabaseTable;

namespace DataExportManager2Library.Data.DataTables
{
    public class CohortCustomColumn : VersionedDatabaseEntity, IColumn
    {
        public string SelectSQL { get; set; }
        public int ExtractableCohort_ID { get; private set; }

        [NoMappingToDatabase]
        public ColumnInfo ColumnInfo
        {
            get { return null; }
        }
        
        [NoMappingToDatabase]
        public int Order { get; set; }

        [NoMappingToDatabase]
        public string Alias {
            get { return null; }
        }
        [NoMappingToDatabase]
        public bool HashOnDataRelease {
            get { return false; }
        }
        [NoMappingToDatabase]
        public bool IsExtractionIdentifier 
        {
            get { return false; }
        }
        [NoMappingToDatabase]
        public bool IsPrimaryKey { get { return false; } }

        public CohortCustomColumn(IRepository repository, DbDataReader r) : base(repository, r)
        {
            SelectSQL = r["SelectSQL"] as string;
            ExtractableCohort_ID = (int)r["ExtractableCohort_ID"];
        }

        public CohortCustomColumn(IRepository repository, int extractableCohortID, string selectSQL)
        {
            Repository = repository;
            
            Repository.InsertAndHydrate(this, new Dictionary<string, object>
            {
                {"ExtractableCohort_ID", extractableCohortID},
                {"SelectSQL", selectSQL}
            });
        }

        public override string ToString()
        {
            return SelectSQL;
        }

        public string GetRuntimeName()
        {
          return QuerySyntaxHelper.GetRuntimeName(this);
        }
    }
}

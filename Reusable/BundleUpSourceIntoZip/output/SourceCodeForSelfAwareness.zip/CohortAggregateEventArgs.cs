using CatalogueLibrary.Data; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using CatalogueLibrary.Data.Aggregation;

namespace CohortManager.UserFriendly.Events
{
    public class CohortAggregateEventArgs
    {
        public AggregateConfiguration Configuration { get; set; }
        public Catalogue[] Catalogues { get; set; }
        public string Sentence { get; set; }

        public CohortAggregateEventArgs(AggregateConfiguration config, Catalogue[] catalogues)
        {
            Configuration = config;
            Catalogues = catalogues;
        }

        public CohortAggregateEventArgs(AggregateConfiguration config, string sentence, Catalogue[] catalogues)
        {
            Configuration = config;
            Sentence = sentence;
        }
    }
}

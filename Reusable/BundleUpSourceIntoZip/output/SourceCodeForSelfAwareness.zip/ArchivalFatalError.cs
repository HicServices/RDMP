using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved

namespace HIC.Logging.PastEvents
{
    public class ArchivalFatalError : IArchivalLoggingRecordOfPastEvent
    {
        public int ID { get; private set; }
        public DateTime Date { get; set; }
        public string Source { get; set; }
        public string Description { get; set; }
        public string Explanation { get; set; }

        public ArchivalFatalError(int id, DateTime date,string source, string description, string explanation)
        {
            ID = id;
            Date = date;
            Source = source;
            Description = description;
            Explanation = explanation;
        }
        public string ToShortString()
        {
            var s = ToString();
            if (s.Length > ArchivalDataLoadInfo.MaxDescriptionLength)
                return s.Substring(0, ArchivalDataLoadInfo.MaxDescriptionLength) + "...";
            return s;
        }
        public override string ToString()
        {
            return Source + " - " + Description + (string.IsNullOrWhiteSpace(Explanation)?"(UNRESOLVED)":"(RESOLVED:"+Explanation+")");
        }
    }
}

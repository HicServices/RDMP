using System.Drawing; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved

namespace ReusableUIComponents.Dependencies.Models
{
    public class ColorResponse
    {
        public ColorResponse(KnownColor gradientStartColor, KnownColor gradientEndColor)
        {
            GradientStartColor = gradientStartColor;
            GradientEndColor = gradientEndColor;
        }

        public KnownColor GradientStartColor{ get;set; }
        public KnownColor GradientEndColor { get; set; }
    }


}

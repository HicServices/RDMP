namespace DataQualityEngine.Data
{
    public class ArchivalPeriodicityCount
    {
        public int CountGood;
        public int Total;
    }
}

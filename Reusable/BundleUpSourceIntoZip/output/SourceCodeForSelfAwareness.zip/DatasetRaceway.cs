using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using CatalogueLibrary.Data;
using CatalogueManager.TestsAndSetup.ServicePropogation;
using DataQualityEngine.Data;

namespace Dashboard.Raceway
{
    /// <summary>
    /// Allows you to quickly view the timespan of each of your datasets, which sections of your datasets are failing validation (e.g. 'Prescribing' 2001-2002 records are all failing
    /// validation but 2003 onwards are fine) and identify any gaps in your record coverage.
    /// 
    /// Each dataset appears as a green/red bar (See DatasetRaceLane) along a shared axis (See DatasetRaceLaneAxis).  You can switch from viewing all months for which you have data, only
    /// the last decade, year or last 6 months.  Clicking the 'Data' tab will let you view the raw counts powering the entire raceway (THIS IS VERY SLOW TO LOAD!) so only click the tab if
    /// you really mean it.
    /// 
    /// By default the row height of each bar in a dataset indicates the proportion of records in that month relative to the average number of records per month, this allows you to see for
    /// example the gradual increase in volume of records per month in a dataset and identify any periods where it doubles (may indicate duplication) or a hole appears.  If you tick 'Ignore
    /// Row Counts' then full bars will appear only, this lets you identify which datasets are responsible for sparse errors (e.g. if 'Biochemistry' has 1,00,000,000 and some records have
    /// dates sprinkled between 1900-01-01 and 2000-01-01 then these will appear on the axis but won't be visible due to how sparse the nubmer of error records are).
    /// </summary>
    public partial class DatasetRaceway : RDMPUserControl
    {
        private RacewayShowPeriod _period;
        
        public DatasetRaceway()
        {
            InitializeComponent();
            ddShowPeriod.DataSource = Enum.GetValues(typeof (RacewayShowPeriod));
            
            int vertScrollWidth = SystemInformation.VerticalScrollBarWidth;
            tableLayoutPanel1.Padding = new Padding(0, 0, vertScrollWidth, 0);
        }

        public void GenerateChart()
        {
            foreach (ColumnStyle r in tableLayoutPanel1.ColumnStyles)
                r.SizeType = SizeType.AutoSize;

            foreach (RowStyle r in tableLayoutPanel1.RowStyles)
                r.SizeType = SizeType.AutoSize;


            var allCatalogues = RepositoryLocator.CatalogueRepository.GetAllCatalogues();

            Dictionary<Catalogue,DataTable> dictionary = new Dictionary<Catalogue, DataTable>();

            var dqeRepository = new DQERepository(RepositoryLocator.CatalogueRepository);

            foreach (var cata in allCatalogues.OrderBy(c=>c.Name))
            {
                var eval = dqeRepository.GetMostRecentEvaluationFor(cata);

                if(eval != null)
                {
                    DataTable dt = PeriodicityState.GetPeriodicityForDataTableForEvaluation(eval,"ALL", true);

                    if(dt == null)
                        continue;

                    if(dt.Rows.Count== 0)
                        continue;

                    dictionary.Add(cata, dt);
                }
            }
            
            tableLayoutPanel1.Controls.Clear();
            tableLayoutPanel1.RowCount = dictionary.Keys.Count();
            
            //every month seen in every dataset ever
            var buckets = GetBuckets(dictionary);
            
            datasetRaceLaneXAxis1.SetupFor(buckets);

            PopulateDatagrid(dictionary, buckets);

            int rowIndex = 0;
            foreach (var kvp in dictionary)
            {
                var racelane = new DatasetRaceLane();
                racelane.SetupForCatalogue(kvp.Key,kvp.Value, buckets);
                racelane.Dock = DockStyle.Top;
                racelane.IgnoreRowCounts = cbIgnoreRowCounts.Checked;

                tableLayoutPanel1.Controls.Add(racelane, 0, rowIndex);
                rowIndex++;
            }

            //setup the axis
            tableLayoutPanel1.SuspendLayout();

            foreach (ColumnStyle r in tableLayoutPanel1.ColumnStyles)
                r.SizeType = SizeType.AutoSize;

            foreach (RowStyle r in tableLayoutPanel1.RowStyles)
                r.SizeType = SizeType.AutoSize;

            tableLayoutPanel1.ResumeLayout(true); 
            this.Invalidate();
        }

        private void PopulateDatagrid(Dictionary<Catalogue, DataTable> dictionary, DateTime[] buckets)
        {
            DataTable dtSummary = new DataTable();

            dtSummary.Columns.Add("Dataset");

            foreach (DateTime bucket in buckets)
                dtSummary.Columns.Add(bucket.ToString("Y"));


            foreach (KeyValuePair<Catalogue, DataTable> kvp in dictionary)
            {
                Catalogue c = kvp.Key;
                DataTable periodicity = kvp.Value;

                object[] values = new object[buckets.Length + 1];
                values[0] = c.Name;

                for (int i = 0; i < buckets.Length; i++)
                {
                    int good, bad;
                    if (DatasetRaceLane.GetGoodBadCountForMonthIfExists(periodicity, buckets[i], out good, out bad))
                        values[i + 1] = "Good:" + good.ToString("N0") + " Bad:" + bad.ToString("N0");
                    else
                        values[i + 1] = "Good:0 Bad:0";
                }

                dtSummary.Rows.Add(values);
            }

            dataGridView1.DataSource = dtSummary;
            dataGridView1.Columns[0].Frozen = true;
        }
        private DateTime[] GetBuckets(Dictionary<Catalogue, DataTable> dictionary)
        {
            var buckets = new List<DateTime>();

            foreach (DataTable timePeriodicityDataTable in dictionary.Values)
                foreach (DataRow row in timePeriodicityDataTable.Rows)
                {
                    DateTime dt = new DateTime(Convert.ToInt32(row["Year"]), Convert.ToInt32(row["Month"]), 1);

                    //if it is before the start or after today
                    if (dt < GetUserPickedStartDate() || dt.Date>DateTime.Now.Date)
                        continue;

                    if (!buckets.Contains(dt))
                        buckets.Add(dt);
                }

            return buckets.OrderBy(d => d).ToArray(); 
        }

        private DateTime GetUserPickedStartDate()
        {
            switch (_period)
            {
                case RacewayShowPeriod.AllTime:
                    return DateTime.MinValue;
                case RacewayShowPeriod.LastDecade:
                    return DateTime.Now.AddYears(-10);
                case RacewayShowPeriod.LastYear:
                    return DateTime.Now.AddYears(-1);
                case RacewayShowPeriod.LastSixMonths:
                    return DateTime.Now.AddMonths(-6);
                default:
                    throw new ArgumentOutOfRangeException();
            }
        }

        private void ddShowPeriod_SelectedIndexChanged(object sender, EventArgs e)
        {
            var oldPeriod = _period;
            _period = (RacewayShowPeriod)ddShowPeriod.SelectedValue;

            if(oldPeriod != _period)
                GenerateChart();
        }

        enum RacewayShowPeriod
        {
            AllTime,
            LastDecade,
            LastYear,
            LastSixMonths
        }

        private void cbIgnoreRowCounts_CheckedChanged(object sender, EventArgs e)
        {
            foreach (DatasetRaceLane lane in tableLayoutPanel1.Controls)
            {
                lane.IgnoreRowCounts = cbIgnoreRowCounts.Checked;
                lane.Invalidate();
            }
        }

        private void dataGridView1_ColumnAdded(object sender, DataGridViewColumnEventArgs e)
        {
            e.Column.FillWeight = 1;    //allows for up to 65535 columns = 
        }

        private void tableLayoutPanel1_Resize(object sender, EventArgs e)
        {

        }
    }
}

using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using CatalogueLibrary.Data;
using CatalogueLibrary.Repositories;
using CatalogueManager.MainFormUITabs.SubComponents;
using CatalogueManager.TestsAndSetup.ServicePropogation;
using MapsDirectlyToDatabaseTable;
using ReusableLibraryCode.DataAccess;
using ReusableUIComponents;
//http://download.microsoft.com/download/A/D/E/ADEFBFFF-2165-4F63-BB29-DCE891B95CC7/VisualBasicPowerPacksSetup.exe
using Microsoft.VisualBasic.PowerPacks;

namespace CatalogueManager.SimpleDialogs
{
    /// <summary>
    /// Allow you to configure SQL Authentication for accessing data tables in your data repository.  This is optional and in fact the preferred method is to use Integrated Security 
    /// (Windows Authentication) when connecting to your data repository.  Credentials are stored in encrypted form (See PasswordEncryptionKeyLocationUI).  Credentials can be configured
    /// to work on multiple tables (e.g. all the tables in a given database).
    /// 
    /// Each time RDMP accesses data in your repository it will be under a specific DataAccessContext.  These are: DataLoad, DataExport, Logging and InternalDataProcessing (everything 
    /// else including DQE etc).  You can set credentials to only be used under specific contexts or set them to Any (meaning the credentials can be used for any tasks). 
    /// </summary>
    public partial class ConfigureCredentialsForTableInfos : RDMPForm
    {
        private readonly TableInfo _importedTableinfo;

        // do not remove "unused" Lineshapes. They are being used.
        LineShape _credentialsLine;
        private LineShape _tableinfoLine;
        private ShapeContainer _canvas;

        public ConfigureCredentialsForTableInfos(TableInfo tableInfo)
        {
            InitializeComponent();
            _importedTableinfo = tableInfo;
            _canvas = new ShapeContainer { Parent = panelCredentialsVisualisation };
            ddContext.DataSource = Enum.GetValues(typeof(DataAccessContext));
            lbTableInfos.EnableRightClick = false;
            lbTableInfos.SelectionChanged += LbTableInfosOnSelectionChanged;

            lvSelectedTableInfoCredentialsIntersection.CollectionChanged +=(s,e)=> RefreshUIFromDatabase();
            lvTableInfosUsingCredentials.CollectionChanged += (s, e) => RefreshUIFromDatabase();
            lvCredentialsUsedBySelectedTableInfo.CollectionChanged += (s, e) => RefreshUIFromDatabase();
            
            lblNoRelationship.Text = "";
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            if(VisualStudioDesignMode)
                return;

            RefreshUIFromDatabase();

            BetterToolTip.SetToolTip(lbCredentials, ToolTips.ConfigureCredentialsAddEdit, Images.ConfigureCredentialsAddEdit);
            BetterToolTip.SetToolTip(lvSelectedTableInfoCredentialsIntersection, ToolTips.ConfigureCredentialsExistingRelationships, Images.ConfigureCredentialsExistingRelationships);
            BetterToolTip.SetToolTip(lvTableInfosUsingCredentials, ToolTips.ConfigureCredentialsBreakLinkage, Images.ConfigureCredentialsBreakLinkage);
            BetterToolTip.SetToolTip(panelCredentialsVisualisation, ToolTips.ConfigureCredentialsPermissionsVisualiser, Images.ConfigureCredentialsPermissionsVisualiser);
        }

        private void RefreshUIFromDatabase()
        {
            var credToReselect = lbCredentials.SelectedItem as DataAccessCredentials;
            var tableinfoToReselect = lbTableInfos.SelectedTableInfo;

            GetCredentials();
            GetTableInfos();
            UpdateUIBasedOnSelections();


            if (credToReselect != null)
                lbCredentials.SelectedItem = lbCredentials.Items.Cast<DataAccessCredentials>().FirstOrDefault(c => c.ID == credToReselect.ID);

            if (tableinfoToReselect != null)
                lbTableInfos.SelectTableInfo(tableinfoToReselect);
        }



        private void btnAddCredentials_Click(object sender, EventArgs e)
        {
            try
            {
                DataAccessCredentials credentialsToCreate = new DataAccessCredentials(RepositoryLocator.CatalogueRepository,"");
                credentialsToCreate.SaveToDatabase();
                RefreshUIFromDatabase();
            }
            catch (Exception exception)
            {
                ExceptionViewer.Show(exception);
            }
        }

        private void btnEditCredentials_Click(object sender, EventArgs e)
        {
            EditCredentials();
        }

        private void EditCredentials()
        {
            try
            {
                var control = new EditCredentialControl(lbCredentials.SelectedItem as DataAccessCredentials);
                control.ShowDialog(this);
                GetCredentials();
            }
            catch (Exception e)
            {
                ExceptionViewer.Show(e);
            }
        }

        private void lbCredentials_DrawItem(object sender, DrawItemEventArgs e)
        {
            try
            {
                if (e.Index >= 0)
                {
                    Graphics g = e.Graphics;

                    g.FillRectangle(new SolidBrush(e.BackColor), e.Bounds);
                    DataAccessCredentials toDisplay = lbCredentials.Items[e.Index] as DataAccessCredentials;

                    if (toDisplay.ToString().Contains("DMP_Credentials_"))
                    {
                        g.DrawString(toDisplay.ToString(), e.Font, new SolidBrush(Color.Red),
                            new PointF(e.Bounds.X, e.Bounds.Y));
                    }
                    else
                    {
                        g.DrawString(toDisplay.ToString(), e.Font, new SolidBrush(Color.Black),
                            new PointF(e.Bounds.X, e.Bounds.Y));
                    }
                }
            }
            catch (Exception exception)
            {
                ExceptionViewer.Show(exception);
            }
        }

        private void ClearCanvas()
        {
            _canvas.Shapes.Clear();
            _canvas.Refresh();
            _canvas.Update();
        }

        private void DrawRelationshipLines()
        {
            ClearCanvas();

            List<string> relationships = lvSelectedTableInfoCredentialsIntersection.GetAllRelationships();

            if (relationships.Capacity == 0)
            {
                lblNoRelationship.Text = "No Relationship";
                return;
            }
            lblNoRelationship.Text = "";

            int colourIterator = 0;
            Color[] lineColours = { Color.OrangeRed, Color.Blue, Color.Green, Color.Brown, Color.Yellow };

            foreach (string context in relationships)
            {
                Label contextLabelName = GetLabelByName(context);

                _tableinfoLine = new LineShape
                {
                    Parent = _canvas,
                    BorderWidth = 4,
                    BorderColor = lineColours[colourIterator],
                    StartPoint = new Point(lblselectedTableinfo.Right / 2, lblselectedTableinfo.Top),
                    EndPoint = new Point(contextLabelName.Right - contextLabelName.Width / 2, contextLabelName.Top + 10)
                };

                _credentialsLine = new LineShape
                {
                    Parent = _canvas,
                    BorderWidth = 4,
                    BorderColor = lineColours[colourIterator],
                    StartPoint = new Point(lblselectedCredentials.Right - lblselectedCredentials.Width / 2, lblselectedCredentials.Top + 10),
                    EndPoint = new Point(contextLabelName.Right - contextLabelName.Width / 2, contextLabelName.Top + 10)
                };

                colourIterator++;
            }
        }

        private Label GetLabelByName(string name)
        {
            return (from Control c in panelCredentialsVisualisation.Controls where c.GetType() == typeof(Label) where c.Text == name select (Label)c).FirstOrDefault();
        }

        private void GetCredentials()
        {
            try
            {
                
                lbCredentials.Items.Clear();
                lbCredentials.Items.AddRange(RepositoryLocator.CatalogueRepository.GetAllObjects<DataAccessCredentials>().ToArray());
            }
            catch (Exception exception)
            {
                ExceptionViewer.Show(exception);
            }
        }

        private void GetTableInfos()
        {
            try
            {
                if (_importedTableinfo == null)
                {
                    lbTableInfos.Collection = new ObservableCollection<TableInfo>(RepositoryLocator.CatalogueRepository.GetAllObjects<TableInfo>());
                }
                else
                {
                    lbTableInfos.Collection = new ObservableCollection<TableInfo>(new List<TableInfo>() { _importedTableinfo });
                }
            }
            catch (Exception exception)
            {
                ExceptionViewer.Show(exception);
            }
        }


        private void ConfigureCredentialsForTableInfos_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
                this.Close();
        }

        private void UpdateUIBasedOnSelections()
        {
            try
            {
                //first bit -- user selects credentials
                var selectedCredentials = lbCredentials.SelectedItem as DataAccessCredentials;

                //if the user has selected credentials
                if (selectedCredentials != null)
                {
                    //show him all the table infos that are used by the credentials
                    gbTableInfosUsingCredential.Enabled = true;
                    btnEditCredentials.Enabled = true;
                    gbTableInfosUsingCredential.Text = "TableInfos Using:" + selectedCredentials;
                    lvTableInfosUsingCredentials.ShowAllRelationshipsFor(selectedCredentials);
                }
                else
                {
                    //user has not selected any credentials

                    //do not show him which table infos are used by the selected credentials
                    gbTableInfosUsingCredential.Text = "TableInfos Using:";
                    gbTableInfosUsingCredential.Enabled = false;
                    btnEditCredentials.Enabled = false;
                    lvTableInfosUsingCredentials.Clear();
                }

                //second bit --user selects table info
                if (lbTableInfos.SelectedTableInfo != null)
                {
                    //user has selected a TableInfo

                    //show him ALL credentials used by TableInfo
                    gbCredentialsUsedBySelectedTableInfo.Text = "Credentials Used By:" + lbTableInfos.SelectedTableInfo;
                    gbCredentialsUsedBySelectedTableInfo.Enabled = true;
                    lvCredentialsUsedBySelectedTableInfo.ShowAllRelationshipsFor(lbTableInfos.SelectedTableInfo);
                }
                else
                {
                    //if user has not selected any TableInfo

                    //do not show him which credentials are in use by the tableinfo
                    gbCredentialsUsedBySelectedTableInfo.Text = "Credentials Used By:";
                    gbCredentialsUsedBySelectedTableInfo.Enabled = false;
                    lvCredentialsUsedBySelectedTableInfo.Clear();

                }


                //third bit -- user has selected BOTH credentials and table info so show him the Intersection (and/or allow him to create new relationships between these two entities)
                if (lbCredentials.SelectedItem != null && lbTableInfos.SelectedTableInfo != null)
                {
                    //user has selected both a TableInfo and a Credentials
                    gbAllowUseOfCredentials.Enabled = true;
                    lvSelectedTableInfoCredentialsIntersection.ShowAllRelationshipsFor(lbTableInfos.SelectedTableInfo,
                        selectedCredentials);

                }
                else
                {
                    //user has not selected one or the other
                    //so disable the boxes
                    gbAllowUseOfCredentials.Enabled = false;
                    lvSelectedTableInfoCredentialsIntersection.Clear();
                }

                //Draw lines to show relationships visually
                if (selectedCredentials != null) lblselectedCredentials.Text = selectedCredentials.ToString();
                if (lbTableInfos.SelectedTableInfo != null)
                    lblselectedTableinfo.Text = lbTableInfos.SelectedTableInfo.ToString();
                DrawRelationshipLines();
            }
            catch (Exception exception)
            {
                ExceptionViewer.Show(exception);
            }
        }

        private void lbCredentials_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateUIBasedOnSelections();
        }


        private void LbTableInfosOnSelectionChanged()
        {
            UpdateUIBasedOnSelections();
        }

        private void btnGrantPermission_Click(object sender, EventArgs e)
        {
            try
            {
                if (lbTableInfos.SelectedTableInfo == null)
                {
                    MessageBox.Show("You must select a TableInfo");
                    return;
                }

                lbTableInfos.SelectedTableInfo.SetCredentials(lbCredentials.SelectedItem as DataAccessCredentials, (DataAccessContext)ddContext.SelectedItem);
                MessageBox.Show("Relationship set between " + lbCredentials.SelectedItem + " and " + lbTableInfos.SelectedTableInfo + " under context " + (DataAccessContext)ddContext.SelectedItem);

                //update because things could be selected that have relationship changes now
                RefreshUIFromDatabase();
            }
            catch (Exception exception)
            {
                ExceptionViewer.Show(exception);
            }
        }

        private void lbTableInfos_Load(object sender, EventArgs e)
        {

        }

        private void lbCredentials_DoubleClick(object sender, EventArgs e)
        {
            if (lbCredentials.SelectedItem != null)
            {
                EditCredentials();
            }
        }

        private void lbCredentials_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.Delete)
                {
                    var credentialsToDelete = lbCredentials.SelectedItem as DataAccessCredentials;
                    var TablesThatUseCredentials = credentialsToDelete.GetAllTableInfosThatUseThis();
                    if (MessageBox.Show("Are you sure you want to delete Credentials:  " + credentialsToDelete.Name + "?",
                            "Delete Credentials Permanently?", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        if (TablesThatUseCredentials.Count == 0)
                        {
                            credentialsToDelete.DeleteInDatabase();
                            MessageBox.Show("Credentials Successfully Deleted", "Delete Success");
                        }
                        else
                        {
                            MessageBox.Show("Cannot delete credentials " + credentialsToDelete.Name + " since they are used by the following Tableinfo(s) \n (" + string.Join("\n", TablesThatUseCredentials.Values.Select(t => string.Join(",", t))) + "). \n Please remove" +
                                            " existing relationships before deleting credentials.", "Delete Failed");
                        }
                    }
                }
                GetCredentials();
            }
            catch (Exception exception)
            {
                ExceptionViewer.Show(exception);
            }
        }
    }
}

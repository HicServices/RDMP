namespace CatalogueManager.ExtractionUIs // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
{
    partial class ConfigureLookups
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ConfigureLookups));
            this.lbLookups = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tbID = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cbCollate_Latin1_General_BIN = new System.Windows.Forms.CheckBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.ddLookupExtractionJoinType = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cbxPrimaryKey = new CatalogueManager.AutoCompleteTextbox();
            this.cbxForeignKey = new CatalogueManager.AutoCompleteTextbox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.pPreview = new System.Windows.Forms.Panel();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.btnAddCompositeJoin = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbLookups
            // 
            this.lbLookups.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbLookups.FormattingEnabled = true;
            this.lbLookups.Location = new System.Drawing.Point(3, 27);
            this.lbLookups.Name = "lbLookups";
            this.lbLookups.Size = new System.Drawing.Size(365, 498);
            this.lbLookups.TabIndex = 0;
            this.lbLookups.SelectedIndexChanged += new System.EventHandler(this.lbLookups_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Is a description for:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(97, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Foreign Key:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(97, 62);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Primary Key:";
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.tbID);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.cbCollate_Latin1_General_BIN);
            this.groupBox1.Controls.Add(this.btnSave);
            this.groupBox1.Controls.Add(this.btnAdd);
            this.groupBox1.Controls.Add(this.ddLookupExtractionJoinType);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.cbxPrimaryKey);
            this.groupBox1.Controls.Add(this.cbxForeignKey);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(711, 173);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Lookup";
            // 
            // tbID
            // 
            this.tbID.Location = new System.Drawing.Point(168, 13);
            this.tbID.Name = "tbID";
            this.tbID.ReadOnly = true;
            this.tbID.Size = new System.Drawing.Size(135, 20);
            this.tbID.TabIndex = 14;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(141, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(21, 13);
            this.label5.TabIndex = 13;
            this.label5.Text = "ID:";
            // 
            // cbCollate_Latin1_General_BIN
            // 
            this.cbCollate_Latin1_General_BIN.AutoSize = true;
            this.cbCollate_Latin1_General_BIN.Checked = true;
            this.cbCollate_Latin1_General_BIN.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbCollate_Latin1_General_BIN.Location = new System.Drawing.Point(168, 117);
            this.cbCollate_Latin1_General_BIN.Name = "cbCollate_Latin1_General_BIN";
            this.cbCollate_Latin1_General_BIN.Size = new System.Drawing.Size(157, 17);
            this.cbCollate_Latin1_General_BIN.TabIndex = 12;
            this.cbCollate_Latin1_General_BIN.Text = "Collate Latin1_General_BIN";
            this.cbCollate_Latin1_General_BIN.UseVisualStyleBackColor = true;
            this.cbCollate_Latin1_General_BIN.CheckedChanged += new System.EventHandler(this.cbCollate_Latin1_General_BIN_CheckedChanged);
            // 
            // btnSave
            // 
            this.btnSave.Enabled = false;
            this.btnSave.Location = new System.Drawing.Point(249, 140);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 9;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(168, 140);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 8;
            this.btnAdd.Text = "Add As New";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // ddLookupExtractionJoinType
            // 
            this.ddLookupExtractionJoinType.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ddLookupExtractionJoinType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.ddLookupExtractionJoinType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.ddLookupExtractionJoinType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddLookupExtractionJoinType.FormattingEnabled = true;
            this.ddLookupExtractionJoinType.Location = new System.Drawing.Point(168, 90);
            this.ddLookupExtractionJoinType.Name = "ddLookupExtractionJoinType";
            this.ddLookupExtractionJoinType.Size = new System.Drawing.Size(537, 21);
            this.ddLookupExtractionJoinType.TabIndex = 7;
            this.ddLookupExtractionJoinType.SelectedIndexChanged += new System.EventHandler(this.cbxLookupExtractionJoinType_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(17, 93);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(145, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Lookup Extraction Join Type:";
            // 
            // cbxPrimaryKey
            // 
            this.cbxPrimaryKey.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cbxPrimaryKey.AutoCompleteList = ((System.Collections.Generic.List<object>)(resources.GetObject("cbxPrimaryKey.AutoCompleteList")));
            this.cbxPrimaryKey.CaseSensitive = false;
            this.cbxPrimaryKey.Location = new System.Drawing.Point(168, 62);
            this.cbxPrimaryKey.MinTypedCharacters = 2;
            this.cbxPrimaryKey.Name = "cbxPrimaryKey";
            this.cbxPrimaryKey.SelectedIndex = -1;
            this.cbxPrimaryKey.Size = new System.Drawing.Size(537, 20);
            this.cbxPrimaryKey.SuppressAutoComplete = false;
            this.cbxPrimaryKey.TabIndex = 5;
            this.cbxPrimaryKey.SelectedItemChanged += new System.EventHandler(this.cbxJoinKey2_SelectedIndexChanged);
            // 
            // cbxForeignKey
            // 
            this.cbxForeignKey.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cbxForeignKey.AutoCompleteList = ((System.Collections.Generic.List<object>)(resources.GetObject("cbxForeignKey.AutoCompleteList")));
            this.cbxForeignKey.CaseSensitive = false;
            this.cbxForeignKey.Location = new System.Drawing.Point(168, 39);
            this.cbxForeignKey.MinTypedCharacters = 2;
            this.cbxForeignKey.Name = "cbxForeignKey";
            this.cbxForeignKey.SelectedIndex = -1;
            this.cbxForeignKey.Size = new System.Drawing.Size(537, 20);
            this.cbxForeignKey.SuppressAutoComplete = false;
            this.cbxForeignKey.TabIndex = 4;
            this.cbxForeignKey.SelectedItemChanged += new System.EventHandler(this.cbxJoinKey1_SelectedIndexChanged);
            // 
            // btnDelete
            // 
            this.btnDelete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnDelete.Location = new System.Drawing.Point(6, 531);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 9;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // pPreview
            // 
            this.pPreview.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pPreview.Location = new System.Drawing.Point(3, 182);
            this.pPreview.Name = "pPreview";
            this.pPreview.Size = new System.Drawing.Size(711, 371);
            this.pPreview.TabIndex = 10;
            // 
            // splitContainer1
            // 
            this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.btnAddCompositeJoin);
            this.splitContainer1.Panel1.Controls.Add(this.label1);
            this.splitContainer1.Panel1.Controls.Add(this.btnDelete);
            this.splitContainer1.Panel1.Controls.Add(this.lbLookups);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.groupBox1);
            this.splitContainer1.Panel2.Controls.Add(this.pPreview);
            this.splitContainer1.Size = new System.Drawing.Size(1100, 561);
            this.splitContainer1.SplitterDistance = 375;
            this.splitContainer1.TabIndex = 11;
            // 
            // btnAddCompositeJoin
            // 
            this.btnAddCompositeJoin.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnAddCompositeJoin.Location = new System.Drawing.Point(208, 531);
            this.btnAddCompositeJoin.Name = "btnAddCompositeJoin";
            this.btnAddCompositeJoin.Size = new System.Drawing.Size(160, 22);
            this.btnAddCompositeJoin.TabIndex = 13;
            this.btnAddCompositeJoin.Text = "Configure Composite Join(s)";
            this.btnAddCompositeJoin.UseVisualStyleBackColor = true;
            this.btnAddCompositeJoin.Click += new System.EventHandler(this.btnAddCompositeJoin_Click);
            // 
            // ConfigureLookups
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1100, 561);
            this.Controls.Add(this.splitContainer1);
            this.Name = "ConfigureLookups";
            this.Text = "Configure Lookups";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lbLookups;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.ComboBox ddLookupExtractionJoinType;
        private System.Windows.Forms.Label label4;
        private AutoCompleteTextbox cbxPrimaryKey;
        private AutoCompleteTextbox cbxForeignKey;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Panel pPreview;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.CheckBox cbCollate_Latin1_General_BIN;
        private System.Windows.Forms.Button btnAddCompositeJoin;
        private System.Windows.Forms.TextBox tbID;
        private System.Windows.Forms.Label label5;
    }
}

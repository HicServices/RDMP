using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Data.Common;
using CatalogueLibrary.Data;
using DataExportManager2.Interfaces.Data.DataTables;
using MapsDirectlyToDatabaseTable;

namespace DataExportManager2Library.Data.DataTables
{
    public class CumulativeExtractionResults : VersionedDatabaseEntity, ICumulativeExtractionResults
    {
        public int ExtractionConfiguration_ID { get; set; }
        public int ExtractableDataSet_ID { get; set; }
        
        public DateTime DateOfExtraction { get; set; }
        public string Filename { get; set; }
        public int RecordsExtracted { get; set; }
        public int DistinctReleaseIdentifiersEncountered { get; set; }
        public string FiltersUsed { get; set; }
        public string Exception { get; set; }
        public string SQLExecuted { get; set; }
        public int CohortExtracted { get; set; }

        #region Relationships
        [NoMappingToDatabase]
        public IExtractableDataSet ExtractableDataSet
        {
            get
            {
                return Repository.GetObjectByID<ExtractableDataSet>(ExtractableDataSet_ID);
            }
        }

        #endregion

        public CumulativeExtractionResults(IRepository repository, IExtractionConfiguration configuration, IExtractableDataSet dataset, string SQL)
        {
            Repository = repository;
            Repository.InsertAndHydrate(this, new Dictionary<string, object>
            {
                {"ExtractionConfiguration_ID", configuration.ID},
                {"ExtractableDataSet_ID", dataset.ID},
                {"SQLExecuted", SQL},
                {"CohortExtracted", configuration.Cohort_ID}
            });
        }

        public CumulativeExtractionResults(IRepository repository, DbDataReader r) : base(repository, r)
        {
            ExtractionConfiguration_ID = int.Parse(r["ExtractionConfiguration_ID"].ToString());
            ExtractableDataSet_ID = int.Parse(r["ExtractableDataSet_ID"].ToString());
            DateOfExtraction = (DateTime)r["DateOfExtraction"];
            RecordsExtracted = int.Parse(r["RecordsExtracted"].ToString());
            DistinctReleaseIdentifiersEncountered = int.Parse(r["DistinctReleaseIdentifiersEncountered"].ToString());
            Exception = r["Exception"] as string;
            FiltersUsed = r["FiltersUsed"] as string;
            Filename = r["Filename"] as string;
            SQLExecuted = r["SQLExecuted"] as string;
            CohortExtracted = int.Parse(r["CohortExtracted"].ToString());
        }

    }
}

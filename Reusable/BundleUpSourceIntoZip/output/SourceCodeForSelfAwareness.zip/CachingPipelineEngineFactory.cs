using CatalogueLibrary; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using CatalogueLibrary.Data;
using CatalogueLibrary.Data.Cache.FetchRequestProvider;
using CatalogueLibrary.Data.Pipelines;
using CatalogueLibrary.DataFlowPipeline;
using CatalogueLibrary.Repositories;
using ReusableLibraryCode.Progress;

namespace CachingEngine.DataRetrievers
{
    public class CachingPipelineEngineFactory
    {
        private readonly IDynamicPipelineEngineFactory _dynamicPipelineEngineFactory;

        public CachingPipelineEngineFactory(IDynamicPipelineEngineFactory dynamicPipelineEngineFactory)
        {
            _dynamicPipelineEngineFactory = dynamicPipelineEngineFactory;
        }

        public IDataFlowPipelineEngine CreateCachingPipelineEngine(ICacheProgress cacheProgress, ICatalogueRepository repository, IDataLoadEventListener listener)
        {
            var loadSchedule = cacheProgress.GetLoadProgress();

            var cacheFetchRequestFactory = new CacheFetchRequestFactory();
            var initialFetchRequest = cacheFetchRequestFactory.Create(cacheProgress, loadSchedule);

            // Create and initialize the pipeline engine
            var engine = _dynamicPipelineEngineFactory.Create(cacheProgress, listener);

            // Get the HICProjectDirectory for the engine initialization
            var loadMetadata = loadSchedule.GetLoadMetadata();
            var hicProjectDirectory = new HICProjectDirectory(loadMetadata.LocationOfFlatFiles, false);

            engine.Initialize(new CacheFetchRequestProvider(initialFetchRequest), initialFetchRequest.PermissionWindow, hicProjectDirectory, repository.MEF);

            return engine;
        }

        public IDataFlowPipelineEngine CreateRetryCachingPipelineEngine(ICacheProgress cacheProgress, ICatalogueRepository repository, IDataLoadEventListener listener)
        {
            // Create and initialize the pipeline engine
            var engine = _dynamicPipelineEngineFactory.Create(cacheProgress, listener);

            // Get the HICProjectDirectory for the engine initialization
            var loadSchedule = cacheProgress.GetLoadProgress();
            var loadMetadata = loadSchedule.GetLoadMetadata();
            var hicProjectDirectory = new HICProjectDirectory(loadMetadata.LocationOfFlatFiles, false);

            engine.Initialize(new FailedCacheFetchRequestProvider(cacheProgress), cacheProgress.GetPermissionWindow(), hicProjectDirectory, repository.MEF);

            return engine;
        }
    }
}

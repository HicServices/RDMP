namespace CatalogueManager.ExtractionUIs // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
{
    partial class ConfigureJoins
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbLookups = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tbJoinKey1 = new System.Windows.Forms.TextBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.ddLookupExtractionJoinType = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cbxJoinKey2 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnDelete = new System.Windows.Forms.Button();
            this.pPreview = new System.Windows.Forms.Panel();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.cbCollate_Latin1_General_BIN = new System.Windows.Forms.CheckBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbLookups
            // 
            this.lbLookups.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbLookups.FormattingEnabled = true;
            this.lbLookups.Location = new System.Drawing.Point(3, 27);
            this.lbLookups.Name = "lbLookups";
            this.lbLookups.Size = new System.Drawing.Size(365, 485);
            this.lbLookups.TabIndex = 0;
            this.lbLookups.SelectedIndexChanged += new System.EventHandler(this.lbLookups_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Is a foreign key to:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(17, 58);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Primary Key:";
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.cbCollate_Latin1_General_BIN);
            this.groupBox1.Controls.Add(this.tbJoinKey1);
            this.groupBox1.Controls.Add(this.btnSave);
            this.groupBox1.Controls.Add(this.btnAdd);
            this.groupBox1.Controls.Add(this.ddLookupExtractionJoinType);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.cbxJoinKey2);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(711, 177);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Join";
            // 
            // tbJoinKey1
            // 
            this.tbJoinKey1.Location = new System.Drawing.Point(127, 27);
            this.tbJoinKey1.Name = "tbJoinKey1";
            this.tbJoinKey1.ReadOnly = true;
            this.tbJoinKey1.Size = new System.Drawing.Size(577, 20);
            this.tbJoinKey1.TabIndex = 10;
            // 
            // btnSave
            // 
            this.btnSave.Enabled = false;
            this.btnSave.Location = new System.Drawing.Point(208, 148);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 9;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(127, 148);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 8;
            this.btnAdd.Text = "Add As New";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // ddLookupExtractionJoinType
            // 
            this.ddLookupExtractionJoinType.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ddLookupExtractionJoinType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.ddLookupExtractionJoinType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.ddLookupExtractionJoinType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddLookupExtractionJoinType.FormattingEnabled = true;
            this.ddLookupExtractionJoinType.Location = new System.Drawing.Point(127, 83);
            this.ddLookupExtractionJoinType.Name = "ddLookupExtractionJoinType";
            this.ddLookupExtractionJoinType.Size = new System.Drawing.Size(578, 21);
            this.ddLookupExtractionJoinType.TabIndex = 7;
            this.ddLookupExtractionJoinType.SelectedIndexChanged += new System.EventHandler(this.cbxLookupExtractionJoinType_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(17, 86);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(106, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Extraction Join Type:";
            // 
            // cbxJoinKey2
            // 
            this.cbxJoinKey2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cbxJoinKey2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cbxJoinKey2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cbxJoinKey2.FormattingEnabled = true;
            this.cbxJoinKey2.Location = new System.Drawing.Point(127, 55);
            this.cbxJoinKey2.Name = "cbxJoinKey2";
            this.cbxJoinKey2.Size = new System.Drawing.Size(578, 21);
            this.cbxJoinKey2.TabIndex = 5;
            this.cbxJoinKey2.SelectedIndexChanged += new System.EventHandler(this.cbxJoinKey2_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Foreign Key:";
            // 
            // btnDelete
            // 
            this.btnDelete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnDelete.Location = new System.Drawing.Point(6, 531);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 9;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // pPreview
            // 
            this.pPreview.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pPreview.Location = new System.Drawing.Point(3, 186);
            this.pPreview.Name = "pPreview";
            this.pPreview.Size = new System.Drawing.Size(711, 367);
            this.pPreview.TabIndex = 10;
            // 
            // splitContainer1
            // 
            this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.label1);
            this.splitContainer1.Panel1.Controls.Add(this.btnDelete);
            this.splitContainer1.Panel1.Controls.Add(this.lbLookups);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.groupBox1);
            this.splitContainer1.Panel2.Controls.Add(this.pPreview);
            this.splitContainer1.Size = new System.Drawing.Size(1100, 561);
            this.splitContainer1.SplitterDistance = 375;
            this.splitContainer1.TabIndex = 11;
            // 
            // cbCollate_Latin1_General_BIN
            // 
            this.cbCollate_Latin1_General_BIN.AutoSize = true;
            this.cbCollate_Latin1_General_BIN.Checked = true;
            this.cbCollate_Latin1_General_BIN.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbCollate_Latin1_General_BIN.Location = new System.Drawing.Point(127, 111);
            this.cbCollate_Latin1_General_BIN.Name = "cbCollate_Latin1_General_BIN";
            this.cbCollate_Latin1_General_BIN.Size = new System.Drawing.Size(157, 17);
            this.cbCollate_Latin1_General_BIN.TabIndex = 11;
            this.cbCollate_Latin1_General_BIN.Text = "Collate Latin1_General_BIN";
            this.cbCollate_Latin1_General_BIN.UseVisualStyleBackColor = true;
            this.cbCollate_Latin1_General_BIN.CheckedChanged += new System.EventHandler(this.cbCollate_Latin1_General_BIN_CheckedChanged);
            // 
            // ConfigureJoins
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1100, 561);
            this.Controls.Add(this.splitContainer1);
            this.Name = "ConfigureJoins";
            this.Text = "Configure Joins";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lbLookups;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.ComboBox ddLookupExtractionJoinType;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbxJoinKey2;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Panel pPreview;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TextBox tbJoinKey1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox cbCollate_Latin1_General_BIN;
    }
}

using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.ComponentModel;
using System.Linq;
using System.Windows.Forms;
using CatalogueLibrary.Data;
using CatalogueLibrary.DataHelper;
using CatalogueLibrary.Repositories;
using CatalogueManager.TestsAndSetup.ServicePropogation;
using ReusableUIComponents;
using ScintillaNET;

namespace CatalogueManager.ExtractionUIs
{
    /// <summary>
    /// Sometimes when building your database schema you need to join two tables across multiple fields.  For example a Header and Results table may join on LabNumber + Hospital 
    /// (Header.LabNumber = Results.LabNumber AND Header.Hospital = Results.Hospital), such a relationship would be required if there was crossover in lab numbers between hospitals.
    /// 
    /// This window lets you augment an existing JoinInfo (2 columns that join together) with additional columns in those tables (for example as described above).
    /// 
    /// </summary>
    public partial class ConfigureLookupCompositeJoinInfo : BetterToolTipForm, IKnowIfImHostedByVisualStudio
    {
        private readonly Lookup _lookup;
        private readonly CatalogueRepository _catalogueRepository;

        private LookupCompositeJoinInfo CurrentlySelectedLookupCompositeJoinInfo
        {
            get { return _currentlySelectedLookupCompositeJoinInfo; }
            set
            {
                {
                    if (value != null)
                    {
                        tbID.Text = value.ID.ToString();
                        cbxForeignKey.Text = value.ForeignKey.Name;
                        cbxPrimaryKey.Text = value.PrimaryKey.Name;
                        cbCollate_Latin1_General_BIN.Checked = !string.IsNullOrWhiteSpace(value.Collation);
                        btnSave.Enabled = true;
                        
                    }
                    else
                    {
                        tbID.Text = "";
                        cbxForeignKey.Text = "";
                        cbxPrimaryKey.Text = "";
                        btnSave.Enabled = false;
                    }

                    _currentlySelectedLookupCompositeJoinInfo = value;
                    
                }
            }
        }

        private readonly Scintilla QueryPreview;
        private LookupCompositeJoinInfo _currentlySelectedLookupCompositeJoinInfo;

        public bool VisualStudioDesignMode { get; set; }

        public ConfigureLookupCompositeJoinInfo(Lookup lookup)
        {
            InitializeComponent();
            
            _lookup = lookup;
            
            VisualStudioDesignMode = (LicenseManager.UsageMode == LicenseUsageMode.Designtime);

            if (lookup == null)
                return;

            _catalogueRepository = (CatalogueRepository) _lookup.Repository;

            //add any bloody columns in the entire database because someone might want to join to with a composite key that is part of a join to another table i.e. there are 3 tables involved in the lookup join
            cbxForeignKey.DataSource = _catalogueRepository.GetAllObjects<ColumnInfo>().ToArray();

            //add only the columns that are in the same table for join key 2
            TableInfo originalPrimaryKeyTable = lookup.Description.TableInfo;
            cbxPrimaryKey.DataSource = originalPrimaryKeyTable.ColumnInfos.ToArray();


            #region Query Editor setup
            

            if (VisualStudioDesignMode) //dont add the QueryEditor if we are in design time (visual studio) because it breaks
                return;


            QueryPreview = new Scintilla();
            QueryPreview.Dock = DockStyle.Fill;
            QueryPreview.Scrolling.ScrollBars = ScrollBars.Both;
            QueryPreview.ConfigurationManager.Language = "mssql";
            QueryPreview.Margins[0].Width = 40; //allows display of line numbers
            QueryPreview.IsReadOnly = true;


            pPreview.Controls.Add(QueryPreview);
            #endregion


            RefreshUIFromDatabase();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            var composite = lbCompositeLookups.SelectedItem as LookupCompositeJoinInfo;

            if (composite != null)
                composite.DeleteInDatabase();

            CurrentlySelectedLookupCompositeJoinInfo = null;

            RefreshUIFromDatabase();
        }

        private void RefreshUIFromDatabase()
        {
           lbCompositeLookups.Items.Clear();
           lbCompositeLookups.Items.AddRange(_lookup.GetSupplementalJoins().ToArray());

            QueryPreview.IsReadOnly = false;
            string joinSql = JoinHelper.GetJoinSQL(_lookup);
            QueryPreview.Text = "SELECT top 1 * FROM " + Environment.NewLine + joinSql;
            QueryPreview.IsReadOnly = true;

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                new LookupCompositeJoinInfo(_catalogueRepository, _lookup,
                                                                    cbxForeignKey.SelectedItem as ColumnInfo,
                                                                    cbxPrimaryKey.SelectedItem as ColumnInfo,
                                                                    cbCollate_Latin1_General_BIN.Checked?"Latin1_General_BIN":null);
                
                CurrentlySelectedLookupCompositeJoinInfo = null;

                RefreshUIFromDatabase();
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message);
            }


        }

        private void lbCompositeLookups_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            CurrentlySelectedLookupCompositeJoinInfo = lbCompositeLookups.SelectedItem as LookupCompositeJoinInfo;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (_currentlySelectedLookupCompositeJoinInfo == null)
            {
                MessageBox.Show(
                    "You can only save if you have selected an existing CompositeJoinInfo otherwise you must select create new");
                return;
            }

            try
            {
                _currentlySelectedLookupCompositeJoinInfo.ForeignKey_ID = (cbxForeignKey.SelectedItem as ColumnInfo).ID;
                _currentlySelectedLookupCompositeJoinInfo.PrimaryKey_ID = (cbxPrimaryKey.SelectedItem as ColumnInfo).ID;

                _currentlySelectedLookupCompositeJoinInfo.Collation = cbCollate_Latin1_General_BIN.Checked ? "Latin1_General_BIN" : null;
                _currentlySelectedLookupCompositeJoinInfo.SaveToDatabase();

                RefreshUIFromDatabase();
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message);
            }
        }

        
    }
}

using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
namespace HIC.Common.Validation.Constraints
{
    public enum Consequence
    {
        Missing,
        Wrong,
        InvalidatesRow
    }

    public abstract class Constraint
    {
        public string Name { get; set; }

        public abstract Type GetCompatibleType();

        public Consequence? Consequence { get; set; }
        
        public virtual bool Ignore(object value)
        {
            return value == null;
        }

        public abstract void RenameColumn(string originalName, string newName);

        public abstract string GetHumanReadable();
    }
}

using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Diagnostics.Contracts;
using System.IO;
using System.Text.RegularExpressions;
using CatalogueLibrary.Repositories;
using DataExportManager2.Interfaces.Repositories;
using DataExportManager2Library.Repositories;

namespace RDMPStartup
{
    public class ConfigFileRepositoryFinder : IRDMPPlatformRepositoryServiceLocator
    {
        private readonly LinkedRepositoryProvider _linkedRepositoryProvider;

        public CatalogueRepository CatalogueRepository
        {
            get { return _linkedRepositoryProvider.CatalogueRepository; }
        }

        public DataExportRepository DataExportRepository
        {
            get { return _linkedRepositoryProvider.DataExportRepository; }
        }
        
        private readonly string _contentsOfConfig;
        
        public ConfigFileRepositoryFinder(string configFilepath)
        {
            Contract.Requires<FileNotFoundException>(File.Exists(configFilepath));

            _contentsOfConfig = File.ReadAllText(configFilepath); 

            var catalogueConnectionString = GetValueFromAppConfigSuperAwesome("TestCatalogueConnectionString");
            var dataExportManagerConnectionString = GetValueFromAppConfigSuperAwesome("DataExportManagerConnectionString");
            
            _linkedRepositoryProvider = new LinkedRepositoryProvider(catalogueConnectionString, dataExportManagerConnectionString);
        }

        private string GetValueFromAppConfigSuperAwesome(string key)
        {
            MatchCollection matchCollection = Regex.Matches(_contentsOfConfig, "<" + key + ">(.*)</" + key + ">");

            if (matchCollection.Count != 1)
                throw new Exception("Problem with regex reading from config, unexpected number of matches:" + matchCollection.Count + " for key:" + key);

            return matchCollection[0].Groups[1].Value;
        }
    }
}

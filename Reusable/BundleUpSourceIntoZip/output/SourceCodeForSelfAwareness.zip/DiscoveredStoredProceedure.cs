namespace ReusableLibraryCode.DatabaseHelpers.Discovery // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
{
    public class DiscoveredStoredProceedure
    {
        public string Name { get; set; }

        public DiscoveredStoredProceedure(string name)
        {
            Name = name;
        }
    }
}

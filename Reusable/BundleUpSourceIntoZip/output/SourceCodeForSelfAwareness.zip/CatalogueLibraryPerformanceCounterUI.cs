using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Linq;
using System.Windows.Forms;
using CatalogueLibrary.Data;
using ReusableLibraryCode;
using ReusableLibraryCode.Performance;
using ReusableUIComponents;
using ReusableUIComponents.Performance;

namespace CatalogueManager.SimpleDialogs
{
    /// <summary>
    /// This form is mainly used for diagnostic purposes and lets you track every SQL query sent to the RDMP Data Catalogue and Data Export Manager databases.  This is useful for diagnosing
    /// the problem with sluggish user interfaces.  Once you select 'Start Command Auditting' it will record each unique SQL query sent to either database and the number of times it is sent
    /// including a StackTrace for the location in the RMDP software which the query was issued from.
    /// </summary>
    public partial class CatalogueLibraryPerformanceCounterUI : BetterToolTipForm
    {
        public CatalogueLibraryPerformanceCounterUI()
        {
            InitializeComponent();
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (DatabaseCommandHelper.PerformanceCounter == null)
                lblCommandsAudited.Text = "Commands Audited:0";
            else
            {
                int timesSeen = DatabaseCommandHelper.PerformanceCounter.DictionaryOfQueries.Seconds.Sum(s=>s.TimesSeen);

                lblCommandsAudited.Text = "Commands Audited:" + timesSeen + " (" + DatabaseCommandHelper.PerformanceCounter.DictionaryOfQueries.Firsts.Count + " distinct)";
            }
        }

        private void btnToggleCommandAuditing_Click(object sender, EventArgs e)
        {

            if(DatabaseCommandHelper.PerformanceCounter == null)
            {
                DatabaseCommandHelper.PerformanceCounter = new ComprehensiveQueryPerformanceCounter();
                btnToggleCommandAuditing.Text = "Stop Command Auditing";
                btnViewPerformanceResults.Enabled = true;
            }
            else
            {
                DatabaseCommandHelper.PerformanceCounter = null;
                btnToggleCommandAuditing.Text = "Start Command Auditing";
                btnViewPerformanceResults.Enabled = false;
            }
            

        }
        
        private void CatalogueLibraryPerformanceCounterUI_FormClosing(object sender, FormClosingEventArgs e)
        {
            //clear it before closing always
            DatabaseCommandHelper.PerformanceCounter = null;
        }

        private void btnViewPerformanceResults_Click(object sender, EventArgs e)
        {
            Form f = new Form();
            var ui = new ComprehensiveQueryPerformanceCounterUI();
            ui.Dock = DockStyle.Fill;
            
            ui.LoadState(DatabaseCommandHelper.PerformanceCounter);
            f.WindowState = FormWindowState.Maximized;
            f.Controls.Add(ui);

            this.TopMost = false;
            f.ShowDialog();
            this.TopMost = true;
        }
    }
}

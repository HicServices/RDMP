using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CatalogueLibrary.Data;
using CatalogueManager.TestsAndSetup;
using CatalogueManager.TestsAndSetup.ServicePropogation;
using ReusableUIComponents;

namespace CatalogueManager.MainFormUITabs
{
    /// <summary>
    /// Each dataset (Catalogue) is made up of 1 or more virtual columns (CatalogueItems), these are documented useful columns (or transforms) which researchers might want to do research on.
    /// You do not have to have a CatalogueItem for every single column in the underlying table (especially if the dataset is a mile wide but people only ever use 10 columns of it!).  This
    /// control lets you adjust the descriptive metadata of the datasets (Catalogue) and edit each Catalogues CatalogueItems (including descriptions).
    /// 
    /// At the very least you should ensure that every dataset (Catalogue) has a description and that all Extractable CatalogueItems (that you give to researchers) have a description too.  
    /// There is even a pie chart on the Dashboard that tells you how much of your extractable datasets/columns are undocumented!
    /// 
    /// For a list of all the Catalogue level operations you can do see CatalogueCollection.  
    /// 
    /// For a list of all the CatalogueItem level operations see CatalogueItemTab.
    /// </summary>
    public partial class CatalogueAndItemsTab : RDMPUserControl
    {
        public CatalogueAndItemsTab()
        {
            InitializeComponent();

            BetterToolTip toolTip = new BetterToolTip(this);
            toolTip.SetToolTip(catalogueCollectionHost1, ToolTips.CatalogueTabListbox, Images.CatalogueTabListbox);
            
            catalogueCollectionHost1.SelectedCatalogueChanged += catalogueCollectionHost1_SelectedCatalogueChanged;
            catalogueCollectionHost1.CollectionChanged+=(s,e)=>RefreshLists();
            

            catalogueTab1.CatalogueRenamedOrFolderChanged += RefreshLists;
        }

        void catalogueCollectionHost1_SelectedCatalogueChanged(object sender, EventArgs e)
        {
            catalogueItemTab1.Catalogue = catalogueCollectionHost1.SelectedCatalogue;
            catalogueTab1.Catalogue = catalogueCollectionHost1.SelectedCatalogue;
        }


        public void RefreshLists()
        {
            ///////////catalogues listboxes ////////////
            catalogueCollectionHost1.Collection = new ObservableCollection<Catalogue>(RepositoryLocator.CatalogueRepository.GetAllCatalogues(true));
            catalogueItemTab1.RefreshLists();
            catalogueTab1.ClearIfNoLongerExists();
        }
    }
}

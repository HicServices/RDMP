using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.ObjectModel;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using CatalogueLibrary.Data;
using CatalogueManager.TestsAndSetup;
using CatalogueManager.TestsAndSetup.ServicePropogation;
using HIC.Logging;
using MapsDirectlyToDatabaseTable.Revertable;
using ReusableUIComponents;

namespace CatalogueManager.MainFormUITabs
{
    /// <summary>
    /// Allows you to modify the descriptive data stored in the RDMP database about the selected Catalogue (dataset).  Pressing Ctrl+S will save any changes.  If you change the Folder then
    /// a reload of the CatalogueCollection tree will occur (See CatalogueCollectionHost).  You should make sure that you provide as much background about your datasets as possible since 
    /// this is the information that will be given to researchers when you extract the dataset (as well as being a great reference for when you find a dataset and your not quite sure about
    /// what it contains or how it got there or who supplied it etc).
    /// 
    /// The collection of fields for documentation were chosen by committee and based on the 'Dublin Core'.  Realistically though just banging all the information into 'Resource Description'
    /// is probably a more realistic goal.  Documentation may be boring but it is absolutely vital for handling providence of research datasets especially if you frequently get given small 
    /// datasets from researchers (e.g. questionnaire data they have collected) for use in cohort generation etc).
    /// 
    /// There is also a box for storing a ticket number, this will let you reference a ticket in your ticketing system (e.g. Jira, Fogbugz etc).  This requires selecting/writting a compatible
    /// plugin for your ticketing system and configuring it (see TicketingSystemConfigurationUI)
    /// </summary>
    public partial class CatalogueTab : RDMPUserControl
    {
        private bool _loadingUI;
        private Catalogue _catalogue;

        public event Action CatalogueRenamedOrFolderChanged = delegate { };
        private bool _nameChangedOrFolderChanged = false;

        public CatalogueTab()
        {
            InitializeComponent();

            BetterToolTip toolTip = new BetterToolTip(this);
            toolTip.SetToolTip(c_ddOverrideChildren,ToolTips.OverwriteValues ,Images.OverwriteValues);
            
            ticketingControl1.TicketTextChanged += ticketingControl1_TicketTextChanged;
        }

        public Catalogue Catalogue
        {
            get { return _catalogue; }
            set
            {
                if(value != null)
                    try
                    {
                        ticketingControl1.ReCheckTicketingSystemInCatalogue();
                    }
                    catch (Exception e)
                    {
                        ExceptionViewer.Show(e);
                    }

                _catalogue = value;
                _loadingUI = true;
                _nameChangedOrFolderChanged = false;

                if (value == null)
                {
                    c_btnSave.Enabled = false;
                    ClearFormComponents();
                    panel1.Enabled = false;
                    return;
                }

                panel1.Enabled = true;
                c_btnSave.Enabled = true;
                ticketingControl1.Enabled = true;

                c_tbID.Text = value.ID.ToString();
                ticketingControl1.TicketText = value.Ticket;
                c_tbName.Text = value.Name;
                c_tbAcronym.Text = value.Acronym;
                c_tbDescription.Text = value.Description;
                c_tbDetailPageURL.Text = value.Detail_Page_URL != null ? value.Detail_Page_URL.ToString() : "";

                c_ddType.DataSource = Enum.GetValues(typeof(Catalogue.CatalogueType));
                c_ddType.SelectedItem = value.Type;

                c_ddPeriodicity.DataSource = Enum.GetValues(typeof(Catalogue.CataloguePeriodicity));
                c_ddPeriodicity.SelectedItem = value.Periodicity;

                c_ddGranularity.DataSource = Enum.GetValues(typeof(Catalogue.CatalogueGranularity));
                c_ddGranularity.SelectedItem = value.Granularity;

                c_tbGeographicalCoverage.Text = value.Geographical_coverage;
                c_tbBackgroundSummary.Text = value.Background_summary;
                c_tbTopics.Text = value.Search_keywords;
                c_tbUpdateFrequency.Text = value.Update_freq;
                c_tbUpdateSchedule.Text = value.Update_sched;
                c_tbTimeCoverage.Text = value.Time_coverage;
                c_tbLastRevisionDate.Text = value.Last_revision_date.ToString();
                tbAdministrativeContactName.Text = value.Contact_details;
                c_tbResourceOwner.Text = value.Resource_owner;
                c_tbAttributionCitation.Text = value.Attribution_citation;
                c_tbAccessOptions.Text = value.Access_options;

                c_tbAPIAccessURL.Text = value.API_access_URL != null ? value.API_access_URL.ToString() : "";
                c_tbBrowseUrl.Text = value.Browse_URL != null ? value.Browse_URL.ToString() : "";
                c_tbBulkDownloadUrl.Text = value.Bulk_Download_URL != null ? value.Bulk_Download_URL.ToString() : "";
                c_tbQueryToolUrl.Text = value.Query_tool_URL != null ? value.Query_tool_URL.ToString() : "";
                c_tbSourceUrl.Text = value.Source_URL != null ? value.Source_URL.ToString() : "";

                tbCountryOfOrigin.Text = value.Country_of_origin ?? "";
                tbDataStandards.Text = value.Data_standards ?? "";
                tbAdministrativeContactName.Text = value.Administrative_contact_name ?? "";
                tbAdministrativeContactEmail.Text = value.Administrative_contact_email ?? "";
                tbAdministrativeContactTelephone.Text = value.Administrative_contact_telephone ?? "";
                tbAdministrativeContactAddress.Text = value.Administrative_contact_address ?? "";
                tbEthicsApprover.Text = value.Ethics_approver ?? "";
                tbSourceOfDataCollection.Text = value.Source_of_data_collection ?? "";
                c_tbSubjectNumbers.Text = value.SubjectNumbers ?? "";

                tbFolder.Text = value.Folder.Path;

                if (value.Explicit_consent == null)
                    ddExplicitConsent.Text = "";
                else if (value.Explicit_consent == true)
                    ddExplicitConsent.Text = "Yes";
                else
                    ddExplicitConsent.Text = "No";

                tbDatasetStartDate.Text = value.DatasetStartDate.ToString();

                _loadingUI = false;

            }
        }
        
        void ticketingControl1_TicketTextChanged(object sender, EventArgs e)
        {
            if (Catalogue != null)
                Catalogue.Ticket = ticketingControl1.TicketText;
        }

        private void ClearFormComponents()
        {
            _loadingUI = true;

            try
            {

                foreach (Control c in panel1.Controls)
                    if (c is TextBox)
                        c.Text = "";
                    else if (c is ComboBox)
                        c.Text = "";

                c_btnSave.Enabled = false;
            }
            finally
            {
                _loadingUI = false;
            }
        }


        
        private void btnSave_Click(object sender, EventArgs e)
        {
            if(Catalogue == null)
                return;

            Catalogue.SaveToDatabase();
            c_btnSave.Enabled = true;
            lblSaved.Text = "Saved";
            if (_nameChangedOrFolderChanged)
            {
                CatalogueRenamedOrFolderChanged();
                _nameChangedOrFolderChanged = false;
            }

        }


        private void c_ddOverrideChildren_Click(object sender, EventArgs e)
        {
            if (Catalogue != null)
                if (MessageBox.Show("Are you sure?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question,
                    MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    var catalogueItems = Catalogue.CatalogueItems.ToArray();
                    foreach (var catalogueItem in catalogueItems)
                    {
                        catalogueItem.Periodicity = Catalogue.Periodicity;
                        catalogueItem.Topic = Catalogue.Search_keywords;
                        catalogueItem.SaveToDatabase();
                    }
                }
        }

        protected override bool ProcessKeyPreview(ref Message m)
        {
            PreviewKey p = new PreviewKey(ref m, ModifierKeys);

            if (p.IsKeyDownMessage && p.e.KeyCode == Keys.S && p.e.Control)
            {
                if(Catalogue != null)
                    btnSave_Click(null, null);

                p.Trap(this);
            }

            return base.ProcessKeyPreview(ref m);
        }

        #region Getters and setters


        private void tbDetailPageURL_TextChanged(object sender, EventArgs e)
        {
            SetUriPropertyOnCatalogue((TextBox)sender, "Detail_Page_URL");
        }

        private void tbName_TextChanged(object sender, EventArgs e)
        {

            string reasonInvalid;
            if (!Catalogue.IsAcceptableName(c_tbName.Text,out reasonInvalid))
            {
                lblReasonNameIsUnacceptable.Text = reasonInvalid;
                lblReasonNameIsUnacceptable.Visible = true;
                c_tbName.ForeColor = Color.Red;
                return;
            }
            
            c_tbName.ForeColor = Color.Black;
            lblReasonNameIsUnacceptable.Visible = false;

            SetStringPropertyOnCatalogue((TextBox)sender, "Name");

            if (!_loadingUI)
                _nameChangedOrFolderChanged = true;
        }

        private void tbAcronym_TextChanged(object sender, EventArgs e)
        {
            SetStringPropertyOnCatalogue((TextBox)sender, "Acronym");
        }

        private void tbDescription_TextChanged(object sender, EventArgs e)
        {
            SetStringPropertyOnCatalogue((TextBox)sender, "Description");
        }

        private void tbCoverage_TextChanged(object sender, EventArgs e)
        {
            SetStringPropertyOnCatalogue((TextBox)sender, "Geographical_coverage");
        }

        private void tbNotes_TextChanged(object sender, EventArgs e)
        {
            SetStringPropertyOnCatalogue((TextBox)sender, "Background_summary");
        }

        private void tbTopics_TextChanged(object sender, EventArgs e)
        {
            SetStringPropertyOnCatalogue((TextBox)sender, "Search_keywords");
        }

        private void tbUpdateFrequency_TextChanged(object sender, EventArgs e)
        {
            SetStringPropertyOnCatalogue((TextBox)sender, "Update_freq");
        }

        private void tbUpdateSchedule_TextChanged(object sender, EventArgs e)
        {
            SetStringPropertyOnCatalogue((TextBox)sender, "Update_sched");
        }

        private void tbTimeCoverage_TextChanged(object sender, EventArgs e)
        {
            SetStringPropertyOnCatalogue((TextBox)sender, "Time_coverage");
        }
        private void tbDataStandards_TextChanged(object sender, EventArgs e)
        {
            SetStringPropertyOnCatalogue((TextBox)sender, "Data_standards");
        }

        private void tbAdministrativeContactName_TextChanged(object sender, EventArgs e)
        {
            SetStringPropertyOnCatalogue((TextBox)sender, "Administrative_contact_name");
        }

        private void tbAdministrativeContactEmail_TextChanged(object sender, EventArgs e)
        {
            SetStringPropertyOnCatalogue((TextBox)sender, "Administrative_contact_email");
        }

        private void tbAdministrativeContactTelephone_TextChanged(object sender, EventArgs e)
        {
            SetStringPropertyOnCatalogue((TextBox)sender, "Administrative_contact_telephone");
        }

        private void tbAdministrativeContactAddress_TextChanged(object sender, EventArgs e)
        {
            SetStringPropertyOnCatalogue((TextBox)sender, "Administrative_contact_address");
        }
        private void c_tbSubjectNumbers_TextChanged(object sender, EventArgs e)
        {
            SetStringPropertyOnCatalogue((TextBox)sender, "SubjectNumbers");
        }
        private void ddExplicitConsent_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_loadingUI)
                return;

            lblSaved.Text = "";

            if (Catalogue != null)
            {
                if (ddExplicitConsent.Text.Equals("Yes"))
                    Catalogue.Explicit_consent = true;
                
                if (ddExplicitConsent.Text.Equals("No"))
                    Catalogue.Explicit_consent = false;

                if (string.IsNullOrWhiteSpace(ddExplicitConsent.Text))
                    Catalogue.Explicit_consent = null;
            }
        }

        private void tbCountryOfOrigin_TextChanged(object sender, EventArgs e)
        {
            SetStringPropertyOnCatalogue((TextBox)sender, "Country_of_origin");
        }

        private void tbEthicsApprover_TextChanged(object sender, EventArgs e)
        {
            SetStringPropertyOnCatalogue((TextBox)sender, "Ethics_approver");
        }

        private void tbSourceOfDataCollection_TextChanged(object sender, EventArgs e)
        {
            SetStringPropertyOnCatalogue((TextBox)sender, "Source_of_data_collection");
        }
        private void c_tbResourceOwner_TextChanged(object sender, EventArgs e)
        {
            SetStringPropertyOnCatalogue((TextBox)sender, "Resource_owner");
        }

        private void tbAttributionCitation_TextChanged(object sender, EventArgs e)
        {
            SetStringPropertyOnCatalogue((TextBox)sender, "Attribution_citation");
        }

        private void tbAccessOptions_TextChanged(object sender, EventArgs e)
        {
            SetStringPropertyOnCatalogue((TextBox)sender, "Access_options");
        }

        private void tbAPIAccessURL_TextChanged(object sender, EventArgs e)
        {
            SetUriPropertyOnCatalogue((TextBox)sender, "API_access_URL");
        }

        private void tbBrowseUrl_TextChanged(object sender, EventArgs e)
        {
            SetUriPropertyOnCatalogue((TextBox)sender, "Browse_URL");
        }

        private void tbBulkDownloadUrl_TextChanged(object sender, EventArgs e)
        {
            SetUriPropertyOnCatalogue((TextBox)sender, "Bulk_Download_URL");
        }

        private void tbQueryToolUrl_TextChanged(object sender, EventArgs e)
        {
            SetUriPropertyOnCatalogue((TextBox)sender, "Query_tool_URL");
        }

        private void tbSourceUrl_TextChanged(object sender, EventArgs e)
        {
            SetUriPropertyOnCatalogue((TextBox)sender, "Source_URL");
        }
        private void tbLastRevisionDate_TextChanged(object sender, EventArgs e)
        {
            if (_loadingUI)
                return;

            TextBox senderAsTextBox = (TextBox)sender;
            try
            {
                if (Catalogue != null)
                {
                    DateTime answer = DateTime.Parse(senderAsTextBox.Text);

                    Catalogue.Last_revision_date = answer;
                    senderAsTextBox.ForeColor = Color.Black;
                }
            }
            catch (FormatException)
            {
                senderAsTextBox.ForeColor = Color.Red;
            }
        }

        private void ddType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_loadingUI)
                return;
            lblSaved.Text = "";
            if (Catalogue != null)
                Catalogue.Type = (Catalogue.CatalogueType)c_ddType.SelectedItem;
        }

        private void ddPeriodicity_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_loadingUI)
                return;

            if (Catalogue != null)
                Catalogue.Periodicity = (Catalogue.CataloguePeriodicity)c_ddPeriodicity.SelectedItem;

            lblSaved.Text = "";
        }

        private void c_ddGranularity_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_loadingUI)
                return;

            if (Catalogue != null)
                Catalogue.Granularity = (Catalogue.CatalogueGranularity)c_ddGranularity.SelectedItem;

            lblSaved.Text = "";

        }
        #endregion

        private void SetUriPropertyOnCatalogue(TextBox tb, string property)
        {
            if (_loadingUI)
                return;
            lblSaved.Text = "";

            if (Catalogue != null)
            {
                try
                {
                    Uri u = new Uri(tb.Text);

                    tb.ForeColor = Color.Black;

                    PropertyInfo target = Catalogue.GetType().GetProperty(property);
                    FieldInfo targetMaxLength = Catalogue.GetType().GetField(property + "_MaxLength");

                    if (target == null || targetMaxLength == null)
                        throw new Exception("Could not find property " + property + " or it did not have a specified _MaxLength");

                    if (tb.TextLength > (int)targetMaxLength.GetValue(Catalogue))
                        throw new UriFormatException("Uri is too long to fit in database");

                    target.SetValue(Catalogue, new Uri(tb.Text), null);
                    tb.ForeColor = Color.Black;

                }
                catch (UriFormatException)
                {
                    tb.ForeColor = Color.Red;
                }
            }
        }

        private void SetStringPropertyOnCatalogue(TextBox tb, string property)
        {
            if (_loadingUI)
                return;
            SetStringProperty(tb, property, Catalogue);
        }

        private void SetStringProperty(TextBox tb, string property, object toSetOn)
        {
            if (_loadingUI)
                return;

            lblSaved.Text = "";

            if (toSetOn != null)
            {
                PropertyInfo target = toSetOn.GetType().GetProperty(property);
                FieldInfo targetMaxLength = toSetOn.GetType().GetField(property + "_MaxLength");


                if (target == null || targetMaxLength == null)
                    throw new Exception("Could not find property " + property + " or it did not have a specified _MaxLength");

                if (tb.TextLength > (int)targetMaxLength.GetValue(toSetOn))
                    tb.ForeColor = Color.Red;
                else
                {
                    target.SetValue(toSetOn, tb.Text, null);
                    tb.ForeColor = Color.Black;
                }
            }
        }

        
        private void tbDatasetStartDate_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (Catalogue == null)
                    return;

                if (string.IsNullOrWhiteSpace(tbDatasetStartDate.Text))
                {
                    Catalogue.DatasetStartDate = null;
                    return;
                }

                DateTime dateTime = DateTime.Parse(tbDatasetStartDate.Text);
                Catalogue.DatasetStartDate = dateTime;

                tbDatasetStartDate.ForeColor = Color.Black;
                
            }
            catch (Exception)
            {
                tbDatasetStartDate.ForeColor = Color.Red;
            }
        }
        
        private void tbFolder_TextChanged(object sender, EventArgs e)
        {
            try
            {
                Catalogue.Folder = new CatalogueFolder(Catalogue, tbFolder.Text);
                tbFolder.ForeColor = Color.Black;
                
                if (!_loadingUI)
                    _nameChangedOrFolderChanged = true;
            }
            catch (Exception )
            {
                tbFolder.ForeColor = Color.Red;
            }
        }

        public void ClearIfNoLongerExists()
        {
            if (Catalogue != null && Catalogue.HasLocalChanges().Evaluation == ChangeDescription.DatabaseCopyWasDeleted)
                Catalogue = null;
        }
    }
}

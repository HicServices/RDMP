using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using CatalogueLibrary.Data;
using CatalogueLibrary.PluginManagement;
using CatalogueLibrary.Reports;
using CatalogueLibrary.Repositories;
using CatalogueManager.DataLoadUIs;
using CatalogueManager.LocationsMenu;
using CatalogueManager.LocationsMenu.LocationAdjustment;
using CatalogueManager.LocationsMenu.Ticketing;
using CatalogueManager.LogViewer;
using CatalogueManager.MainFormUITabs;
using CatalogueManager.SimpleDialogs;
using CatalogueManager.SimpleDialogs.Governance;
using CatalogueManager.SimpleDialogs.Reports;
using CatalogueManager.TestsAndSetup;
using CatalogueManager.TestsAndSetup.ServicePropogation;
using DataQualityEngine;
using RDMPObjectVisualisation;
using RDMPStartup;
using ReusableLibraryCode;
using ReusableLibraryCode.Checks;
using ReusableUIComponents;
using ReusableUIComponents.ChecksUI;

namespace CatalogueManager
{
    /// <summary>
    /// Main window of the CatalogueManager application, this Form lets you view all your datasets, curate descriptive metadata, configure extractable columns, generate reports etc
    /// 
    /// On the left you can see all the datasets you have configured for use with the RDMP.  Left clicking on a datset (called a Catalogue) will show you the descriptive data you 
    /// have recorded.  Double clicking a dataset will show you the extraction logic (if any) for the dataset.  Right clicking a Catalogue will give you access to most dataset level
    /// operations (configuring loading / lookups / deleting etc).  Each Catalogue has 1 or more CatalogueItems (visible through the CatalogueItems tab), these are the columns in 
    /// the dataset that are maintained by RDMP. If you have very wide data tables with hundreds of columns you might only configure a subset of those columns (the ones most useful
    ///  to researchers) for extraction.
    /// 
    /// The TableInfo tab shows the RDMP's table reference (TableInfo), this is a pointer to the specific database/tables/credentials used to access the data in the dataset at query
    /// time (e.g. when doing a project extraction).
    /// 
    /// The Top menu lets you 
    /// Locations:
    /// - Change which DataCatalogue database you are pointed at (not usually needed unless you have two different databases e.g. a Test database and a Live database)
    /// - Setup Logging / Anonymisation / Query Caching / Data Quality Engine databases
    /// - Configure a Ticketing system e.g. Jira for tracking time against tickets (you can set a ticket identifier for datasets, project extractions etc)
    /// - Perform bulk renaming operations across your entire catalogue database (useful for when someone remaps your server drives to a new letter! e.g. 'D:\Datasets\Private\' becomes 'E:\')
    /// - Refresh the window by reloading all Catalogues/TableInfos etc 
    /// 
    /// View:
    /// - View/Edit dataset loading logic
    /// - View/Edit the governance approvals your datasets have (including attachments, period covered, datasets included in approval etc)
    /// - View the Logging database contents (a relational view of all activities undertaken by all Data Analysts using the RDMP - loading, extractions, dqe runs etc).
    /// 
    /// Reports
    /// - Generate a veriety of reports that summarise the state of your datasets / governance etc
    /// 
    /// Help
    /// - View the user manual
    /// - View a technical description of each of the core objects maintained by RDMP (Catalogues, TableInfos etc) and what they mean (intended for programmers)
    /// - Generate user interface document (the document you are currently reading).
    /// </summary>
    public partial class CatalogueManagerMainForm : RDMPForm
    {
        /// <summary>
        /// used to disable change events while we are clearing form values
        /// </summary>
        public CatalogueManagerMainForm()
        {
            InitializeComponent();
            tableInfoTab1.TableListRefreshed += tableInfoTab1_TableListRefreshed;
           
            tabPane1.MouseHover += tabPane1_MouseHover;
            tabPane1.MouseLeave += tabPane1_MouseLeave;
        }

        void tabPane1_MouseLeave(object sender, EventArgs e)
        {
            toolTips.Hide((Control)sender);
        }

        void tabPane1_MouseHover(object sender, EventArgs e)
        {
            var pos = ((Control)sender).PointToClient(Cursor.Position);

            string message = "Here there be dragons";

            TabPage cursorIsIn = null;

            for (int i = 0; i < tabPane1.TabPages.Count; i++)
                if (tabPane1.GetTabRect(i).Contains(pos))
                    cursorIsIn = tabPane1.TabPages[i];


            if (cursorIsIn == null)
                return;

            if (cursorIsIn == tpCatalogues)
                message = HelpTextConstants.CatalogueTab;
            else if (cursorIsIn == tpTableInfo)
                message = HelpTextConstants.TableInfoTab;
            
            pos = new Point(pos.X + 10,pos.Y);
            toolTips.Show(message,(Control)sender,pos);
        }

        private ToolTip toolTips = new ToolTip();

        void tableInfoTab1_TableListRefreshed(object sender, EventArgs e)
        {
            //don't cascade refresh if we are already doing a refresh all
            if (doingRefreshAllLists)
                return;

            //if associated table infos are being deleted/added then we must update everything from the top down (refreshing the cata also refreshes the cata item)
            catalogueAndItemsTab1.RefreshLists();

        }
        
        private void CatalogueManager_Load(object sender, EventArgs e)
        {
            var version = FileVersionInfo.GetVersionInfo(Assembly.GetExecutingAssembly().Location).ProductVersion;
            this.Text = "Catalogue Manager - v" + version;
            
            RefreshAllLists();
   
        }

        bool doingRefreshAllLists = false;

        private void RefreshAllLists()
        {
            try
            {
                doingRefreshAllLists = true;

                catalogueAndItemsTab1.RefreshLists();
                tableInfoTab1.RefreshList();

                SetRebuildIndexEnableability();
            }
            catch (Exception exception)
            {
                //something went wrong with the Refresh, ask if they want to see the diagnostics screen
                DiagnosticsScreen.OfferLaunchingDiagnosticsScreenOrEnvironmentExit(RepositoryLocator,this,exception);
                
                //hopefully they resolved the issue :) - load the data again - Recursion
                RefreshAllLists();
            }
            doingRefreshAllLists = false;
        }

     

        private void LaunchDatabaseSettingsChangeDialog()
        {
            var dialog = new ChoosePlatformDatabases();
            dialog.RepositoryLocator = RepositoryLocator;
            dialog.ShowDialog(this);
        }

        private void changeCatalogueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LaunchDatabaseSettingsChangeDialog();
            RefreshAllLists();
        }

        private void refreshToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RefreshAllLists();
        }
        
        
        private void databaseAccessComplexToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ConfigureAccessRightsReport dialog = new ConfigureAccessRightsReport();
            dialog.Show();
        }


        private void issueReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var generator = new CatalogueItemIssueReportGenerator(RepositoryLocator.CatalogueRepository);
            if (generator.RequirementsMet())
                generator.GenerateReport();
            else
                MessageBox.Show(generator.RequirementsDescription());
        }

        private void metadataReportToolStripMenuItem_Click(object sender, EventArgs e)
        {

            RequiresMicrosoftOffice requirement = new RequiresMicrosoftOffice();

            if (requirement.RequirementsMet())
            {
                ConfigureMetadataReport dialog = new ConfigureMetadataReport();
                dialog.RepositoryLocator = RepositoryLocator;
                dialog.Show();    
            }
            else
                MessageBox.Show(requirement.RequirementsDescription());

        }
        private void configureExternalServersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var manageExternalServers = new ManageExternalServers();
            manageExternalServers.RepositoryLocator = RepositoryLocator;
            manageExternalServers.ShowDialog(this);
        }

        private void launchDiagnosticsScreen_Click(object sender, EventArgs e)
        {
            DiagnosticsScreen dialog = new DiagnosticsScreen(null);
            dialog.RepositoryLocator = RepositoryLocator;
            dialog.ShowDialog();

            if(dialog.ShouldReloadCatalogues)
                RefreshAllLists();
        }

        private void showPerformanceCounterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new CatalogueLibraryPerformanceCounterUI().Show();
        }

        private void clearAllAutocompleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RecentHistoryOfControls.GetInstance().Clear();
        }

        private void openExeDirectoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                Process.Start(Environment.CurrentDirectory);
            }
            catch (Exception exception)
            {
                ExceptionViewer.Show(exception);
            }
        }

        private void setTicketingSystemToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TicketingSystemConfigurationUI ui = new TicketingSystemConfigurationUI();
            ui.RepositoryLocator = RepositoryLocator;
            ui.ShowDialog();

            catalogueAndItemsTab1.RefreshLists();
        }

        private void tpCatalogues_Leave(object sender, EventArgs e)
        {
            catalogueAndItemsTab1.catalogueCollectionHost1.CatalogueCollection.AllowUserToSaveChanges();
        }

        private void loadMetadataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LoadMetadataUI dialog = new LoadMetadataUI(null);
            dialog.RepositoryLocator = RepositoryLocator;
            dialog.ShowDialog();
        }

        private void governanceManagementToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GovernanceUI dialog = new GovernanceUI();
            dialog.RepositoryLocator = RepositoryLocator;
            dialog.ShowDialog();
        }

        private void governanceReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var generator = new GovernanceReport(new DatasetTimespanCalculator(), RepositoryLocator.CatalogueRepository);

            if (generator.RequirementsMet())
                generator.GenerateReport();
            else
                MessageBox.Show(generator.RequirementsDescription());
        }

        

        private void generateTestDataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UserExercisesUI ui = new UserExercisesUI();
            ui.ShowDialog();
        }

        private void logViewerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var servers = RepositoryLocator.CatalogueRepository.GetAllObjects<ExternalDatabaseServer>().ToArray();

            SelectIMapsDirectlyToDatabaseTableDialog dialog = new SelectIMapsDirectlyToDatabaseTableDialog(servers,false,false);
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                LogViewerForm form = new LogViewerForm((ExternalDatabaseServer)dialog.Selected);
                form.Show();
            }
        }

        private void SetRebuildIndexEnableability()
        {
            mi_CatalogueDatabaseIndexRebuild.Enabled = RepositoryLocator.CatalogueRepository != null;
            mi_DataExportDatabaseIndexRebuild.Enabled = RepositoryLocator.DataExportRepository != null;
        }
        
        private void mi_RebuildIndex_Click(object sender, EventArgs e)
        {
            SqlConnection con;
            if (sender == mi_CatalogueDatabaseIndexRebuild)
                con = (SqlConnection)RepositoryLocator.CatalogueRepository.GetConnection().Connection;
            else if (sender == mi_DataExportDatabaseIndexRebuild)
                con = (SqlConnection)RepositoryLocator.DataExportRepository.GetConnection().Connection;
            else
                throw new ArgumentException();
            
            SMOIndexRebuilder rebuilder = new SMOIndexRebuilder();

            using (con)
            {
                con.Open();
                rebuilder.RebuildIndexes(con, new PopupChecksUI("Rebuild Indexes", false));
            }
        }

        private void serverSpecReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var dialog = new DatabaseSizeReportUI();
            dialog.RepositoryLocator = RepositoryLocator;
            dialog.Show();
        }

        private void adjustFileLocationsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LocationsAdjuster  adjuster = new LocationsAdjuster();
            adjuster.RepositoryLocator = RepositoryLocator;
            adjuster.ShowDialog(this);
        }

        private void dITAExtractionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form f = new Form();
            f.Text = "DITA Extraction of Catalogue Metadata";
            DitaExtractorUI d = new DitaExtractorUI();
            f.Width = d.Width + 10;
            f.Height = d.Height + 50;
            f.Controls.Add(d);
            f.Show();
        }

        private void uploadPluginToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var ofd = new OpenFileDialog
            {
                CheckFileExists = true,
                Filter = @"Plugin files (*.zip)|*.zip|Dll Files (*.dll)|*.dll",
                Multiselect = true
            };

            if (ofd.ShowDialog() != DialogResult.OK) return;

            // Upload dlls
            var dlls = ofd.FileNames.Where(f => Path.GetExtension(f) == ".dll").ToArray();
            var popup = new PopupChecksUI("Uploading dlls...", false);
            foreach (string file in dlls)
            {
                try
                {
                    new LoadModuleAssembly(RepositoryLocator.CatalogueRepository, new FileInfo(file), true);
                    popup.OnCheckPerformed(new CheckEventArgs("Committed file " + file, CheckResult.Success));
                }
                catch (Exception exception)
                {
                    popup.OnCheckPerformed(new CheckEventArgs("Failed to upload " + file, CheckResult.Fail, exception));
                }
            }

            popup.OnCheckPerformed(new CheckEventArgs("Finished committing dlls, reloading MEF plugins...",CheckResult.Success));

            // Install plugins
            var plugins = ofd.FileNames.Where(f => Path.GetExtension(f) == ".zip").ToList();
            popup.OnCheckPerformed(new CheckEventArgs("Installing plugins...", CheckResult.Success));
            var pluginProcessor = new PluginProcessor(popup, RepositoryLocator.CatalogueRepository);

            var numFailures = 0;
            foreach (var plugin in plugins)
            {
                try
                {
                    pluginProcessor.ProcessFile(new FileInfo(plugin));
                }
                catch (Exception ex)
                {
                    ++numFailures;
                    popup.OnCheckPerformed(new CheckEventArgs("Failed to process plugin: " + plugin, CheckResult.Fail, ex));
                }
            }

            var repo = RepositoryLocator.CatalogueRepository;
            // Only reload MEF if at least one plugin installed successfully
            // todo: this could be made more efficient by only reloading the new plugin-related assemblies
            if (numFailures < plugins.Count || (plugins.Count == 0 && dlls.Any()))
                repo.MEF.ReloadMEFImmediately(new LoadModuleAssemblyLoadingUI(repo));
            
            popup.OnCheckPerformed(new CheckEventArgs("All Checks Complete", CheckResult.Success));
        }

        private void userManualToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                var req = new RequiresMicrosoftOffice();

                if (!req.RequirementsMet())
                {
                    MessageBox.Show(req.RequirementsDescription());
                    return;
                }

                FileInfo f = UsefulStuff.SprayFile(GetType().Assembly, "CatalogueManager.UserManual.docx", "UserManual.docx");
                Process.Start(f.FullName);
            }
            catch (Exception exception)
            {
                ExceptionViewer.Show(exception);
            }
        }

        private void generateClassTableSummaryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var report = new DocumentationReportMapsDirectlyToDatabaseOfficeBit();

            if (!report.RequirementsMet())
            {
                MessageBox.Show(report.RequirementsDescription());
                return;
            }

            report.GenerateReport(new PopupChecksUI("Generating class summaries",false));
        }

        private void generateUserInterfaceDocumentationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var generator = new DocumentationReportFormsAndControlsUI();
            generator.RepositoryLocator = RepositoryLocator;
            generator.Show();
        }

        
    }

}

using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Data.Common;
using System.Text.RegularExpressions;
using MapsDirectlyToDatabaseTable;
using ReusableLibraryCode;

namespace CatalogueLibrary.Data
{
    /// <summary>
    /// A lightweight record of a problem you have encountered with a specific column/transform in a dataset.  Must be tied to a CatalogueItem 
    /// which is the column as it is made available to researchers.  Note that depending on settings these Issues may be written out by DataExportManager
    /// into the metadata report so be careful what you write in the name/description fields - i.e. don't put in sensitive information that could upset 
    /// governancers.
    /// 
    /// Note also the Ticket property, this lets you use your own agencies Ticketing system (e.g. JIRA) to track time/descriptions whilst also making the 
    /// RDMP aware of the issues.  See TicketingSystemConfiguration for how to setup a ticketing system plugin for your RDMP deployment.
    /// </summary>
    public class CatalogueItemIssue : VersionedDatabaseEntity
    {
        private string _description;

        #region Properties
        [DoNotExtractProperty]
        public int CatalogueItem_ID { get; set; }

        public string Name { get; set; }

        public string Description
        {
            get { return _description; }
            set
            {

                if(value != null)
                {
                    Regex regCHI = new Regex(@"\b[0-9]{10}\b");
                    Regex regPROCHI = new Regex(@"\b[a-zA-Z]{3}[0-9]{7}\b");

                    if(regCHI.IsMatch(value))
                        throw new ArgumentException("CHI numbers should not appear in issue descriptions (Issue ID=" + ID + ")" );

                    if (regPROCHI.IsMatch(value))
                        throw new ArgumentException("PROCHI numbers should not appear in issue descriptions (Issue ID=" + ID + ")");
                        
                }

                _description = value; 
                
            }
        }


        [DoNotExtractProperty]
        public string Action { get; set; }
        public string NotesToResearcher { get; set; }
        

        //do not remove this attribute because SQL often contains ANOCHI or PROCHIs
        [DoNotExtractProperty]
        public string SQL { get; set; }

        [DoNotExtractProperty]
        public string Ticket { get; set; }


        [DoNotExtractProperty]
        public IssueStatus Status { get; set; }


        [DoNotExtractProperty]
        public DateTime DateCreated { get; set; }
        public DateTime? DateOfLastStatusChange { get; set; }

        [DoNotExtractProperty]
        public string UserWhoCreated { get; set; }

        [DoNotExtractProperty]
        public string UserWhoLastChangedStatus { get; set;}

        public IssueSeverity Severity { get; set; }

        [DoNotExtractProperty]
        public int? ReportedBy_ID { get; set; }
        [DoNotExtractProperty]
        public DateTime? ReportedOnDate { get; set; }

        [DoNotExtractProperty]
        public int? Owner_ID { get; set; }
      
        [DoNotExtractProperty]
        [AdjustableLocation]
        public string PathToExcelSheetWithAdditionalInformation { get; set; }

        #endregion

        #region Relationships
        [NoMappingToDatabase]
        public CatalogueItem CatalogueItem
        {
            get
            {
                return Repository.GetObjectByID<CatalogueItem>(CatalogueItem_ID);
            }
        }
        [NoMappingToDatabase]
        public IssueSystemUser ReportedBy {
            get { return ReportedBy_ID == null? null: Repository.GetObjectByID<IssueSystemUser>((int) ReportedBy_ID); }
        }

        [NoMappingToDatabase]
        public IssueSystemUser Owner {
            get { return Owner_ID == null ? null : Repository.GetObjectByID<IssueSystemUser>((int) Owner_ID); }
        }
        #endregion

        public CatalogueItemIssue(IRepository repository, CatalogueItem item)
        {
            repository.InsertAndHydrate(this,new Dictionary<string, object>
            {
                {"CatalogueItem_ID", item.ID},
                {"Status", IssueStatus.Outstanding},
                {"Name", "NewIssue" + Guid.NewGuid()},
                {"UserWhoCreated", Environment.UserName}
            });
        }

        public CatalogueItemIssue(IRepository repository,DbDataReader r) : base(repository,r)
        {
            CatalogueItem_ID = int.Parse(r["CatalogueItem_ID"].ToString());
            Name = r["Name"] as string;
            Description = r["Description"] as string;
            Action = r["Action"] as string;
            NotesToResearcher = r["NotesToResearcher"] as string;

            SQL = r["SQL"] as string;
            Ticket = r["Ticket"] as string;

            DateCreated = DateTime.Parse(r["DateCreated"].ToString());

            if(r["DateOfLastStatusChange"] != DBNull.Value)
                DateOfLastStatusChange = DateTime.Parse(r["DateOfLastStatusChange"].ToString());

            if (r["ReportedBy_ID"] != DBNull.Value)
                ReportedBy_ID = int.Parse(r["ReportedBy_ID"].ToString());

            if (r["Owner_ID"] != DBNull.Value)
                Owner_ID = int.Parse(r["Owner_ID"].ToString());

            if (r["ReportedOnDate"] != DBNull.Value)
                ReportedOnDate = DateTime.Parse(r["ReportedOnDate"].ToString());

            UserWhoCreated = r["UserWhoCreated"] as string;
            UserWhoLastChangedStatus = r["UserWhoLastChangedStatus"] as string;

            IssueStatus status;

            if(!Enum.TryParse(r["Status"].ToString(), out status))
                throw new Exception("Did not recognise status \""+r["Status"]+"\"");

            Status = status;
            IssueSeverity severity;

            if (!Enum.TryParse(r["Severity"].ToString(), out severity))
                throw new Exception("Did not recognise IssueSeverity \"" + r["Severity"] + "\"");
            else
                Severity = severity;

            PathToExcelSheetWithAdditionalInformation = r["PathToExcelSheetWithAdditionalInformation"] as string;
        }
        
        
        public string GetNameIncludingTicketIfExists()
        {

            string issueBit =
                "(" +
                (string.IsNullOrWhiteSpace(Ticket) ? "No JIRA Ticket" : Ticket)
                +
                " ID=" + ID
                 + ")";
           return Name + issueBit;
        }

        public string GetReportedByName()
        {
            if (this.ReportedBy_ID == null)
                return "Unknown";

            return ReportedBy.Name;
        }

        public string GetOwnerByName()
        {
            if (this.Owner_ID == null)
                return "Unknown";

            return Owner.Name;
        }

        
    }

    public enum IssueSeverity
    {
        Red,
        Amber,
        Green
    }

    public enum IssueStatus
    {
        Outstanding,
        InDevelopment,
        Blocked,
        Resolved
    }
}

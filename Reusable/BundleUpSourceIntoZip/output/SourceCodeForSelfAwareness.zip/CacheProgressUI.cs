using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using CatalogueLibrary;
using CatalogueLibrary.Data;
using CatalogueLibrary.Data.Cache;
using CatalogueLibrary.Data.Cache.FetchRequestProvider;
using CatalogueLibrary.Data.Pipelines;
using CatalogueLibrary.DataFlowPipeline;
using CatalogueLibrary.DataFlowPipeline.Requirements;
using CatalogueLibrary.Repositories;
using CatalogueManager.SimpleDialogs.SimpleFileImporting;
using CatalogueManager.TestsAndSetup.ServicePropogation;
using ReusableLibraryCode;
using ReusableUIComponents;

namespace CatalogueManager.DataLoadUIs
{
    public partial class CacheProgressUI : RDMPUserControl
    {
        public ICacheProgress CacheProgress { get; private set; }

        public CacheProgressUI()
        {
            InitializeComponent();
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            RefreshUIFromDatabase();
            if (CacheProgress != null)
                SetCacheProgress(CacheProgress);
        }

        private void RefreshUIFromDatabase()
        {
            ddCacheLagDurationType.DataSource = Enum.GetValues(typeof(CacheLagPeriod.PeriodType));
            ddPermissionWindow.DataSource = RepositoryLocator.CatalogueRepository.GetAllObjects<PermissionWindow>().ToList();

            var problemsDuringLoad = FormsHelper.SetupAutoCompleteForTypes(cbPipelineContext, RepositoryLocator.CatalogueRepository.MEF.GetTypes<IDataFlowContextProvider>());
            if (problemsDuringLoad.Any())
                MessageBox.Show(problemsDuringLoad.Aggregate("Problems loading IDataFlowContextProvider types for Pipeline Context Field dropdown:" + Environment.NewLine, (s, n) => s + Environment.NewLine + ExceptionHelper.ExceptionToListOfInnerMessages(n)));
        }

        public void SetCacheProgress(ICacheProgress cacheProgress)
        {
            CacheProgress = cacheProgress;

            if (CacheProgress == null)
                ClearCacheProgressPanel();
            else
                PopulateCacheProgressPanel(CacheProgress);
        }

        private void PopulateCacheProgressPanel(ICacheProgress cacheProgress)
        {
            tbCacheProgressID.Text = cacheProgress.ID.ToString();
            tbCacheProgress.Text = cacheProgress.CacheFillProgress.HasValue ? cacheProgress.CacheFillProgress.ToString() : "Caching not started";

            var pipelineContextClass = cacheProgress.PipelineContextField.Remove(cacheProgress.PipelineContextField.Length - ".Context".Length);
            cbPipelineContext.SelectedIndex = cbPipelineContext.FindStringExact(pipelineContextClass);
            UpdateCacheLagPeriodControl();

            tbChunkPeriod.Text = cacheProgress.ChunkPeriod.ToString();

            if (cacheProgress.PermissionWindow_ID.HasValue)
                ddPermissionWindow.SelectedItem = ddPermissionWindow.Items.Cast<IPermissionWindow>().First(window => window.ID == cacheProgress.PermissionWindow_ID);

            cbPermissionWindowRequired.Checked = cacheProgress.PermissionWindow_ID.HasValue;
        }

        private void ClearCacheProgressPanel()
        {
            tbCacheProgressID.Text = "";
        }

        private void UpdateCacheLagPeriodControl()
        {
            if (CacheProgress == null)
                return;

            var cacheLagPeriod = CacheProgress.GetCacheLagPeriod();
            if (cacheLagPeriod == null)
            {
                udCacheLagDuration.Value = 0;
                ddCacheLagDurationType.SelectedItem = CacheLagPeriod.PeriodType.Day;
            }
            else
            {
                udCacheLagDuration.Value = cacheLagPeriod.Duration;
                ddCacheLagDurationType.SelectedItem = cacheLagPeriod.Type;
            }
        }

        private void btnConfigureCachingPipeline_Click(object sender, EventArgs e)
        {
            // Associate a new caching pipeline on-the-fly
            // todo: saving a new entity in the database at this point goes a bit against the law of least astonishment, this is just for testing purposes for now
            Pipeline pipeline;
            if (CacheProgress.Pipeline_ID == null)
            {
                pipeline = new Pipeline(CacheProgress.Repository,"CachingPipeline_" + Guid.NewGuid());
                CacheProgress.Pipeline_ID = pipeline.ID;
                CacheProgress.SaveToDatabase();
            }
            else
                pipeline = CacheProgress.Pipeline;

            var mef = ((CatalogueRepository) pipeline.Repository).MEF;
            
            //var engine = engineFactory.Create(cacheProgress, new ToConsoleDataLoadEventReciever());
            var contextFactory = new ContextFactory(mef);
            var context = contextFactory.CreateObject(CacheProgress.PipelineContextField);

            var uiFactory = new ConfigurePipelineUIFactory(mef, RepositoryLocator.CatalogueRepository);
            var form = uiFactory.Create(context.GetType().GenericTypeArguments[0].FullName, pipeline, null, null, context, 
                new List<object>
                {
                    new CacheFetchRequestProvider(new CacheFetchRequest(pipeline.Repository,DateTime.Now)),
                    CacheProgress.GetPermissionWindow() ?? new PermissionWindow(),
                    new HICProjectDirectory(CacheProgress.GetLoadProgress().GetLoadMetadata().LocationOfFlatFiles, false)
                });

            form.ShowDialog();
        }

        private void btnAddNewPermissionWindow_Click(object sender, EventArgs e)
        {
            var permissionWindow = new PermissionWindow(CacheProgress.Repository);
            var form = new PermissionWindowUI();
            form.SetPermissionWindow(permissionWindow);

            if (form.ShowDialog() != DialogResult.OK)
                permissionWindow.DeleteInDatabase();
            else
            {
                
                // refresh the dropdown
                ddPermissionWindow.DataSource = CacheProgress.Repository.GetAllObjects<PermissionWindow>().ToList();

                // select the new permission window entry in the dropdown
                ddPermissionWindow.SelectedItem = ddPermissionWindow;

                CacheProgress.PermissionWindow_ID = permissionWindow.ID;
                CacheProgress.SaveToDatabase();
            }
        }

        private void btnEditPermissionWindow_Click(object sender, EventArgs e)
        {
            var form = new PermissionWindowUI();
            form.SetPermissionWindow(ddPermissionWindow.SelectedItem as IPermissionWindow);
            form.ShowDialog();
        }

        private void cbPermissionWindowRequired_CheckedChanged(object sender, EventArgs e)
        {
            EnablePermissionWindowUI(cbPermissionWindowRequired.Checked);

            if (cbPermissionWindowRequired.Checked)
            {
                var permissionWindow = ddPermissionWindow.SelectedItem as IPermissionWindow;
                if (permissionWindow != null)
                    CacheProgress.PermissionWindow_ID = permissionWindow.ID;
            }
            else
                CacheProgress.PermissionWindow_ID = null;
        }

        private void EnablePermissionWindowUI(bool enabled)
        {
            ddPermissionWindow.Enabled = enabled;
            btnAddNewPermissionWindow.Enabled = enabled;
            btnEditPermissionWindow.Enabled = enabled;
        }

        private void ddPermissionWindow_SelectedIndexChanged(object sender, EventArgs e)
        {
            var permissionWindow = ddPermissionWindow.SelectedItem as IPermissionWindow;
            if (permissionWindow == null)
                throw new Exception("Invalid PermissionWindow object in the permission window drop-down field");

            CacheProgress.PermissionWindow_ID = permissionWindow.ID;
        }

        private void udCacheLagDuration_ValueChanged(object sender, EventArgs e)
        {
            CacheProgress.SetCacheLagPeriod(CreateNewCacheLagPeriod());
        }

        private void ddCacheLagDurationType_SelectedIndexChanged(object sender, EventArgs e)
        {
            CacheProgress.SetCacheLagPeriod(CreateNewCacheLagPeriod());
        }

        // Returns null if there is no duration, otherwise picks up the current state of both Duration and Type UI elements
        private CacheLagPeriod CreateNewCacheLagPeriod()
        {
            var duration = Convert.ToInt32(udCacheLagDuration.Value);
            CacheLagPeriod cacheLagPeriod = null;

            if (duration != 0 && (ddCacheLagDurationType.SelectedItem != null))
                cacheLagPeriod = new CacheLagPeriod(duration, (CacheLagPeriod.PeriodType)ddCacheLagDurationType.SelectedItem);

            return cacheLagPeriod;
        }

        private void cbPipelineContext_SelectedIndexChanged(object sender, EventArgs e)
        {
            CacheProgress.PipelineContextField = cbPipelineContext.SelectedItem + ".Context";
        }
    }
}

using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using BrightIdeasSoftware;
using CatalogueLibrary.Data;
using CatalogueLibrary.Data.Aggregation;
using CatalogueLibrary.Data.Cohort;
using CatalogueLibrary.Repositories;
using CatalogueManager.AggregationUIs;
using CohortManagerLibrary;
using CohortManagerLibrary.Execution;
using MapsDirectlyToDatabaseTable;
using QueryCaching.Aggregation;
using ReusableUIComponents;

namespace CohortManager.SubComponents
{

    /// <summary>
    /// Cohort identification in the RDMP is done by assembling patient sets and applying set operations on these sets (See 'Cohort Generation' in UserManual.docx).  For a use case of
    /// cohort identification see CohortIdentificationConfigurationUI.
    /// 
    /// The cohort identification requirements of researchers can sometimes be very complicated and so the RDMP is designed to help you split down the requirements into manageable bite
    /// sized pieces (Sets).
    /// 
    /// Start by identifying the first dataset you will need to iterrogate (e.g. if they want to know about diabetic medications drag in 'Prescribing').  Next double click the set
    /// and configure appropriate filters (See AggregateConfigurationUI) do not change the Dimension (this should already be the patient identifier).  Finally once you have configured
    /// the correct filters you should rename your set (AggregateConfiguration) to have a name that reflects the filters (e.g. 'People who have been prescribed a diabetic medication).
    /// 
    /// Next identify the next dataset you need to interrogate (e.g. if they want to exclude patients who have a 'Biochemistry' test result of 'CREATANINE' > 100)  create this set as 
    /// you did above.  
    /// 
    /// Then set the root container to EXCEPT such that your configuration is the first set of patients excluding the second set of patinets.
    /// 
    /// There are 3 set operations:
    ///  
    /// UNION - All patients in any of the sets (e.g. patients prescribed opiates UNION patients who have attended a drug rehabilitation clinic outpatient appointment)
    /// INTERSECT - Only patients who are in all the sets (e.g. patients prescribed opiates WHO HAVE ALSO attended a drug rehabilitation clinic)
    /// EXCEPT - All patients in the first set throwing out any that are in subsequent sets (e.g. patients prescribed opiates EXCEPT those who have attended a drug rehabilitation clinic)
    /// 
    /// Once you have configured your sets / set operations click 'Start All Tasks' to launch the SQL queries in parallel to the server.  If a set or container fails you can right click
    /// it to view the SQL error message or just look at the SQL the system has generated and run that manually (e.g. in Sql Management Studio). 
    /// 
    /// Once some of your sets are executing correctly you can improve performance by caching the identifier lists 'Cache Selected' (See QueryCachingServerSelector for how this is 
    /// implemented).
    /// 
    /// You will see an Identifier Count for each set, this is the number of unique patient identifiers amongst all records returned by the query.  Selecting a set will allow you to
    /// see an extract of the rows that matched the filters (See CohortIdentificationExecutionResultsUI)
    /// 
    /// Ticking 'Include Cumulative Totals' will give you a second total for each set that is in a container with at least 1 other set, this is the number of unique identifiers after
    /// performing the set operation e.g.
    /// 
    /// Except
    /// 
    /// People in Tayside
    /// 
    /// Dead People
    /// 
    /// will give you 3 totals:
    /// 
    /// 1. Total number of people who live in Tayside
    /// 
    /// 2. Total number of people who are dead across all healthboards
    /// 
    /// 3. The number of people in set 1 that are not in set 2 (because of the EXCEPT)
    /// 
    /// 
    /// </summary>
    public partial class ConfigureCohortContainersUI : UserControl
    {
        public event EventHandler SelectionChanged;
        private CohortIdentificationConfiguration _configuration;
        private CohortAggregateContainer _root;

        private CohortCompiler Compiler = new CohortCompiler(null);
        private ExternalDatabaseServer QueryCachingServer;
        
        private bool _designMode;
        
        private ISqlParameter[] _globals;

        public EventHandler ConfigurationChanged;

        public object SelectedObject
        {
            get { return otvConfiguration.SelectedObject; }
        }

        public CohortIdentificationConfiguration Configuration
        {
            get { return _configuration; }
            set
            {
                //they changed what we are pointing at so refresh from db
                _configuration = value;

                if (value != null && value.QueryCachingServer_ID != null)
                    QueryCachingServer =
                        value.QueryCachingServer;
                else
                    QueryCachingServer = null;

                Compiler.CohortIdentificationConfiguration = value;

                RefreshUIFromDatabase();
            }
        }


        public ConfigureCohortContainersUI()
        {
            InitializeComponent();

            _designMode = LicenseManager.UsageMode == LicenseUsageMode.Designtime; //dont connect to database in design mode
                
            if(_designMode)
                return;

            RefreshUIFromDatabase();

            otvConfiguration.CanExpandGetter += CanExpandGetter;
            otvConfiguration.ChildrenGetter += ChildrenGetter;
            olvAggregate.ImageGetter += ImageGetter;

            SimpleDropSink sink1 = (SimpleDropSink)otvConfiguration.DropSink;
            sink1.AcceptExternal = true;
            sink1.CanDropBetween = true;

            //set to true to debug dragging and dropping
            lblDropTarget.Visible = false;
            lblSubIndex.Visible = false;

            refreshThreadCountPeriodically.Start();
        }

        private object ImageGetter(object rowObject)
        {
            if(rowObject is AggregationTask)
                return "aggregates.png";

            return null;
        }


        private void RefreshUIFromDatabase()
        {
            if (_designMode)
                return;
            
            Compiler.CancelAllTasks(false);

            otvConfiguration.ClearObjects();

            if (Configuration == null)
                return;

            otvConfiguration.Enabled = true;

            Configuration.CreateRootContainerIfNotExists();
            //if there is no root container,create one
            _root = Configuration.RootCohortAggregateContainer;
            _globals = Configuration.GetAllParameters();

            try
            {
                
                otvConfiguration.AddObject(Compiler.GetTask(_root, _globals));
                otvConfiguration.ExpandAll();
                
            }
            catch (Exception e)
            {
                otvConfiguration.Enabled = false;
                ExceptionViewer.Show("Failed to populate tree of Tasks",e);
                
            }

            if (ConfigurationChanged != null)
                ConfigurationChanged(this, new EventArgs());
        }

        #region children getting
        private bool CanExpandGetter(object model)
        {
            var container = model as AggregationContainerTask;
            if (container != null)//todo this gets spammed
                return container.Container.GetSubContainers().Any() || container.Container.GetAggregateConfigurations().Any();//it is a container so it can be expanded if there are any subcontainers or configurations
            
            return false;
        }
        private IEnumerable ChildrenGetter(object model)
        {
            var containerTask = model as AggregationContainerTask;
            if (containerTask != null)
            {
                //ensure we listen for state change on the root
                return containerTask.Container.GetOrderedContents().Cast<IMapsDirectlyToDatabaseTable>().Select(c => Compiler.GetTask(c, _globals)).ToArray();
            }

            return null;
        }


        #endregion

        private void btnAddContainer_Click(object sender, EventArgs e)
        {
            var selectedContainer = otvConfiguration.SelectedObject as AggregationContainerTask;
            
            var newContainer = new CohortAggregateContainer(Configuration.Repository, SetOperation.UNION);

            if (selectedContainer != null)
                selectedContainer.Container.AddChild(newContainer);
            else
                _root.AddChild(newContainer);

            RefreshUIFromDatabase();
        }

        private void otvConfiguration_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
                DeleteSelectedItem();
        }

        private void DeleteSelectedItem()
        {

            try
            {
                var containerTask = otvConfiguration.SelectedObject as AggregationContainerTask;

                if (containerTask != null)
                {
                    if (Configuration.RootCohortAggregateContainer_ID ==
                        ((IMapsDirectlyToDatabaseTable)containerTask.Container).ID)
                    {
                        MessageBox.Show("Cannot delete root container");
                        return;
                    }

                    DialogResult result =
                        MessageBox.Show("Are you sure you want to delete " + containerTask.Container + " from the database?",
                            "Delete Record",
                            MessageBoxButtons.YesNo);

                    if (result == DialogResult.Yes)
                    {
                        containerTask.Container.DeleteInDatabase();
                        RefreshUIFromDatabase();
                    }
                }

                var configurationTask = otvConfiguration.SelectedObject as AggregationTask;

                if (configurationTask != null)
                {
                    //it is likely they don't actually want to nuke the entire aggregate but instead just stop using it in this particular cohort generation activity
                    containerTask = (AggregationContainerTask)otvConfiguration.GetParent(configurationTask);
                    containerTask.Container.RemoveChild(configurationTask.Aggregate);

                    RefreshUIFromDatabase();

                }
            }
            catch (Exception ex)
            {
                ExceptionViewer.Show(ex);
            }
        }

        #region drag and drop
        private void otvConfiguration_ModelCanDrop(object sender, ModelDropEventArgs e)
        {
            e.Handled = true;
            e.Effect = DragDropEffects.None;

            lblDropTarget.Text = "Drop:" + e.TargetModel;
            lblSubIndex.Text = "Location:" + e.DropTargetLocation;

            if (e.SourceModels.Count != 1)
            {
                e.InfoMessage = "Only drag one object at once"; 
                return;
            }

            //things they are dragging
            var config = e.SourceModels[0] as AggregateConfiguration;
            var catalogue = e.SourceModels[0] as Catalogue;
            var containerTask = e.SourceModels[0] as AggregationContainerTask;

            //user is dragging a Task - make changes to the underlying entity
            if (e.SourceModels[0] is AggregationTask)
                config = ((AggregationTask) e.SourceModels[0]).Aggregate;
            
            //Thing they might be dragging onto
            var targetContainerTask = e.TargetModel as AggregationContainerTask;
            var targetAggregationTask = e.TargetModel as AggregationTask;
            
            //they are dragging a Catalogue
            if (catalogue != null)
            {
                if (targetContainerTask == null && targetAggregationTask == null)
                    e.InfoMessage = "Catalogues must be dragged onto Containers (UNION/INTERSECT/EXCEPT)";
                else
                    e.Effect = DragDropEffects.Move;
            }
            else
            //they are dragging an AggregateConfiguration
            if (config != null)
            {
                //if it is drop target of container
                if (targetContainerTask != null)
                    if (targetContainerTask.Container.GetAggregateConfigurations().Any(c => c.ID == config.ID))
                        //see if it is already in container
                        e.InfoMessage = "Container already contains a reference to this aggregate";
                    else
                        e.Effect = DragDropEffects.Move; //it can legitimately be added to this container
                else
                {
                    //thin air?
                    if(targetAggregationTask == null)
                    {
                        e.InfoMessage = "You cannot drop tasks into thin air";
                        return;
                    }

                    //drop target is another aggregate

                    //cannot drop an item onto itself!
                    if (config.ID == targetAggregationTask.Aggregate.ID)
                        return;

                    //also you cannot drop it directly ontop of an item either
                    if (e.DropTargetLocation == DropTargetLocation.Item)
                        return;

                    //they are dragging an aggrgate onto another aggregate - always allowed
                    e.Effect = DragDropEffects.Move;
                }
            }
            else
                if (containerTask != null)
                {
                    //if they are dropping a container onto another container
                    if (targetContainerTask != null)
                    {
                        if (containerTask.Container.HasChild(targetContainerTask.Container)) //
                            e.InfoMessage = "You cannot drop a container into it's child container";
                        else if (containerTask.Container.ID == targetContainerTask.Container.ID)
                            e.InfoMessage = "You cannot drop a container onto itself!";
                        else
                            e.Effect = DragDropEffects.Move;
                    }
                    else
                    {
                        //they are dropping the container onto an aggregate... right?
                        if (targetAggregationTask == null)
                        {
                            e.InfoMessage = "You cannot drop containers into thin air";
                            return;
                        }

                        //if the container is being draged onto one of it;s children then forbid it
                        if(containerTask.Container.HasChild(targetAggregationTask.Aggregate))
                            e.InfoMessage = "You cannot drop a container into one of it's children";
                        else
                            //they are trying to drop a container onto an aggregate  - means they are reordering which is permitted
                            e.Effect = DragDropEffects.Move;
                          
                    }
                }
            else
                e.InfoMessage = "Only containers and aggregates can be dropped on this control";
        }

        private void otvConfiguration_ModelDropped(object sender, ModelDropEventArgs e)
        {
            try
            {
                //////////////The thing being draggged
                //thing being dragged --AggregateConfiguration
                var config = e.SourceModels[0] as AggregateConfiguration;
                var catalogue = e.SourceModels[0] as Catalogue;
                var containerTask = e.SourceModels[0] as AggregationContainerTask;
            
                //or task version
                //user is dropping a Task - make changes to the underlying entity
                if (e.SourceModels[0] is AggregationTask)
                    config = ((AggregationTask)e.SourceModels[0]).Aggregate;

                //or container is being dragged
                if(config == null && catalogue == null && containerTask == null)
                    throw new NotSupportedException("User is dragging something that isn't a container or an aggregate?");

                //////////////The thing being Dropped onto
                //being dragged onto a configuration - for reordering
                var targetConfigTask = e.TargetModel as AggregationTask;
                //or onto a different new container
                var targetContainerTask = e.TargetModel as AggregationContainerTask;

                IOrderable orderable = (IOrderable) targetConfigTask ?? targetContainerTask;

                //drop target has to be one of these two right
                if (orderable == null)
                    return;

                //what will the new position be within the container we will put it into
                int order = orderable.Order;

                switch (e.DropTargetLocation)
                {
                    case DropTargetLocation.AboveItem:
                        order--;
                        break;
                    case DropTargetLocation.BelowItem:
                        order++;
                        break;
                    case DropTargetLocation.SubItem:
                        order++;
                        break;
                }

                //they are dragging it onto another CONFIGURATION not a container
                if (targetContainerTask == null)
                {
                    //get the container 
                    targetContainerTask = (AggregationContainerTask) otvConfiguration.GetParent(targetConfigTask);
                    
                }
                else
                {
                    //user is dropping onto a container
                    //but they are dropping it ABOVE the container (they are trying to reorder the config above the container
                    if (e.DropTargetLocation == DropTargetLocation.AboveItem)
                        //get the containers parent
                        targetContainerTask = (AggregationContainerTask) otvConfiguration.GetParent(targetContainerTask);

                    //user is dropping it below a container but that container is not expanded so actually they want to reorder it below the container
                    if (e.DropTargetLocation == DropTargetLocation.BelowItem && !otvConfiguration.IsExpanded(targetContainerTask))
                        //get the containers parent
                        targetContainerTask = (AggregationContainerTask) otvConfiguration.GetParent(targetContainerTask);
                }

                //user is dragging a catalogue
                if (catalogue != null)
                {
                    //if create an aggregate configuration for the Catalogue
                    config = Configuration.CreateNewEmptyConfigurationForCatalogue(catalogue);

                    BumpContentsToMakeRoomFor(targetContainerTask.Container, config, order, e.DropTargetLocation == DropTargetLocation.BelowItem);

                    targetContainerTask.Container.AddChild(config,order); //make it belong to container
                }
                else
                //user is dragging an aggregate configuration
                if (config != null)
                {
                    //user is dragging a aggregate within this control 
                    if(e.SourceListView == otvConfiguration)
                    {
                        //get it's current parent and remove it
                        ((AggregationContainerTask)otvConfiguration.GetParent(e.SourceModels[0])).Container.RemoveChild(config);
                    }
                    else
                    {
                        //user is dragging the aggregate from somewhere else
                        if (!Configuration.IsValidNamedConfiguration(config))
                            //if name does not match we should instead be creating and importing an adjusted clone
                            config = Configuration.CreateCloneOfConfiguration(config);
                    }

                    BumpContentsToMakeRoomFor(targetContainerTask.Container, config, order, e.DropTargetLocation == DropTargetLocation.BelowItem);

                    targetContainerTask.Container.AddChild(config,order); //make it belong to container
                }
                else
                {
                    //user is dragging a container
                    containerTask.Container.Order = order;
                    containerTask.Container.SaveToDatabase();
                
                    
                    //onto another container
                    if(targetContainerTask != null)
                    {
                        //delete all relationships to current parents
                        containerTask.Container.MakeIntoAnOrphan();

                        //bump down others
                        BumpContentsToMakeRoomFor(targetContainerTask.Container, containerTask.Container, order, e.DropTargetLocation == DropTargetLocation.BelowItem);

                        //add make it a child of the parent
                        targetContainerTask.Container.AddChild(containerTask.Container);

                    }
                
                }
            }
            catch (Exception exception)
            {
                ExceptionViewer.Show(exception);
            }
            RefreshUIFromDatabase();

        }

        private void BumpContentsToMakeRoomFor(CohortAggregateContainer container, IOrderable makeRoomFor, int order, bool incrementSubsequentElements)
        {
            if (incrementSubsequentElements)
                foreach (IOrderable orderable in container.GetOrderedContents().Where(o => o.Order >= order && !o.Equals(makeRoomFor)))
                {
                    orderable.Order++;
                    ((ISaveable)orderable).SaveToDatabase();
                }
            else
                foreach (IOrderable orderable in container.GetOrderedContents().Where(o => o.Order <= order && !o.Equals(makeRoomFor)))
                {
                    orderable.Order--;
                    ((ISaveable)orderable).SaveToDatabase();
                }
        }

        #endregion

        private void otvConfiguration_CellRightClick(object sender, CellRightClickEventArgs e)
        {
            var containerTask = e.HitTest.RowObject as AggregationContainerTask;
            var configurationTask = e.HitTest.RowObject as AggregationTask;
            ICompileable compileable = e.HitTest.RowObject as ICompileable;

            
            //create right click context menu
            var RightClickMenu = new ContextMenuStrip();

            if (containerTask != null)
            {
                var container = containerTask.Container;

                RightClickMenu.Items.Add("Set EXCEPT",null, (o, args) => { container.Operation = SetOperation.EXCEPT;container.SaveToDatabase();RefreshUIFromDatabase();});
                RightClickMenu.Items.Add("Set UNION", null, (o, args) => { container.Operation = SetOperation.UNION; container.SaveToDatabase(); RefreshUIFromDatabase(); });
                RightClickMenu.Items.Add("Set INTERSECT", null, (o, args) => { container.Operation = SetOperation.INTERSECT; container.SaveToDatabase(); RefreshUIFromDatabase(); });

                if (containerTask.State == CompilationState.Crashed)
                    RightClickMenu.Items.Add("View Crash Message", null, (o, args) => ExceptionViewer.Show(containerTask.CrashMessage));


                RightClickMenu.Items.Add("Set Order Number To", null, (o, args) => SetOrderNumberTo(containerTask));

            }

            if (configurationTask != null)
            {
                RightClickMenu.Items.Add("Edit Configuration",null, (o, args) => EditConfiguration(configurationTask));
              
                if(configurationTask.State == CompilationState.Crashed)
                    RightClickMenu.Items.Add("View Crash Message", null, (o, args) => ExceptionViewer.Show(configurationTask.CrashMessage));
              
                var cachingMenuItem = RightClickMenu.Items.Add("Save To Cache", imageList1.Images["CacheResultsIcon.png"], (o, args) =>
                {
                    //cache the task
                    RightClickMenu_SaveToCache(configurationTask);
                    //and refresh the interface
                    RefreshUIFromDatabase();
                });

                var clearCachingMenuItem = RightClickMenu.Items.Add("Clear From Cache", null, (o, args) =>
                {
                    //clear the one you right clicked
                    ClearCacheFor(configurationTask);
                    //and refresh the interface
                    RefreshUIFromDatabase();
                });


                cachingMenuItem.Enabled = 
                    QueryCachingServer != null //there must be a caching server
                    && configurationTask.State == CompilationState.Finished  //execution must have finished
                    && configurationTask.GetCachedQueryUseCount().StartsWith("0"); //it can't already be cached

                clearCachingMenuItem.Enabled = 
                    QueryCachingServer != null //there must be a caching server
                    && configurationTask.GetCachedQueryUseCount().Equals("1/1"); //it must have been cached

                RightClickMenu.Items.Add("Set Order Number To", null, (o, args) => SetOrderNumberTo(configurationTask));

                if(false)
                {
                    //todo is it different?
                    RightClickMenu.Items.Add("View Differences Vs Last Execution", imageList1.Images["Diff.png"], (o, args) => ViewCacheDifferencesInSQL(configurationTask));
                }
            }


            if (compileable != null)
            {
                var startThisTaskOnly = RightClickMenu.Items.Add("Start This Task Only", null, (o, args) => StartThisTaskOnly(compileable));

                if (compileable.State != CompilationState.NotScheduled)
                    startThisTaskOnly.Enabled = false;
            }

            
            if(RightClickMenu.Items.Count >0)
                RightClickMenu.Show(otvConfiguration,e.Location);
        }

        private void SetOrderNumberTo(AggregationContainerTask containerTask)
        {
            var dialog = new TypeNumberOrCancelDialog();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    containerTask.Container.Order = (int)dialog.ResultNumber;
                    containerTask.Container.SaveToDatabase();
                }
                catch (Exception e)
                {
                    ExceptionViewer.Show(e);
                }

                RefreshUIFromDatabase();
            }
        }

        private void SetOrderNumberTo(AggregationTask configurationTask)
        {
            var dialog = new TypeNumberOrCancelDialog();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    CohortAggregateContainer.SetOrderIfExistsFor(configurationTask.Aggregate,(int)dialog.ResultNumber);
                }
                catch (Exception e)
                {
                    ExceptionViewer.Show(e);
                }

                RefreshUIFromDatabase();
            }
        }


        private void StartThisTaskOnly(ICompileable configurationTask)
        {
            Compiler.LaunchSingleTask(configurationTask,_timeout);
        }

        private void ViewCacheDifferencesInSQL(AggregationTask configurationTask)
        {
            
        }

        private void RightClickMenu_SaveToCache(AggregationTask configurationTask)
        {
            try
            {
                CacheConfigurationResults(configurationTask);
            }
            catch (Exception exception)
            {
                ExceptionViewer.Show(exception);
            }
        }
        
        private void ClearCacheFor(AggregationTask configurationTask)
        {
            CachedAggregateConfigurationResultsManager manager = new CachedAggregateConfigurationResultsManager(QueryCachingServer);
            manager.DeleteCacheEntryIfAny(configurationTask.Aggregate,AggregateOperation.IndexedExtractionIdentifierList);
        }
        
        private void CacheConfigurationResults(AggregationTask configurationTask)
        {
            CachedAggregateConfigurationResultsManager manager = new CachedAggregateConfigurationResultsManager(QueryCachingServer);
            
            Dictionary<string,string> explicitTypingDictionary = new Dictionary<string, string>();
            
            try
            {
                ColumnInfo identifierColumnInfo = configurationTask.Aggregate.AggregateDimensions.Single().ColumnInfo;
                explicitTypingDictionary.Add(identifierColumnInfo.GetRuntimeName(),identifierColumnInfo.Data_type);
            }
            catch (Exception e)
            {
                throw new Exception("Error occurred trying to find the data type of the identifier column when attempting to submit the result data table to the cache",e);
            }

            manager.CommitResults(
                configurationTask.Aggregate,
                AggregateOperation.IndexedExtractionIdentifierList,
                Compiler.Tasks[configurationTask].CountSQL,
                Compiler.Tasks[configurationTask].Identifiers,
                explicitTypingDictionary);
        }

        private void EditConfiguration(AggregationTask aggregateTask)
        {

            try
            {
                AggregateConfigurationUI.PopupOnNewForm(aggregateTask.Aggregate);
                _configuration.EnsureNamingConvention(aggregateTask.Aggregate);
                RefreshUIFromDatabase();
            }
            catch (Exception e)
            {
                ExceptionViewer.Show(e);
            }
        }

        private void otvConfiguration_ItemActivate(object sender, EventArgs e)
        {
            //see if it is an aggregate they can edit
            var aggregateTask = otvConfiguration.SelectedObject as AggregationTask;
            
            //it is an aggregate task
            if (aggregateTask != null) 
                EditConfiguration(aggregateTask);

            var containerTask = otvConfiguration.SelectedObject as AggregationContainerTask;
            
            if(containerTask != null && containerTask.CrashMessage != null)
                ExceptionViewer.Show(containerTask.CrashMessage);   
        }


        private void otvConfiguration_SelectionChanged(object sender, EventArgs e)
        {
            UpdateRunnablesButtons();

        }

        private void UpdateRunnablesButtons()
        {
            if (Configuration == null)
                return;

            var runnables = GetSelectedRunableTasks().ToArray();
            //if user has selected at least 1 unscheduled task then we can schedule it
            btnStartSelected.Enabled = runnables.Any();
            btnStartSelected.Text = string.Format("Start Selected ({0})", runnables.Length);

            //if there is no caching 
            if (Configuration.QueryCachingServer_ID == null)
            {
                //disable the cache selected tasks button
                btnCacheSelected.Enabled = false;
                return;
            }

            //caching is supported but... are there any selected aggregates that could be cached
            var cachables = GetSelectedCachableTasks().ToArray();
            btnCacheSelected.Enabled = cachables.Any();
            btnCacheSelected.Text = string.Format("Cache Selected ({0})", cachables.Length);

            var clearables = GetCacheClearableTasks().ToArray();
            btnClearCacheForSelected.Enabled = clearables.Any();
            btnClearCacheForSelected.Text = string.Format("Clear Cache For Selected({0})", clearables.Length);
        }

        private void otvConfiguration_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (SelectionChanged != null)
                SelectionChanged(sender, e);
        }

        private IEnumerable<AggregationTask> GetSelectedCachableTasks()
        {
            return
                otvConfiguration.SelectedObjects.OfType<AggregationTask>()
                    .Where(t => t.State == CompilationState.Finished && t.IsCacheableWhenFinished());
        }
        private IEnumerable<AggregationTask> GetCacheClearableTasks()
        {
            return
                otvConfiguration.SelectedObjects.OfType<AggregationTask>()
                    .Where(t =>!t.IsCacheableWhenFinished());
        }
        private IEnumerable<ICompileable> GetSelectedRunableTasks()
        {
           return
                 otvConfiguration.SelectedObjects.Cast<ICompileable>().Where(t => t.State == CompilationState.NotScheduled);
        }
        public CohortIdentificationTaskExecution GetSelectedTaskExecutionResultsIfAny()
        {
            var task = SelectedObject as ICompileable;
            if(task != null)
                if (Compiler.Tasks.ContainsKey(task))
                    return Compiler.Tasks[task];

            return null;
        }

        public string GetSelectedTaskSQLIfAny()
        {
            var task = SelectedObject as ICompileable;
            if(task != null)
                if(Compiler.Tasks.ContainsKey(task))
                    return Compiler.Tasks[task].CountSQL;

            return null;
        }

        private int _timeout = 30;

        private void tbTimeout_TextChanged(object sender, EventArgs e)
        {
            try
            {
                _timeout = int.Parse(tbTimeout.Text);
                tbTimeout.ForeColor = Color.Black;
            }
            catch (Exception exception)
            {
                _timeout = 30;
                tbTimeout.ForeColor = Color.Red;
            }
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            Compiler.LaunchScheduledTasksAsync(_timeout);
        }


        private void btnCancel_Click(object sender, EventArgs e)
        {
            Compiler.CancelAllTasks(false);
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            Compiler.CancelAllTasks(true);
            RefreshUIFromDatabase();
        }

        private void refreshThreadCountPeriodically_Tick(object sender, EventArgs e)
        {
            UpdateRunnablesButtons();
            otvConfiguration.RebuildColumns();
            lblThreadCount.Text = "Thread Count:" + Compiler.GetAliveThreadCount();
        }
        
        private void btnCacheSelected_Click(object sender, EventArgs e)
        {
            int successes = 0;
            foreach (AggregationTask t in GetSelectedCachableTasks())
                try
                {
                    CacheConfigurationResults(t);
                    successes ++;
                }
                catch (Exception exception)
                {
                    ExceptionViewer.Show("Could not cache task "+ t,exception);
                }

            RefreshUIFromDatabase();
        }

        private void btnStartSelected_Click(object sender, EventArgs e)
        {
            foreach (ICompileable runnable in GetSelectedRunableTasks())
                Compiler.LaunchSingleTask(runnable, _timeout);
        }

        private void btnClearCacheForSelected_Click(object sender, EventArgs e)
        {
            int successes = 0;
            foreach (AggregationTask t in GetCacheClearableTasks())
                try
                {
                    ClearCacheFor(t);
                    Compiler.CancelTask(t,true);
                    successes++;
                }
                catch (Exception exception)
                {
                    ExceptionViewer.Show("Could not clear cache for task " + t, exception);
                }

            RefreshUIFromDatabase();
        }

        private void cbIncludeCumulative_CheckedChanged(object sender, EventArgs e)
        {
            Compiler.IncludeCumulativeTotals = cbIncludeCumulative.Checked;

            //if they are ticking it then reset otherwise they are unticking it so no need really to nuke everything
            if(cbIncludeCumulative.Checked)
                btnReset_Click(null,null);
        }
    }
}

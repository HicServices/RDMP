using System;

namespace LoadModules.Generic.DataFlowOperations.Aliases.Exceptions
{
    public class AliasException:Exception
    {
        public AliasException(string msg) : base(msg)
        {
            
        }
    }
}

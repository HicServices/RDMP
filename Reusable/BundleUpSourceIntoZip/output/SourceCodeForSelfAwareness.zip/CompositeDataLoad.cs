using System.Collections.Generic; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using CatalogueLibrary;
using CatalogueLibrary.Data.DataLoad;
using CatalogueLibrary.DataFlowPipeline;
using DataLoadEngine.Job;
using ReusableLibraryCode.Progress;

namespace DataLoadEngine.LoadPipeline.Components
{
    public class CompositeDataLoad : DataLoadComponent
    {
        private readonly IList<DataLoadComponent> _components = new List<DataLoadComponent>();

        public CompositeDataLoad(IList<DataLoadComponent> components)
        {
            _components = components;

        }

        public override ProcessExitCode Run(IDataLoadJob job, GracefulCancellationToken cancellationToken)
        {
            foreach (var component in _components)
            {
                var result = component.Run(job, cancellationToken);

                if (result != ProcessExitCode.Success)
                    return result;
            }

            return ProcessExitCode.Success;
        }

        public override void LoadCompletedSoDispose(ExitCodeType exitCode,IDataLoadEventListener postLoadEventListener)
        {
            foreach (var component in _components)
                component.LoadCompletedSoDispose(exitCode,postLoadEventListener);
        }

        public void DisposeAllComponentsImmediately()
        {
            DisposeImmediately = true;

            foreach (var component in _components)
                component.SetDisposeImmediately();
        }
    }
}

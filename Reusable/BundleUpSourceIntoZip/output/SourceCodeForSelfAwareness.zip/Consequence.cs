using System;
namespace HIC.Common.Validation.Constraints
{
    public enum Consequence
    {
        Missing,
        Wrong,
        InvalidatesRow
    }
}

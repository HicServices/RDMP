using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;
using MapsDirectlyToDatabaseTable;
using ReusableLibraryCode;

namespace CatalogueLibrary.Data.Cache
{
    /// <summary>
    /// Describes a failed attempt to contact a caching service including the time it occurred and any associated Exception as well as whether it has been 
    /// resolved.  Any object of type ICacheFetchRequest (with paired Exception) can be used to create a failure record.
    /// </summary>
    public class CacheFetchFailure : DatabaseEntity, ICacheFetchFailure
    {
        public int CacheProgress_ID { get; set; }
        public DateTime FetchRequestStart { get; set; }
        public DateTime FetchRequestEnd { get; set; }
        public string ExceptionText { get; set; }
        public DateTime LastAttempt { get; set; }
        public DateTime? ResolvedOn { get; set; }

        public CacheFetchFailure(IRepository repository, ICacheFetchRequest failedRequest, Exception e)
        {
            repository.InsertAndHydrate(this,new Dictionary<string, object>
            {
                {"CacheProgress_ID", failedRequest.CacheProgress.ID},
                {"FetchRequestStart", failedRequest.Start},
                {"FetchRequestEnd", failedRequest.End},
                {"ExceptionText", ExceptionHelper.ExceptionToListOfInnerMessages(e)},
                {"LastAttempt", DateTime.Now},
                {"ResolvedOn", DBNull.Value}
            });
        }

        public CacheFetchFailure(IRepository repository,DbDataReader r) : base(repository,r)
        {
            CacheProgress_ID = int.Parse(r["CacheProgress_ID"].ToString());
            FetchRequestStart = (DateTime)r["FetchRequestStart"];
            FetchRequestEnd = (DateTime)r["FetchRequestEnd"];
            ExceptionText = r["ExceptionText"].ToString();
            LastAttempt = (DateTime)r["LastAttempt"];
            ResolvedOn = ObjectToNullableDateTime(r["ResolvedOn"]);
        }


        public void Resolve()
        {
            ResolvedOn = DateTime.Now;
            SaveToDatabase();
        }
    }
}

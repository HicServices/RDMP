using System.ComponentModel; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Windows.Forms;
using DataLoadEngine.DataProvider;

namespace DatasetLoaderUI
{
    /// <summary>
    /// TECHNICAL: Base class for FileProviderConfiguration and ArchiveFileProviderConfiguration
    /// </summary>
    [TypeDescriptionProvider(typeof(AbstractControlDescriptionProvider<DataProviderConfigurationControl, UserControl>))]
    public abstract class DataProviderConfigurationControl : UserControl
    {
        public virtual IDataProvider DataProvider { get; set; }
        public string DestPath { get; set; }
    }
}

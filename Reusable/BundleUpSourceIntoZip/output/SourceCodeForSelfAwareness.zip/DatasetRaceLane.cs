using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CatalogueLibrary.Data;
using CatalogueManager.TestsAndSetup.ServicePropogation;
using DataQualityEngine.Data;
using HIC.Common.Validation.Constraints;

namespace Dashboard.Raceway
{
    /// <summary>
    /// Part of DatsetRaceway, this control shows a miniature bar chart with 1 bar per month of data held within the dataset.  Bar colour indicates the proportion of records in that month
    /// which are passing/failing validation (green = passing, red = failing).  The month axis is shared across all datasets in the DatasetRaceway meaning that you see a continuous axis
    /// that spans the whole length of time you have been holding data for in any of your datasets.  The data for this graph comes from the Data Quality Engine evaluations database so if
    /// you have never run the DQE on a given dataset it will not appear iun the DatasetRaceway.
    /// 
    /// The overall effect of this control is to allow you to rapidly identify any datasets that you host which have suddenly started failing validation, see where each dataset starts and
    /// if there are any gaps or periods of duplication (e.g. where the bars double in height for a period).
    ///  
    /// </summary>
    public partial class DatasetRaceLane : UserControl, IKnowIfImHostedByVisualStudio
    {
        private Catalogue _catalogue;
        private DataTable _periodicityTable;
        private DateTime[] _buckets;
        
        private SolidBrush[] _bucketColors;
        private float[] _bucketThicknesses;
        private Pen _dottedPen;

        public bool VisualStudioDesignMode { get; set; }

        public DatasetRaceLane()
        {
            InitializeComponent();
            _dottedPen = new Pen(Color.Black, 1);
            _dottedPen.DashStyle = DashStyle.Dot;

            VisualStudioDesignMode = (LicenseManager.UsageMode == LicenseUsageMode.Designtime);
        }

        public bool IgnoreRowCounts { get; set; }

        public void SetupForCatalogue(Catalogue catalogue, DataTable periodicityTable, DateTime[] buckets)
        {
            _catalogue = catalogue;
            _periodicityTable = periodicityTable;
            _buckets = buckets;

            if (catalogue == null)
                return;

            ComputeBucketColorsAndLineThickness(periodicityTable,buckets);
        }

        private void ComputeBucketColorsAndLineThickness(DataTable periodicityTable, DateTime[] buckets)
        {
            _bucketColors = new SolidBrush[buckets.Length];
            _bucketThicknesses = new float[buckets.Length];

            //get the maximum number of rows regardless of consequence found in any data month
            int maxRowsInAnyMonth = 0;

            foreach (DataRow dr in periodicityTable.Rows)
            {
                int rowTotal = Convert.ToInt32(dr["Correct"]);

                foreach (var consequence in Enum.GetValues(typeof (Consequence)))
                    rowTotal += Convert.ToInt32(dr[consequence.ToString()]);

                maxRowsInAnyMonth = Math.Max(maxRowsInAnyMonth, rowTotal);
            }

            for (int i = 0; i < buckets.Length; i++)
            {
                int good;
                int bad;

                //see if we have an entry for this bucket
                if (GetGoodBadCountForMonthIfExists(periodicityTable,buckets[i],out good, out bad))
                {
                    float ratioGood = (float) good/(good + bad);

                    _bucketColors[i] = new SolidBrush(Color.FromArgb((int)(255 - (ratioGood * 255)), (int)(ratioGood * 255), 0));
                    _bucketThicknesses[i] = ((float)(good + bad))/maxRowsInAnyMonth;
                }
                else
                {
                    _bucketColors[i] = new SolidBrush(Color.White);
                    _bucketThicknesses[i] = 0;
                }
            }
        }

        public static bool GetGoodBadCountForMonthIfExists(DataTable periodicityTable, DateTime dateTime, out int good, out int bad)
        {
            foreach (DataRow dr in periodicityTable.Rows)
            {
                if (Convert.ToInt32(dr["Year"]) == dateTime.Year && Convert.ToInt32(dr["Month"]) == dateTime.Month)
                {
                    good = Convert.ToInt32(dr["Correct"]);
                    bad = 0;

                    foreach (var consequence in Enum.GetValues(typeof(Consequence)))
                        bad += Convert.ToInt32(dr[consequence.ToString()]);

                    return true;
                }
            }

            good = 0;
            bad = 0;
            return false;
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            SolidBrush white = new SolidBrush(Color.FromKnownColor(KnownColor.White));
            SolidBrush black = new SolidBrush(Color.FromKnownColor(KnownColor.Black));
            e.Graphics.FillRectangle(white, e.ClipRectangle);

            if (VisualStudioDesignMode)
                return;

            float increment = (float)e.ClipRectangle.Width / _buckets.Length;

            //cannot paint this control it is crazy
            if (increment < 1)
                return;

            for (int i = 0; i < _buckets.Length; i++)
            {
                var thicknessRatio = IgnoreRowCounts ? 1 : _bucketThicknesses[i];

                //create a rectangle that reflects this far along the control
                RectangleF rect = new RectangleF(i * increment, Height - (Height * thicknessRatio), increment, Height * thicknessRatio);
                e.Graphics.FillRectangle(_bucketColors[i], rect);
            }
            
            var font = new Font(Font, FontStyle.Bold);
            var middleLineOfControlY = Height/2;
            e.Graphics.DrawString(_catalogue.Name, font, black, new Point(0, middleLineOfControlY));

            var stringBounds = e.Graphics.MeasureString(_catalogue.Name, font);
            int dottedLineStartAtX = (int)(stringBounds.Width + 5);
            int dottedLineStartAtY = (int) ((stringBounds.Height/2) + middleLineOfControlY);
            e.Graphics.DrawLine(_dottedPen, new Point(dottedLineStartAtX, dottedLineStartAtY), new Point(this.Width*2, dottedLineStartAtY));

        }

        
    }
}

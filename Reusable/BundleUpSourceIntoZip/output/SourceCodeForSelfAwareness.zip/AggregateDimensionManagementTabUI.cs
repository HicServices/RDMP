using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CatalogueLibrary.Data;
using CatalogueLibrary.Data.Aggregation;
using CatalogueLibrary.Repositories;
using MapsDirectlyToDatabaseTable;
using ReusableUIComponents;

namespace CatalogueManager.AggregationUIs
{
    /// <summary>
    /// Allows you to choose which columns will appear in your GROUP BY statement.  Each Extractable column in your Catalogue will appear under Available Dimensions for you 
    /// to choose.  Once imported a column can have it's definition changed e.g. you could wrap a date field in a function YEAR() or call an anonymisation scalar function etc.
    /// 
    /// If there are multiple tables in your dataset which are JOINed (e.g. a header table and a results table) then the QueryBuilder will attempt to figure out from your 
    /// selected columns which tables it needs to join and on what keys (based on the configurations you set up in the Catalogue Manager database).  However sometimes this
    /// is not possible or the system gets it wrong correct in which case you can override the QueryBuilders descision by Forcing it to use specific tables.  This is useful
    /// for example if the patient identifier and date are in a header table but you want a count of total Results (i.e. by left joining on the result table).
    /// </summary>
    public partial class AggregateDimensionManagementTabUI : UserControl
    {
        private AggregateConfiguration _aggregateConfiguration;
        Catalogue _catalogue;
        bool bLoading = true;

        public event Action DimensionsRefreshed = delegate { };

        public AggregateDimensionManagementTabUI()
        {
            InitializeComponent();

            aggregateDimensionUI1.Saved += (s, e) => RefreshDimensions();

            BetterToolTip toolTip = new BetterToolTip(this);
            toolTip.SetToolTip(groupBox2, ToolTips.AggregateForceJoins, Images.AggregateForceJoins);
        }

        public AggregateConfiguration AggregateConfiguration
        {
            get { return _aggregateConfiguration; }
            set{
                

                _aggregateConfiguration = value;
                
                if (value == null)
                {
                    lbAvailableExtractionInformations.Items.Clear();
                    lbSelectedDimensions.Items.Clear();

                    _catalogue = null;

                    lbSelectedTables.Items.Clear();
                    tbAutomaticJoins.Text = "";
                    lbAvailableTables.Items.Clear();
                    
                }
                else
                {
                    _catalogue = value.Catalogue;

                    try
                    {
                        RefreshDimensions();
                    }
                    catch (Exception e)
                    {
                        ExceptionViewer.Show(e);
                    }
                }
                bLoading = false;
            }
        }

        private void btnImportDimension_Click(object sender, EventArgs e)
        {
            if (AggregateConfiguration == null)
                return;

            foreach (ExtractionInformation extractionInformation in lbAvailableExtractionInformations.SelectedItems)
                AggregateConfiguration.AddDimension(extractionInformation);

            RefreshDimensions();
        }

        private void btnForceJoinOnSelectedTable_Click(object sender, EventArgs e)
        {
            var t = lbAvailableTables.SelectedItem as TableInfo;

            if (t == null)
            {
                MessageBox.Show(
                    "Select a TableInfo to FORCE JOIN on (only table infos in the extraction SQL are available for FORCE JOINs");
                return;
            }


            if (AggregateConfiguration == null)
            {
                MessageBox.Show("No AggregateConfiguration selected");
                return;
            }
            
            ((CatalogueRepository)AggregateConfiguration.Repository).AggregateForcedJoiner.CreateLinkBetween(AggregateConfiguration, t);

            RefreshDimensions();
        }

        private void RefreshDimensions()
        {
            var repository = AggregateConfiguration.Repository; 

            var selected = AggregateConfiguration.AggregateDimensions;
            var available = _catalogue.GetAllExtractionInformation(ExtractionCategory.Any);

            bool deletedOneOrMore = false;

            //make sure tostring works on all dimensions
            foreach (AggregateDimension dimension in selected)
            {
                try
                {
                    dimension.GetRuntimeName();
                }
                catch (Exception exception)
                {
                    if (
                        MessageBox.Show(
                            "Dimension with SelectSQL:" + dimension.SelectSQL + " (ID=" + dimension.ID +
                            ") is broken (Message was " + exception.Message + ").  Would you like to delete it?",
                            "Delete broken dimension?", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {

                        dimension.DeleteInDatabase();
                        deletedOneOrMore = true;
                    }
                    else
                    {
                        return;
                    }
                }
            }
            if (deletedOneOrMore)
                selected = AggregateConfiguration.AggregateDimensions;

            if (!selected.Any() && !available.Any())
                MessageBox.Show(
                    "No extraction information has been configured for any of the columns/catalogue items in this dataset.");

            lbAvailableExtractionInformations.Items.Clear();
            lbAvailableExtractionInformations.Items.AddRange(
                available.Where(a => !selected.Any(s => s.ID == a.ID)).ToArray());
                //a subtract b (by ID because not IComparible... probably)

            lbSelectedDimensions.Items.Clear();
            lbSelectedDimensions.Items.AddRange(selected.ToArray());
            
            IEnumerable<int> tableIDs = selected.Select(s => s.ColumnInfo.TableInfo_ID).Distinct();

            

            TableInfo[] tablesThatAreJoinedBecauseTheyAreInSelectedDimensions =
                repository.GetAllObjectsInIDList<TableInfo>(tableIDs).ToArray();
            
            TableInfo[] tablesThatAreAvailableToJoinTo =
                repository.GetAllObjectsInIDList<TableInfo>(available.Select(a => a.ColumnInfo.TableInfo_ID).Distinct()).ToArray();

            TableInfo[] tablesWithForcedJoins =
                AggregateConfiguration.ForcedJoins.ToArray();

            //those the user has chosen to force a join to
            lbSelectedTables.Items.Clear();
            lbSelectedTables.Items.AddRange(tablesWithForcedJoins);

            //those that are joined because they in selected dimensions
            tbAutomaticJoins.Text =
                tablesThatAreJoinedBecauseTheyAreInSelectedDimensions.Aggregate("", (s, n) => s + n.ToString() + ",")
                    .TrimEnd(',');

            //the remaining few tables that are not joined to (either because of a forced join or because of an implicit join)
            lbAvailableTables.Items.Clear();
            lbAvailableTables.Items.AddRange(
                tablesThatAreAvailableToJoinTo
                    .Except(tablesThatAreJoinedBecauseTheyAreInSelectedDimensions)
                    .Except(tablesWithForcedJoins)
                    .ToArray());

            DimensionsRefreshed();
        }

        private void lbSelectedDimensions_SelectedIndexChanged(object sender, EventArgs e)
        {
            aggregateDimensionUI1.AggregateDimension = lbSelectedDimensions.SelectedItem as AggregateDimension;
        }

        private void lbSelectedDimensions_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                AggregateDimension aggregateDimension = lbSelectedDimensions.SelectedItem as AggregateDimension;

                if (aggregateDimension != null)
                {
                    try
                    {
                        aggregateDimension.DeleteInDatabase();
                    }
                    catch (Exception exception)
                    {
                        ExceptionViewer.Show(exception);
                        return;
                    }

                    aggregateDimensionUI1.AggregateDimension = null;
                    RefreshDimensions();
                }
            }
        }

        private void lbSelectedTables_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                TableInfo t = lbSelectedTables.SelectedItem as TableInfo;

                if (t != null && AggregateConfiguration != null)
                {
                    ((CatalogueRepository)AggregateConfiguration.Repository).AggregateForcedJoiner.BreakLinkBetween(AggregateConfiguration, t);
                    RefreshDimensions();
                }
            }
        }
    }
}

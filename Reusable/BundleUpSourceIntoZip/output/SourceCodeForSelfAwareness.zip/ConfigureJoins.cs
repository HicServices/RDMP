using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Windows.Forms;
using CatalogueLibrary.Data;
using CatalogueLibrary.DataHelper;
using CatalogueLibrary.Repositories;
using ReusableUIComponents;
using ScintillaNET;

namespace CatalogueManager.ExtractionUIs
{
    /// <summary>
    /// Many researchers like flat tables they can load into SPSS or STATA or Excell and thus would prefer not to deal with multiple tables if possible.  Storing datasets as flat
    /// tables however is often suboptimal in terms of performance and storage space.  Therefore it is possible to configure a dataset (Catalogue) which includes columns from 
    /// multiple tables.  For example if you have a Header and Results table in which Header tells you when a test was done and by whome including sample volume etc and each test
    /// gives multiple results (white blood cell count, red blood cell count etc) then you will obviously want to store it as two seperate tables.
    /// 
    /// Configuring join logic in RDMP enables the QueryBuilder to write an SQL SELECT query including a LEFT JOIN / RIGHT JOIN / INNER JOIN over two or more tables.  If you don't
    /// understand what an SQL Join is then you should research this before using this window.  Unlike a Lookup (See ConfigureLookups) it doesn't really matter which table contains
    /// the ForeignKey and which contains the PrimaryKey since changing the Join direction effectively inverts this logic anyway (i.e. Header RIGHT JOIN Results is the same as Results
    /// LEFT JOIN Header).  Configuring join logic in the RDMP database does not affect your data repository in any way (i.e. it doesn't mean we will suddely start putting referrential
    /// integrity constraints into your database!).
    ///  
    /// You might wonder why you have to configure JoinInfo information into RDMP when it is possibly already implemented in your data model (e.g. with foreign key constraints).  The
    /// explicit record in the RDMP database allows you to hold corrupt/unlinkable data (which would violate a foreign key constraint) and still know that the tables must be joined. 
    /// Additionally it lets you configure joins between tables in different databases and to specify an explicit direction (LEFT / RIGHT / INNER) which is always the same when it comes
    /// time to extract your data for researchers.
    /// 
    /// If you need to join on more than 1 column then just create a JoinInfo for each pair of columns (making sure the direction - LEFT/RIGHT/INNER matches).  For example if the join is
    /// Header.LabNumber = Results.LabNumber AND Header.Hospital = Results.Hospital (because of crossover in LabNumber between hospitals) then you would configure a JoinInfo for 
    /// Header.LabNumber = Results.LabNumber and another for Header.Hospital = Results.Hospital.
    /// </summary>
    public partial class ConfigureJoins : BetterToolTipForm
    {
        private readonly ColumnInfo _foreignKeyColumn;
        private readonly CatalogueRepository _catalogueRepository;
        
        private Scintilla QueryPreview;
        

        public ConfigureJoins(ColumnInfo foreignKeyColumn)
        {
            InitializeComponent();
            
            if (foreignKeyColumn == null)
                return;

            _catalogueRepository = (CatalogueRepository)foreignKeyColumn.Repository;

            _foreignKeyColumn = foreignKeyColumn;
            tbJoinKey1.Text = foreignKeyColumn.Name;

            //add all columns in our entire database to this combo box (eek) - this is the primary key table
            cbxJoinKey2.Items.AddRange(_catalogueRepository.GetAllObjects<ColumnInfo>().ToArray());

            object[] fields = Enum.GetValues(typeof(ExtractionJoinType))
                      .Cast<object>()
                      .ToArray();

            ddLookupExtractionJoinType.Items.AddRange(fields);

            RefreshListbox();

            #region Query Editor setup
            bool designMode = (LicenseManager.UsageMode == LicenseUsageMode.Designtime);

            if (designMode) //dont add the QueryEditor if we are in design time (visual studio) because it breaks
                return;


            QueryPreview = new Scintilla();
            QueryPreview.Dock = DockStyle.Fill;
            QueryPreview.Scrolling.ScrollBars = ScrollBars.Both;
            QueryPreview.ConfigurationManager.Language = "mssql";
            QueryPreview.Margins[0].Width = 40; //allows display of line numbers
            QueryPreview.IsReadOnly = true;


            pPreview.Controls.Add(QueryPreview);

            #endregion
        }

        private void RefreshListbox()
        {
            JoinInfo toReselect = null;

            if (lbLookups.SelectedItem != null)
                toReselect = lbLookups.SelectedItem as JoinInfo;

            

            lbLookups.Items.Clear();
            lbLookups.Items.AddRange(_catalogueRepository.JoinInfoFinder.GetAllJoinInfoForColumnInfoWhereItIsAForeignKey(_foreignKeyColumn));

            if (toReselect != null)
                for (int i = 0; i < lbLookups.Items.Count; i++ )
                {
                    JoinInfo candidateForReselection = lbLookups.Items[i] as JoinInfo;

                    //ever lookup should be this column (the one being edited) as the foreign key or something has gone wrong
                    Debug.Assert(candidateForReselection.ForeignKey.ID == toReselect.ForeignKey.ID);

                    if (candidateForReselection.PrimaryKey.ID == toReselect.PrimaryKey.ID)
                        lbLookups.SelectedIndex = i;
                }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string collation = null;

            if (cbCollate_Latin1_General_BIN.Checked)
                collation = "Latin1_General_BIN";
            try
            {
                if( ddLookupExtractionJoinType.SelectedItem != null)
                    _catalogueRepository.JoinInfoFinder.AddJoinInfo(_foreignKeyColumn, cbxJoinKey2.SelectedItem as ColumnInfo, (ExtractionJoinType)ddLookupExtractionJoinType.SelectedItem, collation);
                else
                    MessageBox.Show("You must configure a Join type (for extraction operations)");

                RefreshListbox();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (lbLookups.SelectedItem is JoinInfo)
                ((JoinInfo)lbLookups.SelectedItem).DeleteInDatabase();

            RefreshListbox();
        }


        private void cbxJoinKey2_SelectedIndexChanged(object sender, EventArgs e)
        {
            GeneratePreviewFromCurrentValues();
        }
        private void cbxLookupExtractionJoinType_SelectedIndexChanged(object sender, EventArgs e)
        {
            GeneratePreviewFromCurrentValues();
        }
        private void cbCollate_Latin1_General_BIN_CheckedChanged(object sender, EventArgs e)
        {
            GeneratePreviewFromCurrentValues();
            btnSave.Enabled = true;   
        }

        private void GeneratePreviewFromCurrentValues()
        {
            string collation = null;

            if (cbCollate_Latin1_General_BIN.Checked)
                collation = "Latin1_General_BIN";

            QueryPreview.IsReadOnly = false;
            //this method handles nulls
            QueryPreview.Text =
                "SELECT " + Environment.NewLine +
                _foreignKeyColumn.Name + Environment.NewLine + 
                "FROM " + Environment.NewLine + 
                JoinHelper.GetJoinSQL(_foreignKeyColumn,
                                                  cbxJoinKey2.SelectedItem as ColumnInfo,
                                                   ddLookupExtractionJoinType.SelectedItem as ExtractionJoinType?, collation);

            QueryPreview.IsReadOnly = true;
        }

        private void lbLookups_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lbLookups.SelectedItem is JoinInfo)
            {
                cbxJoinKey2.Text = (lbLookups.SelectedItem as JoinInfo).PrimaryKey.ToString();
                ddLookupExtractionJoinType.Text = (lbLookups.SelectedItem as JoinInfo).ExtractionJoinType.ToString();
                cbCollate_Latin1_General_BIN.Checked = !string.IsNullOrWhiteSpace((lbLookups.SelectedItem as JoinInfo).Collation);
                
                btnSave.Enabled = true;
                
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            //when the user selects a value from the combo box the save button becomes turned on and the cbx populate
            //when they hit save we delete the selected lookup and reinsert it with the new values
            if (lbLookups.SelectedItem is JoinInfo)
                (lbLookups.SelectedItem as JoinInfo).DeleteInDatabase();

            //throw it back as a save
            btnAdd_Click(null, null);

            btnSave.Enabled = false; 
        }
    }
}

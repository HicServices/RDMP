using HIC.Common.Validation.Constraints; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using HIC.Common.Validation.Constraints.Primary;
using NUnit.Framework;

namespace HIC.Common.Validation.Tests.Constraints
{
    [TestFixture]
    public class ConstraintTest
    {
        [Test]
        [Ignore("Thomas, can you fix or bin please?")]
        public void Name_ComparedWithAdvertisedName_IsSame()
        {
            foreach (string s in Validator.GetPrimaryConstraintNames())
            {
                var p = (PrimaryConstraint)Validator.CreateConstraint(s,Consequence.Missing);

                Assert.IsNotNull(p);
                Assert.AreEqual(p.Name, s);
            }
        }

        [Test]
        [Ignore("Thomas, can you fix or bin please?")]
        public void ConstraintName_AfterConstraintCreation_IsSet()
        {
            foreach (string s in Validator.GetPrimaryConstraintNames())
            {
                Constraint c = Validator.CreateConstraint(s,Consequence.Missing);
                
                Assert.IsNotNull(c);
                Assert.NotNull(c.Name);
            }
        }
    }
}

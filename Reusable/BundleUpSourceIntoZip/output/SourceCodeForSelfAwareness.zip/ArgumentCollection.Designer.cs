using RDMPObjectVisualisation.DemandsInitializationUIs; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved

namespace RDMPObjectVisualisation.DemandsInitializationUIs
{
    partial class ArgumentCollection<T>
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.lbProcessTaskArguments = new System.Windows.Forms.ListBox();
            this._argumentUI1 = new ArgumentUI<T>();
            this.lblArgumentsForClass = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.lblArgumentsForClass);
            this.splitContainer1.Panel1.Controls.Add(this.btnRefresh);
            this.splitContainer1.Panel1.Controls.Add(this.lbProcessTaskArguments);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this._argumentUI1);
            this.splitContainer1.Size = new System.Drawing.Size(720, 463);
            this.splitContainer1.SplitterDistance = 225;
            this.splitContainer1.TabIndex = 8;
            // 
            // btnRefresh
            // 
            this.btnRefresh.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRefresh.Location = new System.Drawing.Point(0, 437);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(216, 23);
            this.btnRefresh.TabIndex = 2;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = true;
            // 
            // lbProcessTaskArguments
            // 
            this.lbProcessTaskArguments.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbProcessTaskArguments.FormattingEnabled = true;
            this.lbProcessTaskArguments.Location = new System.Drawing.Point(3, 31);
            this.lbProcessTaskArguments.Name = "lbProcessTaskArguments";
            this.lbProcessTaskArguments.Size = new System.Drawing.Size(220, 394);
            this.lbProcessTaskArguments.TabIndex = 0;
            this.lbProcessTaskArguments.SelectedIndexChanged += new System.EventHandler(this.lbProcessTaskArguments_SelectedIndexChanged);
            // 
            // processTaskArgumentUI1
            // 
            this._argumentUI1.Dock = System.Windows.Forms.DockStyle.Fill;
            this._argumentUI1.Location = new System.Drawing.Point(0, 0);
            this._argumentUI1.Name = "_argumentUI1";
            this._argumentUI1.Size = new System.Drawing.Size(491, 463);
            this._argumentUI1.TabIndex = 0;
            // 
            // lblArgumentsForClass
            // 
            this.lblArgumentsForClass.AutoSize = true;
            this.lblArgumentsForClass.Location = new System.Drawing.Point(3, 9);
            this.lblArgumentsForClass.Name = "lblArgumentsForClass";
            this.lblArgumentsForClass.Size = new System.Drawing.Size(106, 13);
            this.lblArgumentsForClass.TabIndex = 3;
            this.lblArgumentsForClass.Text = "Arguments For Class:";
            // 
            // ArgumentCollection
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.splitContainer1);
            this.Name = "ArgumentCollection";
            this.Size = new System.Drawing.Size(720, 463);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Label lblArgumentsForClass;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.ListBox lbProcessTaskArguments;
        private ArgumentUI<T> _argumentUI1;
    }
}

using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CatalogueLibrary.Data.Pipelines;
using CatalogueLibrary.DataFlowPipeline;
using CatalogueLibrary.DataFlowPipeline.Requirements;
using RDMPObjectVisualisation.DataObjects;

namespace RDMPObjectVisualisation.Pipelines.Models
{
    internal class AdvertisedPipelineComponentTypeUnderContext<T>
    {
        private bool _allowableUnderContext;
        private string _allowableReason;

        private readonly DataFlowComponentVisualisation.Role _role;
        private Type _componentType;

        

        public AdvertisedPipelineComponentTypeUnderContext(Type componentType, DataFlowPipelineContext<T> context)
        {
            _componentType = componentType;
            if (typeof(IDataFlowSource<T>).IsAssignableFrom(componentType))
                _role = DataFlowComponentVisualisation.Role.Source;
            else
                if (typeof(IDataFlowDestination<T>).IsAssignableFrom(componentType))
                    _role = DataFlowComponentVisualisation.Role.Destination;
                else
                    _role = DataFlowComponentVisualisation.Role.Middle;

            _allowableUnderContext = context.IsAllowable(componentType, out _allowableReason);

        }

        public Type GetComponentType()
        {
            return _componentType;
        }

        public string Namespace()
        {
            return _componentType.Namespace;
        }

        public override string ToString()
        {
            return _componentType.Name;
        }

        public DataFlowComponentVisualisation.Role GetRole()
        {
            return _role;
        }
        public string UIDescribeCompatible()
        {
            return _allowableUnderContext ? "Yes" : "No";
        }

        public bool IsCompatible()
        {
            return _allowableUnderContext;
        }

        public string GetReasonIncompatible()
        {
            return _allowableReason;
        }
    }
}

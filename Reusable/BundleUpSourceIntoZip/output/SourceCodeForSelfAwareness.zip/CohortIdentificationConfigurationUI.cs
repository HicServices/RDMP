using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows.Forms;
using CatalogueLibrary.Data;
using CatalogueLibrary.Data.Cohort;
using CatalogueManager.ExtractionUIs.FilterUIs;
using CatalogueManager.TestsAndSetup.ServicePropogation;

namespace CohortManager.SubComponents
{
    /// <summary>
    /// Allows you to view/edit a CohortIdentificationConfiguration (See CohortManagerMainForm for a description of what one of these is).  This includes giving it a sensible name
    /// e.g. 'Project 132 Cases - Deaths caused by diabetic medication' and AS FULL A DESCRIPTION AS POSSIBLE e.g. 'All patients in Tayside and Fife who are over 16 at the time of 
    /// thier first prescription of a diabetic medication (BNF chapter 6.1) and died within 6 months of the first prescribed date of the diabetic medication'.  The better the 
    /// description the more likely it is that you and the researcher will be on the same page about what you are providing.
    /// 
    /// If you have a large data repository or plan to use lots of different datasets or complex filters in your CohortIdentificationCriteria you should configure a caching database
    /// (See QueryCachingServerSelector) from the dropdown.
    /// 
    /// Next you should add datasets and set operation containers to generate your cohort by dragging datasets from the Catalogue list on the right into the ConfigureCohortContainersUI
    /// list box (See ConfigureCohortContainersUI for configuring filters on the datasets added).
    /// 
    /// In the above example you might have 
    /// 
    /// Set 1 - Prescribing
    /// 
    ///     Filter 1 - Prescription is for a diabetic medication
    /// 
    ///     Filter 2 - Prescription is the first prescription of it's type for the patient
    /// 
    ///     Filter 3 - Patient died within 6 months of prescription
    /// 
    /// INTERSECT
    /// 
    /// Set 2 - Demography
    ///     
    ///     Filter 1 - Latest known healthboard is Tayside or Fife
    /// 
    ///     Filter 2 - Date of Death - Date of Birth > 16 years
    ///  
    /// </summary>
    public partial class CohortIdentificationConfigurationUI : RDMPUserControl
    {
        private CohortIdentificationConfiguration _configuration;

        public CohortIdentificationConfigurationUI()
        {
            InitializeComponent();
            
            catalogueCollection1.CatalogueCollection.CatalogueCollectionChanged += (s, e) => RefreshUIFromDatabase();
            catalogueCollection1.CatalogueCollection.ShowAggregates = AggregatesToShow.CoreOnly; ;
            containersUI.ConfigurationChanged+= ConfigurationChanged;
            containersUI.SelectionChanged += containersUI_SelectionChanged;

            queryCachingServerSelector.SelectedServerChanged += queryCachingServerSelector_SelectedServerChanged;
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            if(VisualStudioDesignMode)
                return;

            RefreshUIFromDatabase();
        }

        void queryCachingServerSelector_SelectedServerChanged()
        {
            if (queryCachingServerSelector.SelecteExternalDatabaseServer == null)
                _configuration.QueryCachingServer_ID = null;
            else
                _configuration.QueryCachingServer_ID = queryCachingServerSelector.SelecteExternalDatabaseServer.ID;
           
            _configuration.SaveToDatabase();
            RefreshUIFromDatabase();
        }

        void containersUI_SelectionChanged(object sender, EventArgs e)
        {
            var results = containersUI.GetSelectedTaskExecutionResultsIfAny();
            cohortIdentificationExecutionResultsUI1.TaskExecution = results;

            var sql = containersUI.GetSelectedTaskSQLIfAny();
            cohortQueryBuilderUI1.SetSelectedSQL(sql);

        }
        
        public CohortIdentificationConfiguration Configuration
        {
            get { return _configuration; }
            set
            {
                queryCachingServerSelector.Enabled = value != null;
                _configuration = value;
                containersUI.Configuration = value;
                cohortQueryBuilderUI1.Configuration = value;

                tbDescription.Enabled = value != null;
                tbName.Enabled = value != null;
                tbID.Enabled = value != null;
                ticket.Enabled = value != null;
                btnConfigureGlobalParameters.Enabled = value != null;

                Enabled = value != null;

                if (value != null)
                {
                    tbDescription.Text = value.Description;
                    tbName.Text = value.Name;
                    tbID.Text = value.ID.ToString();
                    ticket.TicketText = value.Ticket;

                    if (value.QueryCachingServer_ID == null)
                        queryCachingServerSelector.SelecteExternalDatabaseServer = null;
                    else
                        queryCachingServerSelector.SelecteExternalDatabaseServer = value.QueryCachingServer;
                }
                else
                {
                    tbDescription.Text = "";
                    tbName.Text = "";
                    tbID.Text = "";
                    ticket.TicketText = "";
                }
            }
        }

        private void ConfigurationChanged(object sender, EventArgs eventArgs)
        {
            cohortQueryBuilderUI1.RefreshUIFromDatabase();
            catalogueCollection1.CatalogueCollection.RefreshFromCollection();
        }

        public void RefreshUIFromDatabase()
        {

            catalogueCollection1.Collection = new ObservableCollection<Catalogue>(RepositoryLocator.CatalogueRepository.GetAllCataloguesWithAtLeastOneExtractableItem());

            //make like we've just been opened with the same value as we had before though
            Configuration = Configuration;
        }

        public void Save()
        {
            if(Configuration != null)
                Configuration.SaveToDatabase();
        }

        private void tbDescription_TextChanged(object sender, EventArgs e)
        {
            if (Configuration != null)
                Configuration.Description = tbDescription.Text;
        }

        private void tbName_TextChanged(object sender, EventArgs e)
        {
            if (Configuration != null)
            {
                if (string.IsNullOrWhiteSpace(tbName.Text))
                {
                    tbName.Text = "No Name";
                    tbName.SelectAll();
                }

                Configuration.Name = tbName.Text;
            }
        }

        private void ticket_TicketTextChanged(object sender, EventArgs e)
        {
            if (Configuration != null)
                Configuration.Ticket = ticket.TicketText;
        }

        private void btnConfigureGlobalParameters_Click(object sender, EventArgs e)
        {
            if (Configuration != null)
            {
                ParameterCollectionUI.ShowAsDialog(Configuration);
                RefreshUIFromDatabase();
            }
            
        }

        private void cbShowProjectSpecificAggregates_CheckedChanged(object sender, EventArgs e)
        {
            if (cbShowProjectSpecificAggregates.Checked)
                catalogueCollection1.CatalogueCollection.ShowAggregates = AggregatesToShow.All;
            else
                catalogueCollection1.CatalogueCollection.ShowAggregates = AggregatesToShow.CoreOnly;
        }
    }

}

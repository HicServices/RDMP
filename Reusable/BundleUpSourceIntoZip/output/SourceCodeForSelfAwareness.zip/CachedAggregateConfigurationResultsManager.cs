using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Xml.XPath;
using CatalogueLibrary.Data;
using CatalogueLibrary.Data.Aggregation;
using QueryCaching.Database;
using ReusableLibraryCode;
using ReusableLibraryCode.DataAccess;
using ReusableLibraryCode.DatabaseHelpers.Discovery;
using ReusableLibraryCode.DataTableExtension;

namespace QueryCaching.Aggregation
{
    public class CachedAggregateConfigurationResultsManager
    {
        private readonly DiscoveredServer _server;
        private DiscoveredDatabase _database;

        public static Type DbAssembly = typeof (Class1);

        public CachedAggregateConfigurationResultsManager(IExternalDatabaseServer server)
        {
            _server = DataAccessPortal.GetInstance().ExpectServer(server, DataAccessContext.InternalDataProcessing);
            _database = DataAccessPortal.GetInstance().ExpectDatabase(server, DataAccessContext.InternalDataProcessing);
        }

        public const string CachingPrefix = "--Cached:";

        public IHasFullyQualifiedNameToo GetLatestResultsTableUnsafe(AggregateConfiguration configuration,AggregateOperation operation)
        {
            using (var con = _server.GetConnection())
            {
                con.Open();

                var r = DatabaseCommandHelper.GetCommand("Select TableName from [CachedAggregateConfigurationResults] WHERE AggregateConfiguration_ID = " + configuration.ID + " AND Operation = '" +operation + "'" , con).ExecuteReader();
                
                if (r.Read())
                {
                    string tableName =  r["TableName"].ToString();
                    return _database.ExpectTable(tableName);
                }
            }

            return null;
        }

        public IHasFullyQualifiedNameToo GetLatestResultsTable(AggregateConfiguration configuration, AggregateOperation operation, string currentSql)
        {
            using (var con = _server.GetConnection())
            {
                con.Open();

                var cmd = DatabaseCommandHelper.GetCommand("Select TableName,SqlExecuted from [CachedAggregateConfigurationResults] WHERE AggregateConfiguration_ID = " + configuration.ID + " AND Operation = '" + operation + "'", con);
                var r = cmd.ExecuteReader();

                if (r.Read())
                {
                    if (r["SqlExecuted"].Equals(currentSql.Trim()))
                    {
                        string tableName = r["TableName"].ToString();
                        return _database.ExpectTable(tableName);
                    }
                    else
                        return null;//this means that there was outdated SQL, we could show this to user at some point
                }
            }

            return null;
        }

        public void CommitResults(AggregateConfiguration configuration, AggregateOperation operation, string sql,DataTable results, Dictionary<string,string> explicitTypesDictionary)
        {

            if(results == null)
                throw new Exception("DataTable results must have a value");

            if (operation == AggregateOperation.IndexedExtractionIdentifierList)
            {
                if(results.Columns.Count != 1)
                    throw new NotSupportedException("The DataTable that you claimed was an " + operation + " did not have exactly 1 column (it had " + results.Columns.Count +" columns).");

                if (sql.Trim().StartsWith(CachingPrefix))
                    throw new NotSupportedException("Sql for the query started with '" + CachingPrefix + "' which implies you ran some SQL code to fetch some stuff from the cache and then committed it back into the cache (obliterating the record of what the originally executed query was).  This is refered to as Inception Caching and isn't allowed.  Note to developers: this happens if user caches a query then runs the query again (fetching it from the cache) and somehow tries to commit the cache fetch request back into the cache as an overwrite");
            }
            
            if(operation == AggregateOperation.ExtractableAggregateResults)
            {

                if (results.Columns.Count == 0)
                    throw new ArgumentException("The DataTable that you claimed was an " + operation + " had zero columns and therefore cannot be cached");
                
                string[] suspectDimensions =
                    configuration.AggregateDimensions
                        .Where(d => d.IsExtractionIdentifier || d.HashOnDataRelease)
                        .Select(d=>d.GetRuntimeName())
                        .ToArray();
                if (suspectDimensions.Any())
                    throw new NotSupportedException("Aggregate " + configuration +
                                                    " contains dimensions marked as IsExtractionIdentifier or HashOnDataRelease (" +
                                                    string.Join(",", suspectDimensions) +
                                                    ") so the aggregate cannot be cached.  This would/could result in private patient identifiers appearing on your website!");

                if(!configuration.IsExtractable)
                    throw new NotSupportedException("Aggregate " + configuration + " is not marked as IsExtractable therefore cannot be cached for publication on website");
            }

            DeleteCacheEntryIfAny(configuration, operation);

            using (var con = _server.GetConnection())
            {
                con.Open();
                var transaction = con.BeginTransaction();

                string nameWeWillGiveTableInCache = operation + "_AggregateConfiguration" + configuration.ID;

                //it already has a name
                if(!string.IsNullOrWhiteSpace(results.TableName))
                    //if it isn't the one we want then user has named his table something so complain
                    if (!results.TableName.Equals(nameWeWillGiveTableInCache))
                        throw new Exception("Cannot commit data table because you have given it a name (" + results.TableName +") - we want to rename it but I'm guessing you'd be surprised if it came back with a different name on it");
                    
                //either it has no name or it already has name we want so its ok
                results.TableName = nameWeWillGiveTableInCache;

                DataTableHelper helper = new DataTableHelper(results);
                string tableName;

                //add explicit types
                if(explicitTypesDictionary != null)
                    foreach (KeyValuePair<string, string> kvp in  explicitTypesDictionary)
                        helper.ExplicitWriteTypes.Add(kvp.Key, kvp.Value);
                
                helper.UploadFileToConnection(_server, con, out tableName, transaction,true,false);


                var cmdCreateNew =
                    DatabaseCommandHelper.GetCommand(
                        "INSERT INTO [CachedAggregateConfigurationResults] (Committer,AggregateConfiguration_ID,SqlExecuted,Operation,TableName) Values (@Committer,@AggregateConfiguration_ID,@SqlExecuted,@Operation,@TableName)", con,transaction);


                cmdCreateNew.Parameters.Add(DatabaseCommandHelper.GetParameter("@Committer", cmdCreateNew));
                cmdCreateNew.Parameters["@Committer"].Value = Environment.UserName;

                cmdCreateNew.Parameters.Add(DatabaseCommandHelper.GetParameter("@AggregateConfiguration_ID", cmdCreateNew));
                cmdCreateNew.Parameters["@AggregateConfiguration_ID"].Value = configuration.ID;

                cmdCreateNew.Parameters.Add(DatabaseCommandHelper.GetParameter("@SqlExecuted", cmdCreateNew));
                cmdCreateNew.Parameters["@SqlExecuted"].Value = sql.Trim();

                cmdCreateNew.Parameters.Add(DatabaseCommandHelper.GetParameter("@Operation", cmdCreateNew));
                cmdCreateNew.Parameters["@Operation"].Value = operation.ToString();

                cmdCreateNew.Parameters.Add(DatabaseCommandHelper.GetParameter("@TableName", cmdCreateNew));
                cmdCreateNew.Parameters["@TableName"].Value = tableName;

                cmdCreateNew.ExecuteNonQuery();
                
                if (operation == AggregateOperation.IndexedExtractionIdentifierList)
                {
                    //ask the helper what datatype it used for the identifier column
                    string sqlDbTypeForColumn = helper.GetTypeDictionary()[results.Columns[0]].GetSqlDBType();
                    string colName = results.Columns[0].ColumnName;

                    //if user has an explicit type to use for the column (probably a good idea to have all extraction idetntifiers of the same data type
                    if (explicitTypesDictionary != null && explicitTypesDictionary.ContainsKey(colName))
                        sqlDbTypeForColumn = explicitTypesDictionary[colName];//use that instead

                    CreateIndex(tableName,colName ,sqlDbTypeForColumn, configuration.ToString(), con, transaction);
                    
                }
             
                transaction.Commit();
            }
        }

        public void DeleteCacheEntryIfAny(AggregateConfiguration configuration, AggregateOperation operation)
        {
            var table = GetLatestResultsTableUnsafe(configuration, operation);

            if(table != null)

            using (var con = _server.GetConnection())
            {
                con.Open();

                //drop the data
                _database.ExpectTable(table.GetRuntimeName()).Drop();
                
                //delete the record!
                int deletedRows = DatabaseCommandHelper.GetCommand("DELETE FROM [CachedAggregateConfigurationResults] WHERE AggregateConfiguration_ID = "+configuration.ID+" AND Operation = '"+operation+"'", con).ExecuteNonQuery();

                if(deletedRows != 1)
                    throw new Exception("Expected exactly 1 record in CachedAggregateConfigurationResults to be deleted when erasing its record of operation " + operation + " but there were " + deletedRows +" affected records");
            }


        }

        private void CreateIndex(string tableName, string columnName,string sqlDbTypeForColumn, string configurationName, DbConnection con, DbTransaction transaction)
        {
            string notNull = "ALTER TABLE " + tableName + " ALTER COLUMN " + columnName  +" "+ sqlDbTypeForColumn + " NOT NULL";
            try
            {
                var cmdMakeNotNull = DatabaseCommandHelper.GetCommand(notNull, con, transaction);
                cmdMakeNotNull.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                throw new Exception(
                    "Failed when trying to make column " + columnName +
                    " into NotNull for AggregateConfiguration " + configurationName + ".  The SQL that failed was:" +
                    Environment.NewLine + notNull, e);
            }

            string pkCreationSql = "ALTER TABLE " + tableName + " ADD CONSTRAINT PK_" + tableName + " PRIMARY KEY CLUSTERED (" + columnName + ")";
            try
            {
                var cmdCreateIndex = DatabaseCommandHelper.GetCommand(pkCreationSql, con, transaction);
                cmdCreateIndex.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                throw new Exception("Failed to create unique primary key on the results of AggregateConfiguration " + configurationName + ".  The SQL that failed was:" + Environment.NewLine + pkCreationSql, e);
            }
        }
    }
}

using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using CatalogueLibrary;
using CatalogueLibrary.Data;
using CatalogueLibrary.Data.DataLoad;
using CatalogueLibrary.DataFlowPipeline;
using CatalogueManager.DataLoadUIs;
using CatalogueManager.LocationsMenu;
using CatalogueManager.SimpleDialogs;
using CatalogueManager.SimpleDialogs.SimpleFileImporting;
using CatalogueManager.TestsAndSetup;
using CatalogueManager.TestsAndSetup.ServicePropogation;
using DataLoadEngine.Checks;
using DataLoadEngine.DatabaseManagement.EntityNaming;
using DataLoadEngine.DataProvider;
using DataLoadEngine.Job.Scheduling;
using DataLoadEngine.LoadPipeline.Threaded;
using DataLoadEngine.LoadProcess;
using DataLoadEngine.LoadProcess.Scheduling;
using DataLoadEngine.LoadProcess.Scheduling.Strategy;
using HIC.Logging;
using ReusableLibraryCode.Progress;
using ReusableUIComponents;

namespace DatasetLoaderUI
{
    /// <summary>
    /// Main form for the Data Export Manager.  At the top fo the screen is a list of all the loads you have configured with the RDMP (See LoadMetadataUI).  Selecting a load will start
    /// 'pre execution checks' which will tick away.  You can edit a load by selecting 'View Load Metadata' (Launches LoadMetadataUI).
    /// 
    /// This user interface is intended for building and executing loads until they are stable after which you should set up periodic execution (See LoadPeriodicallyUI).
    /// 
    /// Only attempt to launch a data load if the checks are all passing (or giving Warnings that you understand and are not concerned about).  
    /// 
    /// Once started the load progress will appear on the right as data is loaded into RAW, migrated to STAGING and committed to LIVE (See  'RAW Bubble, STAGING Bubble, LIVE Model' in
    /// UserManual.docx for full implementation details).
    /// 
    /// There are various options for debugging for example you can override the location of the RAW bubble (e.g. to a test server), stop the data load after RAW is populated (in which
    /// case the load will crash out early allowing you to evaluated the RAW data in a database environment conducive with debugging dataset issues). 
    /// </summary>
    public partial class DatasetLoader : RDMPForm
    {
        private IDataLoadProcess _dataLoadProcess;
        private LoadMetadata _loadMetadata;
        private HICDatabaseConfiguration _databaseLoadConfiguration;
        private IDataProvider _dataProvider;
        
        private bool _useMultiThreadedLoad;

        private GracefulCancellationTokenSource _cancellationTokenSource;
     
        public DatasetLoader()
        {
            _cancellationTokenSource = null;

            InitializeComponent();


            
            dataLoadEntireSystemStateCheckerUI1.AllChecksComplete += delegate {EnableOnDemandLoad(); };

        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            if (VisualStudioDesignMode)
                return;

            GetAvailableLoads();

            BetterToolTip.SetToolTip(btnOneOffLoad, ToolTips.BulkInsert, Images.BulkInsert);
           
        }

        private void GetAvailableLoads()
        {
            cbxLoadMetadata.Enabled = false;
            cbxLoadMetadata.Items.Clear();

            try
            {
                cbxLoadMetadata.Items.AddRange(RepositoryLocator.CatalogueRepository.GetAllObjects<LoadMetadata>().ToArray());
            }
            catch (Exception exception)
            {
                ExceptionViewer.Show("Catalogue interrogation error",exception);
                return;
            }
            cbxLoadMetadata.Enabled = true;
            cbxLoadMetadata.Sorted = true;
        }
    
        private async void btnLoadDataset_Click(object sender, EventArgs eventArgs)
        {
            // todo: should really be an IsValid-type call, but this will do for now
            if (customDataProviderUI.IsCustomProviderIndicated() && !customDataProviderUI.IsCustomProviderSpecified())
            {
                MessageBox.Show("Please select the custom data source", "No custom data source selected");
                return;
            }

            loadProgressUI1.Clear();
            loadProgressUI1.OnNotify(this, new NotifyEventArgs(ProgressEventType.Information, "Single job scheduled (i.e. using the cache) load starting..."));
            btnLoadDataset.Enabled = false;
            btnStartSingleThreadedLoad.Enabled = false;
            btnStartMultiThreadedLoad.Enabled = false;
            btnAbortLoad.Enabled = true;
         
            try
            {
                // create the load process
                if (customDataProviderUI.IsCustomProviderIndicated())
                {
                    if (customDataProviderUI.IsSingleDataProvider())
                    {
                        _dataProvider = customDataProviderUI.DataProvider;
                        await RunSingleJobDataLoadProcessAsync(_dataProvider);
                    }
                    else if (customDataProviderUI.IsMultiDataProvider())
                    {
                        foreach (var provider in customDataProviderUI.LoadQueue)
                            await RunSingleJobDataLoadProcessAsync(provider);
                    }
                    else
                        throw new NotImplementedException();
                }
                else
                {
                    await RunSingleJobDataLoadProcessAsync(_dataProvider);
                }
            }
            catch (Exception e)
            {
                loadProgressUI1.OnNotify(this,new NotifyEventArgs(ProgressEventType.Error,e.Message,e));
            }
        }
        
        private bool _loadInProgress = false;
        private Task<ExitCodeType> _runningLoadProcessTask;

        private int GetNumDaysPerJob()
        {
            return Convert.ToInt32(udDaysPerJob.Value);
        }

        // single job (and therefore single threaded)
        private async Task RunSingleJobDataLoadProcess()
        {
            if (_cancellationTokenSource != null)
                return;

            _cancellationTokenSource = new GracefulCancellationTokenSource();

            var token = _cancellationTokenSource.Token;
            _runningLoadProcessTask = Task.Run(() => _dataLoadProcess.Run(token), token.CreateLinkedSource().Token);
            await WaitOnLoadTask();
            OnEndDataLoadProcess(_runningLoadProcessTask.Result);

            _cancellationTokenSource = null;
        }

        private ILogManager CreateLogManager(ILoadMetadata loadMetadata)
        {
            return new LogManager(loadMetadata.GetDistinctLoggingDatabaseSettings(false), ProgressLogging.GetInstance(), FatalErrorLogging.GetInstance(), RowErrorLogging.GetInstance());
        }

        private async Task RunSingleJobDataLoadProcessAsync(IDataProvider provider)
        {
            if (_cancellationTokenSource != null)
            {
                MessageBox.Show("Load already underway");
                return;
            }

            var metadata = (ILoadMetadata)cbxLoadMetadata.SelectedItem;
            UpdateDatabaseLoadConfiguration();

            var toAttempt = CreateLoadScheduleSelectionStrategy();
            JobDateGenerationStrategyFactory jobDateGenerationStrategyFactory = new JobDateGenerationStrategyFactory(toAttempt, _databaseLoadConfiguration);

            var logManager = CreateLogManager(metadata);

            _dataLoadProcess = new SingleJobScheduledDataLoadProcess(metadata, _databaseLoadConfiguration,
                GetLoadConfigurationFlags(), jobDateGenerationStrategyFactory,
                CreateLoadScheduleSelectionStrategy(), GetNumDaysPerJob(), logManager, loadProgressUI1)
            {
                DataProviderOverride = provider
            };

            await RunSingleJobDataLoadProcess();
        }

        private void UpdateDatabaseLoadConfiguration()
        {
            if (!string.IsNullOrWhiteSpace(tbRawServer.Text))
                _databaseLoadConfiguration.DeployInfo.SetDatabaseServer(LoadBubble.Raw, tbRawServer.Text);
        }

        private void OnEndDataLoadProcess(ExitCodeType exitCode)
        {
            btnLoadDataset.Enabled = true;
            btnStartSingleThreadedLoad.Enabled = true;
            btnStartMultiThreadedLoad.Enabled = true;
            //btnAbortLoad.Enabled = false;

            _loadInProgress = false;

            string message;
            switch (exitCode)
            {
                case ExitCodeType.Success:
                    message = "Data load has ended successfully";
                    break;
                case ExitCodeType.Error:
                    message = "Data load encountered an error, please see previous exceptions/errors.";
                    break;
                case ExitCodeType.Abort:
                    message = "Data load has been aborted/cancelled successfully";
                    break;
                case ExitCodeType.None:
                    message = "Data load exit state is not determined, investigate...";
                    break;
                case ExitCodeType.OperationNotRequired:
                    message = "Data load is not required, there is no data to load.";
                    break;
                default:
                    throw new ArgumentOutOfRangeException("exitCode");
            }
            
            loadProgressUI1.OnNotify(this,new NotifyEventArgs(ProgressEventType.Information,message ));
        }


        private void btnShowDatasetFolder_Click(object sender, EventArgs e)
        {
            var loadMetadata = cbxLoadMetadata.SelectedItem as LoadMetadata;
            if (loadMetadata == null)
            {
                MessageBox.Show("Could not retrieve the LoadMetadata from the combo box", "Load error");
                return;
            }
            
            Process.Start(loadMetadata.LocationOfFlatFiles);
        }

        private void TryToCreateHICProjectDirectory()
        {
            try
            {
                new HICProjectDirectory(_loadMetadata.LocationOfFlatFiles, false);
            }
            catch (DirectoryNotFoundException e)
            {
                ExceptionViewer.Show("Couldn't create HICProjectDirectory for " + _loadMetadata.Name +
                                     ". It either doesn't exist or you don't have access rights to the root directory (DirectoryNotFoundException could mean this too) " +
                                     _loadMetadata.LocationOfFlatFiles  ,e);
            }
        }

        private void cbxLoadMetadata_SelectedIndexChanged(object sender, EventArgs eventArgs)
        {
            if (_suppressComboBoxChangeEvent)
                return;

            if (cbxLoadMetadata.SelectedIndex == -1)
                return;

            _loadMetadata = cbxLoadMetadata.SelectedItem as LoadMetadata;

            if (_loadMetadata == null)
                return;
            
            customDataProviderUI.LocationOfFlatFiles = _loadMetadata.LocationOfFlatFiles;
            try
            {
                TryToCreateHICProjectDirectory();
            }
            catch (Exception e)
            {
                ExceptionViewer.Show("There was a problem with the LoadMetadata's Project Directory:" + e.Message,e);
                return;

            }
            try
            {

                _databaseLoadConfiguration =
                    new HICDatabaseConfiguration(_loadMetadata)
                    {
                        RequiresStagingTableCreation = true
                    };
            }
            catch (Exception e)
            {
                ExceptionViewer.Show(e);
                return;
            }

            RunChecks();

            btnShowDatasetFolder.Enabled = true;
            btnLoadDataset.Enabled = true;
            btnStartSingleThreadedLoad.Enabled = true;
            btnStartMultiThreadedLoad.Enabled = true;
            gbLoadServers.Enabled = true;

            UpdateSchedulePanel();
        }

        private void UpdateSchedulePanel()
        {
            ddLoadSchedule.Enabled = true;

            var schedules = _loadMetadata.LoadProgresses.ToList();
            if (schedules.Any())
            {
                var loadScheduleData = new Dictionary<int, string> {{0, "All available"}};

                foreach (var loadSchedule in schedules.Where(schedule => !schedule.LockedBecauseRunning))
                    loadScheduleData.Add(loadSchedule.ID, loadSchedule.ResourceIdentifier);

                ddLoadSchedule.DataSource = new BindingSource(loadScheduleData, null);
                ddLoadSchedule.DisplayMember = "Value";
                ddLoadSchedule.ValueMember = "Key";
            }
        }

        private void RunChecks()
        {
            btnOnDemandLoad.Enabled = false;
            UpdateDatabaseLoadConfiguration();

            var checker = new CheckEntireDataLoadProcess(_loadMetadata, _databaseLoadConfiguration, GetLoadConfigurationFlags(), RepositoryLocator.CatalogueRepository.MEF);
            dataLoadEntireSystemStateCheckerUI1.StartChecking(checker);
        }

        private void EnableOnDemandLoad()
        {
            if (InvokeRequired)
                btnOnDemandLoad.Invoke((MethodInvoker) (() => btnOnDemandLoad.Enabled = true));
            else
                btnOnDemandLoad.Enabled = true;
        }
        private void btnViewLoadMetadata_Click(object sender, EventArgs e)
        {
            if (_loadMetadata == null)
            {
                MessageBox.Show("No load metadata has been selected yet");
                return;
            }

            var dialog = new LoadMetadataUI(_loadMetadata);
            dialog.RepositoryLocator = RepositoryLocator;
            dialog.ShowDialog();


            foreach (
                LoadMetadata d in
                    cbxLoadMetadata.Items.Cast<LoadMetadata>()
                        .Where(lmd => dialog.DeletedLoadMetadatas.Any(del => del.ID == lmd.ID))
                        .ToArray())
                cbxLoadMetadata.Items.Remove(d);


            //if none of the load metadatas that were deleted are _loadMetadata
            if(dialog.DeletedLoadMetadatas.All(lmd => lmd.ID != _loadMetadata.ID))
            {
                // Refresh our local LoadMetadata and related UI items
                _loadMetadata.RevertToDatabaseState();
            }
            else
            {
                btnShowDatasetFolder.Enabled = false;
                btnLoadDataset.Enabled = false;
                btnStartSingleThreadedLoad.Enabled = false;
                btnStartMultiThreadedLoad.Enabled = false;
                gbLoadServers.Enabled = false;
                ddLoadSchedule.Enabled = false;
            }
        }

      
        private void DatasetLoader_FormClosing(object sender, FormClosingEventArgs e)
        {
            if(_loadInProgress)
            {
                e.Cancel = true;

                if (MessageBox.Show("Abort load?","Abort",MessageBoxButtons.YesNo)==DialogResult.Yes)
                {
                    // not sure if we can async back up to the UI when form/application is closing...
                    var task = ProcessAbortRequest();
                    task.Wait();
                }
            }
        }

        #region Configuration flags
        // todo: refactor into separate control
        private void cbMigrateRAWToStaging_CheckedChanged(object sender, EventArgs e)
        {
            if (cbMigrateRAWToStaging.Checked)
                cbMigrateStagingToLive.Enabled = true;
            else
            {
                cbMigrateStagingToLive.Enabled = false;
                cbMigrateStagingToLive.Checked = false;
            }
        }

        private void cbMigrateStagingToLive_CheckedChanged(object sender, EventArgs e)
        {
        }

        private HICLoadConfigurationFlags GetLoadConfigurationFlags()
        {
              return new HICLoadConfigurationFlags
            {
                ArchiveData = !cbSkipArchiving.Checked,
                DoLoadToStaging = cbMigrateRAWToStaging.Checked,
                DoMigrateFromStagingToLive = cbMigrateStagingToLive.Checked,
            };

        }
        #endregion

        private async Task RunIterativeLoadProcess()
        {
            if (_cancellationTokenSource != null)
                return;

            _cancellationTokenSource = new GracefulCancellationTokenSource();

            try
            {
                _runningLoadProcessTask = Task.Run(() => _dataLoadProcess.Run(_cancellationTokenSource.Token));
                await WaitOnLoadTask();
            }
            finally
            {
                OnEndIterativeBatchLoad();
            }

            _cancellationTokenSource = null;
        }

        private void OnEndIterativeBatchLoad()
        {
            btnLoadDataset.Enabled = true;
            btnStartSingleThreadedLoad.Enabled = true;
            btnStartMultiThreadedLoad.Enabled = true;
            //btnAbortLoad.Enabled = false;

            loadProgressUI1.OnNotify(this,new NotifyEventArgs(ProgressEventType.Information, "Iterative Batch Load ended successfully"));
        }

        private async void btnAbortLoad_Click(object sender, EventArgs e)
        {
            var abortRequest = ProcessAbortRequest();

            var abortTimer = new Stopwatch();
            abortTimer.Start();
            while (!abortRequest.IsCompleted)
            {
                loadProgressUI1.OnProgress(this, new ProgressEventArgs("Waiting for load task to abort", new ProgressMeasurement(abortTimer.Elapsed.Seconds, ProgressType.Records), abortTimer.Elapsed));
                await Task.Delay(2000);
            }
        }

        private async Task ProcessAbortRequest()
        {
            loadProgressUI1.OnNotify(this, new NotifyEventArgs(ProgressEventType.Information, "Abort requested..."));

            try
            {
                _cancellationTokenSource.Abort();
                await _runningLoadProcessTask.ContinueWith(t =>
                {
                    loadProgressUI1.OnNotify(this, new NotifyEventArgs(ProgressEventType.Information, "Load task aborted successfully"));
                    _loadInProgress = false;
                });
            }
            catch (AggregateException ex)
            {
                loadProgressUI1.OnNotify(this,
                    new NotifyEventArgs(ProgressEventType.Error, "Load task faulted while attempting to abort"));
                ex.Handle(e =>
                {
                    loadProgressUI1.OnNotify(this, new NotifyEventArgs(ProgressEventType.Error, e.Message, e));
                    return true;
                });
            }
            finally
            {
                _cancellationTokenSource = null;
            }
        }

        private async void btnStopLoad_Click(object sender, EventArgs e)
        {
            if (_runningLoadProcessTask == null)
                return;

            try
            {
                _cancellationTokenSource.Stop();
                await _runningLoadProcessTask.ContinueWith(t =>
                {
                    loadProgressUI1.OnNotify(this, new NotifyEventArgs(ProgressEventType.Information, "Load Process stopped successfully"));
                    // enable/disable UI accordingly
                });
            }
            catch (AggregateException exception)
            {
                exception.Handle(ex =>
                {
                    loadProgressUI1.OnNotify(this,
                        new NotifyEventArgs(ProgressEventType.Error,
                            "Errors encountered when waiting for load task to stop", ex));
                    return true;
                });
            }
            finally
            {
                _cancellationTokenSource = null;
            }
        }

        private async Task StartIterativeLoadProcess()
        {
            btnLoadDataset.Enabled = false;
            btnStartSingleThreadedLoad.Enabled = false;
            btnStartMultiThreadedLoad.Enabled = false;
            btnAbortLoad.Enabled = true;

            UpdateDatabaseLoadConfiguration(); // ensure that our configuration object is synced with the UI

			var toAttempt = CreateLoadScheduleSelectionStrategy();
			var jobDateGenerationStrategyFactory = new JobDateGenerationStrategyFactory(toAttempt, _databaseLoadConfiguration);
            var logManager = CreateLogManager(_loadMetadata);
            _dataLoadProcess = new IterativeScheduledDataLoadProcess(_loadMetadata, _databaseLoadConfiguration, GetLoadConfigurationFlags(), jobDateGenerationStrategyFactory, toAttempt, GetNumDaysPerJob(), Convert.ToInt32(tbMaxNumJobsPerStage.Text), _useMultiThreadedLoad, logManager, loadProgressUI1)
            {
                DataProviderOverride = _dataProvider
            };

            await RunIterativeLoadProcess();
        }

        private ILoadScheduleSelectionStrategy CreateLoadScheduleSelectionStrategy()
        {
            var scheduleItem = (KeyValuePair<int, string>)ddLoadSchedule.SelectedItem;
            if (scheduleItem.Key == 0)
                return new AnyAvailableLoadScheduleSelectionStrategy(_loadMetadata);

            var loadProgress = RepositoryLocator.CatalogueRepository.GetObjectByID<LoadProgress>(scheduleItem.Key);

            return new SingleLoadScheduleSelectionStrategy(loadProgress);
        }

        // todo: should really refactor the 'iterative batch load' control into its own class
        private async void btnStartSingleThreadedLoad_Click(object sender, EventArgs e)
        {
            _useMultiThreadedLoad = false;
            loadProgressUI1.Clear();
            loadProgressUI1.OnNotify(this, new NotifyEventArgs(ProgressEventType.Information, "Iterative scheduled (i.e. using the cache) load starting..."));
            await StartIterativeLoadProcess();
        }

        private async void btnStartMultiThreadedLoad_Click(object sender, EventArgs e)
        {
            _useMultiThreadedLoad = true;
            await StartIterativeLoadProcess();
            ShowPipelineInfoUIDialog();
        }

        private void ShowPipelineInfoUIDialog()
        {
            var threadedPipelineInfoUI = new ThreadedPipelineInfoUI
            {
                Dock = DockStyle.Fill
            };
            threadedPipelineInfoUI.SetPipeline(_dataLoadProcess.LoadPipeline as MultiJobThreadedPipeline);

            var form = new Form
            {
                Width = threadedPipelineInfoUI.Width + 12,
                Height = threadedPipelineInfoUI.Height + 20,
                Owner = this
            };

            form.Controls.Add(threadedPipelineInfoUI);
            form.Show();
        }

        private async void btnOnDemandLoad_Click(object sender, EventArgs e)
        {
            loadProgressUI1.Clear();
            UpdateDatabaseLoadConfiguration();

            loadProgressUI1.OnNotify(this, new NotifyEventArgs(ProgressEventType.Information, "Single job on-demand load starting..."));
            await RunOnDemandLoadTask();
            _loadInProgress = false;

        }

        private void btnRerunChecks_Click(object sender, EventArgs e)
        {
            if (_loadMetadata == null)
                return;

            RunChecks();
        }

        private void changeCatalogueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var dialog = new ChoosePlatformDatabases();
            dialog.RepositoryLocator = RepositoryLocator;
            dialog.ShowDialog(this);

            GetAvailableLoads();
        }

        private void launchDiagnosticsScreenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DiagnosticsScreen dialog = new DiagnosticsScreen(null);
            dialog.RepositoryLocator = RepositoryLocator;
            dialog.ShowDialog();

            if (dialog.ShouldReloadCatalogues)
                GetAvailableLoads();
        }

        private void showPerformanceCounterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new CatalogueLibraryPerformanceCounterUI().Show();
        }
        
        private void refreshToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GetAvailableLoads();
        }
        
        private void btnOneOffLoad_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            try
            {
                DialogResult result = ofd.ShowDialog();
                
                if (result == DialogResult.OK)
                {

                    DialogResult dr = MessageBox.Show("Also forward engineer a catalogue?", "Also create a Catalogue",MessageBoxButtons.YesNo);

                    SimpleImportDataFileUI dialog = new SimpleImportDataFileUI(new FileInfo(ofd.FileName),dr == DialogResult.Yes);
                    dialog.RepositoryLocator = RepositoryLocator;
                    dialog.ShowDialog();

                    if (dialog.CatalogueCreatedIfAny != null)
                        MessageBox.Show("Succesfully created Catalogue called " + dialog.CatalogueCreatedIfAny.Name);

                }
            }
            catch (Exception exception)
            {
                ExceptionViewer.Show(exception);
            }
        }

        FilterControl<ComboBox> _filter = new FilterControl<ComboBox>();
        private bool _suppressComboBoxChangeEvent = false;
        

        private void tbFilter_TextChanged(object sender, EventArgs e)
        {
            _suppressComboBoxChangeEvent = true;
            _filter.ApplyFilter(cbxLoadMetadata,tbFilter.Text);
            _suppressComboBoxChangeEvent = false;
        }

        private async Task RunOnDemandLoadTask()
        {
            // Prevent re-entrancy
            if (_cancellationTokenSource != null)
            {
                if(MessageBox.Show("Load might already be in progress (or the CancellationTokenSource has not been reset after a successful load).  We can ignore this and carry on if you want though.  Carry on?","Carry on anyway?",MessageBoxButtons.YesNo) != DialogResult.Yes)
                    return;
            }

            _cancellationTokenSource = new GracefulCancellationTokenSource();

            // Create the 'on demand' data load process, overriding the data provider if one is specified
            var logManager = CreateLogManager(_loadMetadata);
            _dataLoadProcess = new OnDemandDataLoadProcess(_loadMetadata, _databaseLoadConfiguration, GetLoadConfigurationFlags(), logManager, loadProgressUI1)
            {
                DataProviderOverride = _dataProvider
            };

            // Run the task followed by OnEndDataLoadProcess after it has completed
            var tokenSource = _cancellationTokenSource.Token.CreateLinkedSource();
            _runningLoadProcessTask = Task.Run(() => _dataLoadProcess.Run(_cancellationTokenSource.Token), tokenSource.Token);
            await WaitOnLoadTask();
            await _runningLoadProcessTask.ContinueWith(t => OnEndDataLoadProcess(_runningLoadProcessTask.Result));

            _cancellationTokenSource = null;
        }

        private async Task WaitOnLoadTask()
        {
            _loadInProgress = true;
            try
            {
                await _runningLoadProcessTask;
            }
            catch (OperationCanceledException e)
            {
                loadProgressUI1.OnNotify(this, new NotifyEventArgs(ProgressEventType.Warning, "Data Load Cancelled", e));
                _loadInProgress = false;
            }
            catch (Exception e)
            {
                _loadInProgress = false;
                loadProgressUI1.OnNotify(this, new NotifyEventArgs(ProgressEventType.Error, "Entire data load process crashed", e));
                if (_runningLoadProcessTask.Exception != null)
                {
                    _runningLoadProcessTask.Exception.Handle(exception =>
                    {
                        loadProgressUI1.OnNotify(this, new NotifyEventArgs(ProgressEventType.Error, exception.Message, exception));
                        return true;
                    });
                }
            }

        }

        private async void btnIterativeOnDemandLoad_Click(object sender, EventArgs e)
        {
            loadProgressUI1.Clear();
            UpdateDatabaseLoadConfiguration();
            loadProgressUI1.OnNotify(this, new NotifyEventArgs(ProgressEventType.Information, "Iterative job on-demand load starting..."));
            await RunIterativeOnDemandLoadTask();
        }

        private async Task RunIterativeOnDemandLoadTask()
        {
            // Prevent re-entrancy
            if (_cancellationTokenSource != null)
                return;

            _cancellationTokenSource = new GracefulCancellationTokenSource();

            // Create the 'on demand' data load process, overriding the data provider if one is specified
            var logManager = CreateLogManager(_loadMetadata);
            _dataLoadProcess = new OnDemandDataLoadProcess(_loadMetadata, _databaseLoadConfiguration, GetLoadConfigurationFlags(), logManager, loadProgressUI1)
            {
                DataProviderOverride = _dataProvider
            };

            while (true)
            {
                _runningLoadProcessTask = Task.Run(() => _dataLoadProcess.Run(_cancellationTokenSource.Token));
                await WaitOnLoadTask();

                if (!_cancellationTokenSource.Token.IsCancellationRequested && _runningLoadProcessTask.Result == ExitCodeType.Success)
                    continue;

                OnEndDataLoadProcess(_runningLoadProcessTask.Result);
                break;
            }

            _cancellationTokenSource = null;
        }

        private void btnRebuildCacheFromArchive_Click(object sender, EventArgs e)
        {
            var cacheRebuilderForm = new CacheRebuilder();
            cacheRebuilderForm.RepositoryLocator = RepositoryLocator;
            cacheRebuilderForm.ShowDialog();
        }
    }
}

namespace HIC.Common.Validation.UIAttributes // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
{
    public class HideOnValidationUI : System.Attribute
    {
    }

    public class ExpectsColumnNameAsInput: System.Attribute
    {
    }

    public class ExpectsLotsOfText : System.Attribute
    {
    }

    public class ExpectsPredictionRule : System.Attribute
    {
    }

    

}

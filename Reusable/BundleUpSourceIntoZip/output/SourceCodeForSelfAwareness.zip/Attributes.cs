namespace HIC.Common.Validation.UIAttributes
{
    public class HideOnValidationUI : System.Attribute
    {
    }

    public class ExpectsColumnNameAsInput: System.Attribute
    {
    }

    public class ExpectsLotsOfText : System.Attribute
    {
    }

    public class ExpectsPredictionRule : System.Attribute
    {
    }

    

}

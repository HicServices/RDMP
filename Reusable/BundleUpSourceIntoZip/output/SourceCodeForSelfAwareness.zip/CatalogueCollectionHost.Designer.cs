namespace CatalogueManager.MainFormUITabs.SubComponents // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
{
    partial class CatalogueCollectionHost
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;



        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rbNotInternal = new System.Windows.Forms.RadioButton();
            this.rbInternal = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbDeprecated = new System.Windows.Forms.RadioButton();
            this.rbLive = new System.Windows.Forms.RadioButton();
            this.label42 = new System.Windows.Forms.Label();
            this.tbFilter = new System.Windows.Forms.TextBox();
            this.CatalogueCollection = new CatalogueManager.MainFormUITabs.SubComponents.CatalogueCollection();
            this.gbColdStorage = new System.Windows.Forms.GroupBox();
            this.rbColdStorage = new System.Windows.Forms.RadioButton();
            this.rbWarmStorage = new System.Windows.Forms.RadioButton();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.gbColdStorage.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.rbNotInternal);
            this.groupBox2.Controls.Add(this.rbInternal);
            this.groupBox2.Location = new System.Drawing.Point(6, 755);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(268, 43);
            this.groupBox2.TabIndex = 164;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Show (Availablility)";
            // 
            // rbNotInternal
            // 
            this.rbNotInternal.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.rbNotInternal.AutoSize = true;
            this.rbNotInternal.Checked = true;
            this.rbNotInternal.Location = new System.Drawing.Point(29, 20);
            this.rbNotInternal.Name = "rbNotInternal";
            this.rbNotInternal.Size = new System.Drawing.Size(54, 17);
            this.rbNotInternal.TabIndex = 155;
            this.rbNotInternal.TabStop = true;
            this.rbNotInternal.Text = "Public";
            this.rbNotInternal.UseVisualStyleBackColor = true;
            // 
            // rbInternal
            // 
            this.rbInternal.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.rbInternal.AutoSize = true;
            this.rbInternal.Location = new System.Drawing.Point(104, 20);
            this.rbInternal.Name = "rbInternal";
            this.rbInternal.Size = new System.Drawing.Size(84, 17);
            this.rbInternal.TabIndex = 156;
            this.rbInternal.Text = "Internal Only";
            this.rbInternal.UseVisualStyleBackColor = true;
            this.rbInternal.CheckedChanged += new System.EventHandler(this.anyRadiobuttonThatRefreshesLists_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.rbDeprecated);
            this.groupBox1.Controls.Add(this.rbLive);
            this.groupBox1.Location = new System.Drawing.Point(3, 713);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(268, 36);
            this.groupBox1.TabIndex = 163;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Show (Deprecation)";
            // 
            // rbDeprecated
            // 
            this.rbDeprecated.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.rbDeprecated.AutoSize = true;
            this.rbDeprecated.Location = new System.Drawing.Point(107, 16);
            this.rbDeprecated.Name = "rbDeprecated";
            this.rbDeprecated.Size = new System.Drawing.Size(105, 17);
            this.rbDeprecated.TabIndex = 156;
            this.rbDeprecated.Text = "Deprecated Only";
            this.rbDeprecated.UseVisualStyleBackColor = true;
            this.rbDeprecated.CheckedChanged += new System.EventHandler(this.anyRadiobuttonThatRefreshesLists_CheckedChanged);
            // 
            // rbLive
            // 
            this.rbLive.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.rbLive.AutoSize = true;
            this.rbLive.Checked = true;
            this.rbLive.Location = new System.Drawing.Point(29, 16);
            this.rbLive.Name = "rbLive";
            this.rbLive.Size = new System.Drawing.Size(69, 17);
            this.rbLive.TabIndex = 155;
            this.rbLive.TabStop = true;
            this.rbLive.Text = "Live Only";
            this.rbLive.UseVisualStyleBackColor = true;
            // 
            // label42
            // 
            this.label42.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(3, 623);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(32, 13);
            this.label42.TabIndex = 162;
            this.label42.Text = "Filter:";
            // 
            // tbFilter
            // 
            this.tbFilter.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbFilter.Location = new System.Drawing.Point(4, 639);
            this.tbFilter.Name = "tbFilter";
            this.tbFilter.Size = new System.Drawing.Size(267, 20);
            this.tbFilter.TabIndex = 161;
            this.tbFilter.TextChanged += new System.EventHandler(this.tbFilter_TextChanged);
            // 
            // CatalogueCollection
            // 
            this.CatalogueCollection.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.CatalogueCollection.Filter = null;
            this.CatalogueCollection.Location = new System.Drawing.Point(3, 3);
            this.CatalogueCollection.Name = "CatalogueCollection";
            this.CatalogueCollection.SelectedCatalogue = null;
            this.CatalogueCollection.ShowColdStorage = false;
            this.CatalogueCollection.ShowDeprecated = false;
            this.CatalogueCollection.ShowInternal = false;
            this.CatalogueCollection.Size = new System.Drawing.Size(279, 617);
            this.CatalogueCollection.TabIndex = 0;
            // 
            // gbColdStorage
            // 
            this.gbColdStorage.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gbColdStorage.Controls.Add(this.rbColdStorage);
            this.gbColdStorage.Controls.Add(this.rbWarmStorage);
            this.gbColdStorage.Location = new System.Drawing.Point(3, 671);
            this.gbColdStorage.Name = "gbColdStorage";
            this.gbColdStorage.Size = new System.Drawing.Size(268, 36);
            this.gbColdStorage.TabIndex = 166;
            this.gbColdStorage.TabStop = false;
            this.gbColdStorage.Text = "Show (Warm / Cold Storage)";
            // 
            // rbColdStorage
            // 
            this.rbColdStorage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.rbColdStorage.AutoSize = true;
            this.rbColdStorage.Location = new System.Drawing.Point(107, 16);
            this.rbColdStorage.Name = "rbColdStorage";
            this.rbColdStorage.Size = new System.Drawing.Size(86, 17);
            this.rbColdStorage.TabIndex = 156;
            this.rbColdStorage.Text = "Cold Storage";
            this.rbColdStorage.UseVisualStyleBackColor = true;
            this.rbColdStorage.CheckedChanged += new System.EventHandler(this.anyRadiobuttonThatRefreshesLists_CheckedChanged);
            // 
            // rbWarmStorage
            // 
            this.rbWarmStorage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.rbWarmStorage.AutoSize = true;
            this.rbWarmStorage.Checked = true;
            this.rbWarmStorage.Location = new System.Drawing.Point(29, 16);
            this.rbWarmStorage.Name = "rbWarmStorage";
            this.rbWarmStorage.Size = new System.Drawing.Size(53, 17);
            this.rbWarmStorage.TabIndex = 155;
            this.rbWarmStorage.TabStop = true;
            this.rbWarmStorage.Text = "Warm";
            this.rbWarmStorage.UseVisualStyleBackColor = true;
            // 
            // CatalogueCollectionHost
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.gbColdStorage);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.tbFilter);
            this.Controls.Add(this.CatalogueCollection);
            this.Name = "CatalogueCollectionHost";
            this.Size = new System.Drawing.Size(285, 802);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.gbColdStorage.ResumeLayout(false);
            this.gbColdStorage.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public CatalogueCollection CatalogueCollection;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton rbNotInternal;
        private System.Windows.Forms.RadioButton rbInternal;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbDeprecated;
        private System.Windows.Forms.RadioButton rbLive;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox tbFilter;
        private System.Windows.Forms.GroupBox gbColdStorage;
        private System.Windows.Forms.RadioButton rbColdStorage;
        private System.Windows.Forms.RadioButton rbWarmStorage;
    }
}

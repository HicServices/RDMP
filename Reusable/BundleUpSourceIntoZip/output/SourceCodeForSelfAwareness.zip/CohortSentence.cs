using System.Collections.Generic; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using CatalogueLibrary.Data;
using CatalogueLibrary.Data.Aggregation;
using CatalogueLibrary.QueryBuilding;
using CohortManagerLibrary.QueryBuilding;

namespace CohortManagerLibrary.FreeText.Sentencing
{
    public class CohortSentence
    {
        public string Text { get; private set; }
        public List<SentenceSection> Sections { get; private set; }

        public AggregateConfiguration AggregateConfiguration { get; set; }

        public CohortSentence(AggregateConfiguration aggregateConfiguration)
        {
            Text = "";
            Sections = new List<SentenceSection>();

            AggregateConfiguration = aggregateConfiguration;
            Text = GenerateSentence();
        }

        private string GenerateSentence()
        {
            Append(AggregateConfiguration.Catalogue.Name, SentenceSectionType.Catalogue);

            if(AggregateConfiguration.RootFilterContainer_ID != null)
                AppendFiltersRecursively(AggregateConfiguration.RootFilterContainer);

            return Text;
        }

        private void AppendFiltersRecursively(AggregateFilterContainer filterContainer)
        {
            FilterContainerOperation operation = filterContainer.Operation;
            
            //todo sort out brackets if needed

            AggregateFilter[] filters = (AggregateFilter[]) filterContainer.GetFilters();
            for (int i = 0; i < filters.Length; i++)
            {
                if (i > 0)
                    Append(operation.ToString(), SentenceSectionType.FilterContainerOperation);

                Append(filters[i].Name,SentenceSectionType.Filter);

                foreach (AggregateFilterParameter parameter in filters[i].AggregateFilterParameters)
                {
                    Append(parameter.ParameterName, SentenceSectionType.FilterParameter);
                    Append(parameter.Value, SentenceSectionType.FilterParameterValue);
                }
            }

            return;

        }

        private void Append(string toAppendText, SentenceSectionType sentenceSectionType)
        {
            //space seperate them with after the first, the space is considered the next part
            if (!string.IsNullOrWhiteSpace(Text))
                toAppendText = " " + toAppendText.Trim();

            int startIndex = Text.Length;
            int endIndex = Text.Length + toAppendText.Length - 1;
            
            Text += toAppendText;
            Sections.Add(new SentenceSection(startIndex,endIndex,sentenceSectionType));
        }
    }
}

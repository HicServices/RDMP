using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved

namespace HIC.Logging.PastEvents
{
    public class ArchivalDataSource : IArchivalLoggingRecordOfPastEvent
    {
        
        public string MD5 { get; set; }
        public string Source { get; set; }
        public string Archive { get; set; }
        public DateTime? OriginDate { get; internal set; }
        public int ID { get; set; }

        public ArchivalDataSource(int id, object originDate, string source, string archive, string mD5)
        {
            ID = id;
            if (originDate == null || originDate == DBNull.Value)
                OriginDate = null;
            else
                OriginDate = (DateTime) originDate;
            Source = source;
            Archive = archive;
            MD5 = mD5;
        }
        
        public string ToShortString()
        {

            var s = ToString();
            if (s.Length > ArchivalDataLoadInfo.MaxDescriptionLength)
                return s.Substring(0, ArchivalDataLoadInfo.MaxDescriptionLength) + "...";
            return s;
        }

        public override string ToString()
        {
            return  "Source:" + Source + (string.IsNullOrWhiteSpace(MD5) ? "" : "(MD5=" + MD5 + ")");
        }
    }
}

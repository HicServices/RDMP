using System.ComponentModel; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Drawing;
using System.Windows.Forms;
using BrightIdeasSoftware;

namespace CatalogueManager.MainFormUITabs.SubComponents
{
    partial class CatalogueCollection
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CatalogueCollection));
            this.otlvCatalogues = new BrightIdeasSoftware.TreeListView();
            this.olvColumn1 = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvCheckResult = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.imageList_RightClickIcons = new System.Windows.Forms.ImageList(this.components);
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.btnCheckCatalogues = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.otlvCatalogues)).BeginInit();
            this.SuspendLayout();
            // 
            // otlvCatalogues
            // 
            this.otlvCatalogues.AllColumns.Add(this.olvColumn1);
            this.otlvCatalogues.AllColumns.Add(this.olvCheckResult);
            this.otlvCatalogues.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.otlvCatalogues.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.olvColumn1,
            this.olvCheckResult});
            this.otlvCatalogues.IsSimpleDragSource = true;
            this.otlvCatalogues.IsSimpleDropSink = true;
            this.otlvCatalogues.Location = new System.Drawing.Point(0, 0);
            this.otlvCatalogues.Name = "otlvCatalogues";
            this.otlvCatalogues.OwnerDraw = true;
            this.otlvCatalogues.ShowGroups = false;
            this.otlvCatalogues.Size = new System.Drawing.Size(405, 617);
            this.otlvCatalogues.SmallImageList = this.imageList1;
            this.otlvCatalogues.TabIndex = 0;
            this.otlvCatalogues.Text = "label1";
            this.otlvCatalogues.UseCompatibleStateImageBehavior = false;
            this.otlvCatalogues.View = System.Windows.Forms.View.Details;
            this.otlvCatalogues.VirtualMode = true;
            this.otlvCatalogues.CellRightClick += new System.EventHandler<BrightIdeasSoftware.CellRightClickEventArgs>(this.tlvCatalogues_CellRightClick);
            this.otlvCatalogues.ItemActivate += new System.EventHandler(this.tlvCatalogues_ItemActivate);
            this.otlvCatalogues.ItemSelectionChanged += new System.Windows.Forms.ListViewItemSelectionChangedEventHandler(this.tlvCatalogues_ItemSelectionChanged);
            this.otlvCatalogues.KeyUp += new System.Windows.Forms.KeyEventHandler(this.tlvCatalogues_KeyUp);
            // 
            // olvColumn1
            // 
            this.olvColumn1.AspectName = "ToString";
            this.olvColumn1.FillsFreeSpace = true;
            this.olvColumn1.HeaderTextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.olvColumn1.Text = "Catalogues";
            this.olvColumn1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // olvCheckResult
            // 
            this.olvCheckResult.HeaderTextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.olvCheckResult.Text = "Check";
            this.olvCheckResult.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.olvCheckResult.Width = 45;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "Folder.bmp");
            this.imageList1.Images.SetKeyName(1, "Catalogue.bmp");
            this.imageList1.Images.SetKeyName(2, "tick.bmp");
            this.imageList1.Images.SetKeyName(3, "warning.bmp");
            this.imageList1.Images.SetKeyName(4, "failedWithException.bmp");
            this.imageList1.Images.SetKeyName(5, "aggregates.png");
            this.imageList1.Images.SetKeyName(6, "aggregatesShortcut.png");
            // 
            // imageList_RightClickIcons
            // 
            this.imageList_RightClickIcons.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList_RightClickIcons.ImageStream")));
            this.imageList_RightClickIcons.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList_RightClickIcons.Images.SetKeyName(0, "DLE");
            this.imageList_RightClickIcons.Images.SetKeyName(1, "DEM");
            this.imageList_RightClickIcons.Images.SetKeyName(2, "DQE");
            this.imageList_RightClickIcons.Images.SetKeyName(3, "LOG");
            this.imageList_RightClickIcons.Images.SetKeyName(4, "aggregates.png");
            // 
            // progressBar1
            // 
            this.progressBar1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.progressBar1.Location = new System.Drawing.Point(3, 623);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(356, 19);
            this.progressBar1.TabIndex = 166;
            this.progressBar1.Visible = false;
            // 
            // btnCheckCatalogues
            // 
            this.btnCheckCatalogues.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCheckCatalogues.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.25F);
            this.btnCheckCatalogues.Location = new System.Drawing.Point(365, 623);
            this.btnCheckCatalogues.Name = "btnCheckCatalogues";
            this.btnCheckCatalogues.Size = new System.Drawing.Size(40, 22);
            this.btnCheckCatalogues.TabIndex = 167;
            this.btnCheckCatalogues.Text = "Check";
            this.btnCheckCatalogues.UseVisualStyleBackColor = true;
            this.btnCheckCatalogues.Click += new System.EventHandler(this.btnCheckCatalogues_Click);
            // 
            // CatalogueCollection
            // 
            this.Controls.Add(this.btnCheckCatalogues);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.otlvCatalogues);
            this.Name = "CatalogueCollection";
            this.Size = new System.Drawing.Size(405, 645);
            ((System.ComponentModel.ISupportInitialize)(this.otlvCatalogues)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private TreeListView otlvCatalogues;
        private ImageList imageList1;
        private ImageList imageList_RightClickIcons;
        private OLVColumn olvColumn1;
        private ProgressBar progressBar1;
        private OLVColumn olvCheckResult;
        private Button btnCheckCatalogues;
    }
}

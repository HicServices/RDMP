using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved

namespace CatalogueLibrary.Data
{

    /// <summary>
    /// Used by classes to indicate that a property should be initialized from a ProcessTaskArgument
    /// </summary>
    [System.AttributeUsage(AttributeTargets.Property)]
    public class DemandsInitialization:System.Attribute
    {
        public string Description { get; private set; }
        public DemandType DemandType { get; set; }

        public DemandsInitialization(string description,DemandType demandType =  DemandType.Unspecified)
        {
            Description = description;
            DemandType = demandType;
        }
    }

    public enum DemandType
    {
        Unspecified,
        SQL
    }
}

using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using CatalogueLibrary.Data.Cohort;
using CatalogueLibrary.QueryBuilding;
using CatalogueLibrary.Repositories;
using MapsDirectlyToDatabaseTable;
using MapsDirectlyToDatabaseTable.Revertable;
using ReusableLibraryCode;
using ReusableLibraryCode.Checks;

namespace CatalogueLibrary.Data.Aggregation
{
    /// <summary>
    /// Entry point for the aggregation system.  This class describes what a given aggregation is supposed to achieve (e.g. summarise the number of records in a 
    /// dataset by region over time since 2001 to present.  An AggregateConfiguration belongs to a given Catalogue and is the hanging-off point for the rest of the
    /// configuration (e.g. AggregateDimension / AggregateFilter)
    /// </summary>
    public class AggregateConfiguration : VersionedDatabaseEntity, ICheckable, IOrderable, ICollectSqlParameters
    {
        #region Properties
        public string CountSQL { get; set; }
        public int Catalogue_ID { get; set; }

        public int? RootFilterContainer_ID
        {
            get { return _rootFilterContainerID; }
            set
            {
                if (OverrideFiltersByUsingParentAggregateConfigurationInstead_ID != null && value != null)
                    throw new NotSupportedException(string.Format("This AggregateConfiguration has a shortcut to another AggregateConfiguration's Filters (It's OverrideFiltersByUsingParentAggregateConfigurationInstead_ID is {0}) which means it cannot be assigned it's own RootFilterContainerID", OverrideFiltersByUsingParentAggregateConfigurationInstead_ID));

                _rootFilterContainerID = value;
            }
        }

        public string Name { get; set; }
        public string Description { get; set; }
        public DateTime dtCreated { get; set; }

        public int? PivotOnDimensionID { get; set; }

        public bool IsExtractable { get; set; }
        public string HavingSQL { get; set; }
        #endregion 

        #region Relationships
        [NoMappingToDatabase]
        public Catalogue Catalogue
        {
            get
            {
                return Repository.GetObjectByID<Catalogue>(Catalogue_ID);
            }
        }

        [NoMappingToDatabase]
        public AggregateFilterContainer RootFilterContainer
        {
            get
            {
                //if there is an override
                if (OverrideFiltersByUsingParentAggregateConfigurationInstead_ID != null)
                    return Repository.GetObjectByID<AggregateConfiguration>(
                        (int)OverrideFiltersByUsingParentAggregateConfigurationInstead_ID).RootFilterContainer;//return the overriding one
         
                //else return the actual root filter container or null if there isn't one
                return RootFilterContainer_ID == null ? null : Repository.GetObjectByID<AggregateFilterContainer>((int)RootFilterContainer_ID);
            }
        }

        [NoMappingToDatabase]
        public IEnumerable<AnyTableSqlParameter>  Parameters
        {
            get { return ((CatalogueRepository) Repository).GetAllParametersForParentTable(this); }
        }

        [NoMappingToDatabase]
        public TableInfo[] ForcedJoins
        {
            get { return ((CatalogueRepository) Repository).AggregateForcedJoiner.GetAllForcedJoinsFor(this); }
        }

        [NoMappingToDatabase]
        public IEnumerable<AggregateDimension> AggregateDimensions
        {
            get
            {
                return Repository.GetAllObjectsWithParent<AggregateDimension>(this);
            }
        }


        [NoMappingToDatabase]
        public AggregateDimension PivotDimension {
            get
            {
                return PivotOnDimensionID == null
                    ? null
                    : Repository.GetObjectByID<AggregateDimension>((int)PivotOnDimensionID);
            }
        }

        [NoMappingToDatabase]
        public AggregateConfiguration OverrideFiltersByUsingParentAggregateConfigurationInstead {
            get
            {
                return _overrideFiltersByUsingParentAggregateConfigurationInsteadID == null
                    ? null
                    : Repository.GetObjectByID<AggregateConfiguration>(
                        (int) _overrideFiltersByUsingParentAggregateConfigurationInsteadID);
            }
        }

        #endregion

        public int? OverrideFiltersByUsingParentAggregateConfigurationInstead_ID
        {
            get { return _overrideFiltersByUsingParentAggregateConfigurationInsteadID; }
            set
            {
                if (RootFilterContainer_ID != null && value != null)
                    throw new NotSupportedException("Cannot set OverrideFiltersByUsingParentAggregateConfigurationInstead_ID because this AggregateConfiguration already has a filter container set (if you were to be a shortcut and also have a filter tree set it would be very confusing)");

                _overrideFiltersByUsingParentAggregateConfigurationInsteadID = value;
            }
        }

        public AggregateConfiguration(IRepository repository, ICatalogue catalogue, string name)
        {
            repository.InsertAndHydrate(this,new Dictionary<string, object>
            {
                {"Name", name},
                {"Catalogue_ID", catalogue.ID}
            });
        }

        public AggregateConfiguration(IRepository repository,DbDataReader r) : base(repository, r)
        {
            Name = r["Name"] as string;
            Description = r["Description"] as string;
            Catalogue_ID = int.Parse(r["Catalogue_ID"].ToString());
            dtCreated = DateTime.Parse(r["dtCreated"].ToString());

            CountSQL = r["CountSQL"] as string;
            HavingSQL = r["HavingSQL"] as string;

            object rootFilterID = r["RootFilterContainer_ID"];

            if (rootFilterID == null || rootFilterID == DBNull.Value)
                RootFilterContainer_ID = null;
            else
                RootFilterContainer_ID = int.Parse(rootFilterID.ToString());
            
            if (r["PivotOnDimensionID"] == DBNull.Value)
                PivotOnDimensionID = null;
            else
                PivotOnDimensionID = Convert.ToInt32(r["PivotOnDimensionID"]);

            IsExtractable = Convert.ToBoolean(r["IsExtractable"]);

            OverrideFiltersByUsingParentAggregateConfigurationInstead_ID =
                ObjectToNullableInt(r["OverrideFiltersByUsingParentAggregateConfigurationInstead_ID"]);

            ReFetchOrder();
        }

        public void ReFetchOrder()
        {
            var repo = new CatalogueRepository(((CatalogueRepository) Repository).ConnectionStringBuilder);
            _orderWithinKnownContainer = repo.GetOrderIfExistsFor(this);
        }

        public override string ToString()
        {
            return Name;
        }
     

        public void AddDimension(ExtractionInformation basedOnColumn)
        {
            new AggregateDimension(basedOnColumn.Repository,basedOnColumn, this);
        }

        /*
        public void RemoveDimension(ExtractionInformation dimension)
        {
            Delete("DELETE FROM AggregateDimension WHERE AggregateConfiguration_ID=@AggregateConfiguration_ID and ExtractionInformation_ID=@ExtractionInformation_ID", new Dictionary<string, object>
            {
                {"AggregateConfiguration_ID", ID},
                {"ExtractionInformation_ID", dimension.ID}
            });
        }
        */
        public AggregateBuilder GetQueryBuilder()
        {
            var allForcedJoins = ForcedJoins.ToArray();

            AggregateBuilder builder;
            if(allForcedJoins.Any())
                builder = new AggregateBuilder(null, CountSQL, this, allForcedJoins);
            else
                builder = new AggregateBuilder(null, CountSQL,this);

            builder.AddColumnRange(AggregateDimensions.ToArray());
            builder.RootFilterContainer = RootFilterContainer;
                    
            if(PivotOnDimensionID != null)
                builder.SetPivotToDimensionID(PivotDimension);
            
            return builder;
        }
        
        public ISqlParameter[] GetAllParameters()
        {
            return Parameters.ToArray();
        }

        public AggregateContinuousDateAxis GetAxisIfAny()
        {
            //for each dimension
            foreach (AggregateDimension aggregateDimension in AggregateDimensions)
            {
                //if it has an axis
                var axis = aggregateDimension.AggregateContinuousDateAxis;
                if (axis != null)
                    return axis;//return it
            }

            //done
            return null;
        }

        public bool IsAcceptableAsCohortGenerationSource(out string reason)
        {
            reason = null;

            var dimensions = AggregateDimensions.ToArray();

            if (dimensions.Count(d => d.IsExtractionIdentifier) != 1)
                reason = "There must be exactly 1 Dimension and it must be marked IsExtractionIdentifier";

            if (PivotOnDimensionID != null)
                reason = "It cannot contain a pivot";

            if (GetAxisIfAny() != null)
                reason = "It cannot have any axises";
            
            return reason == null;
        }


        public void Check(ICheckNotifier notifier)
        {
            try
            {
                var qb = GetQueryBuilder();
                notifier.OnCheckPerformed(new CheckEventArgs("Succesfully generated Aggregate SQL:"+qb.SQL,CheckResult.Success));
            }
            catch (Exception e)
            {
                notifier.OnCheckPerformed(new CheckEventArgs("Failed to generate Aggregate SQL", CheckResult.Fail, e));
            }
        }

        private int? _orderWithinKnownContainer;
        private int? _overrideFiltersByUsingParentAggregateConfigurationInsteadID;
        private int? _rootFilterContainerID;

        [NoMappingToDatabase]
        public int Order
        {
            get
            {
                if (_orderWithinKnownContainer == null)
                    throw new NotSupportedException(this +" is not part of any known containers");

                return (int) _orderWithinKnownContainer;
            }

            set
            {
                CohortAggregateContainer.SetOrderIfExistsFor(this,value);
                _orderWithinKnownContainer = value;
            }
        }

        [NoMappingToDatabase]
        public bool IsCohortIdentificationAggregate { get {return Name.StartsWith(CohortIdentificationConfiguration.CICPrefix);} }


        public CohortAggregateContainer GetCohortAggregateContainerIfAny()
        {
            return
                Repository.SelectAllWhere<CohortAggregateContainer>(
                    "SELECT CohortAggregateContainer_ID FROM CohortAggregateContainer_AggregateConfiguration WHERE AggregateConfiguration_ID = @AggregateConfiguration_ID", "CohortAggregateContainer_ID",
                    new Dictionary<string, object>
                    {
                        {"AggregateConfiguration_ID", ID}
                    }).SingleOrDefault();
        }
    }
}

using CatalogueManager.MainFormUITabs.SubComponents; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved

namespace DataQualityEngineUI
{
    partial class DataQualityEngineMainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DataQualityEngineMainForm));
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.catalogues = new CatalogueManager.MainFormUITabs.SubComponents.CatalogueCollectionHost();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.btnCheck = new System.Windows.Forms.Button();
            this.btnStartCatalogueConstraintReport = new System.Windows.Forms.Button();
            this.checksUI1 = new ReusableUIComponents.ChecksUI.ChecksUI();
            this.progressUI1 = new ReusableUIComponents.Progress.ProgressUI();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.refreshToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.refreshCataloguesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer1.Location = new System.Drawing.Point(0, 27);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.catalogues);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
            this.splitContainer1.Size = new System.Drawing.Size(1469, 704);
            this.splitContainer1.SplitterDistance = 421;
            this.splitContainer1.TabIndex = 1;
            // 
            // catalogues
            // 
            this.catalogues.AutoSize = true;
            this.catalogues.Collection = null;
            this.catalogues.Dock = System.Windows.Forms.DockStyle.Fill;
            this.catalogues.Location = new System.Drawing.Point(0, 0);
            this.catalogues.Name = "catalogues";
            this.catalogues.Size = new System.Drawing.Size(421, 704);
            this.catalogues.TabIndex = 0;
            // 
            // splitContainer2
            // 
            this.splitContainer2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.btnCheck);
            this.splitContainer2.Panel1.Controls.Add(this.btnStartCatalogueConstraintReport);
            this.splitContainer2.Panel1.Controls.Add(this.checksUI1);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.progressUI1);
            this.splitContainer2.Size = new System.Drawing.Size(1044, 704);
            this.splitContainer2.SplitterDistance = 411;
            this.splitContainer2.TabIndex = 0;
            // 
            // btnCheck
            // 
            this.btnCheck.Location = new System.Drawing.Point(69, 24);
            this.btnCheck.Name = "btnCheck";
            this.btnCheck.Size = new System.Drawing.Size(199, 23);
            this.btnCheck.TabIndex = 1;
            this.btnCheck.Text = "1. Check Catalogue Validation";
            this.btnCheck.UseVisualStyleBackColor = true;
            this.btnCheck.Click += new System.EventHandler(this.btnCheck_Click);
            // 
            // btnStartCatalogueConstraintReport
            // 
            this.btnStartCatalogueConstraintReport.Location = new System.Drawing.Point(69, 53);
            this.btnStartCatalogueConstraintReport.Name = "btnStartCatalogueConstraintReport";
            this.btnStartCatalogueConstraintReport.Size = new System.Drawing.Size(199, 23);
            this.btnStartCatalogueConstraintReport.TabIndex = 1;
            this.btnStartCatalogueConstraintReport.Text = "2. Start Data Quality Engine Execution";
            this.btnStartCatalogueConstraintReport.UseVisualStyleBackColor = true;
            this.btnStartCatalogueConstraintReport.Click += new System.EventHandler(this.btnStartCatalogueConstraintReport_Click);
            // 
            // checksUI1
            // 
            this.checksUI1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.checksUI1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.checksUI1.Location = new System.Drawing.Point(3, 82);
            this.checksUI1.Name = "checksUI1";
            this.checksUI1.Size = new System.Drawing.Size(403, 617);
            this.checksUI1.TabIndex = 0;
            // 
            // progressUI1
            // 
            this.progressUI1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.progressUI1.Location = new System.Drawing.Point(0, 0);
            this.progressUI1.Name = "progressUI1";
            this.progressUI1.Size = new System.Drawing.Size(627, 702);
            this.progressUI1.TabIndex = 1;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.refreshToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1469, 24);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // refreshToolStripMenuItem
            // 
            this.refreshToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.refreshCataloguesToolStripMenuItem});
            this.refreshToolStripMenuItem.Name = "refreshToolStripMenuItem";
            this.refreshToolStripMenuItem.Size = new System.Drawing.Size(70, 20);
            this.refreshToolStripMenuItem.Text = "Locations";
            // 
            // refreshCataloguesToolStripMenuItem
            // 
            this.refreshCataloguesToolStripMenuItem.Name = "refreshCataloguesToolStripMenuItem";
            this.refreshCataloguesToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.refreshCataloguesToolStripMenuItem.Text = "Refresh All";
            this.refreshCataloguesToolStripMenuItem.Click += new System.EventHandler(this.refreshCataloguesToolStripMenuItem_Click);
            // 
            // DataQualityEngineMainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1469, 731);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.splitContainer1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "DataQualityEngineMainForm";
            this.Text = "Data Quality Engine UI";
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private CatalogueCollectionHost catalogues;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private ReusableUIComponents.Progress.ProgressUI progressUI1;
        private System.Windows.Forms.Button btnStartCatalogueConstraintReport;
        private ReusableUIComponents.ChecksUI.ChecksUI checksUI1;
        private System.Windows.Forms.Button btnCheck;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem refreshToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem refreshCataloguesToolStripMenuItem;

    }
}


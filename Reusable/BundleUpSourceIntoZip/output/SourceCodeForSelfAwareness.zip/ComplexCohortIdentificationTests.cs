using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Linq;
using System.Text.RegularExpressions;
using CatalogueLibrary.Data;
using CatalogueLibrary.Data.Aggregation;
using CatalogueLibrary.Data.Cohort;
using Diagnostics.TestData;
using NUnit.Framework;
using Tests.Common;

namespace CohortManagerTests.cs
{
    public class ComplexCohortIdentificationTests : DatabaseTests
    {

        protected BulkTestsData testData;
        protected AggregateConfiguration aggregate1;
        protected AggregateConfiguration aggregate2;
        protected AggregateConfiguration aggregate3;
        protected CohortIdentificationConfiguration cohortIdentificationConfiguration;
        protected CohortAggregateContainer rootcontainer;
        protected CohortAggregateContainer container1;

        [SetUp]
        public void SetupTestData()
        {
            testData = new BulkTestsData(CatalogueRepository,DatabaseICanCreateRandomTablesIn, 100);
            testData.SetupTestData();

            testData.ImportAsCatalogue();
           
            aggregate1 =
                new AggregateConfiguration(CatalogueRepository,testData.catalogue, "UnitTestAggregate1");

            new AggregateDimension(CatalogueRepository,testData.extractionInformations.Single(e => e.GetRuntimeName().Equals("chi")), aggregate1);

            aggregate2 =
                new AggregateConfiguration(CatalogueRepository,testData.catalogue, "UnitTestAggregate2");

            new AggregateDimension(CatalogueRepository,testData.extractionInformations.Single(e => e.GetRuntimeName().Equals("chi")), aggregate2);

            aggregate3 =
                new AggregateConfiguration(CatalogueRepository, testData.catalogue, "UnitTestAggregate3");

            new AggregateDimension(CatalogueRepository,testData.extractionInformations.Single(e => e.GetRuntimeName().Equals("chi")), aggregate3);

            cohortIdentificationConfiguration = new CohortIdentificationConfiguration (CatalogueRepository,"UnitTestIdentification");

            rootcontainer = new CohortAggregateContainer(CatalogueRepository,SetOperation.EXCEPT);
            container1 = new CohortAggregateContainer(CatalogueRepository,SetOperation.UNION);

            cohortIdentificationConfiguration.RootCohortAggregateContainer_ID = rootcontainer.ID;
            cohortIdentificationConfiguration.SaveToDatabase();
        }

        [TearDown]
        public void Cleanup()
        {

            container1.DeleteInDatabase();

            if (aggregate1 != null)
                aggregate1.DeleteInDatabase();
            
            if (aggregate2 != null)
                aggregate2.DeleteInDatabase();

            if (aggregate3 != null)
                aggregate3.DeleteInDatabase();


            if (cohortIdentificationConfiguration != null)
                cohortIdentificationConfiguration.DeleteInDatabase();
            
            if (testData != null)
                testData.DeleteCatalogue();
        }

        [TestFixtureTearDown]
        public void AfterAllTests()
        {
            testData.Destroy();
        }

        [Test]
        public void AggregateOrdering_ExplicitSetting_CorrectOrder()
        {
            try
            {
                //set the order so that 2 comes before 1
                rootcontainer.AddChild(aggregate2, 1);
                rootcontainer.AddChild(aggregate1, 5);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }

            try
            {
                Assert.AreEqual(1,aggregate2.Order);
                Assert.AreEqual(5, aggregate1.Order);

                Assert.AreEqual(rootcontainer.GetAggregateConfigurations()[0].ID, aggregate2.ID);
                Assert.AreEqual(rootcontainer.GetAggregateConfigurations()[1].ID, aggregate1.ID);
            }
            finally
            {
                rootcontainer.RemoveChild(aggregate1);
                rootcontainer.RemoveChild(aggregate2);
            }
        }
        
        [Test]
        public void CloneChild_NamingCorrectNewObject()
        {
            
            //should not follow naming convention
            Assert.IsFalse(cohortIdentificationConfiguration.IsValidNamedConfiguration(aggregate1));

            //add a clone using aggregate1 as a template 
            var clone = cohortIdentificationConfiguration.CreateCloneOfConfiguration(aggregate1);
            //add the clone
            rootcontainer.AddChild(clone, 0);

            try
            {
                //there should be 1 child
                AggregateConfiguration[] aggregateConfigurations = rootcontainer.GetAggregateConfigurations();
                Assert.AreEqual(1,aggregateConfigurations.Length);

                //child should follow naming convention
                Assert.IsTrue(cohortIdentificationConfiguration.IsValidNamedConfiguration(aggregateConfigurations[0]));

                //clone should have a different ID - also it was created after so should be higher ID
                Assert.Greater(aggregateConfigurations[0].ID,aggregate1.ID);

            }
            finally
            {
                rootcontainer.RemoveChild(clone);
                clone.DeleteInDatabase();
            }
        }
        [Test]
        public void CloneChildWithFilter_IDsDifferent()
        {

            var container = new AggregateFilterContainer(CatalogueRepository,FilterContainerOperation.OR);

            aggregate1.RootFilterContainer_ID = container.ID;
            aggregate1.SaveToDatabase();

            var filter = new AggregateFilter(CatalogueRepository,"MyFilter", container);
            filter.WhereSQL = "sex=@sex";
            filter.CreateOrDeleteParametersBasedOnSQL(filter.GetAllParameters());
            filter.SaveToDatabase();

            var param = (AggregateFilterParameter)filter.GetAllParameters().Single();
            param.Value = "'M'";
            param.SaveToDatabase();
            
            //add a clone using aggregate1 as a template 
            var clone = cohortIdentificationConfiguration.CreateCloneOfConfiguration(aggregate1);
            
            //get the sql
            Assert.DoesNotThrow(() => Console.WriteLine(aggregate1.GetQueryBuilder().SQL));
            

            try
            {
                Assert.AreNotEqual(clone.ID,aggregate1.ID);
                Assert.AreNotEqual(clone.RootFilterContainer_ID, aggregate1.RootFilterContainer_ID);


                var cloneContainer = clone.RootFilterContainer;
                var cloneFilter = cloneContainer.GetFilters().Single();

                Assert.AreNotEqual(cloneContainer.ID, container.ID);
                Assert.AreNotEqual(cloneFilter.ID, filter.ID);

                var cloneParameter = (AggregateFilterParameter)cloneFilter.GetAllParameters().Single();
                Assert.AreNotEqual(cloneParameter.ID, param.ID);


                Assert.DoesNotThrow(() => Console.WriteLine(clone.GetQueryBuilder().SQL));

                //it has a different ID and is part of an aggregate filter container (It is presumed to be involved with cohort identification cohortIdentificationConfiguration) which means it will be called cic_X_
                string cohortAggregateSql = clone.GetQueryBuilder().SQL;
                cohortAggregateSql = cohortAggregateSql.Replace("cic_" + cohortIdentificationConfiguration.ID+ "_", "");
                Assert.AreEqual(aggregate1.GetQueryBuilder().SQL, cohortAggregateSql);
            }
            finally
            {
                clone.DeleteInDatabase();
            }
        }
        
    }
}

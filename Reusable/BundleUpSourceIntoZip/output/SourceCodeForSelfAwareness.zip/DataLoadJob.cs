using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.IO;
using System.Linq;
using CatalogueLibrary;
using CatalogueLibrary.Data;
using CatalogueLibrary.Data.DataLoad;
using CatalogueLibrary.Data.EntityNaming;
using CatalogueLibrary.Repositories;
using DataLoadEngine.DatabaseManagement.Operations;
using DataLoadEngine.LoadProcess;
using HIC.Logging;
using ReusableLibraryCode;
using ReusableLibraryCode.Progress;

namespace DataLoadEngine.Job
{
    public class DataLoadJob : IDataLoadJob
    {
        public string Description { get; private set; }
        public IDataLoadInfo DataLoadInfo { get; private set; }
        public IHICProjectDirectory HICProjectDirectory { get; set; }
        private readonly IDataLoadEventListener _listener;

        public int JobID { get; set; }

        private readonly Stack<IDisposeAfterDataLoad> _toDisposeAfterDataLoad = new Stack<IDisposeAfterDataLoad>();
        private readonly Stack<IDisposeAfterDataLoad> _toDisposeAfterStage = new Stack<IDisposeAfterDataLoad>();

        private readonly ILogManager _logManager;
        public ILoadMetadata LoadMetadata { get; private set; }

        public List<TableInfo> RegularTablesToLoad { get; private set; }
        public List<TableInfo> LookupTablesToLoad { get; private set; }

        private string _loggingTask;

        public DataLoadJob(string description, ILogManager logManager, ILoadMetadata loadMetadata, IHICProjectDirectory hicProjectDirectory, IDataLoadEventListener listener)
        {
            _logManager = logManager;
            LoadMetadata = loadMetadata;
            HICProjectDirectory = hicProjectDirectory;
            _listener = listener;
            Description = description;
            DisposeImmediately = false;

            List<ICatalogue> catalogues = LoadMetadata.GetAllCatalogues().ToList();
            
            if (LoadMetadata != null)
                _loggingTask = GetLoggingTask(catalogues);

            RegularTablesToLoad = catalogues.SelectMany(catalogue => catalogue.GetTableInfoList(false)).Distinct().ToList();
            LookupTablesToLoad = catalogues.SelectMany(catalogue => catalogue.GetLookupTableInfoList()).Distinct().ToList();
        }

        private string GetLoggingTask(IEnumerable<ICatalogue> cataloguesToLoad)
        {
            var distinctLoggingTasks = cataloguesToLoad.Select(catalogue => catalogue.LoggingDataTask).Distinct().ToList();
            if (distinctLoggingTasks.Count() > 1)
                throw new Exception("The catalogues to be loaded do not share the same logging task: " + string.Join(", ", distinctLoggingTasks));

            _loggingTask = distinctLoggingTasks.First();
            if (string.IsNullOrWhiteSpace(_loggingTask))
                throw new Exception("There is no logging task specified for this load (the name is blank)");

            return _loggingTask;
        }

        private void CreateDataLoadInfo()
        {
            if (string.IsNullOrWhiteSpace(Description))
                throw new Exception("The data load description (for the DataLoadInfo object) must not be empty, please provide a relevant description");

            DataLoadInfo = _logManager.CreateDataLoadInfo(_loggingTask, typeof(MultiStageDataLoadProcess).Name, Description, "", false);

            if (DataLoadInfo == null)
                throw new Exception("DataLoadInfo is null");

            JobID = DataLoadInfo.ID;
        }

        public void LogProgress(string senderName, string message)
        {
            if (DataLoadInfo == null)
                throw new Exception("Logging hasn't been started for this job (call StartLogging first)");

            if (!DataLoadInfo.IsClosed)
                _logManager.LogProgress(DataLoadInfo, ProgressLogging.ProgressEventType.OnProgress, senderName, message);
        }

        public void LogError(string message, Exception exception)
        {
            // we are bailing out before the load process has had a chance to create a DataLoadInfo object
            if (DataLoadInfo == null)
                CreateDataLoadInfo();

            _logManager.LogFatalError(DataLoadInfo, typeof(MultiStageDataLoadProcess).Name, message + Environment.NewLine + ExceptionHelper.ExceptionToListOfInnerMessages(exception));
            DataLoadInfo.CloseAndMarkComplete();
        }

        public void StartLogging()
        {
            CreateDataLoadInfo();
        }

        public void CloseLogging()
        {
            if (DataLoadInfo != null)
                DataLoadInfo.CloseAndMarkComplete();
        }

        public void LogInformation(string senderName, string message)
        {
            if (DataLoadInfo == null)
                throw new Exception("Logging hasn't been started for this job (call StartLogging first)");

            if(!DataLoadInfo.IsClosed)
                _logManager.LogProgress(DataLoadInfo, ProgressLogging.ProgressEventType.OnInformation, senderName, message);
        }

        public void LogWarning(string senderName, string message)
        {
            if (DataLoadInfo == null)
                throw new Exception("Logging hasn't been started for this job (call StartLogging first)");

            if (!DataLoadInfo.IsClosed)
                _logManager.LogProgress(DataLoadInfo, ProgressLogging.ProgressEventType.OnWarning, senderName, message);
        }

        /// <summary>
        /// It is *extremely* important that the IDisposeAfterDataLoad objects given to this function do not maintain job-specific state which is subsequently
        /// used for disposal after completion of the whole process. Another job may have entered the component before a previous job exits the pipeline. In that case
        /// state for the new job will be used during disposal. Need to force this through interfaces rather than relying on the caller to behave.
        /// 
        /// I have used a 'disposal object' called DeleteCachedFilesOperation to dispose of work done by CachedFileRetriever. CachedFileRetriever pushes that on to
        /// the job's disposal stack.
        /// </summary>
        /// <param name="disposable"></param>
        public void AddForDisposalAfterCompletion(IDisposeAfterDataLoad disposable)
        {
            if (disposable.DisposeImmediately)
                _toDisposeAfterStage.Push(disposable);
            else
                _toDisposeAfterDataLoad.Push(disposable);
        }

        public bool DisposeImmediately { get; private set; }

        public void LoadCompletedSoDispose(ExitCodeType exitCode)
        {
            if (exitCode == ExitCodeType.Success)
            {
                while (_toDisposeAfterDataLoad.Any())
                    _toDisposeAfterDataLoad.Pop().LoadCompletedSoDispose(exitCode, this);
            }
        }

        public void StageCompletedSoDispose(ExitCodeType exitCode)
        {
            if (exitCode == ExitCodeType.Success)
            {
                while (_toDisposeAfterStage.Any())
                    _toDisposeAfterStage.Pop().LoadCompletedSoDispose(exitCode,this);
            }
        }

        public void CreateTablesInStage(DatabaseCloner cloner, INameDatabasesAndTablesDuringLoads namingScheme, LoadBubble stage)
        {
            foreach (TableInfo regularTableInfo in RegularTablesToLoad)
                cloner.CreateTablesInDatabaseFromCatalogueInfo(regularTableInfo, stage, namingScheme);

            foreach (TableInfo lookupTableInfo in LookupTablesToLoad)
                 cloner.CreateTablesInDatabaseFromCatalogueInfo(lookupTableInfo, stage, namingScheme);
            
            AddForDisposalAfterCompletion(cloner);
        }

        public void OnNotify(object sender, NotifyEventArgs e)
        {
            if(DataLoadInfo != null)
                switch (e.ProgressEventType)
                {
                    case ProgressEventType.Information:
                        _logManager.LogProgress(DataLoadInfo, ProgressLogging.ProgressEventType.OnInformation, sender.GetType().Name, e.Message + (e.Exception != null ? "Exception=" + ExceptionHelper.ExceptionToListOfInnerMessages(e.Exception) : ""));
                        break;
                    case ProgressEventType.Warning:
                        _logManager.LogProgress(DataLoadInfo, ProgressLogging.ProgressEventType.OnWarning, sender.GetType().Name, e.Message + (e.Exception != null ? "Exception=" + ExceptionHelper.ExceptionToListOfInnerMessages(e.Exception) : ""));
                        break;
                    case ProgressEventType.Error:
                        _logManager.LogProgress(DataLoadInfo, ProgressLogging.ProgressEventType.OnTaskFailed, sender.GetType().Name, e.Message);
                        _logManager.LogFatalError(DataLoadInfo, sender.GetType().Name, e.Exception != null ? ExceptionHelper.ExceptionToListOfInnerMessages(e.Exception) : e.Message);
                        break;
                    default:
                        throw new ArgumentOutOfRangeException();
                }
            _listener.OnNotify(sender,e);
        }

        public void OnProgress(object sender, ProgressEventArgs e)
        {
            _listener.OnProgress(sender,e);
        }

        public string ArchiveFilepath
        {
            get { return Path.Combine(HICProjectDirectory.ForArchiving.FullName, DataLoadInfo.ID + ".zip"); }
        }


    }

    
}

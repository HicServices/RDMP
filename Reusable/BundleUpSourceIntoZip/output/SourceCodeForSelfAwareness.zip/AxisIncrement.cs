namespace ReusableLibraryCode.DatabaseHelpers.Discovery.QuerySyntax.Aggregation
{
    public enum AxisIncrement
    {
        Day = 1,
        Month = 2,
        Year = 3,
        Quarter=4
    }
}

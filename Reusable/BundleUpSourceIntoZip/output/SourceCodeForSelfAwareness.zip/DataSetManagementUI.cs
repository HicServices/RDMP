using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using CatalogueLibrary.Data;
using CatalogueManager.MainFormUITabs.SubComponents;
using CatalogueManager.TestsAndSetup.ServicePropogation;
using DataExportManager2Library.Data.DataTables;
using ReusableUIComponents;

namespace DataExportManager2.DataSetUI
{
    /// <summary>
    /// Lets you choose which datasets (Catalogues) are extractable as part of research projects.   On the left are all the datasets (Catalogues) you currently have configured in your 
    /// Catalogue Manager Database.  On the right are all those that are currently configured as extractable. 
    /// 
    /// To make a Catalogue extractable, select it and press 'Import As ExtractableDataset'
    /// 
    /// If you don't see a Catalogue you expect to be there on the left then it is likely either already extractable or it doesn't have any columns configured for extraction (See 
    /// ExtractionInformationUI).  Also make sure that it has an IsExtractionIdentifier column (i.e. the patient private identifier field).
    /// 
    /// TECHNICAL: Currently an ExtractableDataset is simply a record in the Data Export Manager dataset which records the ID of the Catalogue record and whether it is temporarily disabled
    /// for extraction.  It mostly exists for future proofing for exmaple if we want to specify dataset level governance rules (Catalogue 'Prescribing' is only available with X special 
    /// approval) rather than the current state which is for all governance levels to be configured on column level.  We could add such a field into the ExtractableDataset table schema 
    /// instead of the Catalogue table schema.
    /// </summary>
    public partial class DataSetManagementUI : RDMPUserControl
    {
        public event ChangesSavedHandler ChangesSaved;

        readonly FilterControl<ListBox> _filter = new FilterControl<ListBox>();
        public DataSetManagementUI()
        {
            InitializeComponent();
        }

        protected override void OnLoad(EventArgs e)
        {
            if(VisualStudioDesignMode)
                return;
        
            RefreshDataSetListbox();
            RefreshCatalogueCollection();
            this.dataSetUI1.ChangesSaved += new ChangesSavedHandler(dataSetUI1_ChangesSaved);
            this.catalogueCollectionHost1.CollectionChanged += (s, ev) => RefreshUIFromDatabase();

            base.OnLoad(e);
        }

        public void RefreshUIFromDatabase()
        {
            RefreshCatalogueCollection();
            RefreshDataSetListbox();
            dataSetUI1.RefreshUIFromDatabase();
        }

        private void RefreshCatalogueCollection()
        {
            
            var catalogues = RepositoryLocator.CatalogueRepository.GetAllCataloguesWithAtLeastOneExtractableItem();
            var extractableDatasets = RepositoryLocator.DataExportRepository.GetAllObjects<ExtractableDataSet>().ToArray();

            //get only those catalogues that are not already in the system
            var cataloguesNotYetImported = catalogues.Where(c => extractableDatasets.All(e => e.Catalogue_ID != c.ID));

            catalogueCollectionHost1.Collection = new ObservableCollection<Catalogue>(cataloguesNotYetImported.ToArray().ToArray());
        }

        void dataSetUI1_ChangesSaved()
        {
            RefreshDataSetListbox();

            if (ChangesSaved != null)
                ChangesSaved();
        }

        private void RefreshDataSetListbox()
        {
            _filter.ClearHiddenNodes(lbDataSets);



            var extractableDataSets = RepositoryLocator.DataExportRepository.GetAllObjects<ExtractableDataSet>().Where(ds => !ds.IsCatalogueDeprecated).ToArray();
            lbDataSets.Items.Clear();
            lbDataSets.Items.AddRange(extractableDataSets);

            var duplicates = extractableDataSets.Where(ds => extractableDataSets.Count(duplicate => duplicate.Catalogue_ID == ds.Catalogue_ID) > 1).ToArray();

            if (duplicates.Any())
                WideMessageBox.Show("The following ExtractableDatasets share the same Catalogue:" + Environment.NewLine + string.Join(Environment.NewLine+"\t",
                    duplicates.Select(d=>d.ToString() + " (ID="+d.ID+" Catalogue_ID=" + d.Catalogue_ID + ")")));




            _filter.ApplyFilter(lbDataSets, tbFilter.Text);
        }


        private void lbCohortDatabaseTable_SelectedIndexChanged(object sender, EventArgs e)
        {

            
            ExtractableDataSet d = lbDataSets.SelectedItem as ExtractableDataSet;

            if (d!= null && d.ToString().StartsWith("Catalogue Deleted"))
            {
                this.dataSetUI1.ExtractableDataSet = null;
                return;
            }

            try
            {
                this.dataSetUI1.ExtractableDataSet = lbDataSets.SelectedItem as ExtractableDataSet;
            }
            catch (Exception ex)
            {
                ExceptionViewer.Show(ex);
            }
        }

        private void btnCohortDatabaseTableAdd_Click(object sender, EventArgs e)
        {
            try
            {
                if (lbDataSets.Items.Cast<ExtractableDataSet>().Any(ds => ds.Catalogue_ID == null))
                {
                    MessageBox.Show("There is already an unassigned dataset (" +
                                    ExtractableDataSet.UnassignedCatalogueName +
                                    ") - assign this ID to your Catalogue instead of creating a new one.");
                    return;
                }
                new ExtractableDataSet(RepositoryLocator.DataExportRepository);
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message);
            }
            RefreshDataSetListbox();

        }

        private void lbCohortDatabaseTable_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete && lbDataSets.SelectedItem != null)
            {
                ExtractableDataSet toDelete = lbDataSets.SelectedItem as ExtractableDataSet;

                if (MessageBox.Show("Are you sure you want to delete " + toDelete + " (ID=" + toDelete.ID + ")",
                                    "Confirm Delete", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    try
                    {
                        toDelete.DeleteInDatabase();
                    }
                    catch (Exception exception)
                    {
                        ExceptionViewer.Show(exception);
                    }

                    this.dataSetUI1.ExtractableDataSet = null; //clear it incase they were editting the same one they are trying to delete
                    RefreshUIFromDatabase();
                    
                    if (ChangesSaved != null)
                        ChangesSaved();
                }
                else
                    return;

            }
        }

        private void lbDataSets_DrawItem(object sender, DrawItemEventArgs e)
        {
           
                e.DrawBackground();
                Graphics g = e.Graphics;

                // draw the background color
                g.FillRectangle(new SolidBrush(e.BackColor), e.Bounds);

                // draw the text of the list item, not doing this will only show
                // the background color
                // you will need to get the text of item to display

                if (e.Index != -1)
                {
                    ExtractableDataSet item = (ExtractableDataSet) (sender as ListBox).Items[e.Index];
                    string toDisplay = item.ToString();

                    //highlight the red one with Null Catalogue
                    g.DrawString(toDisplay, e.Font,
                        toDisplay.Equals(ExtractableDataSet.UnassignedCatalogueName) ? new SolidBrush(Color.Red) : new SolidBrush(e.ForeColor),
                        new PointF(e.Bounds.X, e.Bounds.Y));
                }


            e.DrawFocusRectangle();
            
        }

        private void tbFilter_TextChanged(object sender, EventArgs e)
        {
            _filter.ApplyFilter(lbDataSets,tbFilter.Text);
        }

        private void btnImportAsExtractableDataset_Click(object sender, EventArgs e)
        {

            if(catalogueCollectionHost1.SelectedCatalogue != null)
            {
                ExtractableDataSet extractableDataset = null;
                try
                {
                    extractableDataset = new ExtractableDataSet(RepositoryLocator.DataExportRepository);
                    extractableDataset.Catalogue_ID = catalogueCollectionHost1.SelectedCatalogue.ID;
                    extractableDataset.SaveToDatabase();
                }
                catch (Exception exception)
                {
                    ExceptionViewer.Show(exception);

                    if(extractableDataset != null)
                        extractableDataset.DeleteInDatabase();
                }
                RefreshUIFromDatabase();
            }
        }

    }
}

using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using CatalogueLibrary;
using CatalogueLibrary.Data.DataLoad;
using CatalogueLibrary.DataFlowPipeline;
using DataLoadEngine.DataProvider;
using DataLoadEngine.Job;
using ReusableLibraryCode.Checks;
using ReusableLibraryCode.Progress;

namespace LoadModules.Generic.DataProvider
{
    public class DoNothingDataProvider : IDataProvider
    {

        public ProcessExitCode Fetch(IDataLoadJob job, GracefulCancellationToken cancellationToken)
        {
            job.OnNotify(this, new NotifyEventArgs(ProgressEventType.Warning,"DoNothingDataProvider did nothing!"));
            return ProcessExitCode.Success;
            
        }

        public string GetDescription()
        {
            return "Do nothing data provider, does nothing";
        }

        public IDataProvider Clone()
        {
            throw new NotImplementedException();
        }

        public bool Validate(IHICProjectDirectory destination)
        {
            return true;
        }

        public bool DisposeImmediately { get; set; }

        public void LoadCompletedSoDispose(ExitCodeType exitCode,IDataLoadEventListener postLoadEventListener)
        {
        }

        
        public void Check(ICheckNotifier notifier)
        {
            
        }
    }
}

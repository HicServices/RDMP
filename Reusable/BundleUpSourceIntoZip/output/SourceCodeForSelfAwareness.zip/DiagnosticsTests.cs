using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.IO;
using System.Reflection;
using Diagnostics;
using MapsDirectlyToDatabaseTable;
using NUnit.Framework;
using ReusableLibraryCode;
using ReusableLibraryCode.Checks;
using ReusableLibraryCode.DatabaseHelpers.Discovery;
using Tests.Common;

namespace CatalogueLibraryTests.Integration
{
    
    
    public class DiagnosticsTests:DatabaseTests, ICheckNotifier
    {
        [Test]
        public void TestSetupTestDatasetEnvironment()
        {
            string whereIsTheBinDirectory = Assembly.GetExecutingAssembly().Location;
            
            Console.WriteLine("I think the bin directory is in:" + Path.GetDirectoryName(whereIsTheBinDirectory));


            var testEnvironment = new UserAcceptanceTestEnvironment(
                ServerICanCreateRandomDatabasesAndTablesOn,
                Path.GetDirectoryName(whereIsTheBinDirectory),
                UnitTestLoggingConnectionString,
                "Nothing",
                null,
                null, 
                RepositoryLocator) {SilentRunning = true};

            testEnvironment.Check(this);
        }

        public bool OnCheckPerformed(CheckEventArgs args)
        {
            if (args.Result == CheckResult.Fail && args.Ex != null)
                throw args.Ex;
            
            if(args.Result == CheckResult.Fail)
                throw new Exception("Setup failed with message :" + args.Message);

            //apply any suggested fixes
            return true;
        }
    }

}

using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using CachingEngine;
using CatalogueLibrary;
using CatalogueLibrary.Data;
using CatalogueLibrary.Data.DataLoad;
using CatalogueLibrary.Data.Pipelines;
using CatalogueLibrary.DataFlowPipeline;
using NUnit.Framework;
using ReusableLibraryCode.Progress;
using Rhino.Mocks;
using Tests.Common;

namespace CachingEngineTests.Integration
{
    [Category("Integration")]
    public class CachingHostTests : DatabaseTests
    {

        public CachingHostTests()
        {
            HowMuchDoICare = CarePolice.IDontCareAboutAnythingOrAnyone;
        }
        private ICacheProgress CreateCacheProgressStubWithUnlockedLoadSchedule()
        {
            var cacheProgress = MockRepository.GenerateStub<ICacheProgress>();

            var loadSchedule = MockRepository.GenerateStub<ILoadProgress>();
            loadSchedule.LockedBecauseRunning = false;
            loadSchedule.IsDisabled = false;

            cacheProgress.Stub(progress => progress.GetLoadProgress()).Return(loadSchedule);

            return cacheProgress;
        }

        /// <summary>
        /// Makes sure that a cache progress pipeline will be run if we are within a permission window
        /// </summary>
        [Test]
        public void CacheHostWithinPermissionWindow()
        {
            var rootDir = new DirectoryInfo(".");
            var testDir = rootDir.CreateSubdirectory("CacheHostWithinPermissionWindow");

            if (testDir.Exists)
                Directory.Delete(testDir.FullName, true);

            var hicProjectDirectory = HICProjectDirectory.CreateDirectoryStructure(testDir, "Test");
            var loadMetadata = MockRepository.GenerateStub<ILoadMetadata>();
            loadMetadata.LocationOfFlatFiles = hicProjectDirectory.RootPath.FullName;

            var listener = new ToConsoleDataLoadEventReciever();

            var cacheProgress = CreateCacheProgressStubWithUnlockedLoadSchedule();
            cacheProgress.CacheFillProgress = DateTime.Now.AddDays(-1);
            cacheProgress.PermissionWindow_ID = 1;
            cacheProgress.GetLoadProgress().Stub(schedule => schedule.GetLoadMetadata()).Return(loadMetadata);

            var permissionWindow = MockRepository.GenerateStub<IPermissionWindow>();
            permissionWindow.RequiresSynchronousAccess = true;
            permissionWindow.ID = 1;
            permissionWindow.Stub(window => window.CurrentlyWithinPermissionWindow()).Return(true);
            permissionWindow.Stub(window => window.GetAllCacheProgresses()).Return(new List<ICacheProgress> {cacheProgress});

            cacheProgress.Stub(progress => progress.GetPermissionWindow()).Return(permissionWindow);

            // expect the engine's ExecutePipeline to be called only once
            var dataFlowPipelineEngine = MockRepository.GenerateMock<IDataFlowPipelineEngine>();
            
            // set up a factory stub to return our engine mock
            var dynamicPipelineEngineFactory = MockRepository.GenerateMock<IDynamicPipelineEngineFactory>();
            dynamicPipelineEngineFactory.Stub(factory => factory.Create(cacheProgress, listener)).Return(dataFlowPipelineEngine);

            var cacheHost = new CachingHost(dynamicPipelineEngineFactory, CatalogueRepository)
            {
                CacheProgressList = new List<ICacheProgress> {cacheProgress},
                PermissionWindows = new List<IPermissionWindow> {permissionWindow}
            };

            var stopTokenSource = new CancellationTokenSource();
            var abortTokenSource = new CancellationTokenSource();
            var cancellationToken = new GracefulCancellationToken(stopTokenSource.Token, abortTokenSource.Token);
            var cancellationSource = cancellationToken.CreateLinkedSource();

            var task = Task.Run(() => cacheHost.Start(listener, cancellationToken), cancellationSource.Token);
            Thread.Sleep(500);
            abortTokenSource.Cancel();

            try
            {
                task.Wait();
            }
            catch (AggregateException e)
            {
                Assert.AreEqual(1, e.InnerExceptions.Count);
                Assert.IsInstanceOf(typeof(OperationCanceledException), e.InnerExceptions[0]);

                dataFlowPipelineEngine.AssertWasCalled(engine => engine.ExecuteSinglePass(cancellationToken), options =>
                {
                    options.IgnoreArguments(); // ExecutePipeline is called with a different cancellation token, provided and monitored by the PermissionWindowCacheDownloader
                    options.Repeat.Once();
                });

                testDir.Delete(true);
            }
        }

        /// <summary>
        /// Makes sure that a cache progress pipeline will not be run if we are outside the permission window
        /// </summary>
        [Test]
        public void CacheHostOutwithPermissionWindow()
        {
            var rootDir = new DirectoryInfo(".");
            var testDir = rootDir.CreateSubdirectory("C");

            if (testDir.Exists)
                Directory.Delete(testDir.FullName, true);

            var hicProjectDirectory = HICProjectDirectory.CreateDirectoryStructure(testDir, "Test");
            var loadMetadata = MockRepository.GenerateStub<ILoadMetadata>();
            loadMetadata.LocationOfFlatFiles = hicProjectDirectory.RootPath.FullName;

            var listener = new ToConsoleDataLoadEventReciever();

            var cacheProgress = CreateCacheProgressStubWithUnlockedLoadSchedule();
            cacheProgress.CacheFillProgress = DateTime.Now.AddDays(-1);
            cacheProgress.PermissionWindow_ID = 1;
            cacheProgress.GetLoadProgress().Stub(schedule => schedule.GetLoadMetadata()).Return(loadMetadata);

            var permissionWindow = MockRepository.GenerateStub<IPermissionWindow>();
            permissionWindow.RequiresSynchronousAccess = true;
            permissionWindow.ID = 1;
            permissionWindow.Name = "Test Permission Window";
            permissionWindow.Stub(window => window.CurrentlyWithinPermissionWindow()).Return(false);

            cacheProgress.Stub(progress => progress.GetPermissionWindow()).Return(permissionWindow);

            var dataFlowPipelineEngine = MockRepository.GenerateMock<IDataFlowPipelineEngine>();

            // set up a factory stub to return our engine mock
            var dynamicPipelineEngineFactory = MockRepository.GenerateMock<IDynamicPipelineEngineFactory>();
            dynamicPipelineEngineFactory.Stub(factory => factory.Create(cacheProgress, listener)).Return(dataFlowPipelineEngine);

            var cacheHost = new CachingHost(dynamicPipelineEngineFactory, CatalogueRepository)
            {
                CacheProgressList = new List<ICacheProgress> { cacheProgress },
                PermissionWindows = new List<IPermissionWindow> { permissionWindow }
            };

            var stopTokenSource = new CancellationTokenSource();
            var abortTokenSource = new CancellationTokenSource();
            var cancellationToken = new GracefulCancellationToken(stopTokenSource.Token, abortTokenSource.Token);

            var task = Task.Run(() => cacheHost.Start(listener, cancellationToken), cancellationToken.CreateLinkedSource().Token);

            abortTokenSource.Cancel();
            try
            {
                task.Wait();
            }
            catch (AggregateException e)
            {
                Assert.AreEqual(1, e.InnerExceptions.Count);
                Assert.IsInstanceOf(typeof(TaskCanceledException), e.InnerExceptions[0], e.InnerExceptions[0].Message);

                dataFlowPipelineEngine.AssertWasCalled(engine => engine.ExecutePipeline(cancellationToken), options => options.Repeat.Times(0));
                testDir.Delete(true);
            }
        }


    }
}

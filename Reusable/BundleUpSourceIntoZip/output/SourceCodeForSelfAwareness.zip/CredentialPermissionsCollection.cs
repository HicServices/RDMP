using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CatalogueLibrary.Data;
using CatalogueLibrary.Repositories;
using CatalogueManager.TestsAndSetup.ServicePropogation;
using ReusableLibraryCode.DataAccess;
using ReusableUIComponents;

namespace CatalogueManager.MainFormUITabs.SubComponents
{
    /// <summary>
    /// The preferred method for data access through the RDMP is via Integrated Security (Windows Authentication) but it also supports SQL Authentication 
    /// (See PasswordEncryptionKeyLocationUI for information about how passwords are protected).  
    /// 
    /// This control lets you view/delete access credentials on a data table (TableInfo) and specify the contexts under which the credentials can be used 
    /// (e.g. DataLoad/DataExport/Any etc).  Use Del to delete the usage permission.
    /// 
    /// </summary>
    public partial class CredentialPermissionsCollection : RDMPUserControl
    {
        public event EventHandler CollectionChanged;

        private class DeleteOperation
        {
            public DataAccessCredentials Credentials;
            public DataAccessContext Context;
            public TableInfo Point;
        }

        private ColumnHeader _dataAccessPointColumn;
        private ColumnHeader _contextColumn;
        private ColumnHeader _credentialsColumn;
        private List<string> _relationshipList = new List<string>();
        public bool AutoHideColumns { get; set; }

        public CredentialPermissionsCollection()
        {
            InitializeComponent();

            _dataAccessPointColumn = listView1.Columns[0];
            _contextColumn = listView1.Columns[1];
            _credentialsColumn = listView1.Columns[2];

            AutoHideColumns = true;
        }

        public void ShowAllRelationshipsFor(DataAccessCredentials credential)
        {
            try
            {

                listView1.Items.Clear();
                ResetColumns();

                foreach (KeyValuePair<DataAccessContext, List<TableInfo>> byContext in credential.GetAllTableInfosThatUseThis())
                    foreach (TableInfo someoneWhoUsesCredentialUnderThisContext in byContext.Value)
                    {
                        var item = new ListViewItem(new[] { someoneWhoUsesCredentialUnderThisContext.Name, byContext.Key.ToString(), credential.Name });
                        item.Tag = new DeleteOperation()
                        {
                            Context = byContext.Key,
                            Credentials = credential,
                            Point = someoneWhoUsesCredentialUnderThisContext
                        };
                        listView1.Items.Add(item);

                    }

                AddColumnIfNotExists(_dataAccessPointColumn);
                RemoveColumnIfExists(_credentialsColumn);
                ResizeColumns();
            }
            catch (Exception exception)
            {
                ExceptionViewer.Show(exception);
            }
        }

        public List<string> GetAllRelationships()
        {
            return _relationshipList;
        }

        public void ShowAllRelationshipsFor(TableInfo point, DataAccessCredentials credential)
        {
            try
            {
                listView1.Items.Clear();
                _relationshipList = new List<string>();
                ResetColumns();

                var linker = ((CatalogueRepository) credential.Repository).TableInfoToCredentialsLinker;

                foreach (KeyValuePair<DataAccessContext, DataAccessCredentials> kvp in linker.GetAllLinksBetween(point, credential))
                {
                    var item = new ListViewItem(new[] { point.Name, kvp.Key.ToString(), kvp.Value.Name });

                    _relationshipList.Add(kvp.Key.ToString());
                    
                    item.Tag = new DeleteOperation()
                    {
                        Context = kvp.Key,
                        Credentials = credential,
                        Point = point
                    };
                    listView1.Items.Add(item);
                }

                RemoveColumnIfExists(_dataAccessPointColumn);
                RemoveColumnIfExists(_credentialsColumn);
                ResizeColumns();
            }
            catch (Exception exception)
            {
                ExceptionViewer.Show(exception);
            }
        }

        public void ShowAllRelationshipsFor(TableInfo point)
        {
            try
            {
                listView1.Items.Clear();
                ResetColumns();

                var linker = ((CatalogueRepository)point.Repository).TableInfoToCredentialsLinker;

                foreach (KeyValuePair<DataAccessContext, DataAccessCredentials> kvp in linker.GetCredentialsIfExistsFor(point))
                {
                    var item = new ListViewItem(new[] { point.Name, kvp.Key.ToString(), kvp.Value.Name });
                    item.Tag = new DeleteOperation()
                    {
                        Context = kvp.Key,
                        Credentials = kvp.Value,
                        Point = point
                    };
                    listView1.Items.Add(item);
                }

                RemoveColumnIfExists(_dataAccessPointColumn);
                AddColumnIfNotExists(_credentialsColumn);

                ResizeColumns();
            }
            catch (Exception exception)
            {
                ExceptionViewer.Show(exception);
            }
        }


        private void ResizeColumns()
        {
            foreach (ColumnHeader column in listView1.Columns)
                column.Width = -2; //magical (apparently it resizes to max width of content or header)
        }

        private void RemoveColumnIfExists(ColumnHeader c)
        {
            if (AutoHideColumns && listView1.Columns.Contains(c))
                listView1.Columns.Remove(c);
        }

        private void AddColumnIfNotExists(ColumnHeader c)
        {
            if (AutoHideColumns && !listView1.Columns.Contains(c))
                listView1.Columns.Add(c);
        }

        public void Clear()
        {
            listView1.Clear();
        }

        private void ResetColumns()
        {
            listView1.Columns.Clear();
            listView1.Columns.Add(_dataAccessPointColumn);
            listView1.Columns.Add(_contextColumn);
            listView1.Columns.Add(_credentialsColumn);
        }

        private void listView1_KeyUp(object sender, KeyEventArgs e)
        {
            
            if (e.KeyCode == Keys.Delete)
            {
                var toDelete = listView1.SelectedItems.Cast<ListViewItem>().ToArray();

                if (toDelete.Any())
                {
                    if (
                        MessageBox.Show(
                            "Are you sure you want to remove " + toDelete.Count() +
                            " credential usage permissions? (this will not delete any TableInfos or Credentials - it will just break the linkages)",
                            "Delete usage permissions?", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        foreach (ListViewItem item in toDelete)
                        {
                            var op = (DeleteOperation)item.Tag;

                            var linker = ((CatalogueRepository) op.Credentials.Repository).TableInfoToCredentialsLinker;
                            linker.BreakLinkBetween(op.Credentials, op.Point, op.Context);

                        }
                        if (CollectionChanged != null)
                            CollectionChanged(this, new EventArgs());
                    }

                }
            }
        }
    }
}

using CatalogueManager.MainFormUITabs.SubComponents; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved

namespace CatalogueManager.SimpleDialogs
{
    partial class ConfigureCredentialsForTableInfos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbCredentials = new System.Windows.Forms.ListBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.gbCredentialsUsedBySelectedTableInfo = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.gbExistingPermissions = new System.Windows.Forms.GroupBox();
            this.gbAllowUseOfCredentials = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnGrantPermission = new System.Windows.Forms.Button();
            this.ddContext = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panelCredentialsVisualisation = new System.Windows.Forms.Panel();
            this.lblNoRelationship = new System.Windows.Forms.Label();
            this.lblInternalDataProcessing = new System.Windows.Forms.Label();
            this.lblLogging = new System.Windows.Forms.Label();
            this.lblAny = new System.Windows.Forms.Label();
            this.lblDataExport = new System.Windows.Forms.Label();
            this.lblDataLoad = new System.Windows.Forms.Label();
            this.lblselectedCredentials = new System.Windows.Forms.Label();
            this.lblselectedTableinfo = new System.Windows.Forms.Label();
            this.btnEditCredentials = new System.Windows.Forms.Button();
            this.gbTableInfosUsingCredential = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnAddCredentials = new System.Windows.Forms.Button();
            this.lvCredentialsUsedBySelectedTableInfo = new CatalogueManager.MainFormUITabs.SubComponents.CredentialPermissionsCollection();
            this.lbTableInfos = new CatalogueManager.MainFormUITabs.SubComponents.TableInfoCollectionHost();
            this.lvSelectedTableInfoCredentialsIntersection = new CatalogueManager.MainFormUITabs.SubComponents.CredentialPermissionsCollection();
            this.lvTableInfosUsingCredentials = new CatalogueManager.MainFormUITabs.SubComponents.CredentialPermissionsCollection();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.gbCredentialsUsedBySelectedTableInfo.SuspendLayout();
            this.gbExistingPermissions.SuspendLayout();
            this.gbAllowUseOfCredentials.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panelCredentialsVisualisation.SuspendLayout();
            this.gbTableInfosUsingCredential.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbCredentials
            // 
            this.lbCredentials.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbCredentials.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.lbCredentials.FormattingEnabled = true;
            this.lbCredentials.Location = new System.Drawing.Point(6, 19);
            this.lbCredentials.Name = "lbCredentials";
            this.lbCredentials.Size = new System.Drawing.Size(437, 199);
            this.lbCredentials.TabIndex = 1;
            this.lbCredentials.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.lbCredentials_DrawItem);
            this.lbCredentials.SelectedIndexChanged += new System.EventHandler(this.lbCredentials_SelectedIndexChanged);
            this.lbCredentials.DoubleClick += new System.EventHandler(this.lbCredentials_DoubleClick);
            this.lbCredentials.KeyUp += new System.Windows.Forms.KeyEventHandler(this.lbCredentials_KeyUp);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.splitContainer1);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(0, 0);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1200, 803);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Add Credentials Association";
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(3, 16);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.splitContainer2);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.btnEditCredentials);
            this.splitContainer1.Panel2.Controls.Add(this.gbTableInfosUsingCredential);
            this.splitContainer1.Panel2.Controls.Add(this.label2);
            this.splitContainer1.Panel2.Controls.Add(this.lbCredentials);
            this.splitContainer1.Panel2.Controls.Add(this.btnAddCredentials);
            this.splitContainer1.Size = new System.Drawing.Size(1194, 784);
            this.splitContainer1.SplitterDistance = 732;
            this.splitContainer1.TabIndex = 14;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.gbCredentialsUsedBySelectedTableInfo);
            this.splitContainer2.Panel1.Controls.Add(this.label1);
            this.splitContainer2.Panel1.Controls.Add(this.lbTableInfos);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.gbExistingPermissions);
            this.splitContainer2.Panel2.Controls.Add(this.gbAllowUseOfCredentials);
            this.splitContainer2.Panel2.Controls.Add(this.groupBox1);
            this.splitContainer2.Size = new System.Drawing.Size(732, 784);
            this.splitContainer2.SplitterDistance = 349;
            this.splitContainer2.TabIndex = 0;
            // 
            // gbCredentialsUsedBySelectedTableInfo
            // 
            this.gbCredentialsUsedBySelectedTableInfo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gbCredentialsUsedBySelectedTableInfo.Controls.Add(this.lvCredentialsUsedBySelectedTableInfo);
            this.gbCredentialsUsedBySelectedTableInfo.Enabled = false;
            this.gbCredentialsUsedBySelectedTableInfo.Location = new System.Drawing.Point(3, 538);
            this.gbCredentialsUsedBySelectedTableInfo.Name = "gbCredentialsUsedBySelectedTableInfo";
            this.gbCredentialsUsedBySelectedTableInfo.Size = new System.Drawing.Size(339, 243);
            this.gbCredentialsUsedBySelectedTableInfo.TabIndex = 4;
            this.gbCredentialsUsedBySelectedTableInfo.TabStop = false;
            this.gbCredentialsUsedBySelectedTableInfo.Text = "Credentials Used By:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "TableInfos";
            // 
            // gbExistingPermissions
            // 
            this.gbExistingPermissions.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gbExistingPermissions.Controls.Add(this.lvSelectedTableInfoCredentialsIntersection);
            this.gbExistingPermissions.Location = new System.Drawing.Point(3, 85);
            this.gbExistingPermissions.Name = "gbExistingPermissions";
            this.gbExistingPermissions.Size = new System.Drawing.Size(361, 257);
            this.gbExistingPermissions.TabIndex = 15;
            this.gbExistingPermissions.TabStop = false;
            this.gbExistingPermissions.Text = "Existing Permissions";
            // 
            // gbAllowUseOfCredentials
            // 
            this.gbAllowUseOfCredentials.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gbAllowUseOfCredentials.Controls.Add(this.label3);
            this.gbAllowUseOfCredentials.Controls.Add(this.btnGrantPermission);
            this.gbAllowUseOfCredentials.Controls.Add(this.ddContext);
            this.gbAllowUseOfCredentials.Enabled = false;
            this.gbAllowUseOfCredentials.Location = new System.Drawing.Point(6, 3);
            this.gbAllowUseOfCredentials.Name = "gbAllowUseOfCredentials";
            this.gbAllowUseOfCredentials.Size = new System.Drawing.Size(358, 76);
            this.gbAllowUseOfCredentials.TabIndex = 14;
            this.gbAllowUseOfCredentials.TabStop = false;
            this.gbAllowUseOfCredentials.Text = "Allow Use Of Credentials Under Context (For Selected TableInfo)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 28);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Context";
            // 
            // btnGrantPermission
            // 
            this.btnGrantPermission.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnGrantPermission.Location = new System.Drawing.Point(126, 52);
            this.btnGrantPermission.Name = "btnGrantPermission";
            this.btnGrantPermission.Size = new System.Drawing.Size(102, 22);
            this.btnGrantPermission.TabIndex = 6;
            this.btnGrantPermission.Text = "Grant Permission";
            this.btnGrantPermission.UseVisualStyleBackColor = true;
            this.btnGrantPermission.Click += new System.EventHandler(this.btnGrantPermission_Click);
            // 
            // ddContext
            // 
            this.ddContext.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ddContext.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddContext.FormattingEnabled = true;
            this.ddContext.Location = new System.Drawing.Point(64, 25);
            this.ddContext.Name = "ddContext";
            this.ddContext.Size = new System.Drawing.Size(288, 21);
            this.ddContext.TabIndex = 13;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.panelCredentialsVisualisation);
            this.groupBox1.Location = new System.Drawing.Point(6, 345);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(361, 321);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Permissions Visualiser";
            // 
            // panelCredentialsVisualisation
            // 
            this.panelCredentialsVisualisation.AutoScroll = true;
            this.panelCredentialsVisualisation.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelCredentialsVisualisation.Controls.Add(this.lblNoRelationship);
            this.panelCredentialsVisualisation.Controls.Add(this.lblInternalDataProcessing);
            this.panelCredentialsVisualisation.Controls.Add(this.lblLogging);
            this.panelCredentialsVisualisation.Controls.Add(this.lblAny);
            this.panelCredentialsVisualisation.Controls.Add(this.lblDataExport);
            this.panelCredentialsVisualisation.Controls.Add(this.lblDataLoad);
            this.panelCredentialsVisualisation.Controls.Add(this.lblselectedCredentials);
            this.panelCredentialsVisualisation.Controls.Add(this.lblselectedTableinfo);
            this.panelCredentialsVisualisation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelCredentialsVisualisation.Location = new System.Drawing.Point(3, 16);
            this.panelCredentialsVisualisation.Name = "panelCredentialsVisualisation";
            this.panelCredentialsVisualisation.Size = new System.Drawing.Size(355, 302);
            this.panelCredentialsVisualisation.TabIndex = 16;
            // 
            // lblNoRelationship
            // 
            this.lblNoRelationship.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblNoRelationship.AutoSize = true;
            this.lblNoRelationship.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNoRelationship.ForeColor = System.Drawing.Color.Red;
            this.lblNoRelationship.Location = new System.Drawing.Point(114, 104);
            this.lblNoRelationship.Name = "lblNoRelationship";
            this.lblNoRelationship.Size = new System.Drawing.Size(13, 20);
            this.lblNoRelationship.TabIndex = 7;
            this.lblNoRelationship.Text = ".";
            this.lblNoRelationship.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblInternalDataProcessing
            // 
            this.lblInternalDataProcessing.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblInternalDataProcessing.AutoSize = true;
            this.lblInternalDataProcessing.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblInternalDataProcessing.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInternalDataProcessing.Location = new System.Drawing.Point(228, 249);
            this.lblInternalDataProcessing.Name = "lblInternalDataProcessing";
            this.lblInternalDataProcessing.Size = new System.Drawing.Size(119, 15);
            this.lblInternalDataProcessing.TabIndex = 6;
            this.lblInternalDataProcessing.Text = "InternalDataProcessing";
            // 
            // lblLogging
            // 
            this.lblLogging.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblLogging.AutoSize = true;
            this.lblLogging.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblLogging.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLogging.Location = new System.Drawing.Point(176, 249);
            this.lblLogging.Name = "lblLogging";
            this.lblLogging.Size = new System.Drawing.Size(47, 15);
            this.lblLogging.TabIndex = 5;
            this.lblLogging.Text = "Logging";
            // 
            // lblAny
            // 
            this.lblAny.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblAny.AutoSize = true;
            this.lblAny.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblAny.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAny.Location = new System.Drawing.Point(140, 230);
            this.lblAny.Name = "lblAny";
            this.lblAny.Size = new System.Drawing.Size(27, 15);
            this.lblAny.TabIndex = 4;
            this.lblAny.Text = "Any";
            // 
            // lblDataExport
            // 
            this.lblDataExport.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblDataExport.AutoSize = true;
            this.lblDataExport.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDataExport.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDataExport.Location = new System.Drawing.Point(66, 249);
            this.lblDataExport.Name = "lblDataExport";
            this.lblDataExport.Size = new System.Drawing.Size(62, 15);
            this.lblDataExport.TabIndex = 3;
            this.lblDataExport.Text = "DataExport";
            // 
            // lblDataLoad
            // 
            this.lblDataLoad.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblDataLoad.AutoSize = true;
            this.lblDataLoad.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDataLoad.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDataLoad.Location = new System.Drawing.Point(3, 249);
            this.lblDataLoad.Name = "lblDataLoad";
            this.lblDataLoad.Size = new System.Drawing.Size(56, 15);
            this.lblDataLoad.TabIndex = 2;
            this.lblDataLoad.Text = "DataLoad";
            // 
            // lblselectedCredentials
            // 
            this.lblselectedCredentials.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.lblselectedCredentials.AutoSize = true;
            this.lblselectedCredentials.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblselectedCredentials.Location = new System.Drawing.Point(213, 32);
            this.lblselectedCredentials.Name = "lblselectedCredentials";
            this.lblselectedCredentials.Size = new System.Drawing.Size(129, 15);
            this.lblselectedCredentials.TabIndex = 1;
            this.lblselectedCredentials.Text = "Please Select Credentials";
            this.lblselectedCredentials.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblselectedTableinfo
            // 
            this.lblselectedTableinfo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblselectedTableinfo.AutoSize = true;
            this.lblselectedTableinfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblselectedTableinfo.Location = new System.Drawing.Point(14, 32);
            this.lblselectedTableinfo.Name = "lblselectedTableinfo";
            this.lblselectedTableinfo.Size = new System.Drawing.Size(12, 15);
            this.lblselectedTableinfo.TabIndex = 0;
            this.lblselectedTableinfo.Text = ".";
            this.lblselectedTableinfo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnEditCredentials
            // 
            this.btnEditCredentials.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnEditCredentials.Location = new System.Drawing.Point(130, 224);
            this.btnEditCredentials.Name = "btnEditCredentials";
            this.btnEditCredentials.Size = new System.Drawing.Size(118, 23);
            this.btnEditCredentials.TabIndex = 15;
            this.btnEditCredentials.Text = "Edit Credentials";
            this.btnEditCredentials.UseVisualStyleBackColor = true;
            this.btnEditCredentials.Click += new System.EventHandler(this.btnEditCredentials_Click);
            // 
            // gbTableInfosUsingCredential
            // 
            this.gbTableInfosUsingCredential.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gbTableInfosUsingCredential.Controls.Add(this.lvTableInfosUsingCredentials);
            this.gbTableInfosUsingCredential.Location = new System.Drawing.Point(2, 253);
            this.gbTableInfosUsingCredential.Name = "gbTableInfosUsingCredential";
            this.gbTableInfosUsingCredential.Size = new System.Drawing.Size(444, 503);
            this.gbTableInfosUsingCredential.TabIndex = 14;
            this.gbTableInfosUsingCredential.TabStop = false;
            this.gbTableInfosUsingCredential.Text = "TableInfos Using:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Credentials";
            // 
            // btnAddCredentials
            // 
            this.btnAddCredentials.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnAddCredentials.Location = new System.Drawing.Point(6, 224);
            this.btnAddCredentials.Name = "btnAddCredentials";
            this.btnAddCredentials.Size = new System.Drawing.Size(118, 23);
            this.btnAddCredentials.TabIndex = 12;
            this.btnAddCredentials.Text = "Add New Credentials";
            this.btnAddCredentials.UseVisualStyleBackColor = true;
            this.btnAddCredentials.Click += new System.EventHandler(this.btnAddCredentials_Click);
            // 
            // lvCredentialsUsedBySelectedTableInfo
            // 
            this.lvCredentialsUsedBySelectedTableInfo.AutoHideColumns = true;
            this.lvCredentialsUsedBySelectedTableInfo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvCredentialsUsedBySelectedTableInfo.Location = new System.Drawing.Point(3, 16);
            this.lvCredentialsUsedBySelectedTableInfo.Name = "lvCredentialsUsedBySelectedTableInfo";
            this.lvCredentialsUsedBySelectedTableInfo.Size = new System.Drawing.Size(333, 224);
            this.lvCredentialsUsedBySelectedTableInfo.TabIndex = 15;
            // 
            // lbTableInfos
            // 
            this.lbTableInfos.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbTableInfos.Location = new System.Drawing.Point(6, 19);
            this.lbTableInfos.Name = "lbTableInfos";
            this.lbTableInfos.Size = new System.Drawing.Size(339, 513);
            this.lbTableInfos.TabIndex = 0;
            this.lbTableInfos.Load += new System.EventHandler(this.lbTableInfos_Load);
            // 
            // lvSelectedTableInfoCredentialsIntersection
            // 
            this.lvSelectedTableInfoCredentialsIntersection.AutoHideColumns = true;
            this.lvSelectedTableInfoCredentialsIntersection.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvSelectedTableInfoCredentialsIntersection.Location = new System.Drawing.Point(3, 16);
            this.lvSelectedTableInfoCredentialsIntersection.Name = "lvSelectedTableInfoCredentialsIntersection";
            this.lvSelectedTableInfoCredentialsIntersection.Size = new System.Drawing.Size(355, 238);
            this.lvSelectedTableInfoCredentialsIntersection.TabIndex = 14;
            // 
            // lvTableInfosUsingCredentials
            // 
            this.lvTableInfosUsingCredentials.AutoHideColumns = true;
            this.lvTableInfosUsingCredentials.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvTableInfosUsingCredentials.Location = new System.Drawing.Point(3, 16);
            this.lvTableInfosUsingCredentials.Name = "lvTableInfosUsingCredentials";
            this.lvTableInfosUsingCredentials.Size = new System.Drawing.Size(438, 484);
            this.lvTableInfosUsingCredentials.TabIndex = 13;
            // 
            // ConfigureCredentialsForTableInfos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1200, 803);
            this.Controls.Add(this.groupBox2);
            this.Name = "ConfigureCredentialsForTableInfos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ConfigureCredentialsForTableInfos";
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.ConfigureCredentialsForTableInfos_KeyUp);
            this.groupBox2.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel1.PerformLayout();
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.gbCredentialsUsedBySelectedTableInfo.ResumeLayout(false);
            this.gbExistingPermissions.ResumeLayout(false);
            this.gbAllowUseOfCredentials.ResumeLayout(false);
            this.gbAllowUseOfCredentials.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.panelCredentialsVisualisation.ResumeLayout(false);
            this.panelCredentialsVisualisation.PerformLayout();
            this.gbTableInfosUsingCredential.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private TableInfoCollectionHost lbTableInfos;
        private System.Windows.Forms.ListBox lbCredentials;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnGrantPermission;
        private System.Windows.Forms.Button btnAddCredentials;
        private System.Windows.Forms.ComboBox ddContext;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.GroupBox gbAllowUseOfCredentials;
        private System.Windows.Forms.GroupBox gbExistingPermissions;
        private CredentialPermissionsCollection lvSelectedTableInfoCredentialsIntersection;
        private CredentialPermissionsCollection lvTableInfosUsingCredentials;
        private CredentialPermissionsCollection lvCredentialsUsedBySelectedTableInfo;
        private System.Windows.Forms.GroupBox gbCredentialsUsedBySelectedTableInfo;
        private System.Windows.Forms.GroupBox gbTableInfosUsingCredential;
        private System.Windows.Forms.Button btnEditCredentials;
        private System.Windows.Forms.Panel panelCredentialsVisualisation;
        private System.Windows.Forms.Label lblselectedCredentials;
        private System.Windows.Forms.Label lblselectedTableinfo;
        private System.Windows.Forms.Label lblInternalDataProcessing;
        private System.Windows.Forms.Label lblLogging;
        private System.Windows.Forms.Label lblAny;
        private System.Windows.Forms.Label lblDataExport;
        private System.Windows.Forms.Label lblDataLoad;
        private System.Windows.Forms.Label lblNoRelationship;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}

using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows.Forms;
using CatalogueLibrary.Data;
using CatalogueManager.MainFormUITabs.SubComponents;
using CatalogueManager.SimpleDialogs;
using CatalogueManager.TestsAndSetup.ServicePropogation;
using DataLoadEngine.Migration;
using DataQualityEngine.Reports;
using ReusableLibraryCode.Progress;
using ReusableUIComponents;

namespace DataQualityEngineUI
{
    /// <summary>
    /// Allows you to run the Data Quality Engine against a dataset (Catalogue).  This includes applying all the validation rules (See ValidationSetupForm) against the data fetched
    /// by using the SQL built by the QueryBuilder (See ViewExtractionSql).
    /// 
    /// On the left is a list of all datasets with at least one extractable column.  Start by selecting the dataset (Catalogue) you want to run the DQE on and selecting 'Check Catalogue
    /// Validation'  This will let you know if the validation rules are configured, if there is a time periodicity/pivot fields (See ExtractionInformationChooserUI) etc.  Assuming Checks
    /// pass then you can click 'Start Data Quality Engine Execution'
    /// 
    /// The ProgressUI on the right will be populated with information about how the DQE is doing (number of records processed etc).  
    /// 
    /// 
    /// TECHNICAL: The DQE is usually CPU bound since it spends a lot of time applying regular expressions and validations/hash mapping etc on the data as it comes through and this 
    /// usually takes more time than your data repository server executing the actual extraction query and sending the data down the network cable.  There is very little memory 
    /// consumption from the DQE since records are processed in batches and disposed as it comes available.
    /// 
    /// </summary>
    public partial class DataQualityEngineMainForm : RDMPForm
    {

        public DataQualityEngineMainForm()
        {
            InitializeComponent();

        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            
            if (VisualStudioDesignMode)
                return;

            catalogues.CatalogueCollection.Collection = new ObservableCollection<Catalogue>(RepositoryLocator.CatalogueRepository.GetAllCatalogues());

        }


        private void btnStartCatalogueConstraintReport_Click(object sender, EventArgs e)
        {
            Catalogue c = catalogues.SelectedCatalogue;
            Thread t= new Thread(() =>
            {
                try
                {
                    CatalogueConstraintReport report = new CatalogueConstraintReport(c, MigrationColumnSet.DataLoadRunField);
                    report.GenerateReport(c,progressUI1);
                }
                catch (Exception exception)
                {
                    progressUI1.OnNotify(this,new NotifyEventArgs(ProgressEventType.Error,exception.Message,exception));
                }
            });

            t.Start();
        }

        private void btnCheck_Click(object sender, EventArgs e)
        {
            try
            {
                CatalogueConstraintReport report = new CatalogueConstraintReport(catalogues.SelectedCatalogue, MigrationColumnSet.DataLoadRunField);
                checksUI1.StartChecking(report);
            }
            catch (Exception exception)
            {
                ExceptionViewer.Show(exception);
            }
        }

        private void refreshCataloguesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            catalogues.CatalogueCollection.Collection = new ObservableCollection<Catalogue>(RepositoryLocator.CatalogueRepository.GetAllCatalogues());
        }
    }
}

using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Data;
using CatalogueLibrary.Data;
using CatalogueLibrary.Data.DataLoad;
using DataLoadEngine.DataFlowPipeline.Components.Anonymisation;
using DataLoadEngineTests.Properties;
using NUnit.Framework;
using Tests.Common;

namespace DataLoadEngineTests.Integration
{
    [Ignore("Ignoring these until we have an ANO database on the integration server")]
    public class AnonymisationEngineTests : DatabaseTests
    {
        private readonly string _testDatabaseServer = Settings.Default.TestCatalogueConnectionString;

 
      [Test]
      public void TestAnonymisationEngine()
      {
          const string anoSuffix = "TEST";
          var eds = new ExternalDatabaseServer(CatalogueRepository, "ExternalDatabase");
          var testANOTable = new ANOTable(CatalogueRepository, eds, "ANOTable", anoSuffix);
          var transformer = new ANOTransformer(testANOTable);
          
          var dt = new DataTable();
          
          const string testColumnName = "Data";
          const string testColumnNameANO = ANOTable.ANOPrefix + testColumnName;

          dt.Columns.Add("ID");
          dt.Columns.Add(testColumnName);
          dt.Columns.Add("SomeOtherField");

          dt.Rows.Add(new object[] {1, "FlyMyPretty", "Hi"});
          dt.Rows.Add(new object[] {2, "TapSlippers", "Hi2"});

          DataColumn anoColumn = dt.Columns.Add(testColumnNameANO);

          transformer.Transform(dt,dt.Columns[testColumnName],anoColumn);

          //notice how it still has both the columns, it is the job of the AnonymisationEngine to actually drop the columns 
          Assert.IsTrue(dt.Columns.Contains(testColumnName));
          Assert.IsTrue(dt.Columns.Contains(testColumnNameANO));

          Assert.AreEqual(dt.Rows[0][testColumnName], "FlyMyPretty"); //original value
          Assert.AreNotEqual(dt.Rows[0][anoColumn], "FlyMyPretty");//transformed must be different 
          Assert.AreNotEqual(dt.Rows[0][anoColumn], DBNull.Value); //and not null
          Assert.NotNull(dt.Rows[0][anoColumn]); //and not null

          //note that this might change in future e.g. it could be a prefix or have some imputed crud?!
          Assert.IsTrue(dt.Rows[0][anoColumn].ToString().EndsWith(anoSuffix)); //must have suffix TEST (that is the ANO suffix of this configuration)

          Assert.AreEqual(dt.Rows[1][testColumnName], "TapSlippers"); //original value
          Assert.AreNotEqual(dt.Rows[1][anoColumn], "TapSlippers");//transformed must be different 
          Assert.AreNotEqual(dt.Rows[1][anoColumn], DBNull.Value); //and not null
          Assert.NotNull(dt.Rows[1][anoColumn]); //and not null

          Assert.IsTrue(dt.Rows[1][anoColumn].ToString().EndsWith(anoSuffix)); //must have suffix TEST (that is the ANO suffix of this configuration)
      }
    }
}

using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text.RegularExpressions;
using CatalogueLibrary.Data.DataLoad;
using CatalogueLibrary.Repositories;
using MapsDirectlyToDatabaseTable;
using ReusableLibraryCode;
using ReusableLibraryCode.Checks;


namespace CatalogueLibrary.Data
{
    /// <summary>
    /// References an SQL column in a TableInfo (which itself references an SQL table).  This is the RDMP's awareness of the state of your database.  You can
    /// synchronize against the underlying sql server state using TableInfoSynchronizer.
    /// 
    /// A ColumnInfo can belong to an anonymisation group (ANOTable) e.g. ANOGPCode, in this case it will be aware not only of it's name and datatype in LIVE
    /// but also it's unanonymised name/datatype (see method GetRuntimeName(LoadStage stage)).
    /// 
    /// A ColumnInfo may seem superfluous since you can query much of it's information at runtime but consider the situation where TableInfo is a table valued 
    /// function or it is a view and someone deletes a column from the view without telling anyone.  The ColumnInfo ensures a standard unchanging representation
    /// for the RDMP so that it can rationalize and inform the system user of disapearing columns etc and let the user make descisions about how to resolve it 
    /// (which might be as simple as deleting the ColumnInfos although that will have knock on effects for extraction logic etc).
    /// </summary>
    public class ColumnInfo : VersionedDatabaseEntity, IDeleteable, IComparable, IColumnMetadata,IResolveDuplication, IHasDependencies,ICheckable
    {
        /*
         * [TableInfo_ID]
      ,[ID]
      ,[Type]
      ,[Format]
      ,[Digitisation_specs]
      ,[Name]
      ,[Source]*/

        public int TableInfo_ID { get; private set; }

        public int? ANOTable_ID { get; set; }

        public string Name { get; set; }
        public string Data_type { get; set; }
        public string Format { get; set; }
        public string Digitisation_specs { get; set; }
        public string Source { get; set; }

        public string Description{ get; set; }
        
        public ColumnStatus? Status { get; set; }
        public string RegexPattern { get; set; }
        public string ValidationRules { get; set; }
        public bool IsPrimaryKey { get; set; }

        public int? DuplicateRecordResolutionOrder { get; set; }
        public bool DuplicateRecordResolutionIsAscending { get; set; }

        #region Relationships

        [NoMappingToDatabase]
        public TableInfo TableInfo
        {
            get
            {
                return Repository.GetObjectByID<TableInfo>(TableInfo_ID);
            }
        }
        
        [NoMappingToDatabase]
        public ANOTable ANOTable {
            get { return ANOTable_ID == null ? null : Repository.GetObjectByID<ANOTable>((int) ANOTable_ID); }
        }

        [NoMappingToDatabase]
        public IEnumerable<ExtractionInformation> ExtractionInformations {
            get { return ((CatalogueRepository) Repository).Linker.GetAllExtractionInformationFrom(this); }
        }

        #endregion
        
        public enum ColumnStatus
        {
            Deprecated,
            Inactive,
            Archived,
            Active
        }

        public static int Name_MaxLength;
        public static int Data_type_MaxLength;
        public static int Format_MaxLength;
        public static int Digitisation_specs_MaxLength;
        public static int Source_MaxLength;
        public static int Description_MaxLength;
        public static int RegexPattern_MaxLength;
        public static int ValidationRules_MaxLength;

        private ColumnInfo()
        {
            //used to generate MISSING columns
            ID = -1;
            Name = "MISSING COLUMNINFO";
        }

        public ColumnInfo(IRepository repository, string name, string type, TableInfo parent)
        {
            repository.InsertAndHydrate(this,new Dictionary<string, object>
            {
                {"Name", name != null ? (object) name : DBNull.Value},
                {"Data_type", type != null ? (object) type : DBNull.Value},
                {"TableInfo_ID", parent.ID}
            });
        }

        public ColumnInfo(IRepository repository,DbDataReader r) : base(repository,r)
        {
            TableInfo_ID = int.Parse(r["TableInfo_ID"].ToString());
            Name =r["Name"].ToString();
            Data_type = r["Data_type"].ToString();
            Format = r["Format"].ToString();
            Digitisation_specs = r["Digitisation_specs"].ToString();
            Source = r["Source"].ToString();
            Description = r["Description"].ToString();

            //try to turn string value in database into enum value
            ColumnStatus dbStatus;
            if (ColumnStatus.TryParse(r["Status"].ToString(), out dbStatus))
                Status = dbStatus;

            RegexPattern = r["RegexPattern"].ToString();
            ValidationRules = r["ValidationRules"].ToString();
            IsPrimaryKey = Boolean.Parse(r["IsPrimaryKey"].ToString());

            if (r["ANOTable_ID"] != DBNull.Value)
                ANOTable_ID = int.Parse(r["ANOTable_ID"].ToString());
            else
                ANOTable_ID = null;

            if (r["DuplicateRecordResolutionOrder"] != DBNull.Value)
                DuplicateRecordResolutionOrder = int.Parse(r["DuplicateRecordResolutionOrder"].ToString());
            else
                DuplicateRecordResolutionOrder = null;

            DuplicateRecordResolutionIsAscending = Convert.ToBoolean(r["DuplicateRecordResolutionIsAscending"]);

        }

        public override string ToString()
        {
            return Name;
        }

        public int CompareTo(object obj)
        {
            if (obj is ColumnInfo)
            {
                return - (obj.ToString().CompareTo(this.ToString())); //sort alphabetically (reverse)
            }
            
            throw new Exception("Cannot compare " + this.GetType().Name + " to " + obj.GetType().Name);
            
        }


        public string GetRuntimeName()
        {
            if (Name == null)
                return null;

            return SqlSyntaxHelper.GetRuntimeName(Name);
        }
        public override int GetHashCode()
        {
            return Repository.GetHashCode(this);
        }


        public override bool Equals(object obj)
        {
            return Repository.AreEqual(this, obj);
        }

        
        public static ColumnInfo Missing = new ColumnInfo();
        
        public string GetRuntimeName(LoadStage stage)
        {
            string finalName = this.GetRuntimeName();

            if (stage == LoadStage.AdjustRaw)
            {
                //see if it has an ANO Transform on it
                if (ANOTable_ID != null && finalName.StartsWith("ANO"))
                    return finalName.Substring("ANO".Length);
            }

            //any other stage will be the regular final name
            return finalName;
        }

        /// <summary>
        /// Gets the DataType adjusted for the stage at which the ColumnInfo is at, this is almost always the same as Data_type.  The only
        /// time it is different is when there is an ANOTable involved e.g. ANOLocation could be a varchar(6) like 'AB10_L' after anonymisation
        /// but if the LoadStage is AdjustRaw then it would have a value like 'NH10' (varchar(4) - the unanonymised state).
        /// </summary>
        /// <param name="loadStage"></param>
        /// <returns></returns>
        public string GetRuntimeDataType(LoadStage loadStage)
        {
            if (loadStage == LoadStage.AdjustRaw)
            {
                //if it doesnt have an ANO transform the datatype is the same regardless of stage
                if (ANOTable_ID == null)
                    return Data_type;
                
                //it does have an ANOTable, so get the datatype from the ANOTable because ColumnInfo is of mutable type depending on whether it has been anonymised yet 
                return ANOTable.GetRuntimeDataType(loadStage);
            }

            //The user is asking about a stage other than RAW so tell them about the final column type state
            return Data_type;
        }

        public int? GetColumnLengthIfAny()
        {
            Regex r = new Regex(@"\(\d+\)");

            if (string.IsNullOrWhiteSpace(Data_type))
                return null;
            Match match = r.Match(Data_type);
            if (match.Success)
                return int.Parse(match.Value.TrimStart(new[] {'('}).TrimEnd(new[] {')'}));

            return null;
        }

        public IHasDependencies[] GetObjectsThisDependsOn()
        {
            if (this.Equals(Missing))
                return null;

            List<IHasDependencies> iDependOn = new List<IHasDependencies>();

            iDependOn.AddRange(((CatalogueRepository)Repository).Linker.GetCatalogueItems(this));
            iDependOn.Add(TableInfo);

            return iDependOn.ToArray();
        }

        public IHasDependencies[] GetObjectsDependingOnThis()
        {
            List<IHasDependencies> dependantObjects = new List<IHasDependencies>();

            //add the ExtractionInformations
            var extractionInformations = ((CatalogueRepository)Repository).Linker.GetAllExtractionInformationFrom(this).ToArray();

            //also any CatalogueItem that does not have an extraction information but is still associated with this
            //add in column infos that don't have extraction informations
            dependantObjects.AddRange(
                ((CatalogueRepository)Repository).Linker.GetCatalogueItems(this)//get all catalogueItems
                .Where(c => !extractionInformations.Any(e => e.ColumnInfo.Equals(this)) //where the CatalogueItem is not already referenced via a Extraction information
                ));

            //also lookups are dependent on us
            dependantObjects.AddRange(GetAllLookupForColumnInfoWhereItIsA(LookupType.AnyKey));

            //now add extraction informations
            dependantObjects.AddRange(extractionInformations);

            return dependantObjects.ToArray(); //dependantObjects.ToArray();
        }

        public void Check(ICheckNotifier notifier)
        {
            //if it does not have an ANO transform it should not start with ANO
            if (ANOTable_ID == null)
            {
                //the column has no anotable
                //make sure it doesn't start with ANO (if it does it should have an ANOTable, maybe the user is calling his column ANOUNCEMENT or something (not permitted)
                if (GetRuntimeName().StartsWith(ANOTable.ANOPrefix))
                    notifier.OnCheckPerformed(new CheckEventArgs("ColumnInfo " + this + " (ID=" + ID + ") begins with " + ANOTable.ANOPrefix + " but does not have an ANOTable configured for it", CheckResult.Warning, null));
            }
            else//if it does have an ANO transform it must start with ANO
                if(!GetRuntimeName().StartsWith(ANOTable.ANOPrefix))
                    notifier.OnCheckPerformed(new CheckEventArgs("ColumnInfo " + this + " (ID=" + ID + ") has an ANOTable configured but does not start with " + ANOTable.ANOPrefix + " (All anonymised columns must start with "+ANOTable.ANOPrefix+")", CheckResult.Fail, null));
        }

        public Lookup[] GetAllLookupForColumnInfoWhereItIsA(LookupType type)
        {
            string sql;
            if (type == LookupType.Description)
                sql = "SELECT * FROM Lookup WHERE Description_ID=" + ID;
            else if (type == LookupType.AnyKey)
                sql = "SELECT * FROM Lookup WHERE ForeignKey_ID=" + ID + " OR PrimaryKey_ID=" + ID;
            else if (type == LookupType.ForeignKey)
                sql = "SELECT * FROM Lookup WHERE ForeignKey_ID=" + ID;
            else
                throw new NotImplementedException("Unrecognised LookupType " + type);

            var lookups = Repository.SelectAll<Lookup>(sql, "ID").ToArray();

            if (lookups.Select(l => l.PrimaryKey_ID).Distinct().Count() > 1 && type == LookupType.ForeignKey)
                throw new Exception("Column " + this + " is configured as a foreign key to more than 1 primary key (only 1 is allowed), the Lookups are:" + string.Join(",", lookups.Select(l => l.PrimaryKey)));

            return lookups.ToArray();
        }
    }
}

namespace QueryCaching.Aggregation
{
    public enum AggregateOperation
    {
        IndexedExtractionIdentifierList,
        ExtractableAggregateResults,
        JoinableInceptionQuery
    }
}

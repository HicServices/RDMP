namespace QueryCaching.Aggregation // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
{
    public enum AggregateOperation
    {
        IndexedExtractionIdentifierList,
        ExtractableAggregateResults
    }
}

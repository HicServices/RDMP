using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Data.SqlClient;
using System.Linq;

namespace MapsDirectlyToDatabaseTable
{
}

using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using CatalogueLibrary.Data.Pipelines;
using CatalogueLibrary.DataFlowPipeline;
using CatalogueLibrary.DataFlowPipeline.Requirements;
using CatalogueLibrary.Repositories;
using ReusableUIComponents;
using ReusableUIComponents.Progress;

namespace RDMPObjectVisualisation.Pipelines
{
    public partial class ConfigurePipelineUI<T> : BetterToolTipForm 
    {
        private readonly Pipeline _pipeline;
        private readonly IDataFlowSource<T> _source;
        private readonly IDataFlowDestination<T> _destination;
        private readonly DataFlowPipelineContext<T> _context;

        private readonly DataFlowPipelineEngineFactory<T> _factory;
        private readonly List<object> _initializationObjectsForPreviewPipelineSource;
        private readonly CatalogueRepository _repository;

        private const string NO_COMPONENT = "Unknown";
        
        private PipelineWorkArea<T> _workArea;

        public ConfigurePipelineUI(Pipeline pipeline, IDataFlowSource<T> source, IDataFlowDestination<T> destination, DataFlowPipelineContext<T> context, List<object> initializationObjectsForPreviewPipelineSource, CatalogueRepository repository)
        {
            _pipeline = pipeline;
            _source = source;
            _destination = destination;
            _context = context;
            _initializationObjectsForPreviewPipelineSource = initializationObjectsForPreviewPipelineSource;
            _repository = repository;
            InitializeComponent();

            _factory = new DataFlowPipelineEngineFactory<T>(repository.MEF, context)
            {
                ExplicitSource = source,
                ExplicitDestination = destination
            };

            _workArea = new PipelineWorkArea<T>(pipeline, context, repository) {Dock = DockStyle.Fill};
            panel1.Controls.Add(_workArea);

            tbName.Text = pipeline.Name;
            tbDescription.Text = pipeline.Description;

            RefreshUIFromDatabase();
        }

  
        private void RefreshUIFromDatabase()
        {
            _workArea.SetTo(_factory,_pipeline,_initializationObjectsForPreviewPipelineSource.ToArray());
            try
            {
                InitializeSourceWithPreviewObjects();
            }
            catch (Exception e)
            {
                ExceptionViewer.Show("Failed to initialize source with preview objects",e);
            }
        }



        private void InitializeSourceWithPreviewObjects()
        {
            //fixed source
            if (_source != null)
            {
                _workArea.SetPreview(_source.TryGetPreview());
            }
            else
            {
                //custom source
                if (_initializationObjectsForPreviewPipelineSource == null)
                    return;

                if (!_initializationObjectsForPreviewPipelineSource.Any())
                    return;

                //destination is a pipeline component, factory stamp me out an instance
                var factory = new DataFlowPipelineEngineFactory<T>(_repository.MEF, _context);
                var s = factory.CreateSourceIfExists(_pipeline);

                //now use the stamped out instance for preview generation
                InitializeSourceWithPreviewObjects(s);
            }
        }

        private void InitializeSourceWithPreviewObjects(IDataFlowSource<T> s)
        {
            try
            {
                if (s == null)
                    return;

                _context.PreInitialize(new PopupErrorMessagesEventListener(), s, _initializationObjectsForPreviewPipelineSource.ToArray());
                _workArea.SetPreview(s.TryGetPreview());
            }
            catch (Exception e)
            {
                ExceptionViewer.Show("Could not generate preview for source " + s, e);
            }
        }

       private void tbName_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tbName.Text))
                tbName.Text = "NoName";
            
            _pipeline.Name = tbName.Text;
            _pipeline.SaveToDatabase();
        }
        
        private void btnOk_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        private void tbDescription_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(_pipeline.Description) && string.IsNullOrWhiteSpace(tbDescription.Text))
            {
                if (MessageBox.Show("Are you sure you want to delete the current Description entirely?",
                    "Confirm deleting description?", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    _pipeline.Description = null;
                else
                {
                    tbDescription.Text = _pipeline.Description;
                }
            }
            else
                _pipeline.Description = tbDescription.Text;

            _pipeline.SaveToDatabase();
        }
    }
}

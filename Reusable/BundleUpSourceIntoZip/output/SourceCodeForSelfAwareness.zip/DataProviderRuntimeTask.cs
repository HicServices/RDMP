using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using CatalogueLibrary;
using CatalogueLibrary.Data.DataLoad;
using CatalogueLibrary.DataFlowPipeline;
using CatalogueLibrary.Repositories;
using CatalogueLibrary.Useful;
using DataLoadEngine.DataProvider;
using DataLoadEngine.Job;
using DataLoadEngine.LoadPipeline.Components.Arguments;
using ReusableLibraryCode.Checks;
using ReusableLibraryCode.Progress;

namespace DataLoadEngine.LoadPipeline.Components.Runtime
{
    public class DataProviderRuntimeTask : RuntimeTask
    {
        public IDataProvider Provider { get; private set; }

        public DataProviderRuntimeTask(IProcessTask task, RuntimeArgumentCollection args, ReflectionFactory<IDataProvider> reflectionFactory)
            : base(task, args)
        {
            string classNameToInstantiate = task.Path;
            
            Provider = reflectionFactory.Create(classNameToInstantiate);
            try
            {
                SetPropertiesForClass(RuntimeArguments, Provider);
            }
            catch (Exception e)
            {
                throw new Exception("Error when trying to set the properties for '" + task.Name + "'", e);
            }
        }

        public override ProcessExitCode Run(IDataLoadJob job, GracefulCancellationToken cancellationToken)
        {
            Provider.Validate(job.HICProjectDirectory);

            job.OnNotify(this, new NotifyEventArgs(ProgressEventType.Information, "About to fetch data using class " + Provider.GetType().FullName));
            return Provider.Fetch(job, cancellationToken);
        }

        public override bool Exists()
        {
            return true;
        }

        public override string ToShortString()
        {
            throw new NotImplementedException();
        }

        public override void Abort(IDataLoadEventListener postLoadEventListener)
        {
        }

        public override void LoadCompletedSoDispose(ExitCodeType exitCode,IDataLoadEventListener postLoadEventListener)
        {
            Provider.LoadCompletedSoDispose(exitCode,postLoadEventListener);
        }

        public override void Check(ICheckNotifier checker)
        {
        }

        public override string ShortType()
        {
            throw new NotImplementedException();
        }
    }
}

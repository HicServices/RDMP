using BrightIdeasSoftware; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved

namespace CohortManager.SubComponents
{
    partial class ConfigureCohortContainersUI
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ConfigureCohortContainersUI));
            this.otvConfiguration = new BrightIdeasSoftware.TreeListView();
            this.olvAggregate = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvCatalogue = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvIdentifierCount = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvCumulativeTotal = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvWorking = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvOrder = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvTime = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvCachedQueryUseCount = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.btnAddContainer = new System.Windows.Forms.Button();
            this.lblDropTarget = new System.Windows.Forms.Label();
            this.lblSubIndex = new System.Windows.Forms.Label();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tbTimeout = new System.Windows.Forms.TextBox();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.refreshThreadCountPeriodically = new System.Windows.Forms.Timer(this.components);
            this.lblThreadCount = new System.Windows.Forms.Label();
            this.btnStartSelected = new System.Windows.Forms.Button();
            this.btnCacheSelected = new System.Windows.Forms.Button();
            this.btnClearCacheForSelected = new System.Windows.Forms.Button();
            this.cbIncludeCumulative = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.otvConfiguration)).BeginInit();
            this.SuspendLayout();
            // 
            // otvConfiguration
            // 
            this.otvConfiguration.AllColumns.Add(this.olvAggregate);
            this.otvConfiguration.AllColumns.Add(this.olvCatalogue);
            this.otvConfiguration.AllColumns.Add(this.olvIdentifierCount);
            this.otvConfiguration.AllColumns.Add(this.olvCumulativeTotal);
            this.otvConfiguration.AllColumns.Add(this.olvWorking);
            this.otvConfiguration.AllColumns.Add(this.olvOrder);
            this.otvConfiguration.AllColumns.Add(this.olvTime);
            this.otvConfiguration.AllColumns.Add(this.olvCachedQueryUseCount);
            this.otvConfiguration.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.otvConfiguration.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.olvAggregate,
            this.olvCatalogue,
            this.olvIdentifierCount,
            this.olvCumulativeTotal,
            this.olvWorking,
            this.olvTime,
            this.olvCachedQueryUseCount});
            this.otvConfiguration.FullRowSelect = true;
            this.otvConfiguration.IsSimpleDragSource = true;
            this.otvConfiguration.IsSimpleDropSink = true;
            this.otvConfiguration.Location = new System.Drawing.Point(4, 0);
            this.otvConfiguration.Name = "otvConfiguration";
            this.otvConfiguration.OwnerDraw = true;
            this.otvConfiguration.ShowGroups = false;
            this.otvConfiguration.Size = new System.Drawing.Size(536, 542);
            this.otvConfiguration.SmallImageList = this.imageList1;
            this.otvConfiguration.TabIndex = 0;
            this.otvConfiguration.UseCompatibleStateImageBehavior = false;
            this.otvConfiguration.View = System.Windows.Forms.View.Details;
            this.otvConfiguration.VirtualMode = true;
            this.otvConfiguration.CellRightClick += new System.EventHandler<BrightIdeasSoftware.CellRightClickEventArgs>(this.otvConfiguration_CellRightClick);
            this.otvConfiguration.ModelCanDrop += new System.EventHandler<BrightIdeasSoftware.ModelDropEventArgs>(this.otvConfiguration_ModelCanDrop);
            this.otvConfiguration.ModelDropped += new System.EventHandler<BrightIdeasSoftware.ModelDropEventArgs>(this.otvConfiguration_ModelDropped);
            this.otvConfiguration.SelectionChanged += new System.EventHandler(this.otvConfiguration_SelectionChanged);
            this.otvConfiguration.ItemActivate += new System.EventHandler(this.otvConfiguration_ItemActivate);
            this.otvConfiguration.SelectedIndexChanged += new System.EventHandler(this.otvConfiguration_SelectedIndexChanged);
            this.otvConfiguration.KeyUp += new System.Windows.Forms.KeyEventHandler(this.otvConfiguration_KeyUp);
            // 
            // olvAggregate
            // 
            this.olvAggregate.AspectName = "ToString";
            this.olvAggregate.FillsFreeSpace = true;
            this.olvAggregate.Sortable = false;
            this.olvAggregate.Text = "Aggregate";
            // 
            // olvCatalogue
            // 
            this.olvCatalogue.AspectName = "GetCatalogueName";
            this.olvCatalogue.Sortable = false;
            this.olvCatalogue.Text = "Catalogue";
            this.olvCatalogue.Width = 70;
            // 
            // olvIdentifierCount
            // 
            this.olvIdentifierCount.AspectName = "FinalRowCount";
            this.olvIdentifierCount.Sortable = false;
            this.olvIdentifierCount.Text = "Identifier Count";
            this.olvIdentifierCount.Width = 90;
            // 
            // olvCumulativeTotal
            // 
            this.olvCumulativeTotal.AspectName = "CumulativeRowCount";
            this.olvCumulativeTotal.Text = "Cumulative Total";
            // 
            // olvWorking
            // 
            this.olvWorking.AspectName = "GetStateDescription";
            this.olvWorking.Sortable = false;
            this.olvWorking.Text = "Working";
            this.olvWorking.Width = 80;
            // 
            // olvOrder
            // 
            this.olvOrder.AspectName = "Order";
            this.olvOrder.AspectToStringFormat = "";
            this.olvOrder.DisplayIndex = 5;
            this.olvOrder.IsVisible = false;
            this.olvOrder.Sortable = false;
            this.olvOrder.Text = "Order";
            // 
            // olvTime
            // 
            this.olvTime.AspectName = "ElapsedTime";
            this.olvTime.Text = "Time";
            // 
            // olvCachedQueryUseCount
            // 
            this.olvCachedQueryUseCount.AspectName = "GetCachedQueryUseCount";
            this.olvCachedQueryUseCount.Text = "Cached";
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "aggregates.png");
            this.imageList1.Images.SetKeyName(1, "CacheResultsIcon.png");
            this.imageList1.Images.SetKeyName(2, "Diff.png");
            // 
            // btnAddContainer
            // 
            this.btnAddContainer.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAddContainer.Location = new System.Drawing.Point(4, 606);
            this.btnAddContainer.Name = "btnAddContainer";
            this.btnAddContainer.Size = new System.Drawing.Size(533, 23);
            this.btnAddContainer.TabIndex = 1;
            this.btnAddContainer.Text = "Add Container";
            this.btnAddContainer.UseVisualStyleBackColor = true;
            this.btnAddContainer.Click += new System.EventHandler(this.btnAddContainer_Click);
            // 
            // lblDropTarget
            // 
            this.lblDropTarget.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblDropTarget.AutoSize = true;
            this.lblDropTarget.Location = new System.Drawing.Point(301, 525);
            this.lblDropTarget.Name = "lblDropTarget";
            this.lblDropTarget.Size = new System.Drawing.Size(41, 13);
            this.lblDropTarget.TabIndex = 2;
            this.lblDropTarget.Text = "Target:";
            // 
            // lblSubIndex
            // 
            this.lblSubIndex.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblSubIndex.AutoSize = true;
            this.lblSubIndex.Location = new System.Drawing.Point(286, 545);
            this.lblSubIndex.Name = "lblSubIndex";
            this.lblSubIndex.Size = new System.Drawing.Size(55, 13);
            this.lblSubIndex.TabIndex = 3;
            this.lblSubIndex.Text = "SubIndex:";
            // 
            // btnCalculate
            // 
            this.btnCalculate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnCalculate.Location = new System.Drawing.Point(4, 580);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(93, 23);
            this.btnCalculate.TabIndex = 4;
            this.btnCalculate.Text = "Start All Tasks";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(378, 585);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Timeout(s):";
            // 
            // tbTimeout
            // 
            this.tbTimeout.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.tbTimeout.Location = new System.Drawing.Point(443, 582);
            this.tbTimeout.Name = "tbTimeout";
            this.tbTimeout.Size = new System.Drawing.Size(94, 20);
            this.tbTimeout.TabIndex = 6;
            this.tbTimeout.Text = "30";
            this.tbTimeout.TextChanged += new System.EventHandler(this.tbTimeout_TextChanged);
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnCancel.Location = new System.Drawing.Point(231, 580);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(86, 23);
            this.btnCancel.TabIndex = 4;
            this.btnCancel.Text = "Cancel  Tasks";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnReset
            // 
            this.btnReset.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnReset.Location = new System.Drawing.Point(323, 580);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(56, 23);
            this.btnReset.TabIndex = 7;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // refreshThreadCountPeriodically
            // 
            this.refreshThreadCountPeriodically.Interval = 500;
            this.refreshThreadCountPeriodically.Tick += new System.EventHandler(this.refreshThreadCountPeriodically_Tick);
            // 
            // lblThreadCount
            // 
            this.lblThreadCount.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblThreadCount.AutoSize = true;
            this.lblThreadCount.Location = new System.Drawing.Point(3, 554);
            this.lblThreadCount.Name = "lblThreadCount";
            this.lblThreadCount.Size = new System.Drawing.Size(81, 13);
            this.lblThreadCount.TabIndex = 8;
            this.lblThreadCount.Text = "Thread Count:0";
            // 
            // btnStartSelected
            // 
            this.btnStartSelected.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnStartSelected.Enabled = false;
            this.btnStartSelected.Location = new System.Drawing.Point(103, 554);
            this.btnStartSelected.Name = "btnStartSelected";
            this.btnStartSelected.Size = new System.Drawing.Size(122, 23);
            this.btnStartSelected.TabIndex = 9;
            this.btnStartSelected.Text = "Start Selected";
            this.btnStartSelected.UseVisualStyleBackColor = true;
            this.btnStartSelected.Click += new System.EventHandler(this.btnStartSelected_Click);
            // 
            // btnCacheSelected
            // 
            this.btnCacheSelected.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnCacheSelected.Enabled = false;
            this.btnCacheSelected.Location = new System.Drawing.Point(103, 580);
            this.btnCacheSelected.Name = "btnCacheSelected";
            this.btnCacheSelected.Size = new System.Drawing.Size(122, 23);
            this.btnCacheSelected.TabIndex = 9;
            this.btnCacheSelected.Text = "Cache Selected";
            this.btnCacheSelected.UseVisualStyleBackColor = true;
            this.btnCacheSelected.Click += new System.EventHandler(this.btnCacheSelected_Click);
            // 
            // btnClearCacheForSelected
            // 
            this.btnClearCacheForSelected.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnClearCacheForSelected.Enabled = false;
            this.btnClearCacheForSelected.Location = new System.Drawing.Point(443, 545);
            this.btnClearCacheForSelected.Name = "btnClearCacheForSelected";
            this.btnClearCacheForSelected.Size = new System.Drawing.Size(94, 37);
            this.btnClearCacheForSelected.TabIndex = 10;
            this.btnClearCacheForSelected.Text = "Clear Cache For Selected";
            this.btnClearCacheForSelected.UseVisualStyleBackColor = true;
            this.btnClearCacheForSelected.Click += new System.EventHandler(this.btnClearCacheForSelected_Click);
            // 
            // cbIncludeCumulative
            // 
            this.cbIncludeCumulative.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cbIncludeCumulative.AutoSize = true;
            this.cbIncludeCumulative.Location = new System.Drawing.Point(289, 560);
            this.cbIncludeCumulative.Name = "cbIncludeCumulative";
            this.cbIncludeCumulative.Size = new System.Drawing.Size(148, 17);
            this.cbIncludeCumulative.TabIndex = 11;
            this.cbIncludeCumulative.Text = "Include Cumulative Totals";
            this.cbIncludeCumulative.UseVisualStyleBackColor = true;
            this.cbIncludeCumulative.CheckedChanged += new System.EventHandler(this.cbIncludeCumulative_CheckedChanged);
            // 
            // ConfigureCohortContainersUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.cbIncludeCumulative);
            this.Controls.Add(this.btnClearCacheForSelected);
            this.Controls.Add(this.btnCacheSelected);
            this.Controls.Add(this.btnStartSelected);
            this.Controls.Add(this.lblThreadCount);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.tbTimeout);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.lblSubIndex);
            this.Controls.Add(this.lblDropTarget);
            this.Controls.Add(this.btnAddContainer);
            this.Controls.Add(this.otvConfiguration);
            this.Name = "ConfigureCohortContainersUI";
            this.Size = new System.Drawing.Size(540, 632);
            ((System.ComponentModel.ISupportInitialize)(this.otvConfiguration)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TreeListView otvConfiguration;
        private System.Windows.Forms.Button btnAddContainer;
        private OLVColumn olvAggregate;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Label lblDropTarget;
        private System.Windows.Forms.Label lblSubIndex;
        private OLVColumn olvIdentifierCount;
        private OLVColumn olvWorking;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbTimeout;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Timer refreshThreadCountPeriodically;
        private System.Windows.Forms.Label lblThreadCount;
        private OLVColumn olvCatalogue;
        private OLVColumn olvOrder;
        private OLVColumn olvTime;
        private OLVColumn olvCachedQueryUseCount;
        private System.Windows.Forms.Button btnStartSelected;
        private System.Windows.Forms.Button btnCacheSelected;
        private System.Windows.Forms.Button btnClearCacheForSelected;
        private OLVColumn olvCumulativeTotal;
        private System.Windows.Forms.CheckBox cbIncludeCumulative;
    }
}

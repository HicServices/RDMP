using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved

namespace HIC.Logging.PastEvents
{
    public class ArchivalProgressLog : IArchivalLoggingRecordOfPastEvent
    {
        public int ID { get; set; }
        public DateTime Date { get; set; }
        public string EventType { get; set; }
        public string Description { get; set; }

        public ArchivalProgressLog(int id, DateTime date,string eventType,string description)
        {
            ID = id;
            Date = date;
            EventType = eventType;
            Description = description;
        }
        public string ToShortString()
        {
            var s = ToString();
            if (s.Length > ArchivalDataLoadInfo.MaxDescriptionLength)
                return s.Substring(0, ArchivalDataLoadInfo.MaxDescriptionLength) + "...";
            return s;
        }
        public override string ToString()
        {
            return Date + " - " + Description;
        }
    }
}

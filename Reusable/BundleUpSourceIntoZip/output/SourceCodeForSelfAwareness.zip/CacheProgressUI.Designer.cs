namespace CatalogueManager.DataLoadUIs // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
{
    partial class CacheProgressUI
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbCacheProgress = new System.Windows.Forms.GroupBox();
            this.cbPipelineContext = new System.Windows.Forms.ComboBox();
            this.cbPermissionWindowRequired = new System.Windows.Forms.CheckBox();
            this.btnEditPermissionWindow = new System.Windows.Forms.Button();
            this.btnAddNewPermissionWindow = new System.Windows.Forms.Button();
            this.ddPermissionWindow = new System.Windows.Forms.ComboBox();
            this.tbCacheProgress = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnConfigureCachingPipeline = new System.Windows.Forms.Button();
            this.ddCacheLagDurationType = new System.Windows.Forms.ComboBox();
            this.udCacheLagDuration = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.tbChunkPeriod = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbCacheProgressID = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.gbCacheProgress.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.udCacheLagDuration)).BeginInit();
            this.SuspendLayout();
            // 
            // gbCacheProgress
            // 
            this.gbCacheProgress.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gbCacheProgress.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gbCacheProgress.Controls.Add(this.cbPipelineContext);
            this.gbCacheProgress.Controls.Add(this.cbPermissionWindowRequired);
            this.gbCacheProgress.Controls.Add(this.btnEditPermissionWindow);
            this.gbCacheProgress.Controls.Add(this.btnAddNewPermissionWindow);
            this.gbCacheProgress.Controls.Add(this.ddPermissionWindow);
            this.gbCacheProgress.Controls.Add(this.tbCacheProgress);
            this.gbCacheProgress.Controls.Add(this.label4);
            this.gbCacheProgress.Controls.Add(this.btnConfigureCachingPipeline);
            this.gbCacheProgress.Controls.Add(this.ddCacheLagDurationType);
            this.gbCacheProgress.Controls.Add(this.udCacheLagDuration);
            this.gbCacheProgress.Controls.Add(this.label10);
            this.gbCacheProgress.Controls.Add(this.label8);
            this.gbCacheProgress.Controls.Add(this.label13);
            this.gbCacheProgress.Controls.Add(this.tbChunkPeriod);
            this.gbCacheProgress.Controls.Add(this.label3);
            this.gbCacheProgress.Controls.Add(this.tbCacheProgressID);
            this.gbCacheProgress.Controls.Add(this.label9);
            this.gbCacheProgress.Location = new System.Drawing.Point(3, 3);
            this.gbCacheProgress.Name = "gbCacheProgress";
            this.gbCacheProgress.Size = new System.Drawing.Size(505, 233);
            this.gbCacheProgress.TabIndex = 32;
            this.gbCacheProgress.TabStop = false;
            this.gbCacheProgress.Text = "Cache Progress:";
            // 
            // cbPipelineContext
            // 
            this.cbPipelineContext.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbPipelineContext.FormattingEnabled = true;
            this.cbPipelineContext.Location = new System.Drawing.Point(159, 117);
            this.cbPipelineContext.Name = "cbPipelineContext";
            this.cbPipelineContext.Size = new System.Drawing.Size(340, 21);
            this.cbPipelineContext.TabIndex = 42;
            this.cbPipelineContext.SelectedIndexChanged += new System.EventHandler(this.cbPipelineContext_SelectedIndexChanged);
            // 
            // cbPermissionWindowRequired
            // 
            this.cbPermissionWindowRequired.AutoSize = true;
            this.cbPermissionWindowRequired.Location = new System.Drawing.Point(159, 183);
            this.cbPermissionWindowRequired.Name = "cbPermissionWindowRequired";
            this.cbPermissionWindowRequired.Size = new System.Drawing.Size(311, 17);
            this.cbPermissionWindowRequired.TabIndex = 41;
            this.cbPermissionWindowRequired.Text = "Source component can only access data at particular times?";
            this.cbPermissionWindowRequired.UseVisualStyleBackColor = true;
            this.cbPermissionWindowRequired.CheckedChanged += new System.EventHandler(this.cbPermissionWindowRequired_CheckedChanged);
            // 
            // btnEditPermissionWindow
            // 
            this.btnEditPermissionWindow.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnEditPermissionWindow.Enabled = false;
            this.btnEditPermissionWindow.Location = new System.Drawing.Point(408, 206);
            this.btnEditPermissionWindow.Name = "btnEditPermissionWindow";
            this.btnEditPermissionWindow.Size = new System.Drawing.Size(91, 23);
            this.btnEditPermissionWindow.TabIndex = 40;
            this.btnEditPermissionWindow.Text = "Edit...";
            this.btnEditPermissionWindow.UseVisualStyleBackColor = true;
            this.btnEditPermissionWindow.Click += new System.EventHandler(this.btnEditPermissionWindow_Click);
            // 
            // btnAddNewPermissionWindow
            // 
            this.btnAddNewPermissionWindow.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAddNewPermissionWindow.Enabled = false;
            this.btnAddNewPermissionWindow.Location = new System.Drawing.Point(311, 206);
            this.btnAddNewPermissionWindow.Name = "btnAddNewPermissionWindow";
            this.btnAddNewPermissionWindow.Size = new System.Drawing.Size(91, 23);
            this.btnAddNewPermissionWindow.TabIndex = 31;
            this.btnAddNewPermissionWindow.Text = "Add New...";
            this.btnAddNewPermissionWindow.UseVisualStyleBackColor = true;
            this.btnAddNewPermissionWindow.Click += new System.EventHandler(this.btnAddNewPermissionWindow_Click);
            // 
            // ddPermissionWindow
            // 
            this.ddPermissionWindow.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ddPermissionWindow.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddPermissionWindow.Enabled = false;
            this.ddPermissionWindow.FormattingEnabled = true;
            this.ddPermissionWindow.Location = new System.Drawing.Point(159, 206);
            this.ddPermissionWindow.Name = "ddPermissionWindow";
            this.ddPermissionWindow.Size = new System.Drawing.Size(146, 21);
            this.ddPermissionWindow.TabIndex = 39;
            this.ddPermissionWindow.SelectedIndexChanged += new System.EventHandler(this.ddPermissionWindow_SelectedIndexChanged);
            // 
            // tbCacheProgress
            // 
            this.tbCacheProgress.Location = new System.Drawing.Point(159, 39);
            this.tbCacheProgress.Name = "tbCacheProgress";
            this.tbCacheProgress.ReadOnly = true;
            this.tbCacheProgress.Size = new System.Drawing.Size(130, 20);
            this.tbCacheProgress.TabIndex = 27;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(68, 42);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 13);
            this.label4.TabIndex = 21;
            this.label4.Text = "Cache Progress:";
            // 
            // btnConfigureCachingPipeline
            // 
            this.btnConfigureCachingPipeline.Location = new System.Drawing.Point(159, 144);
            this.btnConfigureCachingPipeline.Name = "btnConfigureCachingPipeline";
            this.btnConfigureCachingPipeline.Size = new System.Drawing.Size(156, 23);
            this.btnConfigureCachingPipeline.TabIndex = 37;
            this.btnConfigureCachingPipeline.Text = "Configure Caching Pipeline";
            this.btnConfigureCachingPipeline.UseVisualStyleBackColor = true;
            this.btnConfigureCachingPipeline.Click += new System.EventHandler(this.btnConfigureCachingPipeline_Click);
            // 
            // ddCacheLagDurationType
            // 
            this.ddCacheLagDurationType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddCacheLagDurationType.FormattingEnabled = true;
            this.ddCacheLagDurationType.Location = new System.Drawing.Point(203, 65);
            this.ddCacheLagDurationType.Name = "ddCacheLagDurationType";
            this.ddCacheLagDurationType.Size = new System.Drawing.Size(71, 21);
            this.ddCacheLagDurationType.TabIndex = 33;
            this.ddCacheLagDurationType.SelectedIndexChanged += new System.EventHandler(this.ddCacheLagDurationType_SelectedIndexChanged);
            // 
            // udCacheLagDuration
            // 
            this.udCacheLagDuration.Location = new System.Drawing.Point(159, 65);
            this.udCacheLagDuration.Name = "udCacheLagDuration";
            this.udCacheLagDuration.Size = new System.Drawing.Size(38, 20);
            this.udCacheLagDuration.TabIndex = 38;
            this.udCacheLagDuration.ValueChanged += new System.EventHandler(this.udCacheLagDuration_ValueChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(51, 209);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(102, 13);
            this.label10.TabIndex = 30;
            this.label10.Text = "Permission Window:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(79, 94);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(74, 13);
            this.label8.TabIndex = 30;
            this.label8.Text = "Chunk Period:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(58, 68);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(95, 13);
            this.label13.TabIndex = 30;
            this.label13.Text = "Cache Lag Period:";
            // 
            // tbChunkPeriod
            // 
            this.tbChunkPeriod.Location = new System.Drawing.Point(159, 91);
            this.tbChunkPeriod.Name = "tbChunkPeriod";
            this.tbChunkPeriod.Size = new System.Drawing.Size(130, 20);
            this.tbChunkPeriod.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(67, 120);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 13);
            this.label3.TabIndex = 21;
            this.label3.Text = "Pipeline Context:";
            // 
            // tbCacheProgressID
            // 
            this.tbCacheProgressID.Location = new System.Drawing.Point(159, 13);
            this.tbCacheProgressID.Name = "tbCacheProgressID";
            this.tbCacheProgressID.ReadOnly = true;
            this.tbCacheProgressID.Size = new System.Drawing.Size(130, 20);
            this.tbCacheProgressID.TabIndex = 2;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(132, 16);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(21, 13);
            this.label9.TabIndex = 21;
            this.label9.Text = "ID:";
            // 
            // CacheProgressUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.gbCacheProgress);
            this.MaximumSize = new System.Drawing.Size(0, 237);
            this.MinimumSize = new System.Drawing.Size(511, 237);
            this.Name = "CacheProgressUI";
            this.Size = new System.Drawing.Size(511, 237);
            this.gbCacheProgress.ResumeLayout(false);
            this.gbCacheProgress.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.udCacheLagDuration)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbCacheProgress;
        private System.Windows.Forms.CheckBox cbPermissionWindowRequired;
        private System.Windows.Forms.Button btnEditPermissionWindow;
        private System.Windows.Forms.Button btnAddNewPermissionWindow;
        private System.Windows.Forms.ComboBox ddPermissionWindow;
        private System.Windows.Forms.TextBox tbCacheProgress;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnConfigureCachingPipeline;
        private System.Windows.Forms.ComboBox ddCacheLagDurationType;
        private System.Windows.Forms.NumericUpDown udCacheLagDuration;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox tbChunkPeriod;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbCacheProgressID;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cbPipelineContext;
    }
}

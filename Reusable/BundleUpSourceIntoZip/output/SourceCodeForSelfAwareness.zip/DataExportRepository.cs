using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Data.Common;
using CatalogueLibrary.Repositories;
using DataExportManager2.Interfaces.Data;
using DataExportManager2.Interfaces.Data.DataTables;
using DataExportManager2.Interfaces.Repositories;
using DataExportManager2Library.Data.DataTables;
using DataExportManager2Library.Data.LinkCreators;
using MapsDirectlyToDatabaseTable;

namespace DataExportManager2Library.Repositories
{
    public class DataExportRepository : TableRepository, IDataExportRepository
    {
        public CatalogueRepository CatalogueRepository { get; private set; }
        public ISelectedDataSets SelectedDataSets { get; private set; }
        
        public DataExportRepository(DbConnectionStringBuilder connectionString, CatalogueRepository catalogueRepository) : base(null, connectionString)
        {
            CatalogueRepository = catalogueRepository;
            SelectedDataSets = new SelectedDataSets(this);
        }

        /// <summary>
        /// Defines a new ExtractionConfiguration for the supplied  project this is stored in the DataExportManager2 database and the
        ///  ID of the new record is returned by this  method, use GetExtractionConfigurationByID to get the object back from the database
        /// </summary>
        /// <returns></returns>
        public int CreateNewExtractionConfigurationForProjectInDatabase(IProject project)
        {
            return InsertAndReturnID<ExtractionConfiguration>(new Dictionary<string, object>
            {
                {"dtCreated", DateTime.Now},
                {"Project_ID", ((Project)project).ID},
                {"Username", Environment.UserName},
                {"Description", "Initial Configuration"}
            });
        }


        public IEnumerable<ICumulativeExtractionResults> GetAllCumulativeExtractionResultsFor(IExtractionConfiguration configuration, IExtractableDataSet dataset)
        {
            return GetAllObjects<CumulativeExtractionResults>("WHERE ExtractionConfiguration_ID=" + configuration.ID + "AND ExtractableDataSet_ID=" + dataset.ID);
        }

        protected override IMapsDirectlyToDatabaseTable ConstructEntity(Type t, DbDataReader reader)
        {
            // Find the constructor
            var constructorInfo = t.GetConstructor(new[] { typeof(IRepository), typeof(DbDataReader) });
            if (constructorInfo == null)
                throw new Exception("ConstructEntity<" + t.Name + "> requires that the specified IMapsDirectlyToDatabaseTable object implements the constructor IRepository, DbDataReader");

            var toReturn = (IMapsDirectlyToDatabaseTable)constructorInfo.Invoke(new object[] { this, reader });

            toReturn.Repository = this;
            return toReturn;
        }

    }
}

using System.ServiceProcess; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved

namespace DLEWindowsService
{
    public class DLEService : ServiceBase
    {
        public DLEService()
        {
            ServiceName = Program.ServiceName;
        }

        protected override void OnStart(string[] args)
        {
            Program.Start(args);
        }

        protected override void OnStop()
        {
            Program.Stop();
        }
    }
}

using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MapsDirectlyToDatabaseTable.Relationships
{
    public class ChildFinder
    {
        private RelationshipMap _map;

        public ChildFinder(SqlConnectionStringBuilder builder)
        {
            try
            {
                _map = new RelationshipMap(builder);
            }
            catch (Exception e)
            {
                throw new Exception("Could not assembly relationship map",e);
            }
        }

        public IMapsDirectlyToDatabaseTable[] GetChildren(IMapsDirectlyToDatabaseTable root, bool cascadeOnly)
        {
            //find the relationships
            
            throw new NotImplementedException("This is half implemented code to allow the generation of dependency graphs without having to have explicit logic about how to find children in the classes themselves, a lot of it works and has tests but might disapear in due course");

            /*
            var relationships = _map.GetRelationships(root.GetType().Name,cascadeOnly);
             
            foreach (Relationship relationship in relationships)
            {
                
                //MapsDirectlyToDatabaseTableRepository.GetObjectByID<>()
                //relationship.ChildForeignKeyField
            }*/
        }
    }
}

using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Diagnostics.Contracts;
using System.IO;
using CatalogueLibrary.Data;
using CatalogueLibrary.Data.Cache;
using CatalogueLibrary.Data.DataLoad;
using CatalogueLibrary.DataFlowPipeline.Requirements;
using CatalogueLibrary.Repositories;
using ReusableLibraryCode.Checks;
using ReusableLibraryCode.Progress;

namespace CatalogueLibrary.DataFlowPipeline.Destinations
{
    public enum CacheFileGranularity
    {
        Hour,
        Day
    };

    public interface ICacheFileSystemDestination : IPipelineRequirement<ICacheFetchRequestProvider>, IPipelineRequirement<IHICProjectDirectory>, IPipelineRequirement<MEF>
    {
        CacheFileGranularity CacheFileGranularity { get; set; }
    }

    public abstract class CacheFilesystemDestination<T> : ICacheFileSystemDestination, IPluginDataFlowComponent<T>, IDataFlowDestination<T>
    {
        protected MEF MEFPlugins;

        [DemandsInitialization("The date format for archiving the report files")]
        public string DateFormat { get; set; }

        [DemandsInitialization("The type of archive that should be used to hold the XML files, e.g. zip, tar")]
        public CacheArchiveType ArchiveType { get; set; }

        [DemandsInitialization("The time period covered by a single archive file (different from ChunkPeriod which determines the period retrieved by the caching implementation in a single request")]
        public CacheFileGranularity CacheFileGranularity { get; set; }

        [DemandsInitialization("The cache's root directory")]
        public DirectoryInfo CacheDirectory { get; set; }

        [DemandsInitialization("The full class name of the CacheLayout class")]
        public string CacheLayoutType { get; set; }

        [DemandsInitialization("The full class name of the CachePathResolver class")]
        public string CachePathResolverType  { get; set; }

        protected ICacheLayout CacheLayout;
        protected ICacheFetchRequestProvider CacheFetchRequestProvider;
        protected ILoadCachePathResolver CachePathResolver;
        protected IHICProjectDirectory HICProjectDirectory;

        public abstract T ProcessPipelineData(T toProcess, IDataLoadEventListener listener, GracefulCancellationToken cancellationToken);
        
        public void PreInitialize(ICacheFetchRequestProvider value, IDataLoadEventListener listener)
        {
            CacheFetchRequestProvider = value;

            if (CacheFetchRequestProvider == null)
                throw new Exception("Pipeline requirement failure, the CacheFetchRequest object is null. Check that this component has been correctly initialised (requires a single CacheFetchRequest)");
        }

        public void PreInitialize(MEF mefPlugins, IDataLoadEventListener listener)
        {
            MEFPlugins = mefPlugins;

            if (CacheLayout == null)
                CreateCacheLayout();
        }

        public void PreInitialize(IHICProjectDirectory value, IDataLoadEventListener listener)
        {
            HICProjectDirectory = value;

            // CacheDirectory overrides HICProjectDirectory, so only set CacheDirectory if it is null (i.e. no alternative cache location has been configured in the destination component)
            if (CacheDirectory == null)
            {
                if (value.Cache == null)
                    throw new Exception("For some reason the HICProjectDirectory does not have a Cache specified and the FilesystemDestination component does not have an override CacheDirectory specified");

                CacheDirectory = value.Cache;
            }

            if (CacheLayout == null)
                CreateCacheLayout();
        }

        private void CreateCacheLayout()
        {
            // These checks are so we don't have to worry about order of execution for the pre-initialize statements
            // This is a bit awkward because it depends on two pre-initialized fields.
            if (MEFPlugins == null)
                return;

            if (CacheDirectory == null)
                return;

            var factory = new CacheLayoutFactory(MEFPlugins);
            CacheLayout = factory.Create(CacheLayoutType, CacheDirectory);
            CacheLayout.ArchiveType = ArchiveType;
            CacheLayout.DateFormat = DateFormat;
            
            if (CacheLayout == null)
                throw new Exception("Could not create CacheLayout '" + CacheLayoutType + "' for the cache destination component.");
        }

        public void Dispose(IDataLoadEventListener listener, Exception pipelineFailureExceptionIfAny)
        {
        }

        public abstract void Abort(IDataLoadEventListener listener);

        public void Stop()
        {
        }

        public void Abort()
        {
        }

        public bool SilentRunning { get; set; }
        public virtual void Check(ICheckNotifier notifier)
        {
            if (MEFPlugins == null)
                throw new InvalidOperationException("MEFPlugins is null, ensure that pre-initialize has been called with a valid object before checking.");

            if (HICProjectDirectory == null)
                throw new InvalidOperationException("HICProjectDirectory is null, ensure that pre-initialize has been called with a valid object before checking.");

            // Check that we can see an instance of the CacheLayout class (we need a valid HICProjectDirectory to create one, so can't go that far)
            if (MEFPlugins.GetTypeByNameFromAnyLoadedAssembly(CacheLayoutType) == null)
                notifier.OnCheckPerformed(new CheckEventArgs("The type specified for CacheLayoutType (" + CacheLayoutType + ") in the CachedFileRetriever component cannot be located. Please ensure that the name is correct and that any dependent projects have been fully built.", CheckResult.Fail));
            else
                notifier.OnCheckPerformed(new CheckEventArgs("Found " + CacheLayoutType, CheckResult.Success));

            // Check that we can see an instance of the CachePathResolver class
            if (MEFPlugins.GetTypeByNameFromAnyLoadedAssembly(CachePathResolverType) == null)
                notifier.OnCheckPerformed(new CheckEventArgs("The type specified for CachePathResolverType (" + CachePathResolverType + ") in the CachedFileRetriever component cannot be located. Please ensure that the name is correct and that any dependent projects have been fully built.", CheckResult.Fail));
            else
                notifier.OnCheckPerformed(new CheckEventArgs("Found " + CachePathResolverType, CheckResult.Success));


            if (DateFormat == null)
                notifier.OnCheckPerformed(new CheckEventArgs("DateFormat has not been set", CheckResult.Fail));
            else
                notifier.OnCheckPerformed(new CheckEventArgs("DateFormat of CacheFilesystemDestination component is " + DateFormat, CheckResult.Success));

            // If we have an overriden cache directory, ensure we can reach it and write to it
            if (CacheDirectory != null)
            {
                try
                {
                    var tempFilename = Path.Combine(CacheDirectory.FullName, ".test.txt");
                    var sw = File.CreateText(tempFilename);
                    sw.Close();
                    sw.Dispose();
                    File.Delete(tempFilename);
                    notifier.OnCheckPerformed(new CheckEventArgs("Confirmed could write to/delete from the overridden CacheDirectory: " + CacheDirectory.FullName, CheckResult.Success));
                }
                catch (Exception e)
                {
                    notifier.OnCheckPerformed(new CheckEventArgs("Could not write to the overridden CacheDirectory: " + CacheDirectory.FullName, CheckResult.Fail, e));
                }
            }

            // Check CacheLayout creation
            CreateCacheLayout();
            if (CacheLayout.DateFormat == null)
                notifier.OnCheckPerformed(new CheckEventArgs("The CacheLayout object in CacheFilesystemDestination is not being constructed correctly, DateFormat is null", CheckResult.Fail));
            else
                notifier.OnCheckPerformed(new CheckEventArgs("CacheLayout object in CacheFilesystemDestination is OK", CheckResult.Success));
        }
    }
}

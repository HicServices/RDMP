//specially for MSword file // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using CatalogueLibrary.Data;
using CatalogueLibrary.Triggers;
using Microsoft.Office.Interop.Word;
using ReusableLibraryCode;
using ReusableLibraryCode.Checks;
using ReusableLibraryCode.DataAccess;

namespace CatalogueLibrary.Reports
{
    public class DocumentationReportMapsDirectlyToDatabaseOfficeBit : RequiresMicrosoftOffice
    {
        Microsoft.Office.Interop.Word.Application wrdApp;
        private DocumentationReportMapsDirectlyToDatabase _report;

        public void GenerateReport(ICheckNotifier notifier)
        {
            try
            {
                _report = new DocumentationReportMapsDirectlyToDatabase(typeof(Catalogue).Assembly);
                _report.Check(notifier);
            
                object oMissing = Missing.Value;
                object oEndOfDoc = "\\endofdoc"; /* \endofdoc is a predefined bookmark */

                //word = new word.ApplicationClass();
                wrdApp = new Application();

                wrdApp.Visible = true;
                var doc = wrdApp.Documents.Add(ref oMissing, ref oMissing, ref oMissing, ref oMissing);

                Range wrdRng = doc.Bookmarks.get_Item(ref oEndOfDoc).Range;

                Table newTable;
                newTable = doc.Tables.Add(wrdRng, _report.Summaries.Count+1, 2, ref oMissing, ref oMissing);
                newTable.Borders.InsideLineStyle = WdLineStyle.wdLineStyleSingle;
                newTable.Borders.OutsideLineStyle = WdLineStyle.wdLineStyleSingle;
                newTable.AllowAutoFit = true;
            
                //Listing Cell header
                newTable.Cell(1, 1).Range.Text = "Table";
                newTable.Cell(1, 2).Range.Text = "Definition";

                Type[] keys = _report.Summaries.Keys.ToArray();

                for(int i=0;i<_report.Summaries.Count;i++)
                {
                    newTable.Cell(i + 2, 1).Range.Text = keys[i].Name;
                    newTable.Cell(i + 2, 2).Range.Text = _report.Summaries[keys[i]];
                }
            }
            catch (Exception e)
            {
                notifier.OnCheckPerformed(new CheckEventArgs("Report generation failed",CheckResult.Fail ,e));
            }
        }
    }
}

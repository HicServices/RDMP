namespace CatalogueManager.AggregationUIs // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
{
    partial class AggregateDimensionManagementTabUI
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lbAvailableTables = new System.Windows.Forms.ListBox();
            this.tbAutomaticJoins = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.btnForceJoinOnSelectedTable = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.lbSelectedTables = new System.Windows.Forms.ListBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.aggregateDimensionUI1 = new CatalogueManager.AggregationUIs.AggregateDimensionUI();
            this.btnImportDimension = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.lbAvailableExtractionInformations = new System.Windows.Forms.ListBox();
            this.lbSelectedDimensions = new System.Windows.Forms.ListBox();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.lbAvailableTables);
            this.groupBox2.Controls.Add(this.tbAutomaticJoins);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.btnForceJoinOnSelectedTable);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.lbSelectedTables);
            this.groupBox2.Location = new System.Drawing.Point(6, 700);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(925, 174);
            this.groupBox2.TabIndex = 19;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "TableJoins";
            // 
            // lbAvailableTables
            // 
            this.lbAvailableTables.FormattingEnabled = true;
            this.lbAvailableTables.Location = new System.Drawing.Point(6, 35);
            this.lbAvailableTables.Name = "lbAvailableTables";
            this.lbAvailableTables.ScrollAlwaysVisible = true;
            this.lbAvailableTables.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lbAvailableTables.Size = new System.Drawing.Size(382, 134);
            this.lbAvailableTables.TabIndex = 0;
            // 
            // tbAutomaticJoins
            // 
            this.tbAutomaticJoins.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbAutomaticJoins.Location = new System.Drawing.Point(508, 110);
            this.tbAutomaticJoins.Multiline = true;
            this.tbAutomaticJoins.Name = "tbAutomaticJoins";
            this.tbAutomaticJoins.ReadOnly = true;
            this.tbAutomaticJoins.Size = new System.Drawing.Size(411, 59);
            this.tbAutomaticJoins.TabIndex = 11;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 19);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(88, 13);
            this.label9.TabIndex = 7;
            this.label9.Text = "Available Tables:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(505, 94);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(335, 13);
            this.label11.TabIndex = 10;
            this.label11.Text = "Automatically JOINed Tables (Based on Selected Dimensions above):";
            // 
            // btnForceJoinOnSelectedTable
            // 
            this.btnForceJoinOnSelectedTable.Location = new System.Drawing.Point(394, 35);
            this.btnForceJoinOnSelectedTable.Name = "btnForceJoinOnSelectedTable";
            this.btnForceJoinOnSelectedTable.Size = new System.Drawing.Size(108, 56);
            this.btnForceJoinOnSelectedTable.TabIndex = 8;
            this.btnForceJoinOnSelectedTable.Text = "Force JOIN to TableInfo >>";
            this.btnForceJoinOnSelectedTable.UseVisualStyleBackColor = true;
            this.btnForceJoinOnSelectedTable.Click += new System.EventHandler(this.btnForceJoinOnSelectedTable_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(505, 16);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(115, 13);
            this.label10.TabIndex = 10;
            this.label10.Text = "Force JOIN To Tables:";
            // 
            // lbSelectedTables
            // 
            this.lbSelectedTables.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbSelectedTables.FormattingEnabled = true;
            this.lbSelectedTables.Location = new System.Drawing.Point(508, 35);
            this.lbSelectedTables.Name = "lbSelectedTables";
            this.lbSelectedTables.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lbSelectedTables.Size = new System.Drawing.Size(408, 56);
            this.lbSelectedTables.Sorted = true;
            this.lbSelectedTables.TabIndex = 9;
            this.lbSelectedTables.KeyUp += new System.Windows.Forms.KeyEventHandler(this.lbSelectedTables_KeyUp);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.aggregateDimensionUI1);
            this.groupBox1.Location = new System.Drawing.Point(400, 314);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(534, 380);
            this.groupBox1.TabIndex = 18;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Selected Dimension";
            // 
            // aggregateDimensionUI1
            // 
            this.aggregateDimensionUI1.AggregateDimension = null;
            this.aggregateDimensionUI1.AutoSize = true;
            this.aggregateDimensionUI1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.aggregateDimensionUI1.Location = new System.Drawing.Point(3, 16);
            this.aggregateDimensionUI1.Name = "aggregateDimensionUI1";
            this.aggregateDimensionUI1.Size = new System.Drawing.Size(528, 361);
            this.aggregateDimensionUI1.TabIndex = 5;
            // 
            // btnImportDimension
            // 
            this.btnImportDimension.Location = new System.Drawing.Point(416, 41);
            this.btnImportDimension.Name = "btnImportDimension";
            this.btnImportDimension.Size = new System.Drawing.Size(108, 23);
            this.btnImportDimension.TabIndex = 17;
            this.btnImportDimension.Text = "Import (COPY)";
            this.btnImportDimension.UseVisualStyleBackColor = true;
            this.btnImportDimension.Click += new System.EventHandler(this.btnImportDimension_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(110, 13);
            this.label5.TabIndex = 14;
            this.label5.Text = "Available Dimensions:";
            // 
            // lbAvailableExtractionInformations
            // 
            this.lbAvailableExtractionInformations.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.lbAvailableExtractionInformations.FormattingEnabled = true;
            this.lbAvailableExtractionInformations.Location = new System.Drawing.Point(3, 22);
            this.lbAvailableExtractionInformations.Name = "lbAvailableExtractionInformations";
            this.lbAvailableExtractionInformations.ScrollAlwaysVisible = true;
            this.lbAvailableExtractionInformations.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lbAvailableExtractionInformations.Size = new System.Drawing.Size(382, 667);
            this.lbAvailableExtractionInformations.TabIndex = 13;
            // 
            // lbSelectedDimensions
            // 
            this.lbSelectedDimensions.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.lbSelectedDimensions.FormattingEnabled = true;
            this.lbSelectedDimensions.Location = new System.Drawing.Point(533, 22);
            this.lbSelectedDimensions.Name = "lbSelectedDimensions";
            this.lbSelectedDimensions.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lbSelectedDimensions.Size = new System.Drawing.Size(392, 277);
            this.lbSelectedDimensions.Sorted = true;
            this.lbSelectedDimensions.TabIndex = 16;
            this.lbSelectedDimensions.SelectedIndexChanged += new System.EventHandler(this.lbSelectedDimensions_SelectedIndexChanged);
            this.lbSelectedDimensions.KeyUp += new System.Windows.Forms.KeyEventHandler(this.lbSelectedDimensions_KeyUp);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(530, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(109, 13);
            this.label6.TabIndex = 15;
            this.label6.Text = "Selected Dimensions:";
            // 
            // AggregateDimensionManagementTabUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnImportDimension);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lbAvailableExtractionInformations);
            this.Controls.Add(this.lbSelectedDimensions);
            this.Controls.Add(this.label6);
            this.Name = "AggregateDimensionManagementTabUI";
            this.Size = new System.Drawing.Size(937, 877);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ListBox lbAvailableTables;
        private System.Windows.Forms.TextBox tbAutomaticJoins;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnForceJoinOnSelectedTable;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ListBox lbSelectedTables;
        private System.Windows.Forms.GroupBox groupBox1;
        private AggregateDimensionUI aggregateDimensionUI1;
        private System.Windows.Forms.Button btnImportDimension;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ListBox lbAvailableExtractionInformations;
        private System.Windows.Forms.ListBox lbSelectedDimensions;
        private System.Windows.Forms.Label label6;
    }
}

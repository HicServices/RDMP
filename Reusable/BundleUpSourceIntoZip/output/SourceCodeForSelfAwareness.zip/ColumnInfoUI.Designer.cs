namespace CatalogueManager.MainFormUITabs.SubComponents // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
{
    partial class ColumnInfoUI
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ti_gbColumnInfo = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cbIsPrimaryKey = new System.Windows.Forms.CheckBox();
            this.label48 = new System.Windows.Forms.Label();
            this.cbxColumnInfoStatus = new System.Windows.Forms.ComboBox();
            this.tbColumnInfoID = new System.Windows.Forms.TextBox();
            this.tbColumnInfoValidationRules = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.tbColumnInfoName = new System.Windows.Forms.TextBox();
            this.tbColumnInfoRegexPattern = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.tbColumnInfoType = new System.Windows.Forms.TextBox();
            this.label58 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.tbColumnInfoDescription = new System.Windows.Forms.TextBox();
            this.tbColumnInfoFormat = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.btnColumnInfoSave = new System.Windows.Forms.Button();
            this.tbColumnInfoDigitisationSpecs = new System.Windows.Forms.TextBox();
            this.tbColumnInfoSource = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.ti_gbColumnInfo.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // ti_gbColumnInfo
            // 
            this.ti_gbColumnInfo.Controls.Add(this.panel1);
            this.ti_gbColumnInfo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ti_gbColumnInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ti_gbColumnInfo.Location = new System.Drawing.Point(0, 0);
            this.ti_gbColumnInfo.Name = "ti_gbColumnInfo";
            this.ti_gbColumnInfo.Size = new System.Drawing.Size(503, 800);
            this.ti_gbColumnInfo.TabIndex = 151;
            this.ti_gbColumnInfo.TabStop = false;
            this.ti_gbColumnInfo.Text = "ColumnInfo";
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.cbIsPrimaryKey);
            this.panel1.Controls.Add(this.label48);
            this.panel1.Controls.Add(this.cbxColumnInfoStatus);
            this.panel1.Controls.Add(this.tbColumnInfoID);
            this.panel1.Controls.Add(this.tbColumnInfoValidationRules);
            this.panel1.Controls.Add(this.label47);
            this.panel1.Controls.Add(this.label59);
            this.panel1.Controls.Add(this.tbColumnInfoName);
            this.panel1.Controls.Add(this.tbColumnInfoRegexPattern);
            this.panel1.Controls.Add(this.label46);
            this.panel1.Controls.Add(this.label57);
            this.panel1.Controls.Add(this.tbColumnInfoType);
            this.panel1.Controls.Add(this.label58);
            this.panel1.Controls.Add(this.label45);
            this.panel1.Controls.Add(this.tbColumnInfoDescription);
            this.panel1.Controls.Add(this.tbColumnInfoFormat);
            this.panel1.Controls.Add(this.label56);
            this.panel1.Controls.Add(this.label44);
            this.panel1.Controls.Add(this.btnColumnInfoSave);
            this.panel1.Controls.Add(this.tbColumnInfoDigitisationSpecs);
            this.panel1.Controls.Add(this.tbColumnInfoSource);
            this.panel1.Controls.Add(this.label49);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 25);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(497, 772);
            this.panel1.TabIndex = 160;
            // 
            // cbIsPrimaryKey
            // 
            this.cbIsPrimaryKey.AutoSize = true;
            this.cbIsPrimaryKey.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.cbIsPrimaryKey.Location = new System.Drawing.Point(142, 9);
            this.cbIsPrimaryKey.Name = "cbIsPrimaryKey";
            this.cbIsPrimaryKey.Size = new System.Drawing.Size(92, 17);
            this.cbIsPrimaryKey.TabIndex = 162;
            this.cbIsPrimaryKey.Text = "Is Primary Key";
            this.cbIsPrimaryKey.UseVisualStyleBackColor = true;
            this.cbIsPrimaryKey.CheckedChanged += new System.EventHandler(this.cbIsPrimaryKey_CheckedChanged);
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label48.Location = new System.Drawing.Point(13, 10);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(74, 13);
            this.label48.TabIndex = 143;
            this.label48.Text = "ColumnInfo ID";
            // 
            // cbxColumnInfoStatus
            // 
            this.cbxColumnInfoStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxColumnInfoStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.cbxColumnInfoStatus.FormattingEnabled = true;
            this.cbxColumnInfoStatus.Items.AddRange(new object[] {
            "",
            "Active",
            "Inactive",
            "Archived",
            "Deprecated"});
            this.cbxColumnInfoStatus.Location = new System.Drawing.Point(91, 286);
            this.cbxColumnInfoStatus.Name = "cbxColumnInfoStatus";
            this.cbxColumnInfoStatus.Size = new System.Drawing.Size(388, 21);
            this.cbxColumnInfoStatus.TabIndex = 7;
            this.cbxColumnInfoStatus.SelectedIndexChanged += new System.EventHandler(this.cbxColumnInfoStatus_SelectedIndexChanged);
            // 
            // tbColumnInfoID
            // 
            this.tbColumnInfoID.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.tbColumnInfoID.Location = new System.Drawing.Point(93, 7);
            this.tbColumnInfoID.Name = "tbColumnInfoID";
            this.tbColumnInfoID.ReadOnly = true;
            this.tbColumnInfoID.Size = new System.Drawing.Size(43, 20);
            this.tbColumnInfoID.TabIndex = 0;
            // 
            // tbColumnInfoValidationRules
            // 
            this.tbColumnInfoValidationRules.AcceptsReturn = true;
            this.tbColumnInfoValidationRules.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbColumnInfoValidationRules.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.tbColumnInfoValidationRules.Location = new System.Drawing.Point(91, 345);
            this.tbColumnInfoValidationRules.Multiline = true;
            this.tbColumnInfoValidationRules.Name = "tbColumnInfoValidationRules";
            this.tbColumnInfoValidationRules.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tbColumnInfoValidationRules.Size = new System.Drawing.Size(401, 318);
            this.tbColumnInfoValidationRules.TabIndex = 9;
            this.tbColumnInfoValidationRules.TextChanged += new System.EventHandler(this.tbColumnInfoValidationRules_TextChanged);
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label47.Location = new System.Drawing.Point(12, 32);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(73, 13);
            this.label47.TabIndex = 144;
            this.label47.Text = "Column Name";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label59.Location = new System.Drawing.Point(4, 348);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(80, 13);
            this.label59.TabIndex = 159;
            this.label59.Text = "ValidationRules";
            // 
            // tbColumnInfoName
            // 
            this.tbColumnInfoName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbColumnInfoName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.tbColumnInfoName.Location = new System.Drawing.Point(93, 29);
            this.tbColumnInfoName.Name = "tbColumnInfoName";
            this.tbColumnInfoName.Size = new System.Drawing.Size(401, 20);
            this.tbColumnInfoName.TabIndex = 1;
            this.tbColumnInfoName.TextChanged += new System.EventHandler(this.tbColumnInfoName_TextChanged);
            // 
            // tbColumnInfoRegexPattern
            // 
            this.tbColumnInfoRegexPattern.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbColumnInfoRegexPattern.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.tbColumnInfoRegexPattern.Location = new System.Drawing.Point(93, 319);
            this.tbColumnInfoRegexPattern.Name = "tbColumnInfoRegexPattern";
            this.tbColumnInfoRegexPattern.Size = new System.Drawing.Size(401, 20);
            this.tbColumnInfoRegexPattern.TabIndex = 8;
            this.tbColumnInfoRegexPattern.TextChanged += new System.EventHandler(this.tbColumnInfoRegexPattern_TextChanged);
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label46.Location = new System.Drawing.Point(27, 58);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(57, 13);
            this.label46.TabIndex = 146;
            this.label46.Text = "Data Type";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label57.Location = new System.Drawing.Point(17, 322);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(72, 13);
            this.label57.TabIndex = 158;
            this.label57.Text = "RegexPattern";
            // 
            // tbColumnInfoType
            // 
            this.tbColumnInfoType.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbColumnInfoType.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.tbColumnInfoType.Location = new System.Drawing.Point(93, 55);
            this.tbColumnInfoType.Name = "tbColumnInfoType";
            this.tbColumnInfoType.Size = new System.Drawing.Size(401, 20);
            this.tbColumnInfoType.TabIndex = 2;
            this.tbColumnInfoType.TextChanged += new System.EventHandler(this.tbColumnInfoType_TextChanged);
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label58.Location = new System.Drawing.Point(48, 289);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(32, 13);
            this.label58.TabIndex = 157;
            this.label58.Text = "State";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label45.Location = new System.Drawing.Point(48, 84);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(39, 13);
            this.label45.TabIndex = 148;
            this.label45.Text = "Format";
            // 
            // tbColumnInfoDescription
            // 
            this.tbColumnInfoDescription.AcceptsReturn = true;
            this.tbColumnInfoDescription.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbColumnInfoDescription.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.tbColumnInfoDescription.Location = new System.Drawing.Point(93, 158);
            this.tbColumnInfoDescription.Multiline = true;
            this.tbColumnInfoDescription.Name = "tbColumnInfoDescription";
            this.tbColumnInfoDescription.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tbColumnInfoDescription.Size = new System.Drawing.Size(401, 114);
            this.tbColumnInfoDescription.TabIndex = 6;
            this.tbColumnInfoDescription.TextChanged += new System.EventHandler(this.tbColumnInfoDescription_TextChanged);
            // 
            // tbColumnInfoFormat
            // 
            this.tbColumnInfoFormat.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbColumnInfoFormat.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.tbColumnInfoFormat.Location = new System.Drawing.Point(93, 81);
            this.tbColumnInfoFormat.Name = "tbColumnInfoFormat";
            this.tbColumnInfoFormat.Size = new System.Drawing.Size(401, 20);
            this.tbColumnInfoFormat.TabIndex = 3;
            this.tbColumnInfoFormat.TextChanged += new System.EventHandler(this.tbColumnInfoFormat_TextChanged);
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label56.Location = new System.Drawing.Point(27, 161);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(60, 13);
            this.label56.TabIndex = 154;
            this.label56.Text = "Description";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label44.Location = new System.Drawing.Point(-4, 110);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(91, 13);
            this.label44.TabIndex = 150;
            this.label44.Text = "Digitisation Specs";
            // 
            // btnColumnInfoSave
            // 
            this.btnColumnInfoSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.btnColumnInfoSave.Location = new System.Drawing.Point(93, 669);
            this.btnColumnInfoSave.Name = "btnColumnInfoSave";
            this.btnColumnInfoSave.Size = new System.Drawing.Size(318, 30);
            this.btnColumnInfoSave.TabIndex = 10;
            this.btnColumnInfoSave.Text = "Save Changes To Database";
            this.btnColumnInfoSave.UseVisualStyleBackColor = true;
            this.btnColumnInfoSave.Click += new System.EventHandler(this.btnColumnInfoSave_Click);
            // 
            // tbColumnInfoDigitisationSpecs
            // 
            this.tbColumnInfoDigitisationSpecs.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbColumnInfoDigitisationSpecs.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.tbColumnInfoDigitisationSpecs.Location = new System.Drawing.Point(93, 107);
            this.tbColumnInfoDigitisationSpecs.Name = "tbColumnInfoDigitisationSpecs";
            this.tbColumnInfoDigitisationSpecs.Size = new System.Drawing.Size(401, 20);
            this.tbColumnInfoDigitisationSpecs.TabIndex = 4;
            this.tbColumnInfoDigitisationSpecs.TextChanged += new System.EventHandler(this.tbColumnInfoDigitisationSpecs_TextChanged);
            // 
            // tbColumnInfoSource
            // 
            this.tbColumnInfoSource.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbColumnInfoSource.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.tbColumnInfoSource.Location = new System.Drawing.Point(93, 133);
            this.tbColumnInfoSource.Name = "tbColumnInfoSource";
            this.tbColumnInfoSource.Size = new System.Drawing.Size(401, 20);
            this.tbColumnInfoSource.TabIndex = 5;
            this.tbColumnInfoSource.TextChanged += new System.EventHandler(this.tbColumnInfoSource_TextChanged);
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label49.Location = new System.Drawing.Point(48, 136);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(41, 13);
            this.label49.TabIndex = 152;
            this.label49.Text = "Source";
            // 
            // ColumnInfoUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.ti_gbColumnInfo);
            this.Name = "ColumnInfoUI";
            this.Size = new System.Drawing.Size(503, 800);
            this.ti_gbColumnInfo.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox ti_gbColumnInfo;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.CheckBox cbIsPrimaryKey;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.ComboBox cbxColumnInfoStatus;
        private System.Windows.Forms.TextBox tbColumnInfoID;
        private System.Windows.Forms.TextBox tbColumnInfoValidationRules;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.TextBox tbColumnInfoName;
        private System.Windows.Forms.TextBox tbColumnInfoRegexPattern;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.TextBox tbColumnInfoType;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox tbColumnInfoDescription;
        private System.Windows.Forms.TextBox tbColumnInfoFormat;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Button btnColumnInfoSave;
        private System.Windows.Forms.TextBox tbColumnInfoDigitisationSpecs;
        private System.Windows.Forms.TextBox tbColumnInfoSource;
        private System.Windows.Forms.Label label49;

    }
}

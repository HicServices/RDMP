using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MapsDirectlyToDatabaseTable;
using MySql.Data.MySqlClient;
using ReusableLibraryCode;

namespace CatalogueLibrary.Data.Aggregation
{
    /// <summary>
    /// Each AggregateDimension in an AggregateConfiguration can have a defined date axis, this specifies the start/end and increment of the aggregate e.g.
    /// PrescribedDate dimension may have an axis defining it as running from 2001-2009 in increments of 1 month.  
    /// 
    /// For this to work the AggregateDimension output data should be of type a date also.
    /// </summary>
    public class AggregateContinuousDateAxis: DatabaseEntity
    {
        public int AggregateDimension_ID { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public AxisIncrement AxisIncrement { get; set; }

        public AggregateContinuousDateAxis(IRepository repository,AggregateDimension dimension)
        {
            repository.InsertAndHydrate(this, 
                new Dictionary<string, object>()
                {
                    {"AggregateDimension_ID",dimension.ID}
                });
        }


        public AggregateContinuousDateAxis(IRepository repository,DbDataReader r) : base(repository,r)
        {
            AggregateDimension_ID = int.Parse(r["AggregateDimension_ID"].ToString());
            StartDate = r["StartDate"].ToString();
            EndDate = r["EndDate"].ToString();
            AxisIncrement = (AxisIncrement) r["AxisIncrement"];
        }

        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="thingToWrap"></param>
        /// <returns></returns>
        public string WrapWithIntervalFunction(string thingToWrap)
        {
            switch (AxisIncrement)
            {
                case AxisIncrement.Day:
                    return thingToWrap;
                case AxisIncrement.Month:
                    return " CONVERT(nvarchar(7)," + thingToWrap + ",126)"; //returns 2015-01
                case AxisIncrement.Year:
                    return " YEAR(" + thingToWrap + ")"; //returns 2015
                default:
                    throw new ArgumentOutOfRangeException();
            }
        }

        public string GetJOINSqlWithIntervalFunction(string column1, string column2)
        {
            switch (AxisIncrement)
            {
                case AxisIncrement.Day:
                    return WrapWithIntervalFunction(column1) + "=" + WrapWithIntervalFunction(column2);
                case AxisIncrement.Month:
                    return string.Format("YEAR({0}) = YEAR({1}) AND MONTH({0}) = MONTH({1})", column1,column2);
                case AxisIncrement.Year:
                    return WrapWithIntervalFunction(column1) + "=" + WrapWithIntervalFunction(column2);
                default:
                    throw new ArgumentOutOfRangeException();
            }
        }

    }

    public enum AxisIncrement
    {
        Day = 1,
        Month = 2,
        Year = 3
    }
}

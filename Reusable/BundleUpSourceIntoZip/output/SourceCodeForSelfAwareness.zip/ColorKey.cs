using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReusableUIComponents
{
    /// <summary>
    /// Shows one or more colours to the user as a key for another control e.g. Red = 'Deprecated'
    /// </summary>
    public partial class ColorKey : UserControl
    {
        public ColorKey()
        {
            InitializeComponent();
        }

        private int addedSoFar = 0;

        FlowLayoutPanel flp = new FlowLayoutPanel();

        private bool _horizontalMode = false;
        public void SetHorizontalMode()
        {

            if(tableLayoutPanel1.Controls.Count>0)
                throw new NotSupportedException("You must call SetHorizontal before adding any colors");

            this.Controls.Remove(tableLayoutPanel1);
            
            flp.Dock = DockStyle.Fill;
            this.Controls.Add(flp);
            _horizontalMode = true;
        }

        public void AddColor(Color c, string label)
        {
            var text = new Label();
            text.AutoSize = true;
            text.Text = label;

            var l = new Label();
            l.Width = text.Height;
            l.Height = text.Height;
            l.BackColor = c;
            l.AutoSize = false;

            if (_horizontalMode)
            {
                flp.Controls.Add(l);
                flp.Controls.Add(text);
            }
            else
            {
                tableLayoutPanel1.Controls.Add(l,0,addedSoFar);
                tableLayoutPanel1.Controls.Add(text, 1, addedSoFar);
                addedSoFar++;

                for (int i = 0; i < tableLayoutPanel1.RowStyles.Count; i++)
                    tableLayoutPanel1.RowStyles[i].SizeType = SizeType.AutoSize;

                for (int i = 0; i < tableLayoutPanel1.ColumnStyles.Count; i++)
                    tableLayoutPanel1.ColumnStyles[i].SizeType = SizeType.AutoSize;
            }
        }
    }
}

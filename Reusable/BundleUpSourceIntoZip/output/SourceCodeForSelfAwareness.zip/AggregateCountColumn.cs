using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using CatalogueLibrary.Data;
using CatalogueLibrary.DataHelper;

namespace CatalogueLibrary.QueryBuilding
{
    public class AggregateCountColumn:IColumn
    {
        public AggregateCountColumn(string sql)
        {
            string select;
            string alias;

            QuerySyntaxHelper.SplitLineIntoSelectSQLAndAlias(sql, out select, out alias);
            
            SelectSQL = select;
            Alias = alias;
        }
        public string GetRuntimeName()
        {
            return QuerySyntaxHelper.GetRuntimeName(this);
        }
        
        public ColumnInfo ColumnInfo { get { return null; } }
        public int Order { get; set; }
        
        public string SelectSQL { get; set; }
        public int ID { get { return -1; }}

        public string Alias{get; private set; }
        public bool HashOnDataRelease { get { return false; }}
        public bool IsExtractionIdentifier { get { return false; } }
        public bool IsPrimaryKey { get { return false; } }
    }
}

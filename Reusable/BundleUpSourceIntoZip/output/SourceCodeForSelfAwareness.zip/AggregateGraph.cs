using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using CatalogueLibrary.Data;
using CatalogueLibrary.Data.Aggregation;
using CatalogueLibrary.QueryBuilding;
using CatalogueManager.TestsAndSetup.ServicePropogation;
using CsvHelper;
using DataExportManager2Library.ExtractionTime.FileOutputFormats;
using MapsDirectlyToDatabaseTable;
using QueryCaching.Aggregation;
using ReusableLibraryCode;
using ReusableLibraryCode.Checks;
using ReusableLibraryCode.DataAccess;
using ReusableUIComponents;
using ScintillaNET;

namespace CatalogueManager.AggregationUIs
{

    public delegate void DataTableHandler(object sender, DataTable dt);
    
    /// <summary>
    /// Executes and renders an AggregateConfiguration as a graph.  An AggregateConfiguration is a GROUP BY sql statement.  You can view the statement executed through the 
    /// 'SQL Code' tab.  In the Data tab you can view the raw data returned by the GROUP BY query (And also if applicable you can cache the results for displaying on the website).
    /// 
    /// The Graph will do it's best to render something appropriate to the selected Dimensions, Pivot, Axis etc but there are limits.  If the graph doesn't look the way you want
    /// try putting a year/month axis onto the AggregateConfiguration.  Also make sure that your PIVOT Dimension doesn't have 1000 values or the graph will be completely incomprehensible.
    /// </summary>
    public partial class AggregateGraph : RDMPUserControl
    {
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Scintilla QueryEditor { get; set; }
        ServerDefaults _defaults;

        public static int Timeout
        {
            get { return _timeout; }
            set { _timeout = value; }
        }

        public event DataTableHandler GraphTableRetrieved;

        private AggregateConfiguration _aggregateConfiguration;

        public AggregateGraph()
        {
            InitializeComponent();

            llCancel.Visible = false;

            #region Query Editor setup
            
            if(VisualStudioDesignMode)
                return;

            QueryEditor = new Scintilla();
            QueryEditor.Dock = DockStyle.Fill;
            QueryEditor.Scrolling.ScrollBars = ScrollBars.Both;
            QueryEditor.ConfigurationManager.Language = "mssql";
            QueryEditor.Margins[0].Width = 30; //allows display of line numbers
            QueryEditor.LineWrapping.Mode = LineWrappingMode.Word;

            QueryEditor.Text = "--Graph load has not been attempted yet, wait till the system calls LoadGraphAsync() or LoadGraph()";

            QueryEditor.IsReadOnly = true;
            
            tpCode.Controls.Add(QueryEditor);
            #endregion QueryEditor
        }
        
        public AggregateConfiguration AggregateConfiguration
        {
            get { return _aggregateConfiguration; }
            set
            {
                _aggregateConfiguration = value;

                LoadGraphAsync();
            }
        }

        public void AbortLoadGraph()
        {
            if(_cmd != null)
                _cmd.Cancel();

            pbLoading.Visible = false;
            llCancel.Visible = false;
        }

        public Exception Exception { get; private set; }
        public bool Crashed { get; private set; }
        public bool Done { get; private set; }

        protected void LoadGraphAsync()
        {
            if (chart1.IsDisposed || chart1.Disposing)
                return;

            Done = false;
            Crashed = false;
            
            chart1.Visible = false;

            chart1.Series.Clear();
            
            pbTotalFailure.Visible = false;
            chart1.DataSource = null;

            if (AggregateConfiguration == null)
                return;

            pbLoading.Visible = true;
            llCancel.Visible = true;

            btnPublishToWebsite.Enabled = false;

            label1.ForeColor = Color.Black;
            label1.Text = string.IsNullOrWhiteSpace(AggregateConfiguration.Description) ? "No description" : AggregateConfiguration.Description;

            Thread t = new Thread(LoadGraph);
            t.Start();
        }

        DbCommand _cmd;
        private static int _timeout = 30;

        int invokeGraphCompletionCount;

         ChartDashStyle[] StyleList = new ChartDashStyle[]
         {
             ChartDashStyle.Solid,
             ChartDashStyle.Dash,
             ChartDashStyle.Dot,
             ChartDashStyle.DashDot,
             ChartDashStyle.DashDotDot
         };
        
        private void LoadGraph()
        {
            try
            {
                AggregateContinuousDateAxis axis = AggregateConfiguration.GetAxisIfAny();
                AggregateBuilder builder = GetQueryBuilder(AggregateConfiguration);

                UpdateQueryViewerScreenWithQuery(builder.SQL);

                var countColumn = builder.SelectColumns.FirstOrDefault(c => c.IColumn is AggregateCountColumn);

                var server = AggregateConfiguration.Catalogue.GetDistinctLiveDatabaseServer(DataAccessContext.InternalDataProcessing,false);

                using(var con = server.GetConnection())
                {
                    con.Open();
                    try
                    {
                        _cmd = server.GetCommand(builder.SQL, con);
                        _cmd.CommandTimeout = Timeout;

                        DataTable dt = new DataTable();

                        DbDataAdapter adapter = server.GetDataAdapter(_cmd);
                        adapter.Fill(dt);
                        _cmd = null;

                        if (GraphTableRetrieved != null)
                            GraphTableRetrieved(this, dt);

                        if (dt.Columns.Count < 2)
                            throw new NotSupportedException("Aggregates must have 2 columns at least");
                    
                        //number of invoke calls we are about to make
                        invokeGraphCompletionCount = dt.Columns.Count -1;

                        bool haveSetSource = false;

                        //last column is always the X axis, then for each column before it add a series with Y values comming from that column
                        for (int i = 0; i < dt.Columns.Count - 1; i++)
                        {
                            int index = i;

                            this.Invoke(new MethodInvoker(() =>
                            {
                                if (!haveSetSource)
                                {

                                    try
                                    {
                                        dataGridView1.DataSource = dt;
                                        lblCannotLoadData.Visible = false;
                                    }
                                    catch (Exception e)
                                    {
                                        lblCannotLoadData.Visible = true;
                                        lblCannotLoadData.Text = "Could not load data table:" + e.Message;
                                        dataGridView1.DataSource = null;
                                    }

                                    chart1.DataSource = dt;
                                    haveSetSource = true;
                                }

                                if (countColumn != null)
                                    try
                                    {
                                        chart1.ChartAreas[0].AxisY.Title = countColumn.IColumn.GetRuntimeName();
                                    }
                                    catch (Exception )
                                    {
                                        chart1.ChartAreas[0].AxisY.Title = "Count"; //sometimes you can't get a runtime name e.g. it is count(*) with no alias
                                    }

                                chart1.ChartAreas[0].AxisX.IsMarginVisible = false;
                                chart1.ChartAreas[0].AxisY.IsMarginVisible = false;

                                if (axis != null)
                                {
                                    switch (axis.AxisIncrement)
                                    {
                                        case AxisIncrement.Day:
                                            chart1.ChartAreas[0].AxisX.Title = "Day";


                                            if (dt.Rows.Count <= 370)
                                            {
                                                //by two months
                                                chart1.ChartAreas[0].AxisX.MinorGrid.Interval = 7;
                                                chart1.ChartAreas[0].AxisX.MajorGrid.Interval = 14;
                                                chart1.ChartAreas[0].AxisX.Interval =14;
                                            }
                                            else
                                            {
                                                chart1.ChartAreas[0].AxisX.MajorGrid.Interval = 28;
                                                chart1.ChartAreas[0].AxisX.MinorGrid.Interval = 7;
                                                chart1.ChartAreas[0].AxisX.Interval = 28;
                                            }

                                        
                                            chart1.ChartAreas[0].AxisX.MinorGrid.LineWidth = 1;
                                            chart1.ChartAreas[0].AxisX.MinorGrid.LineDashStyle = ChartDashStyle.Dot;
                                            chart1.ChartAreas[0].AxisX.MinorGrid.Enabled = true;
                                        
                                            break;
                                        case AxisIncrement.Month:

                                            //x axis is the number of rows in the data table
                                            chart1.ChartAreas[0].AxisX.Title = "Month";


                                            //if it is less than or equal to ~3 years at once - with 
                                            if (dt.Rows.Count <= 40)
                                            {
                                                //by month
                                                chart1.ChartAreas[0].AxisX.MinorGrid.Interval = 1;
                                                chart1.ChartAreas[0].AxisX.MajorGrid.Interval = 3;
                                                chart1.ChartAreas[0].AxisX.Interval = 1;
                                            }
                                            else
                                            {
                                                //by year
                                                chart1.ChartAreas[0].AxisX.MinorGrid.Interval = 6;
                                                chart1.ChartAreas[0].AxisX.MajorGrid.Interval = 12;
                                                chart1.ChartAreas[0].AxisX.Interval = 12;
                                            }

                                            chart1.ChartAreas[0].AxisX.MinorGrid.LineWidth = 1;
                                            chart1.ChartAreas[0].AxisX.MinorGrid.LineDashStyle = ChartDashStyle.Dot;
                                            chart1.ChartAreas[0].AxisX.MinorGrid.Enabled = true;
                                        
                                        
                                            break;
                                        case AxisIncrement.Year:

                                            chart1.ChartAreas[0].AxisX.Title = "Year";

                                            if (dt.Rows.Count <= 10)
                                            {
                                                chart1.ChartAreas[0].AxisX.MinorGrid.Interval = 1;
                                                chart1.ChartAreas[0].AxisX.MajorGrid.Interval = 1;
                                                chart1.ChartAreas[0].AxisX.Interval = 1;
                                            }
                                            else
                                            {
                                                chart1.ChartAreas[0].AxisX.MinorGrid.Interval = 1;
                                                chart1.ChartAreas[0].AxisX.MajorGrid.Interval = 5;
                                                chart1.ChartAreas[0].AxisX.Interval = 5;
                                            }

                                            chart1.ChartAreas[0].AxisX.MinorGrid.LineWidth = 1;
                                            chart1.ChartAreas[0].AxisX.MinorGrid.LineDashStyle = ChartDashStyle.Dot;
                                            chart1.ChartAreas[0].AxisX.MinorGrid.Enabled = true;
                                        
                                            break;
                                        default:
                                            throw new ArgumentOutOfRangeException();
                                    }
                                }
                                else
                                    chart1.ChartAreas[0]= new ChartArea();//reset it

                                chart1.ChartAreas[0].AxisY.MinorGrid.Enabled = true;
                                chart1.ChartAreas[0].AxisY.MinorGrid.LineDashStyle = ChartDashStyle.Dot;
                                chart1.ChartAreas[0].AxisY.LabelStyle.Format = "{0:#,#}";
                            
                                //avoid buffer overun
                                if (index > chart1.Series.Count - 1)
                                    chart1.Series.Add(new Series());

                                chart1.Series[index].XValueMember = dt.Columns[0].ColumnName;
                                chart1.Series[index].YValueMembers = dt.Columns[index + 1].ColumnName;
                            
                                if(axis != null)
                                {
                                    chart1.Series[index].ChartType = SeriesChartType.Line;

                                    //alternate in rotating style the various lines on the graph
                                    chart1.Series[index].BorderDashStyle = StyleList[index % StyleList.Length];
                                    chart1.Series[index].BorderWidth = 2;
                                
                                }
                                else
                                {
                                    chart1.Series[index].ChartType = SeriesChartType.Column;
                                    chart1.ChartAreas[0].AxisX.Interval = 1;
                                    chart1.ChartAreas[0].AxisX.LabelAutoFitMinFontSize = 8;
                                }

                                //name series based on column 3 or the aggregate name
                                chart1.Series[index].Name = dt.Columns[index + 1].ColumnName;

                                pbLoading.Visible = false;
                                llCancel.Visible = false;
                                chart1.Visible = true;
                                chart1.DataBind();

                                //set publish enabledness to the enabledness of 
                                btnPublishToWebsite.Enabled = _defaults.GetDefaultFor(ServerDefaults.PermissableDefaults.WebServiceQueryCachingServer_ID) != null;
                                btnClearFromCache.Enabled = false;

                                if (btnPublishToWebsite.Enabled)
                                {
                                    //let them clear if there is a query caching server and the manager has cached results already
                                    btnClearFromCache.Enabled =
                                        GetCacheManager()
                                            .GetLatestResultsTableUnsafe(AggregateConfiguration,
                                                AggregateOperation.ExtractableAggregateResults) != null;
                                }

                                invokeGraphCompletionCount--;
                            }));
                        }

                        while(invokeGraphCompletionCount != 0)
                            Thread.Sleep(100);

                        Done = true;
                    }
                    catch (Exception e)
                    {
                        Crashed = true;
                        Exception = e;
                        throw;
                    }
                }
            }
            catch (Exception e)
            {
                //don't bother if it is closing
                if (IsDisposed || !IsHandleCreated)
                    return;

                this.Invoke(new MethodInvoker(() =>
                {
                    if (IsDisposed || !IsHandleCreated)
                        return;

                    btnViewException.Visible = true;
                    btnViewException.Tag = e;

                    label1.Text = ExceptionHelper.ExceptionToListOfInnerMessages(e, true);
                    label1.ForeColor = Color.Red;

                    pbLoading.Visible = false;
                    llCancel.Visible = false;
                    pbTotalFailure.Visible = true;

                }));

            }
        }

        public void UpdateQueryViewerScreenWithQuery(string sql)
        {
            if (InvokeRequired)
            {
                Invoke(new MethodInvoker(() => UpdateQueryViewerScreenWithQuery(sql)));
                return;
            }

            QueryEditor.IsReadOnly = false;
            QueryEditor.Text = sql;
            QueryEditor.IsReadOnly = true;
        }

        protected virtual AggregateBuilder GetQueryBuilder(AggregateConfiguration aggregateConfiguration)
        {
            return aggregateConfiguration.GetQueryBuilder();
        }


        private string GetSeriesName(object o)
        {
            if (o == null || o == DBNull.Value)
                return "NULL";

            return o.ToString();
        }

        private void btnViewException_Click(object sender, EventArgs e)
        {
            var tag = btnViewException.Tag as Exception;
            if (tag != null)
                ExceptionViewer.Show(tag);
        }

        public void SaveTo(DirectoryInfo subdir, string nameOfFile, ICheckNotifier notifier, Dictionary<AggregateGraph, string> graphSaveLocations = null)
        {
            if (!Done)
            {
                notifier.OnCheckPerformed(
                    new CheckEventArgs(
                        "Graph could not be extracted to " + nameOfFile +
                        " because Done is false, possibly the graph has not been loaded yet or crashed?",
                        CheckResult.Fail, btnViewException.Tag as Exception));
                return;
            }

            string imgSavePath = Path.Combine(subdir.FullName, nameOfFile + ".png");
            string dataSavePath = Path.Combine(subdir.FullName, nameOfFile + ".csv");
            string querySavePath = Path.Combine(subdir.FullName, nameOfFile + ".sql");
            try
            {
                chart1.SaveImage(imgSavePath, ChartImageFormat.Png);
                notifier.OnCheckPerformed(new CheckEventArgs("Saved chart image to " + imgSavePath, CheckResult.Success));

                if(graphSaveLocations != null)
                    graphSaveLocations.Add(this,imgSavePath);
            }
            catch (Exception e)
            {
                notifier.OnCheckPerformed(new CheckEventArgs("Failed to save image to " + imgSavePath, CheckResult.Fail,e));
            }

            try
            {
                var dt = (DataTable) dataGridView1.DataSource;

                using (CsvWriter csvWriter = new CsvWriter(new StreamWriter(dataSavePath)))
                {
                    foreach (DataColumn column in dt.Columns)
                        csvWriter.WriteField(column.ColumnName);

                    csvWriter.NextRecord();

                    foreach (DataRow row in dt.Rows)
                    {
                        for (var i = 0; i < dt.Columns.Count; i++)
                            csvWriter.WriteField(row[i]);

                        csvWriter.NextRecord();
                    }
                }

                notifier.OnCheckPerformed(new CheckEventArgs("Saved chart data to " + dataSavePath, CheckResult.Success));
            }
            catch (Exception e)
            {
                notifier.OnCheckPerformed(new CheckEventArgs("Failed to save chart data to " + dataSavePath,CheckResult.Fail, e));
            }

            try
            {
                File.WriteAllText(querySavePath, QueryEditor.Text);
                notifier.OnCheckPerformed(new CheckEventArgs("Wrote SQL used to " + querySavePath, CheckResult.Success));
            }
            catch (Exception e)
            {
                notifier.OnCheckPerformed(new CheckEventArgs("Failed to save SQL query to " + querySavePath,CheckResult.Fail,e));
            }
        }

        public void GetImage()
        {
            throw new NotImplementedException();
        }

        private void llCancel_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            AbortLoadGraph();
        }

        private void btnPublishToWebsite_Click(object sender, EventArgs e)
        {
            try
            {
                CachedAggregateConfigurationResultsManager cacheManager = GetCacheManager();
                cacheManager.CommitResults(AggregateConfiguration, AggregateOperation.ExtractableAggregateResults, QueryEditor.Text,(DataTable) dataGridView1.DataSource,null);

                var result = cacheManager.GetLatestResultsTable(AggregateConfiguration,AggregateOperation.ExtractableAggregateResults, QueryEditor.Text);

                if(result == null)
                    throw new NullReferenceException("CommitResults passed but GetLatestResultsTable returned false (when we tried to refetch the table name from the cache)");

                MessageBox.Show("DataTable succesfully submitted to:" + result.GetFullyQualifiedName());
                btnClearFromCache.Enabled = true;
            }
            catch (Exception exception)
            {
                ExceptionViewer.Show(exception);
            }
            

        }

        private void btnClearFromCache_Click(object sender, EventArgs e)
        {
            try
            {
                GetCacheManager().DeleteCacheEntryIfAny(AggregateConfiguration,AggregateOperation.ExtractableAggregateResults);
                MessageBox.Show(
                    "Cached results deleted, they should no longer appear on the website (subject to website page level caching in IIS etc of course)");
                btnClearFromCache.Enabled = false;
            }
            catch (Exception exception)
            {
                ExceptionViewer.Show(exception);
            }

        }

        private CachedAggregateConfigurationResultsManager GetCacheManager()
        {
            return new CachedAggregateConfigurationResultsManager(_defaults.GetDefaultFor(ServerDefaults.PermissableDefaults.WebServiceQueryCachingServer_ID));
        }

        public void SetAggregateConfigurationButDontLoadGraphYet(AggregateConfiguration value)
        {
            _aggregateConfiguration = value;
        }

        protected override void OnLoad(EventArgs e)
        {
            if (VisualStudioDesignMode)
                return;

            base.OnLoad(e);
            
            _defaults = new ServerDefaults(RepositoryLocator.CatalogueRepository);
        }
    }
}

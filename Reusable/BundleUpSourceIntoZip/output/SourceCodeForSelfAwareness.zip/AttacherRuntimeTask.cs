using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Linq;
using CatalogueLibrary;
using CatalogueLibrary.Data;
using CatalogueLibrary.Data.DataLoad;
using CatalogueLibrary.DataFlowPipeline;
using CatalogueLibrary.Repositories;
using DataLoadEngine.Attachers;
using DataLoadEngine.Job;
using DataLoadEngine.LoadPipeline.Components.Arguments;
using MapsDirectlyToDatabaseTable;
using ReusableLibraryCode;
using ReusableLibraryCode.Checks;
using ReusableLibraryCode.DatabaseHelpers.Discovery;
using ReusableLibraryCode.Progress;

namespace DataLoadEngine.LoadPipeline.Components.Runtime
{
    public class AttacherRuntimeTask : RuntimeTask
    {
        private DiscoveredDatabase _dbInfo;
        public IAttacher Attacher { get; private set; }

        public AttacherRuntimeTask(IProcessTask processTask, RuntimeArgumentCollection args, MEF mef)
            : base(processTask, args)
        {
            //All attachers must be marked as mounting stages, and therefore we can pull out the RAW Server and Name 
            var mountingStageArgs = args.StageSpecificArguments as MountingStageArgs;
            if (mountingStageArgs == null)
                throw new Exception("AttacherRuntimeTask can only be called as a Mounting stage process with MountingStageArgs");

            Attacher = mef.FactoryCreateA<IAttacher>(Path);
            _dbInfo = mountingStageArgs.DbInfo;
            SetPropertiesForClass(RuntimeArguments, Attacher);
        }


        public override ProcessExitCode Run(IDataLoadJob job, GracefulCancellationToken cancellationToken)
        {
            Attacher.Initialize(job.HICProjectDirectory, RuntimeArguments.StageSpecificArguments.DbInfo);
            job.OnNotify(this,new NotifyEventArgs(ProgressEventType.Information, "About to run attatch class " + Attacher.GetType().FullName));

            try
            {
                return Attacher.Attach(job);

            }
            catch (Exception e)
            {
                job.OnNotify(this, new NotifyEventArgs(ProgressEventType.Error, "Attatch failed on job " + job + " Attacher was of type " + Attacher.GetType().Name + " see InnerException for specifics",e));
                return ProcessExitCode.Failure;
            }
        }

        public override void LoadCompletedSoDispose(ExitCodeType exitCode,IDataLoadEventListener postLoadEventListener)
        {
            Attacher.LoadCompletedSoDispose(exitCode,postLoadEventListener);
        }


        public override bool Exists()
        {
            var className = Path;
            var assemblies = AppDomain.CurrentDomain.GetAssemblies();
            
            foreach (var assembly in assemblies)
            {
                var type = assembly.GetTypes().FirstOrDefault(t => t.FullName == className);
                if (type != null) return true;
            }

            return false;
        }

        public override string ToShortString()
        {
            throw new NotImplementedException();
        }

        public override void Abort(IDataLoadEventListener postLoadEventListener)
        {
            LoadCompletedSoDispose(ExitCodeType.Abort,postLoadEventListener);
        }

        public override void Check(ICheckNotifier checker)
        {
            Attacher.Check(checker);
        }

        public override string ShortType()
        {
            throw new NotImplementedException();
        }
    }
}

using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using CatalogueLibrary.Data;
using CatalogueManager.TestsAndSetup.ServicePropogation;
using DataExportManager2Library.Data.DataTables;
using ReusableUIComponents;

namespace DataExportManager2.DataSetUI
{
    /// <summary>
    /// Part of DataSetManagementUI lets you temporarily disable extraction. 
    /// 
    /// You can also change the Catalogue... never do this.
    /// </summary>
    public partial class DataSetUI : RDMPUserControl
    {
        internal event ChangesSavedHandler ChangesSaved;

        private bool loading = false;

        private ExtractableDataSet _extractableDataSet;
        private bool _designMode;

        public ExtractableDataSet ExtractableDataSet
        {
            get { return _extractableDataSet; }
            set
            {

                _extractableDataSet = value;
                loading = true;


                //if the object passed in was null we set it to "" otherwise we are going to set it to the Name property (unless that is null in which case it's still going to end up as "")

               tbID.Text = value == null ? "" : value.ID.ToString() ?? "";

                

                lblSaved.Text = value == null ? "" : "Saved";

                if(value == null || value.Catalogue_ID == null)
                    cbxCatalogueID.SelectedItem =  null;
                else
                    cbxCatalogueID.Text = value.Catalogue.ToString();
                
                cbDisableExtraction.Checked = value==null ? false : value.DisableExtraction;
               
                loading = false;
            }
        }



        public DataSetUI()
        {
            InitializeComponent();

            lblSaved.Text = "";
            
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            if(VisualStudioDesignMode)
                return;

            RefreshUIFromDatabase();
        }


        protected override bool ProcessKeyPreview(ref Message m)
        {
            PreviewKey p = new PreviewKey(ref m, ModifierKeys);

            if (p.IsKeyDownMessage && p.e.KeyCode == Keys.S && p.e.Control)
            {
                try
                {
                    btnSave_Click(null,null);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

                p.Trap(this);

            }

            return base.ProcessKeyPreview(ref m);
        }

        #region helper methods
        private void SetStringProperty(Control controlContainingValue, string property, object toSetOn)
        {

            if (toSetOn != null)
            {
                PropertyInfo target = toSetOn.GetType().GetProperty(property);
                FieldInfo targetMaxLength = toSetOn.GetType().GetField(property + "_MaxLength");


                if (target == null || targetMaxLength == null)
                    throw new Exception("Could not find property " + property + " or it did not have a specified _MaxLength");

                if (controlContainingValue.Text.Length > (int)targetMaxLength.GetValue(toSetOn))
                    controlContainingValue.ForeColor = Color.Red;
                else
                {
                    target.SetValue(toSetOn, controlContainingValue.Text, null);
                    controlContainingValue.ForeColor = Color.Black;
                }

                lblSaved.Text = ""; //no longer saved, this is used as a boolean e.g. for preview so be careful messing with it's values 
            }
        }
        #endregion



        private void cbxCatalogueID_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (loading)
                return;

            lblSaved.Text = "";

            if (ExtractableDataSet != null)
            {
                if (cbxCatalogueID.SelectedItem is Catalogue)
                {
                    Catalogue cata = cbxCatalogueID.SelectedItem as Catalogue;
                    ExtractableDataSet.Catalogue_ID = cata.ID;  
                }
                else
                    ExtractableDataSet.Catalogue_ID = null;
            }
        }


     
        private void cbxCatalogueID_TextChanged(object sender, EventArgs e)
        {
            if (loading)
                return;

            if (string.IsNullOrWhiteSpace(cbxCatalogueID.Text))
                if (ExtractableDataSet != null)
                    ExtractableDataSet.Catalogue_ID = null;
        }

        private void cbDisableExtraction_CheckedChanged(object sender, EventArgs e)
        {
            if (ExtractableDataSet != null)
            {
                ExtractableDataSet.DisableExtraction = cbDisableExtraction.Checked;
                ExtractableDataSet.SaveToDatabase();
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                ExtractableDataSet.SaveToDatabase();
                this.lblSaved.Text = "Saved";
            }
            catch (Exception exception)
            {
                ExceptionViewer.Show(exception);
            }
            if (ChangesSaved != null)
                ChangesSaved();
        }


        public void RefreshUIFromDatabase()
        {
            
            cbxCatalogueID.Items.Clear();
            cbxCatalogueID.Items.AddRange(RepositoryLocator.CatalogueRepository.GetAllCatalogues());
            cbxCatalogueID.Items.Add(""); //add an empty one so we can select it in cases where no link has yet been made
        }
    }
}

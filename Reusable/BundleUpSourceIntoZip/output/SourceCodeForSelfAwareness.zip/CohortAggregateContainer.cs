using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CatalogueLibrary.Data.Aggregation;
using CatalogueLibrary.Repositories;
using MapsDirectlyToDatabaseTable;
using ReusableLibraryCode;

namespace CatalogueLibrary.Data.Cohort
{
    /// <summary>
    /// Cohort identification is achieved by identifying Sets of patients and performing set operations on them e.g. you might identify "all patients who have been prescribed Diazepam"
    /// and then EXCEPT "patients who have been prescribed Diazepam before 2000".  This is gives you DISTINCT patients who were FIRST prescribed Diazepam AFTER 2000.  A CohortAggregateContainer
    /// is a collection of sets (actually implemented as an AggregateConfiguration) (and optionally subcontainers) which are all separated with the given SetOperation.
    /// </summary>
    public class CohortAggregateContainer : DatabaseEntity, IDeleteable, ISaveable, IOrderable
    {
        public SetOperation Operation { get; set; }
        public int Order { get; set; }

        public CohortAggregateContainer(IRepository repository,DbDataReader r) : base(repository,r)
        {
            Order = int.Parse(r["Order"].ToString());
            SetOperation op;
            SetOperation.TryParse(r["Operation"].ToString(), out op);
            Operation = op;
        }

        public CohortAggregateContainer(IRepository repository,SetOperation operation)
        {
            repository.InsertAndHydrate(this,new Dictionary<string, object>
            {
                {"Operation", operation},
                {"Order", 0}
            });
        }
        public CohortAggregateContainer[] GetSubContainers()
        {
            return Repository.SelectAllWhere<CohortAggregateContainer>("SELECT CohortAggregateContainer_ChildID FROM CohortAggregateSubContainer WHERE CohortAggregateContainer_ParentID=@CohortAggregateContainer_ParentID", 
                "CohortAggregateContainer_ChildID",
                new Dictionary<string, object>
                {
                    {"CohortAggregateContainer_ParentID", ID}
                }).ToArray();
        }

        public CohortAggregateContainer GetParentContainerIfAny()
        {
            return Repository.SelectAllWhere<CohortAggregateContainer>("SELECT CohortAggregateContainer_ParentID FROM CohortAggregateSubContainer WHERE CohortAggregateContainer_ChildID=@CohortAggregateContainer_ChildID",
                "CohortAggregateContainer_ParentID",
                new Dictionary<string, object>
                {
                    {"CohortAggregateContainer_ChildID", ID}
                }).SingleOrDefault();
        }

        public AggregateConfiguration[] GetAggregateConfigurations()
        {
            return Repository.SelectAll<AggregateConfiguration>("SELECT AggregateConfiguration_ID FROM CohortAggregateContainer_AggregateConfiguration where CohortAggregateContainer_ID=" + ID).OrderBy(config=>config.Order).ToArray();
        }

        /// <summary>
        /// Makes the configuration a member of this container.
        /// </summary>
        /// <param name="configuration"></param>
        /// <param name="order"></param>
        public void AddChild(AggregateConfiguration configuration, int order)
        {
            Repository.Insert(
                "INSERT INTO CohortAggregateContainer_AggregateConfiguration (CohortAggregateContainer_ID, AggregateConfiguration_ID, [Order]) VALUES (@CohortAggregateContainer_ID, @AggregateConfiguration_ID, @Order)",
                new Dictionary<string, object>
                {
                    {"CohortAggregateContainer_ID", ID},
                    {"AggregateConfiguration_ID", configuration.ID},
                    {"Order", order}
                });

            configuration.ReFetchOrder();
        }


        public void RemoveChild(AggregateConfiguration configuration)
        {
            Repository.Delete("DELETE FROM CohortAggregateContainer_AggregateConfiguration WHERE CohortAggregateContainer_ID = @CohortAggregateContainer_ID AND AggregateConfiguration_ID = @AggregateConfiguration_ID", new Dictionary<string, object>
            {
                {"CohortAggregateContainer_ID", ID},
                {"AggregateConfiguration_ID", configuration.ID}
            });
        }


        /// <summary>
        /// If the configuration is part of any aggregate container anywhere this method will set the order to the newOrder int
        /// </summary>
        /// <param name="configuration"></param>
        /// <returns></returns>
        public static void SetOrderIfExistsFor(AggregateConfiguration configuration, int newOrder)
        {
            ((CatalogueRepository)configuration.Repository).Update("UPDATE CohortAggregateContainer_AggregateConfiguration SET [Order] = " + newOrder + " WHERE AggregateConfiguration_ID = @AggregateConfiguration_ID", new Dictionary<string, object>
            {
                {"AggregateConfiguration_ID", configuration.ID}
            });
        }

        /// <summary>
        /// Deletes all relationships in which this has a parent - kills all containers parents
        /// </summary>
        public void MakeIntoAnOrphan()
        {
            Repository.Delete("DELETE FROM CohortAggregateSubContainer WHERE CohortAggregateContainer_ChildID = @CohortAggregateContainer_ChildID", new Dictionary<string, object>
            {
                {"CohortAggregateContainer_ChildID", ID}
            });
        }

        public void AddChild(CohortAggregateContainer child)
        {
            Repository.Insert("INSERT INTO CohortAggregateSubContainer(CohortAggregateContainer_ParentID,CohortAggregateContainer_ChildID) VALUES (@CohortAggregateContainer_ParentID, @CohortAggregateContainer_ChildID)", new Dictionary<string, object>
            {
                {"CohortAggregateContainer_ParentID", ID},
                {"CohortAggregateContainer_ChildID", child.ID}
            });
        }

        public override void DeleteInDatabase()
        {
            var children = GetSubContainers();

            //delete the children
            foreach (var subContainer in children)
                subContainer.DeleteInDatabase();

            //now delete this
            base.DeleteInDatabase();
        }

        public override string ToString()
        {
            return Operation.ToString();
        }

        /// <summary>
        /// Returns true if this.Children contains the thing you are looking for - IMPORTANT: also returns true if we are the thing you are looking for
        /// </summary>
        /// <param name="potentialChild"></param>
        /// <returns></returns>
        public bool HasChild(CohortAggregateContainer potentialChild)
        {
            bool foundChildThroughRecursion = false;

            //recurse into all children
            foreach(var c in GetSubContainers())
                if (c.HasChild(potentialChild))//ask children recursively the same question (see return statement for the question we are asking)
                    foundChildThroughRecursion = true;
            
            //are we the one you are looking for or were any of our children
            return potentialChild.ID == this.ID || foundChildThroughRecursion;
        }

        public bool HasChild(AggregateConfiguration configuration)
        {
            bool foundChildThroughRecursion = false;

            //recurse into all children
            foreach (var c in GetSubContainers())
                if (c.HasChild(configuration))//ask children recursively the same question (see return statement for the question we are asking)
                    foundChildThroughRecursion = true;

            //are any of the configurations in this bucket the one you are looking for
            return
            GetAggregateConfigurations().Any(c => c.ID == configuration.ID)//yes
            || foundChildThroughRecursion;//no but a child had it
        }

        public IOrderedEnumerable<IOrderable> GetOrderedContents()
        {
            List<IOrderable> toReturn = new List<IOrderable>();
            toReturn.AddRange(GetSubContainers());
            toReturn.AddRange(GetAggregateConfigurations());

            return toReturn.OrderBy(o => o.Order);

        }

    }

    public enum SetOperation
    {
        UNION,
        INTERSECT,
        EXCEPT
    }
}

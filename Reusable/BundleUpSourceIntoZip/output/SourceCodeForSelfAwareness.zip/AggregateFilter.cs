using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using CatalogueLibrary.Checks;
using MapsDirectlyToDatabaseTable;
using MapsDirectlyToDatabaseTable.Revertable;
using ReusableLibraryCode;
using ReusableLibraryCode.Checks;
using QuerySyntaxHelper = CatalogueLibrary.DataHelper.QuerySyntaxHelper;

namespace CatalogueLibrary.Data.Aggregation
{
    /// <summary>
    /// Sometimes you want to restrict the data that is Aggregated as part of an AggregateConfiguration.  E.g. you might want to only aggregate records loaded
    /// in the last 6 months.  To do this you would need to set a root AggregateFilterContainer on the AggregateConfiguration and then put in an appropriate
    /// AggregateFilter.  Each AggregateFilter can be associated with a given ColumnInfo this will ensure that it is included when it comes to JoinInfo time
    /// in QueryBuilding even if it is not a selected dimension (this allows you to for example aggregate the drug codes but filter by drug prescribed date even
    /// when the two fields are in different tables - that will be joined at QueryTime).
    /// 
    /// Each AggregateFilter can have a collection of AggregateFilterParameters which store SQL paramater values (along with descriptions for the user) that let you
    /// paramaterise (for the user) your AggregateFilter
    /// </summary>
    public class AggregateFilter : VersionedDatabaseEntity, IFilter, ICheckable
    {
        public int? FilterContainer_ID { get; set; }
        public int? AssociatedColumnInfo_ID { get; set; }
        public string WhereSQL { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public int? ClonedFromExtractionFilter_ID { get; set; }


        #region Relationships
        [NoMappingToDatabase]
        public IEnumerable<AggregateFilterParameter> AggregateFilterParameters {
            get { return Repository.GetAllObjectsWithParent<AggregateFilterParameter>(this); }
        }

        #endregion

        public ISqlParameter[] GetAllParameters()
        {
            return AggregateFilterParameters.ToArray();
        }

        public static int Name_MaxLength = -1;
        public static int Description_MaxLength = -1;
        
        //mandatory filters only applies to the catalogue
        public bool IsMandatory { get; set; }

        public AggregateFilter(IRepository repository, string name=null, AggregateFilterContainer container=null)
        {
            repository.InsertAndHydrate(this,new Dictionary<string, object>
            {
                 {"Name", name != null ? (object)name : DBNull.Value},
                 {"FilterContainer_ID", container != null ? (object)container.ID : DBNull.Value}
            });
        }

        public AggregateFilter(IRepository repository,DbDataReader r) : base(repository,r)
        {
            WhereSQL = r["WhereSQL"] as string;
            Description = r["Description"] as string;
            Name = r["Name"] as string;
            IsMandatory = (bool)r["IsMandatory"];
            ClonedFromExtractionFilter_ID = ObjectToNullableInt(r["ClonedFromExtractionFilter_ID"]);

            object associatedColumnInfo_ID = r["AssociatedColumnInfo_ID"];
            if (associatedColumnInfo_ID != DBNull.Value)
                AssociatedColumnInfo_ID = int.Parse(associatedColumnInfo_ID.ToString());

            if (r["FilterContainer_ID"] != null && !string.IsNullOrWhiteSpace(r["FilterContainer_ID"].ToString()))
                FilterContainer_ID = int.Parse(r["FilterContainer_ID"].ToString());
            else
                FilterContainer_ID = null;
        }

        public override string ToString()
        {
            return Name;
        }
        
        public void CreateOrDeleteParametersBasedOnSQL(IEnumerable<ISqlParameter> globals)
        {
            //get what parameter exists
            ISqlParameter[] sqlParameters = this.GetAllParameters();

            //all parameters in the Select SQL
            HashSet<string> parametersRequiredByWhereSQL  = QuerySyntaxHelper.GetRequiredParamaterNamesForQuery(this.WhereSQL,globals);


            //find which current parameters are redundant and delete them
            foreach (AggregateFilterParameter parameter in sqlParameters)
                if (!parametersRequiredByWhereSQL.Contains(parameter.ParameterName))
                    parameter.DeleteInDatabase();
           
            //find new parameters that we don't hvae
            foreach (string requiredParameter in parametersRequiredByWhereSQL)
            {
                if (!sqlParameters.Any(p => p.ParameterName.Equals(requiredParameter)))
                {
                    //no parameters have this parameters name
                    new AggregateFilterParameter(Repository,"DECLARE " + requiredParameter + " AS VARCHAR(50)", this);
                }
            }
        }

        public void CopyValuesOutOfCatalogueVersion(ExtractionFilter catalogueVersion)
        {

            var columnInfo = catalogueVersion.ExtractionInformation.ColumnInfo;

            if(columnInfo == null)
                throw new Exception("Could not import filter because it could not be traced back to a ColumnInfo");


            AssociatedColumnInfo_ID = columnInfo.ID;
            Description = catalogueVersion.Description;
            IsMandatory = catalogueVersion.IsMandatory;
            WhereSQL = catalogueVersion.WhereSQL;
            ClonedFromExtractionFilter_ID = catalogueVersion.ID;
            SaveToDatabase();
        }


        public ColumnInfo GetColumnInfoIfExists()
        {
            if(AssociatedColumnInfo_ID != null)
                try
                {
                    return Repository.GetObjectByID<ColumnInfo>((int)AssociatedColumnInfo_ID);
                }
                catch (KeyNotFoundException)
                {
                    return null;
                }


            return null;

        }
        public void Check(ICheckNotifier notifier)
        {
            var checker = new ClonedFilterChecker(this, ClonedFromExtractionFilter_ID, Repository);
            checker.Check(notifier);
        }
    }
}

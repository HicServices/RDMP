namespace CatalogueLibrary.Nodes
{
    public class AllExternalServersNode : SingletonNode
    {
        public AllExternalServersNode() : base("External Servers (Including Platform Databases)")
        {

        }
    }
}

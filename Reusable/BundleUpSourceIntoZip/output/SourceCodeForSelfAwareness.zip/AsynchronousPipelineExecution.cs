using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CatalogueLibrary.Data.Pipelines;
using CatalogueLibrary.DataFlowPipeline;
using ReusableLibraryCode.Progress;

namespace CachingEngine.PipelineExecution
{
    public class AsynchronousPipelineExecution : IMultiPipelineEngineExecutionStrategy
    {
        public IEngineLockProvider EngineLockProvider { get; set; }

        public void Execute(IEnumerable<IDataFlowPipelineEngine> engines, GracefulCancellationToken cancellationToken, IDataLoadEventListener listener)
        {
            // The code below is a first iteration at a basic implementation, but is not completed or tested and should not be used
            throw new NotImplementedException();

            // Run engines simultaneously as individual tasks
            var engineList = engines.ToList();
            var taskList = engineList.Select(engine => new Task(() => engine.ExecutePipeline(cancellationToken))).ToList();
            foreach (var task in taskList)
                task.Start();

            Task.WaitAll(taskList.ToArray());
        }
    }
}

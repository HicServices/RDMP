using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using DataExportManager2Library.Data.DataTables;
using DataExportManager2Library.Repositories;
using ReusableUIComponents;

namespace DataExportManager2.ProjectUI.DataUsers
{
    /// <summary>
    /// Allows you to configure the names of researchers who will be recieving project extractions (forename, surname, email).  Each project can have zero or more users registered as
    /// using the project data.  This has no effect other than documenting them and including thier names as users in the Release Document (generated when a project extraction is released).
    /// 
    /// You can safely skip doing this if you have other policies in place for documenting/managing project coordinators and data users.
    /// </summary>
    public partial class DataUserManagement : BetterToolTipForm
    {
        private DataExportRepository repository;

        public DataUserManagement(Project project)
        {
            Project = project;
            

            InitializeComponent();

            if(project == null)
                return;

            repository = (DataExportRepository)project.Repository;

            RefreshUIFromDatabase();
        }

        protected Project Project { get; set; }
        private DataUser _currentlySelectedDataUser = null;

        public DataUser CurrentlySelectedDataUser
        {
            get { return _currentlySelectedDataUser; }
            set
            {
                if (value != null)
                {
                    tbID.Text = value.ID.ToString();
                    tbForename.Text = value.Forename;
                    tbSurname.Text = value.Surname;
                    tbEmail.Text = value.Email;
                }
                else
                {
                    tbID.Text = "";
                    tbForename.Text = "";
                    tbSurname.Text = "";
                    tbEmail.Text = "";
                }
                
                _currentlySelectedDataUser = value;
            }
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == (Keys.Control | Keys.S))
            {
                btnSave_Click(null, null);
                return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void lbKnownUsers_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataUser user = lbKnownUsers.SelectedItem as DataUser;

            btnAdd.Enabled = user != null;
            
            if (user != null)
            {
                
                lbUsersRegisteredOnProject.SelectedItem = null;
                CurrentlySelectedDataUser = user;
            }
        }

        private void lbUsersRegisteredOnProject_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataUser user = lbUsersRegisteredOnProject.SelectedItem as DataUser;

            btnRemove.Enabled = user != null;

            if (user != null)
            {
                lbKnownUsers.SelectedItem = null;
                CurrentlySelectedDataUser = user;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if(CurrentlySelectedDataUser == null)
                return;

            CurrentlySelectedDataUser.Email = tbEmail.Text;
            CurrentlySelectedDataUser.Forename = tbForename.Text;
            CurrentlySelectedDataUser.Surname = tbSurname.Text;
            CurrentlySelectedDataUser.SaveToDatabase();

            RefreshUIFromDatabase();

        }

        private void RefreshUIFromDatabase()
        {
            lbKnownUsers.Items.Clear();
            lbUsersRegisteredOnProject.Items.Clear();

            lbUsersRegisteredOnProject.SelectedItem = null;
            lbKnownUsers.SelectedItem = null;

            IEnumerable<DataUser> availableUsers = repository.GetAllObjects<DataUser>();

            foreach (DataUser dataUser in Project.DataUsers)
            {
                DataUser userAlreadyInProject = dataUser;
                availableUsers = availableUsers.Where(user => user.ID != userAlreadyInProject.ID);//cant use foreach variable because of closure apparently
                lbUsersRegisteredOnProject.Items.Add(dataUser);
            }

            lbKnownUsers.Items.AddRange(availableUsers.ToArray());

            btnAdd.Enabled = false;
            btnRemove.Enabled = false;
        }

        #region Drag and Drop

        private void lbDragStart_MouseDown(object sender, MouseEventArgs e)
        {
            ListBox listBox = (ListBox)sender;
            listBox.SelectedIndex = listBox.IndexFromPoint(e.X, e.Y);

            //it seems like you have to manually call this otherwise DoDragDrop will cancel it
            if (listBox == lbKnownUsers)
                lbKnownUsers_SelectedIndexChanged(null, null);
            else
                lbUsersRegisteredOnProject_SelectedIndexChanged(null, null);

            if (listBox.SelectedItem == null) return;

            listBox.DoDragDrop(listBox.SelectedItem, DragDropEffects.Copy);

        }

        private void lb_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(typeof(DataUser)))
                e.Effect = DragDropEffects.Copy;
            else
                e.Effect = DragDropEffects.None;

        }

        private void lbKnownUsers_DragDrop(object sender, DragEventArgs e)
        {
            DataUser dataUser = (DataUser)e.Data.GetData(typeof(DataUser));

            RemoveFromProject(dataUser);
        }
        #endregion
        
        private void btnAddNewUser_Click(object sender, EventArgs e)
        {
            new DataUser(Project.Repository,Guid.NewGuid().ToString(), Guid.NewGuid().ToString());
            RefreshUIFromDatabase();
        }
        
        private void lbUsersRegisteredOnProject_DragDrop(object sender, DragEventArgs e)
        {
            DataUser dataUser = (DataUser) e.Data.GetData(typeof(DataUser));
            AddToProject(dataUser);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            var user = lbKnownUsers.SelectedItem as DataUser;
            AddToProject(user);
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            var user = lbUsersRegisteredOnProject.SelectedItem as DataUser;
            RemoveFromProject(user);
        }

        private void AddToProject(DataUser dataUser)
        {
            try
            {
                //if user is not yet on project
                if (!Project.DataUsers.Contains(dataUser))
                {
                    dataUser.RegisterAsDataUserOnProject(Project);
                    RefreshUIFromDatabase();
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message);
            }
        }
        private void RemoveFromProject(DataUser dataUser)
        {
            try
            {
                //if user is in project (they might just have dragged him off of the lbKnownUsers and back onto it!
                if (Project.DataUsers.Contains(dataUser))
                {
                    dataUser.UnRegisterAsDataUserOnProject(Project);
                    RefreshUIFromDatabase();
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message);
            }
        }

    }
}

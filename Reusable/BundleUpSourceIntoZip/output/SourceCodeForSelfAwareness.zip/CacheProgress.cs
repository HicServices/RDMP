using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Data.Common;
using CatalogueLibrary.Data.Cache;
using CatalogueLibrary.Data.Pipelines;
using CatalogueLibrary.Repositories;
using MapsDirectlyToDatabaseTable;
using ReusableLibraryCode;

namespace CatalogueLibrary.Data
{
    /// <summary>
    /// Records the progress of fetching and caching data from a remote source e.g. a Webservice or Imaging file host.  Each CacheProgress
    /// is tied to a LoadSchedule (which itself is tied to a LoadMetadata).  
    /// </summary>
    public class CacheProgress : VersionedDatabaseEntity, ICacheProgress
    {
        public int LoadSchedule_ID { get; set; }
        public int? PermissionWindow_ID { get; set; }
        public DateTime? CacheFillProgress { get; set; }
        public string CacheLagPeriod { get; set; } // stored as string in DB, use GetCacheLagPeriod() to get as CacheLagPeriod
        public int? Pipeline_ID { get; set; }
        public TimeSpan ChunkPeriod { get; set; }
        public string PipelineContextField { get; set; }


        #region Relationships

        [NoMappingToDatabase]
        public IEnumerable<CacheFetchFailure> CacheFetchFailures {
            get { return Repository.GetAllObjectsWithParent<CacheFetchFailure>(this); }
        }

        [NoMappingToDatabase]
        public LoadProgress LoadProgress
        {
            get { return Repository.GetObjectByID<LoadProgress>(LoadSchedule_ID); }
        }

        [NoMappingToDatabase]
        public Pipeline Pipeline
        {
            get { return Pipeline_ID == null ? null : Repository.GetObjectByID<Pipeline>((int)Pipeline_ID); }
        }

        [NoMappingToDatabase]
        public PermissionWindow PermissionWindow
        {
            get
            {
                return PermissionWindow_ID == null
                    ? null
                    : Repository.GetObjectByID<PermissionWindow>((int) PermissionWindow_ID);
            }
        }

        #endregion


        public CacheLagPeriod GetCacheLagPeriod()
        {
            if (string.IsNullOrWhiteSpace(CacheLagPeriod))
                return null;

            return new CacheLagPeriod(CacheLagPeriod);
        }

        public void SetCacheLagPeriod(CacheLagPeriod cacheLagPeriod)
        {
            CacheLagPeriod = (cacheLagPeriod == null) ? "" : cacheLagPeriod.ToString();
        }

        public ILoadProgress GetLoadProgress()
        {
            return LoadProgress;
        }

        public IPermissionWindow GetPermissionWindow()
        {
            return PermissionWindow;
        }

        public IEnumerable<ICacheFetchFailure> GetAllFetchFailures()
        {
            return CacheFetchFailures;
        }
        
        public CacheProgress(IRepository repository, ILoadProgress loadProgress)
        {
            repository.InsertAndHydrate(this,new Dictionary<string, object>
            {
                {"LoadSchedule_ID", loadProgress.ID}
            });
        }

        public CacheProgress(IRepository repository,DbDataReader r) : base(repository,r)
        {
            LoadSchedule_ID = int.Parse(r["LoadSchedule_ID"].ToString());
            PermissionWindow_ID = ObjectToNullableInt(r["PermissionWindow_ID"]);
            CacheFillProgress = ObjectToNullableDateTime(r["CacheFillProgress"]);
            CacheLagPeriod = r["CacheLagPeriod"].ToString();
            Pipeline_ID = ObjectToNullableInt(r["Pipeline_ID"]);
            ChunkPeriod = (TimeSpan)r["ChunkPeriod"];
            PipelineContextField = r["PipelineContextField"].ToString();
        }

        public IEnumerable<ICacheFetchFailure> FetchPage(int start, int batchSize)
        {
            List<int> toReturnIds = new List<int>();

            using (var conn = ((CatalogueRepository)Repository).GetConnection())
            {
                var cmd =
                    DatabaseCommandHelper.GetCommand(@"SELECT ID FROM CacheFetchFailure 
WHERE CacheProgress_ID = @CacheProgressID AND ResolvedOn IS NULL
ORDER BY FetchRequestStart
OFFSET " + start + @" ROWS
FETCH NEXT " + batchSize + @" ROWS ONLY", conn.Connection,conn.Transaction);

                DatabaseCommandHelper.AddParameterWithValueToCommand("@CacheProgressID",cmd, ID);

                

                using (var reader = cmd.ExecuteReader())
                    while (reader.Read())
                        toReturnIds.Add(Convert.ToInt32(reader["ID"]));

                cmd.Dispose();
            }

            return Repository.GetAllObjectsInIDList<CacheFetchFailure>(toReturnIds); 
        }
    }
}

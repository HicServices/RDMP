using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using BrightIdeasSoftware;
using CatalogueLibrary.Data;
using CatalogueLibrary.Repositories;
using CatalogueManager.ExtractionUIs;
using CatalogueManager.SimpleDialogs;
using CatalogueManager.TestsAndSetup;
using CatalogueManager.TestsAndSetup.ServicePropogation;
using HIC.Common.Validation;
using HIC.Logging;
using MapsDirectlyToDatabaseTable;
using MapsDirectlyToDatabaseTable.Revertable;
using ReusableLibraryCode;
using ReusableUIComponents;

namespace CatalogueManager.MainFormUITabs
{
    /// <summary>
    /// Each dataset (Catalogue) includes one or more virtual columns called CatalogueItems.  Each CatalogueItem is powered by an underlying columns in your data repository but there
    /// can be multiple CatalogueItems per column (for example if the DateOfBirth column is extractable either rounded to the nearest quarter or verbatim).  Thus CatalogueItems are both
    /// an extraction transform/rule set (See ExtractionInformationUI) and a descriptive entity which describes what the researcher will recieve if they are given the column in an extract.
    /// This helpfully also lets you delete/restructure your data tables underneath without loosing the descriptive data, validation rules, logging history etc of your datasets.
    /// 
    /// This control lets you view all the CatalogueItems in a dataset (Catalogue).  By selecting a CatalogueItem you can change the description (use Ctrl+S to save changes).  Double 
    /// clicking a CatalogueItem you launch ExtractionInformationUI which allows you to configure if/how the column is extracted.
    /// 
    /// On the near right of the control you can see what underlying ColumnInfo (reference to a specific column in your data repository) powers the CatalogueItem (Associated Columns).  And 
    /// finally on the extreme right is a list of all the tables and columns that the RDMP knows about in your data warehouse.  You can change which ColumnInfo powers the currently 
    /// selected CatalogueItem by dragging a ColumnInfo from the tree into the AssociatedColumns listbox.
    /// 
    /// Double clicking an Associated ColumnInfo has the same effect as double clicking the CatalogueItem (Launching ExtractionInformationUI)
    /// 
    /// </summary>
    public partial class CatalogueItemTab : RDMPUserControl
    {
        private bool clearingFormComponents;

        public CatalogueItemTab()
        {
            InitializeComponent();
            
            lbCatalogueItems.UseFiltering = true;
            lbCatalogueItems.RowFormatter += RowFormatter;
            lbCatalogueItems.CellClick += lbCatalogueItems_CellClick;

            olvColumn2.AspectGetter += FilterCountAspectGetter;
            //allow user to drag stuff out
            this.tableInfoCollection.AllowDrag = true;
            
            BetterToolTip toolTip = new BetterToolTip(this);
            toolTip.SetToolTip(lbCatalogueItems, ToolTips.WhatIsACatalogueItem, Images.WhatIsACatalogueItem);
            toolTip.SetToolTip(tableInfoCollection, ToolTips.WhatIsAColumnInfo, Images.WhatIsAColumnInfo);
            toolTip.SetToolTip(ci_lbSelectedColumns, ToolTips.WhatIsAColumnInfo, Images.WhatIsAColumnInfo);
            toolTip.SetToolTip(this, ToolTips.CatalogueDataModel, Images.CatalogueDataModel);
        }

        private object FilterCountAspectGetter(object rowObject)
        {
            var ci = (CatalogueItem) rowObject;

            var matches = _classifications.Where(classification => classification.CatalogueItem_ID == ci.ID).ToArray();

            if (!matches.Any())
                return 0;
            
            return matches.Max(c => c.ExtractionFilterCount);
        }


        public event EventHandler GlobalChangesIncurred;

        public Catalogue Catalogue
        {
            get { return _catalogue; }
            set
            {
                _catalogue = value;
                RefreshAllLists();
            }
        }

        private void RefreshAllLists()
        {

            if(RepositoryLocator == null)
                return;

            //if we have been deleted clear the form
            if (Catalogue != null && Catalogue.HasLocalChanges().Evaluation == ChangeDescription.DatabaseCopyWasDeleted)
                _catalogue = null;


            ///////////catalogues listboxes ////////////
            //get old selection
            var toReselectCatalogueItem = lbCatalogueItems.SelectedObject as CatalogueItem;

            //clear catalogue items
            lbCatalogueItems.ClearObjects();

            //assuming there is a Catalogue
            if (Catalogue != null)
            {
                //add the items
                lbCatalogueItems.SetObjects(Catalogue.CatalogueItems.ToArray());

                CalculateCatalogueItemsHighlightColours();

                ClearFormComponents();
            }

            

            ////////////Table/ColumnInfo tree view - Linker tab //////////////
            tableInfoCollection.Collection = new ObservableCollection<TableInfo>(RepositoryLocator.CatalogueRepository.GetAllObjects<TableInfo>()); //600 ms
            tableInfoCollection.CollectionChanged+=(s,e)=>RefreshAllLists();

            this.ci_lbSelectedColumns.Items.Clear();
            HighlightAssociatedColumns(null);

            ClearFormComponents();

            if (toReselectCatalogueItem != null)
                lbCatalogueItems.SelectObject(toReselectCatalogueItem);
            
            CalculateCatalogueItemsHighlightColours();
            lbCatalogueItems.ModelFilter = new TextMatchFilter(lbCatalogueItems, tbFilter.Text);
            lbCatalogueItems.BuildList();
        }


        private void ClearFormComponents()
        {
            clearingFormComponents = true;

            try
            {
                foreach (Control c in this.Controls)
                    if (c is TextBox)
                        c.Text = "";
                    else if (c is ComboBox)
                    {
                        c.Text = "";
                        ((ComboBox)c).Items.Clear();
                    }


                foreach (Control c in this.Controls)
                    if (c is TextBox)
                        c.Text = "";
                    else if (c is ComboBox)
                    {
                        c.Text = "";
                        ((ComboBox)c).Items.Clear();
                    }
            }
            finally
            {
                clearingFormComponents = false;
            }
        }


        private void CreateNewCatalougeItem()
        {
            if (Catalogue == null)
            {
                MessageBox.Show("You must select a Catalogue to add the new Item too");
            }
            else
            {
                new CatalogueItem(Catalogue.Repository,Catalogue, "New CatalogueItem " + Guid.NewGuid());
                RefreshAllLists();
            }
        }

        private void ci_lbCatalogueItems_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
                DeleteCatalogueItem();

            if (e.KeyCode == Keys.V && e.Control)
                handlePasteListOfNewCatalogueItems();

            if (e.KeyCode == Keys.N && e.Control)
                CreateNewCatalougeItem();
        }

        private void handlePasteListOfNewCatalogueItems()
        {
            if (Catalogue == null)
                return;

            string[] toImport = UsefulStuff.GetInstance().GetArrayOfColumnNamesFromStringPastedInByUser(Clipboard.GetText()).ToArray();

            if (toImport.Any())
                if (MessageBox.Show("Add " + toImport.Length + " new CatalogueItems into Catalogue " + Catalogue.Name + "?", "Paste In New Columns?", MessageBoxButtons.OKCancel) == DialogResult.OK)
                {
                    foreach (string name in toImport)
                        new CatalogueItem(Catalogue.Repository,Catalogue, name);
                    
                    RefreshAllLists();
                }
        }

        private void DeleteCatalogueItem()
        {
             CatalogueItem ci = (CatalogueItem)lbCatalogueItems.SelectedObject;

            if (ci == null)
            {
                MessageBox.Show("You must select a CatalogueItem to before you can delete it");
            }
            else
            {
                DialogResult r = MessageBox.Show("Are you sure you want to delete CatalogueItem " + ci.Name+ "?", "Delete Record?",
                                                 MessageBoxButtons.YesNo);

                if (r == DialogResult.Yes)
                {
                    ci.DeleteInDatabase();
                    RefreshAllLists();
                }
            }
        }


        private CatalogueItem previousSelection;
        private void ci_lbCatalogueItems_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            RemindUserToSaveChanges(previousSelection);

            clearingFormComponents = true;
            CatalogueItem ci = (CatalogueItem)lbCatalogueItems.SelectedObject;
            

            if (ci == null)
            {

                ClearFormComponents();
                return;
            }
            
            ci_tbID.Text = ci.ID.ToString();
            ci_tbName.Text = ci.Name;

            _oldCatalogueItemName = ci.Name;
            _newCatalogueItemName = ci.Name;

            ci_tbStatisticalConsiderations.Text = ci.Statistical_cons;
            ci_tbResearchRelevance.Text = ci.Research_relevance;
            ci_tbDescription.Text = ci.Description;
            ci_tbTopics.Text = ci.Topic;

            ci_ddPeriodicity.DataSource = Enum.GetValues(typeof(Catalogue.CataloguePeriodicity));
            ci_ddPeriodicity.SelectedItem = ci.Periodicity;

            ci_tbAggregationMethod.Text = ci.Agg_method;
            ci_tbLimitations.Text = ci.Limitations;
            ci_tbComments.Text = ci.Comments;

            ColumnInfo[] cols = ci.ColumnInfos.ToArray();
            ci_lbSelectedColumns.Items.Clear();
            ci_lbSelectedColumns.Items.AddRange(cols);
            HighlightAssociatedColumns(ci);

            clearingFormComponents = false;

            previousSelection = ci;
        }


        private void RemindUserToSaveChanges(CatalogueItem catalogueItem)
        {
            bool madeChangesToCatalogue = false;
            
            if (unsavedChanges)
                if(catalogueItem != null)
                   if(MessageBox.Show("Save Changes?", "", MessageBoxButtons.YesNo) == DialogResult.Yes)
                   {
                       catalogueItem.SaveToDatabase();
                       madeChangesToCatalogue = PropagateRenameIfRequired(catalogueItem);
                   }
                   else
                       catalogueItem.RevertToDatabaseState();
                
            //either they saved or chose not to save changes
            unsavedChanges = false;

            if (madeChangesToCatalogue && GlobalChangesIncurred != null)
                GlobalChangesIncurred(this, new EventArgs());


        }


        private void ImportNewCatalogueItemIntoCurrentlySelectedCatalogue()
        {
            if (Catalogue != null)
            {
                ImportCloneOfCatalogueItem cloner = new ImportCloneOfCatalogueItem(Catalogue);
                cloner.ShowDialog(this);
                RefreshAllLists();
            }
        }

        private void ImportDescriptiveDataIntoCurrentlySelectedCatalogue(bool bOnlyShowCatalogueItemsWithSameName)
        {
           var cataItem = lbCatalogueItems.SelectedObject as CatalogueItem;

            if (cataItem == null)
                MessageBox.Show(
                    "You must select a CatalogueItem (on the left) in which to populate the descriptive data of");

            if (Catalogue != null && cataItem != null)
            {
                ImportCloneOfCatalogueItem cloner = new ImportCloneOfCatalogueItem(Catalogue, cataItem, bOnlyShowCatalogueItemsWithSameName);
                cloner.ShowDialog(this);
                cataItem.SaveToDatabase();

                //reselect it to make it update the textboxes
                lbCatalogueItems.SelectedItem = null;
                lbCatalogueItems.SelectObject(cataItem);
            }
        }

        private string _oldCatalogueItemName = "";
        private string _newCatalogueItemName = "";

        private void ci_tbName_TextChanged(object sender, EventArgs e)
        {
            _newCatalogueItemName = ci_tbName.Text;
            SetStringPropertyOnCatalogueItem((TextBox)sender,"Name");
        }

        private void ci_tbStatisticalConsiderations_TextChanged(object sender, EventArgs e)
        {
            SetStringPropertyOnCatalogueItem((TextBox)sender, "Statistical_cons");
        }

        private void ci_tbResearchRelevance_TextChanged(object sender, EventArgs e)
        {
            SetStringPropertyOnCatalogueItem((TextBox)sender, "Research_relevance");
        }

        private void ci_tbDescription_TextChanged(object sender, EventArgs e)
        {
            SetStringPropertyOnCatalogueItem((TextBox)sender, "Description");
        }

        private void ci_tbTopics_TextChanged(object sender, EventArgs e)
        {
            SetStringPropertyOnCatalogueItem((TextBox)sender, "Topic");
        }

        private void ci_ddPeriodicity_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (clearingFormComponents)
                return;

            var catalogueItem = (CatalogueItem)lbCatalogueItems.SelectedObject;

            if (catalogueItem != null)
                catalogueItem.Periodicity = (Catalogue.CataloguePeriodicity)ci_ddPeriodicity.SelectedItem;
        }

        private void ci_tbAggregationMethod_TextChanged(object sender, EventArgs e)
        {
            SetStringPropertyOnCatalogueItem((TextBox)sender, "Agg_method");
        }

        private void ci_tbLimitations_TextChanged(object sender, EventArgs e)
        {
            SetStringPropertyOnCatalogueItem((TextBox)sender, "Limitations");
        }

        private void ci_tbComments_TextChanged(object sender, EventArgs e)
        {
            SetStringPropertyOnCatalogueItem((TextBox)sender, "Comments");
        }

        private void SaveCurrentlySelectedCatalogueItem()
        {
            bool madeChangesToCatalogue = false;

            CatalogueItem ci = (CatalogueItem)lbCatalogueItems.SelectedObject;
            
            if (ci == null)
                return;

            int lastSelectedID = ci.ID;

            //there is a selected catalogue item and we are being told to save it
            if (ci != null)
            {
                //see if we need to display the dialog that lets the user sync up descriptions of multiuse columns e.g. CHI
                bool shouldDialogBeDisplayed;
                var propagate = new PropagateSaveChangesToCatalogueItemToSimilarNamedCatalogueItems(ci, out shouldDialogBeDisplayed);

                //there are other CatalogueItems that share the same name as this one so give the user the option to propagate his changes to those too
                if (shouldDialogBeDisplayed)
                {
                    DialogResult dialogResult = propagate.ShowDialog(this);

                    if(dialogResult != DialogResult.Cancel)
                    {

                        ci.SaveToDatabase();
                        madeChangesToCatalogue = PropagateRenameIfRequired(ci);
                    }
                }
                else
                {
                    ci.SaveToDatabase();
                    madeChangesToCatalogue = PropagateRenameIfRequired(ci);
                }

            }

            unsavedChanges = false;
            ClearFormComponents();

            // try to select the users last choice again
            CatalogueItem toSelect = null;

            foreach (CatalogueItem catalogue in lbCatalogueItems.Objects)
                if (catalogue.ID == lastSelectedID)
                {
                    toSelect = catalogue;
                }

            lbCatalogueItems.SelectObject(toSelect);

            this.lblSaved.Text = "Saved";

            if (madeChangesToCatalogue && GlobalChangesIncurred != null)
                GlobalChangesIncurred(this, new EventArgs());

            lbCatalogueItems.BuildList();
        }

        private bool PropagateRenameIfRequired(CatalogueItem ci)
        {
            if(ci == null)
                return false;

            if(_oldCatalogueItemName.Equals(_newCatalogueItemName))
                return false;

            if(ci.Name != _newCatalogueItemName)
                throw new Exception("Unsure why _newCatalogueItemName is not an exact match for ci.Name");



            if(Catalogue == null || Catalogue.ID != ci.Catalogue_ID)
                throw new Exception("How did you rename a catalogue item without having it's parent selected?");

            if (!string.IsNullOrWhiteSpace(Catalogue.ValidatorXML) && Catalogue.ValidatorXML.Contains(_oldCatalogueItemName))
                if(MessageBox.Show("You just renamed the CatlogueItem " + _oldCatalogueItemName + " to " + _newCatalogueItemName + " would you like to perform a rename on the validation XML for the Catalogue?","Fix Validation references?",MessageBoxButtons.YesNo)
                    == DialogResult.Yes)
                    try
                    {
                        Validator validator = Validator.LoadFromXml(Catalogue.ValidatorXML);

                        validator.RenameColumn(_oldCatalogueItemName, _newCatalogueItemName);
                    
                        string newXML = validator.SaveToXml();

                        Catalogue.ValidatorXML = newXML;
                        Catalogue.SaveToDatabase();
                        return true;
                    }
                    catch(Exception ex)
                    {
                        MessageBox.Show("Problem occurred when attempting to rename column " + _oldCatalogueItemName +
                                        " to " + _newCatalogueItemName + " : " + ex);
                    }

            return false;
        }

        #region Linker section
        private void ci_lbSelectedColumns_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete && ci_lbSelectedColumns.SelectedItem != null)
            {
                try
                {
                    var ci = (CatalogueItem) lbCatalogueItems.SelectedObject;

                    ((CatalogueRepository)ci.Repository).Linker.DeleteLink(ci, (ColumnInfo)ci_lbSelectedColumns.SelectedItem);
                }
                catch (Exception)
                {


                }

                ci_lbSelectedColumns.Items.Remove(ci_lbSelectedColumns.SelectedItem);
                HighlightAssociatedColumns((CatalogueItem)lbCatalogueItems.SelectedObject);

            }
        }

        private void ci_lbSelectedColumns_DragDrop(object sender, DragEventArgs e)
        {


            OLVDataObject o = e.Data as OLVDataObject;

            //if source is not an object list/tree view or there is not exactly 1 ColumnInfo
            if (o == null || o.ModelObjects.Count != 1 || !(o.ModelObjects[0] is ColumnInfo))
                return;
            
            CatalogueItem selectedCatalogueItem = lbCatalogueItems.SelectedObject as CatalogueItem;
            ColumnInfo info = (ColumnInfo) o.ModelObjects[0];

            if (selectedCatalogueItem == null)
            {
                MessageBox.Show("You must select a CatalogueItem on the left first");
            }
            else
                if (info != null)
                {
                    try
                    {
                        
                        //add link
                        ((CatalogueRepository)info.Repository).Linker.AddLinkBetween(selectedCatalogueItem, info);

                        //update UI to show association
                        ci_lbSelectedColumns.Items.Add(info);
                        HighlightAssociatedColumns(selectedCatalogueItem);

                        //if it did not have a name before
                        if (selectedCatalogueItem.Name.StartsWith("New CatalogueItem"))
                        {
                            //give it one
                            selectedCatalogueItem.Name = info.GetRuntimeName();
                            selectedCatalogueItem.SaveToDatabase();
                            
                            //and refresh UI 
                            RefreshAllLists();
                        }
                    }
                    catch (ArgumentException ex)
                    {
                        MessageBox.Show(ex.Message);
                    }

                }
        }

        private void ci_lbSelectedColumns_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.None;
            
            OLVDataObject o = e.Data as OLVDataObject;

            //if source is not an object list/tree view
            if (o == null)
                return;

            //if there is precisely 1 object and it is a ColumnInfo
            if(o.ModelObjects.Count == 1 && o.ModelObjects[0] is ColumnInfo)
                e.Effect = DragDropEffects.Copy;
            
        }

        #region Right Click Context Menu

        ContextMenuStrip ci_ColumnInfoPickerRightClickMenu;

       
        private void ci_lbSelectedColumns_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                if (ci_lbSelectedColumns.SelectedItem != null)
                {
                    //create right click context menu
                    ci_ColumnInfoPickerRightClickMenu = new ContextMenuStrip();
                    ci_ColumnInfoPickerRightClickMenu.Items.Add("Configure For Extraction",null,ci_ColumnInfoPickerRightClickMenu_ConfigureForExtraction_Click);
                    

                    //show it
                    ci_ColumnInfoPickerRightClickMenu.Show(ci_lbSelectedColumns, e.Location);
                    ci_ColumnInfoPickerRightClickMenu_currentColumnInfo = (ColumnInfo)ci_lbSelectedColumns.SelectedItem;
                }
            }
        }

   
        private ColumnInfo ci_ColumnInfoPickerRightClickMenu_currentColumnInfo;
        
        void ci_ColumnInfoPickerRightClickMenu_ConfigureForExtraction_Click(object sender, EventArgs e)
        {
            if (lbCatalogueItems.SelectedItem == null)
            {
                MessageBox.Show("You must select a CatalogueItem");
                return;
            }

            ExtractionInformationUI ui = new ExtractionInformationUI(lbCatalogueItems.SelectedObject as CatalogueItem, ci_ColumnInfoPickerRightClickMenu_currentColumnInfo);
            ui.ShowDialog(this);
            if(ui.ShouldReloadCatalogues)
            {
                RefreshAllLists();
                return;
            }

            //changes in dialog may have changed extraction highlight
            HighlightAssociatedColumns(lbCatalogueItems.SelectedObject as CatalogueItem);
        }
        #endregion

        private void ci_lbSelectedColumns_SelectedIndexChanged(object sender, EventArgs e)
        {

            //try to select the ColumnInfo in the tree on the right
            if (ci_lbSelectedColumns.SelectedItem is ColumnInfo)
            {
                ColumnInfo columnInfo = (ColumnInfo)ci_lbSelectedColumns.SelectedItem;

                int id = columnInfo.ID;

                if (id == -1) //it's a missing column
                    return;

                //it is not a missing column

                //make sure the tableinfo is the only one visible on the right
                string nameOfTable = columnInfo.TableInfo.Name;
                tableInfoCollection.SetFilter(nameOfTable);

                //now select it
                tableInfoCollection.SelectColumnInfo(columnInfo);
            }
        }

        #endregion
        
        protected override bool ProcessKeyPreview(ref Message m)
        {
            
            PreviewKey p = new PreviewKey(ref m, ModifierKeys);
            
            if (p.IsKeyDownMessage)
            {

                if(p.e.KeyCode == Keys.S && p.e.Control)
                {
                    SaveCurrentlySelectedCatalogueItem();
                    p.Trap(this);
                    return true;
                }

                if (p.e.KeyCode == Keys.E && p.e.Control)
                {
                    ViewExtractionInformationFor(lbCatalogueItems.SelectedObject as CatalogueItem);
                    p.Trap(this);
                    return true;
                }

                if (p.e.KeyCode == Keys.I && p.e.Control && p.e.Shift)
                {
                    descriptiveDataIntoCurrentCatalogueItemToolStripMenuItem_Click(null, null);
                    p.Trap(this);
                    return true;
                }
                if (p.e.KeyCode == Keys.I && p.e.Control)
                {
                    descriptiveDataFromAnotherCatalogueItem_SameName_ToolStripMenuItem_Click(null, null);
                    p.Trap(this);
                    return true;
                }

            
            }
            return base.ProcessKeyPreview(ref m);
        }

    

        #region Helper Methods for setting string and Uri properties



        private void SetStringPropertyOnCatalogueItem(TextBox tb, string property)
        {
            if (clearingFormComponents)
                return;

            unsavedChanges = true;
            lblSaved.Text = "";

            CatalogueItem ci = (CatalogueItem)lbCatalogueItems.SelectedObject;
            SetStringProperty(tb, property, ci);
        }

        private void SetStringProperty(TextBox tb, string property, object toSetOn)
        {
            if (clearingFormComponents)
                return;

            unsavedChanges = true;
            lblSaved.Text = "";

            if (toSetOn != null)
            {
                PropertyInfo target = toSetOn.GetType().GetProperty(property);
                FieldInfo targetMaxLength = toSetOn.GetType().GetField(property + "_MaxLength");


                if (target == null || targetMaxLength == null)
                    throw new Exception("Could not find property " + property + " or it did not have a specified _MaxLength");

                if (tb.TextLength > (int)targetMaxLength.GetValue(toSetOn))
                    tb.ForeColor = Color.Red;
                else
                {
                    target.SetValue(toSetOn, tb.Text, null);
                    tb.ForeColor = Color.Black;
                }
            }
        }

        #endregion


        public void RefreshLists()
        {
            RefreshAllLists();
        }

        private object highlightIndexesLock = new object();
        private HighlightAssociatedColumnType[] _highlightAssociatedColumnAssociatedColumnIndexes;
        private bool unsavedChanges=false;

        private enum HighlightAssociatedColumnType
        {
            None,
            IndicatesTimeSpanOfCatalogue,
            Core,
            Supplemental,
            SpecialApprovalRequired,
            Internal

        }

        private void RowFormatter(OLVListItem olvItem)
        {
            CatalogueItem ci = (CatalogueItem) olvItem.RowObject;

            if (_highlightCatalogueItemBecauseItHasDodgyName.Any(id => id == ci.ID))
                olvItem.ForeColor = Color.Red;             //it doesn't match ExtractionInformation name and user pressed HighlightDodgyNames
            else
                if (_classifications.Any(classification => classification.ExtractionCategory == ExtractionCategory.Deprecated && classification.CatalogueItem_ID == ci.ID))
                    olvItem.ForeColor = Color.Orange;         //it is deprecated
                else
                    if (_classifications.Any(classification => classification.IsLookupDescription && classification.CatalogueItem_ID == ci.ID))
                        olvItem.ForeColor = Color.PowderBlue;   //it is a lookup description
                    if (_classifications.Any(classification => classification.ExtractionInformation_ID != null && classification.CatalogueItem_ID == ci.ID))
                        olvItem.ForeColor = Color.SteelBlue;    //it has at least one ExtractionInformation (determined in CalculateCatalogueItemsHighlightColours rather than every draw frame!)
                        else
                            if (ci.Name.StartsWith("New CatalogueItem"))
                                olvItem.ForeColor = Color.Red;            //it is NewCatalogueItem x082734o87
                            else
                                olvItem.ForeColor = Color.Black;        //Everything else
        }

        /// <summary>
        ///used to highlight extraction columns in the AssociatedColumns listbox
        /// </summary>
        private void HighlightAssociatedColumns(CatalogueItem catalogueItem)
        {
            lock (highlightIndexesLock)
            {
                
                if (ci_lbSelectedColumns.Items.Count == 0 || catalogueItem == null)
                {
                    _highlightAssociatedColumnAssociatedColumnIndexes = null;
                    return;
                }
                else
                {
                    Catalogue parent = catalogueItem.Catalogue;


                    var repo = ((CatalogueRepository) parent.Repository);


                    _highlightAssociatedColumnAssociatedColumnIndexes = new HighlightAssociatedColumnType[ci_lbSelectedColumns.Items.Count];

                    //for each associated column
                    for(int i=0;i<ci_lbSelectedColumns.Items.Count;i++)
                    {
                        ExtractionInformation extractionInformation = repo.Linker.GetExtractionInformationFrom(catalogueItem, ci_lbSelectedColumns.Items[i] as ColumnInfo);
                        //see if it is configured for extraction
                        if ( extractionInformation!= null)
                        {
                            if (parent.TimeCoverage_ExtractionInformation_ID == extractionInformation.ID)
                                _highlightAssociatedColumnAssociatedColumnIndexes[i] = HighlightAssociatedColumnType.IndicatesTimeSpanOfCatalogue; //it is the one and only timespan field for the catalogue
                            else
                                if (extractionInformation.ExtractionCategory == ExtractionCategory.Core)
                                    _highlightAssociatedColumnAssociatedColumnIndexes[i] = HighlightAssociatedColumnType.Core;
                                else
                                    if (extractionInformation.ExtractionCategory == ExtractionCategory.Supplemental)
                                        _highlightAssociatedColumnAssociatedColumnIndexes[i] = HighlightAssociatedColumnType.Supplemental;
                                    else
                                    if (extractionInformation.ExtractionCategory == ExtractionCategory.SpecialApprovalRequired)
                                        _highlightAssociatedColumnAssociatedColumnIndexes[i] = HighlightAssociatedColumnType.SpecialApprovalRequired;
                                            else
                                                if (extractionInformation.ExtractionCategory == ExtractionCategory.Internal)
                                                    _highlightAssociatedColumnAssociatedColumnIndexes[i] = HighlightAssociatedColumnType.Internal;
                                    
                        }
                        else
                            _highlightAssociatedColumnAssociatedColumnIndexes[i] = HighlightAssociatedColumnType.None; //it's not extractable at all
                    }
                }
            }
        }

        private void ci_lbSelectedColumns_DrawItem(object sender, DrawItemEventArgs e)
        {
            lock (highlightIndexesLock)
            {
                e.DrawBackground();
                Graphics g = e.Graphics;

                // draw the background color you want
                // mine is set to olive, change it to whatever you want
                g.FillRectangle(new SolidBrush(e.BackColor), e.Bounds);

                // draw the text of the list item, not doing this will only show
                // the background color
                // you will need to get the text of item to display
                
                if (e.Index != -1)
                {


                    string toDisplay = (sender as ListBox).Items[e.Index].ToString();

                    //if highlighting array is not yet completely populated (race condition - it will be blocking waiting redraw to finish)
                    if(_highlightAssociatedColumnAssociatedColumnIndexes == null)
                        g.DrawString(toDisplay, e.Font, new SolidBrush(e.ForeColor), new PointF(e.Bounds.X, e.Bounds.Y));
                    else
                    //highlight in appropriate colour
                    if (_highlightAssociatedColumnAssociatedColumnIndexes[e.Index] == HighlightAssociatedColumnType.Core)
                        g.DrawString(toDisplay, new Font(e.Font, FontStyle.Bold), new SolidBrush(Color.Green), new PointF(e.Bounds.X, e.Bounds.Y));
                    else
                    if (_highlightAssociatedColumnAssociatedColumnIndexes[e.Index] == HighlightAssociatedColumnType.Supplemental)
                        g.DrawString(toDisplay, new Font(e.Font, FontStyle.Bold), new SolidBrush(Color.Orange), new PointF(e.Bounds.X, e.Bounds.Y));
                    else
                        if (_highlightAssociatedColumnAssociatedColumnIndexes[e.Index] == HighlightAssociatedColumnType.Internal)
                            g.DrawString(toDisplay, new Font(e.Font, FontStyle.Bold), new SolidBrush(Color.Red), new PointF(e.Bounds.X, e.Bounds.Y));
                    else
                        if (_highlightAssociatedColumnAssociatedColumnIndexes[e.Index] == HighlightAssociatedColumnType.SpecialApprovalRequired)
                            g.DrawString(toDisplay, new Font(e.Font, FontStyle.Bold), new SolidBrush(Color.Tan), new PointF(e.Bounds.X, e.Bounds.Y));
                    else
                    if (_highlightAssociatedColumnAssociatedColumnIndexes[e.Index] == HighlightAssociatedColumnType.IndicatesTimeSpanOfCatalogue)
                        g.DrawString(toDisplay + " (Catalogue Timespan) ", new Font(e.Font, FontStyle.Bold), new SolidBrush(Color.LightSeaGreen), new PointF(e.Bounds.X, e.Bounds.Y));
                    else
                        g.DrawString(toDisplay, e.Font, new SolidBrush(e.ForeColor), new PointF(e.Bounds.X, e.Bounds.Y));

                }

                
                e.DrawFocusRectangle();
            }
        }

        
        private Catalogue _catalogue;
        private List<int> _highlightCatalogueItemBecauseItHasDodgyName = new List<int>();
        private CatalogueItemClassification[] _classifications = {};

        private void CalculateCatalogueItemsHighlightColours()
        {
            if (Catalogue == null)
                return;
            
            _classifications = ((CatalogueRepository)Catalogue.Repository).Linker.ClassifyCatalogueItemsOf(Catalogue);
        }

        private void HighlightDodgyCatalogueItemNames()
        {
            _highlightCatalogueItemBecauseItHasDodgyName = new List<int>();
            foreach (CatalogueItem cataItem in lbCatalogueItems.Objects)
            {
                
                ExtractionInformation[] extractionInfos = cataItem.ExtractionInformations.ToArray();

                if(extractionInfos.Any(info=>!info.GetRuntimeName().Equals(cataItem.Name)))
                    _highlightCatalogueItemBecauseItHasDodgyName.Add(cataItem.ID);
            }

            lbCatalogueItems.Invalidate();
        }

        private void ci_lbSelectedColumns_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            int index = ci_lbSelectedColumns.IndexFromPoint(e.Location);
            if (index != ListBox.NoMatches)
            {
                if (lbCatalogueItems.SelectedItem == null)
                {
                    MessageBox.Show("You must select a CatalogueItem");
                    return;
                }

                //for some reason if the listbox is blank of items this can come up wtih a high index e.g. 65535, in which case return instead of bombing.
                if(index > ci_lbSelectedColumns.Items.Count)
                    return;
                
                var ui = new ExtractionInformationUI(lbCatalogueItems.SelectedObject as CatalogueItem, ci_lbSelectedColumns.Items[index] as ColumnInfo);
                ui.ShowDialog(this);

                if (ui.ShouldReloadCatalogues)
                {
                    RefreshAllLists();
                    return;
                }
            
                //changes in dialog may have changed extraction highlight
                HighlightAssociatedColumns(lbCatalogueItems.SelectedObject as CatalogueItem);
            }
        }

        private void tbFilter_TextChanged(object sender, EventArgs e)
        {
            lbCatalogueItems.ModelFilter = new TextMatchFilter(lbCatalogueItems, tbFilter.Text);
        }

        private void ViewExtractionInformationFor(CatalogueItem toView)
        {
            if(toView == null)
            {
                MessageBox.Show("No CatalogueItem is selected");
                return;
            }

            
            //see if it has only 1 extractable column
            ExtractionInformation[] extractionInformations = toView.ExtractionInformations.ToArray();

            //it hasonly one extractable column so display that one
            if (extractionInformations.Length == 1)
            {
                ColumnInfo col = extractionInformations[0].ColumnInfo;

                if (col != null)
                {
                    ExtractionInformationUI extractionConfigurationUI = new ExtractionInformationUI(toView, col);
                    extractionConfigurationUI.ShowDialog(this);

                    if (extractionConfigurationUI.ShouldReloadCatalogues)
                        RefreshAllLists();
                }
            }
            else
            {
                //see if it has only one selected column - that is not yet marked for extraction
                if (ci_lbSelectedColumns.Items.Count == 1)
                {
                    ExtractionInformationUI extractionConfigurationUI = new ExtractionInformationUI(toView, ci_lbSelectedColumns.Items[0] as ColumnInfo);
                    extractionConfigurationUI.ShowDialog(this);

                    if (extractionConfigurationUI.ShouldReloadCatalogues)
                        RefreshAllLists();
                }
            }
        }


        void lbCatalogueItems_CellClick(object sender, CellClickEventArgs e)
        {
            //rather than having to manually go across screen and select the associated column for extraction, when it's a 1 to 1 relationship
            //we can just pop it up on double clicks

            if(e.ClickCount == 2)
                ViewExtractionInformationFor(lbCatalogueItems.SelectedObject as CatalogueItem);
        }
        private void listBoxes_MeasureItem(object sender, MeasureItemEventArgs e)
        {
            //don't think this really works, it's supposed to work with UserDrawVariable on listboxes 
            e.ItemHeight = ((Control) sender).Font.Height;
        }



      
        #region Menu Items Functionality
        private void GuessAssociatedColumns()
        {
           
            if (tableInfoCollection.SelectedTableInfo == null)
            {
                MessageBox.Show("Select a table to guess associted columns from (far right)");
                return;
            }
            
            if (Catalogue == null)
            {
                MessageBox.Show(
                    "Select a Catalogue (far left) and we will guess associated columns for any CatalogueItems that do not already have associated columns");
                return;
            }
            
            
            try
            {
                var selectedTableInfo = tableInfoCollection.SelectedTableInfo;

                var linker = ((CatalogueRepository) Catalogue.Repository).Linker;

                //get all columns for the selected parent
                ColumnInfo[] guessPool = selectedTableInfo.ColumnInfos.ToArray();
                foreach (CatalogueItem catalogueItem in Catalogue.CatalogueItems)
                {
                    //column already has one or more associated columns so skip it
                    if(catalogueItem.ColumnInfos.Any())
                        continue;

                    //guess the associated columns
                    ColumnInfo[] guesses = catalogueItem.GuessAssociatedColumn(guessPool).ToArray();

                    //if there is exactly 1 column that matches the guess
                    if (guesses.Length == 1)
                        linker.AddLinkBetween(catalogueItem, guesses[0]);
                    else
                    {
                        for (int i = 0; i < guesses.Length; i++) //note that this sneakily also deals with case where guesses is empty
                        {
                            DialogResult dialogResult = MessageBox.Show("Found multiple matches, approve match?:" +Environment.NewLine + catalogueItem.Name + Environment.NewLine + guesses[i],"Multiple matched guesses",MessageBoxButtons.YesNo);

                            if (dialogResult == DialogResult.Yes)
                            {
                                linker.AddLinkBetween(catalogueItem, guesses[i]);
                                break;
                            }
                        }
                    }
                }

            }
            finally
            {
                RefreshAllLists();
            }
        }

        //todo put this in its own form with its own GUI
        private void GuessAssociatedColumnsButAlsoInClipboard()
        {

            if (tableInfoCollection.SelectedTableInfo == null)
            {
                MessageBox.Show("Select a table to guess associted columns from (far right)");
                return;
            }

            if (Catalogue == null)
            {
                MessageBox.Show(
                    "Select a Catalogue (far left) and we will guess associated columns for any CatalogueItems that do not already have associated columns");
                return;
            }

            try
            {

                var toMarkExtractable = new List<string>(UsefulStuff.GetInstance().GetArrayOfColumnNamesFromStringPastedInByUser(Clipboard.GetText()));

                YesNoYesToAllDialog dialog = new YesNoYesToAllDialog();

                var linker = ((CatalogueRepository)Catalogue.Repository).Linker;

                List<ColumnInfo> guessPool = new List<ColumnInfo>(tableInfoCollection.SelectedTableInfo.ColumnInfos);
                foreach (CatalogueItem catalogueItem in Catalogue.CatalogueItems)
                {
                    //column already has one or more associated columns so skip it
                    if (linker.GetColumnInfos(catalogueItem).Any())
                        continue;

                    foreach (ColumnInfo guess in guessPool.Where(col => col.Name.ToLower().Contains(catalogueItem.Name.ToLower())))
                    {
                        if (!toMarkExtractable.Contains(guess.GetRuntimeName()))//if it is one we are actually interested in
                            continue;

                        DialogResult dr = dialog.ShowDialog("Match " + Environment.NewLine
                                                          + catalogueItem.Name + Environment.NewLine
                                                          + " to " + Environment.NewLine
                                                          + guess.Name, "Approve Match?");
                        if (dr == DialogResult.Yes)
                        {
                            linker.AddLinkBetween(catalogueItem, guess);
                            break;
                        }

                    }
                }

            }
            finally
            {
                RefreshAllLists();
            }




        }

        private void DeleteMissingColumnInfosFromCurrentlySelectedCatalogue()
        {
            int deleteCounter = 0;

            if (Catalogue != null)
            {
                CatalogueItem[] catalogueItems = Catalogue.CatalogueItems.ToArray();
                var linker = ((CatalogueRepository)Catalogue.Repository).Linker;

                foreach (var catalogueItem in catalogueItems)
                {
                    //as soon as you delete one missing column from a CatalogueItem you will delete them all because missing ColumnInfos all have the ID of DBNull in the database
                    if (catalogueItem.ColumnInfos.Any(columnInfo => columnInfo.ID == -1))
                    {
                        linker.DeleteLink(catalogueItem, ColumnInfo.Missing);
                        deleteCounter++;
                    }
                }

                MessageBox.Show("Deleted " + deleteCounter + " Missing ColumnInfo Links");
            }
        }

        private void DeleteAllColumnInfosForCurrentlySelectedCatalogue()
        {
            int deleteCounter = 0;
            
            if (Catalogue != null && MessageBox.Show("Confirm deleting all associated columns (and any extraction information too!)?", "Confirm Delete AssociatedColumns", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {

                CatalogueItem[] catalogueItems = Catalogue.CatalogueItems.ToArray();

                var linker = ((CatalogueRepository)Catalogue.Repository).Linker;

                foreach (var catalogueItem in catalogueItems)
                    deleteCounter += linker.DeleteLinkAllLinksFor(catalogueItem);

                MessageBox.Show("Deleted " + deleteCounter + " Missing ColumnInfo Links");
            }
        }

        private void MarkAllAssociatedColumnsAsExtractable()
        {
            if (Catalogue == null)
            {
                MessageBox.Show(
                    "Select a Catalogue (far left) and we will guess associated columns for any CatalogueItems that do not already have associated columns");
                return;
            }

            DialogResult dialogResult = MessageBox.Show("We are about to enable all associated columns for extraction as Core " +
                "extraction fields.  This will be restricted only to cases where there is " +
                "one and only 1 Associated ColumnInfo per CatalogueItem and it is not already " +
                "configured for extraction.  Do you wish to proceed?", "Proceed", MessageBoxButtons.YesNo);

            int countCreated = 0;

            var linker = ((CatalogueRepository) Catalogue.Repository).Linker;

            if (dialogResult == DialogResult.Yes)
            {
                foreach (CatalogueItem catalogueItem in Catalogue.CatalogueItems)
                {

                    ColumnInfo[] cols = catalogueItem.ColumnInfos.ToArray(); 
                    
                    //do not start marking lots of stuff as ready for extraction for the same CatalogueItem
                    if(cols.Length != 1)
                        continue;

                    //do not try to mark missing column info as extractable
                    if(cols[0].ID == ColumnInfo.Missing.ID)
                        continue;

                    //column already has ExtractionInformation configured for it so ignore it
                    if (linker.GetExtractionInformationFrom(catalogueItem, cols[0]) != null)
                        continue;

                    new ExtractionInformation((CatalogueRepository) catalogueItem.Repository,catalogueItem, cols[0], null);
                    countCreated++;
                }

                MessageBox.Show("Marked " + countCreated + " associated columns as enabled for extraction");
            }
        }

        private void DeleteAllExtractionInformationsForCurrentlySelectedCatalogue()
        {

            if (Catalogue == null)
            {
                MessageBox.Show(
                    "Select a Catalogue (far left) and all extraction informations will be deleted (the underlying columns will remaine associated)");
                return;
            }

            DialogResult dialogResult = MessageBox.Show("We are about to delete all extraction information for the Catalogue " + Catalogue.Name + " (" +
                                                        "this could have catastrophic repercussions for DataExport stuff...  Do you wish to proceed?",
                                                        "Delete swathes of data?", MessageBoxButtons.YesNo);

            var linker = ((CatalogueRepository)Catalogue.Repository).Linker;

            if (dialogResult == DialogResult.Yes)
            {
                int deleteCount = 0;

                foreach (ExtractionInformation extractionInformation in Catalogue.GetAllExtractionInformation(ExtractionCategory.Any))
                {
                    extractionInformation.DeleteInDatabase();
                    deleteCount++;
                }

                MessageBox.Show("Deleted " + deleteCount + " ExtractionInformations");

                RefreshAllLists();
            }
        }

        #endregion

        #region Menu Items Event Handlers

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveCurrentlySelectedCatalogueItem();
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CreateNewCatalougeItem();
        }

        private void deleteDelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DeleteCatalogueItem();
        }

        private void cloneNewCatalogueItemToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ImportNewCatalogueItemIntoCurrentlySelectedCatalogue();
        }

        private void descriptiveDataIntoCurrentCatalogueItemToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ImportDescriptiveDataIntoCurrentlySelectedCatalogue(false);
        }
        private void descriptiveDataFromAnotherCatalogueItem_SameName_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ImportDescriptiveDataIntoCurrentlySelectedCatalogue(true);
        }

        private void deleteAllExtractionInformationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DeleteAllExtractionInformationsForCurrentlySelectedCatalogue();
        }

        private void guessAssociatedColumnInfosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GuessAssociatedColumns();
        }

        private void markAllAssociatedColumnsExtractableToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MarkAllAssociatedColumnsAsExtractable();
        }
        private void extractioncatalogueItemToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ViewExtractionInformationFor(lbCatalogueItems.SelectedObject as CatalogueItem);
        }

        private void deleteMISSINGAssociatedColumnsInfosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DeleteMissingColumnInfosFromCurrentlySelectedCatalogue();
        }
        private void deleteAllAssociatedColumnInfosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DeleteAllColumnInfosForCurrentlySelectedCatalogue();
        }
        private void CatalogueItemTab_Leave(object sender, EventArgs e)
        {
            RemindUserToSaveChanges(lbCatalogueItems.SelectedObject as CatalogueItem);
        }

        private void highlightDodgyNamesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            HighlightDodgyCatalogueItemNames();
        }
        #endregion

        private void catalogueToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void bulkProcessCatalogueItemsToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (Catalogue == null)
                MessageBox.Show("Select a Catalogue first");
            else
            {
                BulkProcessCatalogueItems bulkProcess = new BulkProcessCatalogueItems(Catalogue);
                bulkProcess.ShowDialog();
                RefreshAllLists();
            }
        }


        private void ci_lbCatalogueItems_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = Catalogue != null ? DragDropEffects.Copy : DragDropEffects.None;
        }

        private void ci_lbCatalogueItems_DragDrop(object sender, DragEventArgs e)
        {
            if (Catalogue == null)
            {

                MessageBox.Show("Select a Catalogue first");
                return;
            }


            bool importTable = e.Data.GetDataPresent(typeof (TableInfo));
            bool importColumnInfo = e.Data.GetDataPresent(typeof (ColumnInfo));

            List<ColumnInfo> toImport = new List<ColumnInfo>();

            if(importColumnInfo)
                toImport.Add((ColumnInfo) e.Data.GetData(typeof(ColumnInfo)));

            if(importTable)
                toImport.AddRange(((TableInfo)e.Data.GetData(typeof(TableInfo))).ColumnInfos.ToArray());
            
            var result = MessageBox.Show("Create CatalogueItems and ExtractionInformation (Core) for the following?" + Environment.NewLine +string.Join("\r\n", toImport),"Create new CatalogueItem and ExtractionInformation?",MessageBoxButtons.YesNoCancel);

            if(result == DialogResult.Yes)
            {
                foreach (ColumnInfo columnInfo in toImport)
                {
                    var ci = new CatalogueItem(Catalogue.Repository, Catalogue, columnInfo.GetRuntimeName());
                    new ExtractionInformation((CatalogueRepository) ci.Repository,ci, columnInfo, columnInfo.Name);
                }

                RefreshAllLists();
            }
            
        }

  
    }
}

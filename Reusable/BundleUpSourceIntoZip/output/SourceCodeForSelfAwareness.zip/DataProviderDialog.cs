using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Windows.Forms;
using ReusableUIComponents;

namespace DatasetLoaderUI
{
    public delegate void OnSaveDataProviderDialog(DataProviderConfigurationControl control, DataProviderDialog dialog);
    
    public partial class DataProviderDialog : BetterToolTipForm
    {
        public OnSaveDataProviderDialog OnSaveDialog;

        public DataProviderDialog()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            OnSaveDialog(Controls[1] as DataProviderConfigurationControl, this);
        }
    }
}

using System; // This file is provided to users for the use of debugging RDMP software ONLY all rights reserved
using System.Data.SqlClient;
using System.Linq;
using System.Windows.Forms;
using CatalogueLibrary.Data;
using CatalogueLibrary.Repositories;
using HIC.Logging;
using ReusableLibraryCode.Checks;
using ReusableLibraryCode.DataAccess;
using ReusableUIComponents;
using ReusableUIComponents.ChecksUI;

namespace CatalogueManager.SimpleDialogs
{
    /// <summary>
    /// Every dataset (Catalogue) can have it's own Logging task and Logging server.  If you have multiple logging servers (e.g. a test logging server and a live logging server). You 
    /// can configure each of these independently.  If you only have one logging server then just set the live logging server. 
    /// 
    /// Once you have set the logging server you should create or select an existing task (e.g. 'Loading Biochemistry' might be a good loging task for Biochemistry dataset).  All datasets
    /// in a given load (see LoadMetadataUI) must share the same logging task so it is worth considering the naming for example you might call the task 'Loading Hospital Data' and another
    /// 'Loading Primary Care Data'.
    /// 
    /// Data Extraction always gets logged under a task called 'Data Extraction' but the server you select here will be the one that it is logged against when the dataset is extracted.
    /// 
    /// You can configure defaults for the logging servers of new datasets through ManageExternalServers dialog (See ManageExternalServers)
    /// </summary>
    public partial class ChooseLoggingTaskDialog : BetterToolTipForm, ICheckNotifier
    {
        private readonly Catalogue _catalogue;

        public ChooseLoggingTaskDialog(Catalogue catalogue)
        {
            _catalogue = catalogue;

            InitializeComponent();

            if (catalogue == null)
                return;

            var servers = ((CatalogueRepository) catalogue.Repository).GetAllObjects<ExternalDatabaseServer>().ToArray();

            ddLoggingServer.Items.AddRange(servers);
            ddTestLoggingServer.Items.AddRange(servers);

            ExternalDatabaseServer liveserver = null;

            if (catalogue.LiveLoggingServer_ID != null)
            {
                liveserver = ddLoggingServer.Items.Cast<ExternalDatabaseServer>()
                    .Single(i => i.ID == (int) catalogue.LiveLoggingServer_ID);

                ddLoggingServer.SelectedItem = liveserver;
            }

            if (catalogue.TestLoggingServer_ID != null)
                ddTestLoggingServer.SelectedItem =
                    ddTestLoggingServer.Items.Cast<ExternalDatabaseServer>()
                        .Single(i => i.ID == (int)catalogue.TestLoggingServer_ID);

            try
            {
                //load data tasks (new architecture)
                //if the catalogue knows its logging server - populate values
                if (liveserver != null)
                {
                    LogManager lm = new LogManager(DataAccessPortal.GetInstance().ExpectServer(liveserver, DataAccessContext.Logging), ProgressLogging.GetInstance(), FatalErrorLogging.GetInstance(), RowErrorLogging.GetInstance());

                    foreach (var t in lm.ListDataTasks())
                        if (!cbxDataLoadTasks.Items.Contains(t))
                            cbxDataLoadTasks.Items.Add(t);
                }

            }
            catch (Exception ex)
            {

                MessageBox.Show("Problem getting the list of DataTasks from the new logging architecture:" + ex.Message);
            }


            if (!string.IsNullOrWhiteSpace(catalogue.LoggingDataTask))
                cbxDataLoadTasks.Text = catalogue.LoggingDataTask;
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            RefreshTasks();
        }

        private void RefreshTasks()
        {
            ExternalDatabaseServer liveserver = ddLoggingServer.SelectedItem as ExternalDatabaseServer;
            var server = DataAccessPortal.GetInstance().ExpectServer(liveserver, DataAccessContext.Logging);

            if (liveserver != null)
            {
                cbxDataLoadTasks.Items.Clear();

                try
                {
                    LogManager lm = new LogManager(server, ProgressLogging.GetInstance(), FatalErrorLogging.GetInstance(), RowErrorLogging.GetInstance());
                    cbxDataLoadTasks.Items.AddRange(lm.ListDataTasks());
                }
                catch (Exception e)
                {
                    ExceptionViewer.Show(e);
                }
            }

        }


        private void cbxDataLoadTasks_SelectedIndexChanged(object sender, EventArgs e)
        {
            _catalogue.LoggingDataTask = (string) cbxDataLoadTasks.SelectedItem;
            _catalogue.SaveToDatabase();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void ddLoggingServer_SelectedIndexChanged(object sender, EventArgs e)
        {
            _catalogue.LiveLoggingServer_ID = ((ExternalDatabaseServer)ddLoggingServer.SelectedItem).ID;
            _catalogue.SaveToDatabase();
            RefreshTasks();
        }

        private void ddTestLoggingServer_SelectedIndexChanged(object sender, EventArgs e)
        {
            _catalogue.TestLoggingServer_ID = ((ExternalDatabaseServer)ddTestLoggingServer.SelectedItem).ID;
            _catalogue.SaveToDatabase();
        }

        private void cbxDataLoadTasks_TextChanged(object sender, EventArgs e)
        {
            if (_catalogue == null)
                return;

            _catalogue.LoggingDataTask = cbxDataLoadTasks.Text;
            _catalogue.SaveToDatabase();
        }

        private void btnCreateNewLoggingTask_Click(object sender, EventArgs e)
        {
            try
            {
                var testServer =  ddTestLoggingServer.SelectedItem as ExternalDatabaseServer;
                var liveServer =  ddLoggingServer.SelectedItem as ExternalDatabaseServer;

                string target = "";

                string toCreate = cbxDataLoadTasks.Text;

                if (liveServer != null)
                    target = liveServer.Server + "." + liveServer.Database;

                if (liveServer != null && testServer != null)
                    target += " and ";

                if(testServer != null)
                    target += testServer.Server + "." + testServer.Database;

                if (string.IsNullOrEmpty(target))
                {

                    MessageBox.Show(
                        "You must select a logging server, if you do not have any logging servers yet, use Diagnostics screen to create one");
                    return;
                }

                var dr = MessageBox.Show("Create a new dataset and new data task called \"" + toCreate + "\" in " + target, "Create new logging task", MessageBoxButtons.YesNo);

                if(dr == DialogResult.Yes)
                {
                    if (liveServer != null)
                    {

                        LoggingDatabaseChecker checker = new LoggingDatabaseChecker(liveServer);
                        checker.Check(this);

                        new LogManager(DataAccessPortal.GetInstance().ExpectServer(liveServer, DataAccessContext.Logging), ProgressLogging.GetInstance(), FatalErrorLogging.GetInstance(), RowErrorLogging.GetInstance())
                            .CreateNewLoggingTaskIfNotExists(toCreate);
                        
                    }

                    if(testServer!= null)
                        new LogManager(DataAccessPortal.GetInstance().ExpectServer(testServer, DataAccessContext.Logging), ProgressLogging.GetInstance(), FatalErrorLogging.GetInstance(), RowErrorLogging.GetInstance())
                            .CreateNewLoggingTaskIfNotExists(toCreate);

                    MessageBox.Show("Done");

                    RefreshTasks();
                }
            }
            catch (Exception exception)
            {
                ExceptionViewer.Show(exception);
            }
        }

        public bool OnCheckPerformed(CheckEventArgs args)
        {

            if (args.ProposedFix != null)
                return MakeChangePopup.ShowYesNoMessageBoxToApplyFix(args.Message, args.ProposedFix);
            else
            {
                //if it is sucessful user doesn't need to be spammed with messages
                if(args.Result == CheckResult.Success)
                    return true;

                //its a warning or an error possibly with an exception attached
                if (args.Ex != null)
                    ExceptionViewer.Show(args.Message,args.Ex);
                else
                    MessageBox.Show(args.Message);

                return false;
            }
        }
    }
}
